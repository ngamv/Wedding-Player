#!/usr/bin/env bash
# Renew Let's Encrypt certificates and reload nginx.
# Run this from cron: 0 3 * * * /path/to/orion-ai/scripts/renew-ssl.sh

set -euo pipefail

COMPOSE_FILE="$(dirname "$0")/../docker-compose.ssl.yml"

echo "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] Renewing TLS certificates..."
docker compose -f "$COMPOSE_FILE" run --rm certbot renew --quiet

echo "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] Reloading nginx..."
docker compose -f "$COMPOSE_FILE" exec nginx nginx -s reload

echo "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] Done."
