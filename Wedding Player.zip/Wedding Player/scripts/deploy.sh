#!/usr/bin/env bash
# =============================================================================
# ORION AI v1.0 — Production deployment script
# Usage:
#   ./scripts/deploy.sh          # HTTP-only (no SSL)
#   ./scripts/deploy.sh --ssl    # HTTPS with Let's Encrypt (requires DOMAIN + ACME_EMAIL in .env)
#   ./scripts/deploy.sh --vapid  # Generate VAPID keys and add to .env
# =============================================================================
set -euo pipefail
COMPOSE_FILE="docker-compose.prod.yml"
ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT_DIR"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'
ok()   { echo -e "${GREEN}✔${NC}  $*"; }
warn() { echo -e "${YELLOW}⚠${NC}  $*"; }
err()  { echo -e "${RED}✖${NC}  $*" >&2; exit 1; }
step() { echo -e "\n${CYAN}▶${NC}  $*"; }

# ─── Pre-flight ──────────────────────────────────────────────────────────────

step "Pre-flight checks"

command -v docker >/dev/null 2>&1 || err "docker not found"
docker compose version >/dev/null 2>&1 || err "docker compose (v2) not found"

if [[ ! -f ".env" ]]; then
  warn ".env not found — copying from .env.example"
  cp .env.example .env
  warn "Edit .env (especially JWT_SECRET) before continuing."
  exit 1
fi

# shellcheck source=/dev/null
source .env

if [[ "${JWT_SECRET:-}" == "changez-cette-valeur-par-une-cle-secrete-longue" || -z "${JWT_SECRET:-}" ]]; then
  err "JWT_SECRET is not set or still has the default value. Run:\n  echo JWT_SECRET=\$(openssl rand -hex 32) >> .env"
fi

ok "Pre-flight passed"

# ─── VAPID key generation ────────────────────────────────────────────────────

generate_vapid() {
  step "Generating VAPID keys"
  if python3 -c "import py_vapid" 2>/dev/null; then
    KEYS=$(python3 - <<'EOF'
from py_vapid import Vapid
v = Vapid()
v.generate_keys()
import base64
priv = base64.urlsafe_b64encode(v.private_key.private_bytes(
    encoding=__import__('cryptography.hazmat.primitives.serialization', fromlist=['Encoding']).Encoding.Raw,
    format=__import__('cryptography.hazmat.primitives.serialization', fromlist=['PrivateFormat']).PrivateFormat.Raw,
    encryption_algorithm=__import__('cryptography.hazmat.primitives.serialization', fromlist=['NoEncryption']).NoEncryption()
)).decode().rstrip('=')
pub = base64.urlsafe_b64encode(v.public_key.public_bytes(
    encoding=__import__('cryptography.hazmat.primitives.serialization', fromlist=['Encoding']).Encoding.X962,
    format=__import__('cryptography.hazmat.primitives.serialization', fromlist=['PublicFormat']).PublicFormat.UncompressedPoint
)).decode().rstrip('=')
print(f"VAPID_PRIVATE_KEY={priv}")
print(f"VAPID_PUBLIC_KEY={pub}")
EOF
)
  else
    warn "py_vapid not installed — using Docker to generate keys"
    KEYS=$(docker run --rm python:3.13-slim sh -c \
      "pip install py-vapid -q && python3 -c \"
from py_vapid import Vapid; import base64, cryptography.hazmat.primitives.serialization as s
v = Vapid(); v.generate_keys()
priv = base64.urlsafe_b64encode(v.private_key.private_bytes(s.Encoding.Raw, s.PrivateFormat.Raw, s.NoEncryption())).decode().rstrip('=')
pub  = base64.urlsafe_b64encode(v.public_key.public_bytes(s.Encoding.X962, s.PublicFormat.UncompressedPoint)).decode().rstrip('=')
print(f'VAPID_PRIVATE_KEY={priv}'); print(f'VAPID_PUBLIC_KEY={pub}')
\"" 2>/dev/null)
  fi

  PRIV=$(echo "$KEYS" | grep VAPID_PRIVATE_KEY | cut -d= -f2-)
  PUB=$(echo "$KEYS"  | grep VAPID_PUBLIC_KEY  | cut -d= -f2-)

  # Update .env (remove old values, append new)
  sed -i '/^VAPID_PRIVATE_KEY=/d' .env
  sed -i '/^VAPID_PUBLIC_KEY=/d'  .env
  echo "VAPID_PRIVATE_KEY=$PRIV" >> .env
  echo "VAPID_PUBLIC_KEY=$PUB"   >> .env

  ok "VAPID keys generated and saved to .env"
  echo "  Private : ${PRIV:0:16}…"
  echo "  Public  : ${PUB:0:32}…"
}

# ─── SSL / Let's Encrypt ─────────────────────────────────────────────────────

deploy_ssl() {
  step "SSL deployment (Let's Encrypt)"
  COMPOSE_FILE="docker-compose.ssl.yml"

  [[ -z "${DOMAIN:-}" ]]     && err "DOMAIN is not set in .env"
  [[ -z "${ACME_EMAIL:-}" ]] && err "ACME_EMAIL is not set in .env"

  ok "Domain: $DOMAIN  —  ACME email: $ACME_EMAIL"

  step "Bringing up nginx (HTTP only) for ACME challenge"
  # Temporarily use HTTP nginx so certbot can reach /.well-known/acme-challenge/
  docker compose -f "$COMPOSE_FILE" up -d nginx

  step "Requesting certificate from Let's Encrypt"
  docker compose -f "$COMPOSE_FILE" run --rm certbot
  ok "Certificate obtained"

  step "Starting full stack with HTTPS"
  docker compose -f "$COMPOSE_FILE" up -d --build
  ok "Stack is up on https://$DOMAIN"

  echo ""
  warn "Auto-renew tip: add this cron on the host (runs weekly):"
  echo "  0 3 * * 0 cd $ROOT_DIR && docker compose -f docker-compose.ssl.yml run --rm certbot renew && docker compose -f docker-compose.ssl.yml exec nginx nginx -s reload"
}

# ─── Main ────────────────────────────────────────────────────────────────────

MODE="http"
for arg in "$@"; do
  case "$arg" in
    --ssl)   MODE="ssl"   ;;
    --vapid) MODE="vapid" ;;
  esac
done

case "$MODE" in
  vapid)
    generate_vapid
    ;;
  ssl)
    generate_vapid
    deploy_ssl
    ;;
  http)
    step "Building and starting ORION AI (HTTP)"
    docker compose -f "$COMPOSE_FILE" up -d --build
    ok "Stack is up!"
    echo ""
    echo "  Dashboard : http://localhost"
    echo "  API docs  : http://localhost/api/docs"
    echo ""
    warn "To enable HTTPS, add DOMAIN and ACME_EMAIL to .env then run: ./scripts/deploy.sh --ssl"
    ;;
esac

step "Done"
