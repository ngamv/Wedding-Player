"""Contrôle ComfyUI pour le Planificateur de tâches Windows ou cron."""
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "apps" / "api"))
from app.openjutsu import preflight


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("workflow", default="color", nargs="?")
    args = parser.parse_args()
    try:
        result = preflight(args.workflow)
        status = 0 if result["nodes_ready"] else 1
    except (ValueError, OSError) as error:
        result = {"workflow": args.workflow, "error": str(error)}
        status = 2
    print(json.dumps({"checked_at": datetime.now(timezone.utc).isoformat(), **result}, ensure_ascii=True))
    return status


if __name__ == "__main__":
    sys.exit(main())
