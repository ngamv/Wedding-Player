#!/usr/bin/env node
/**
 * Branche ORION sur une passerelle LLM compatible OpenAI (Groq, OpenRouter,
 * Together, LiteLLM…) pour les tâches où le modèle local est trop faible.
 *
 * Usage :
 *   node scripts/set-cloud-llm.mjs groq <API_KEY>
 *   node scripts/set-cloud-llm.mjs openrouter <API_KEY>
 *   node scripts/set-cloud-llm.mjs <BASE_URL> <API_KEY> [MODELE]
 *
 * Puis : docker compose -f docker-compose.prod.yml up -d api
 * et dans le skill « Générer une application », choisir le modèle « cloud: ».
 */
import { readFileSync, writeFileSync, existsSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");

// Free tiers that write decent code. Model names change over time — override
// with the third argument if a provider retires one.
const PRESETS = {
  groq: { url: "https://api.groq.com/openai/v1", model: "llama-3.3-70b-versatile" },
  openrouter: { url: "https://openrouter.ai/api/v1", model: "meta-llama/llama-3.3-70b-instruct" },
  together: { url: "https://api.together.xyz/v1", model: "meta-llama/Llama-3.3-70B-Instruct-Turbo" },
  mistral: { url: "https://api.mistral.ai/v1", model: "mistral-large-latest" },
};

const [target, key, modelArg] = process.argv.slice(2);

if (!target || !key) {
  console.error("Usage : node scripts/set-cloud-llm.mjs <groq|openrouter|together|mistral|URL> <API_KEY> [MODELE]");
  console.error("Presets :", Object.keys(PRESETS).join(", "));
  process.exit(1);
}

const preset = PRESETS[target.toLowerCase()];
const baseUrl = preset ? preset.url : target;
const model = modelArg || (preset ? preset.model : null);

if (!/^https:\/\//.test(baseUrl)) {
  console.error(`URL inattendue : ${baseUrl}\nAttendu : un preset ou une URL https://…/v1`);
  process.exit(1);
}
if (!model) {
  console.error("Passerelle personnalisée : précisez le nom du modèle en 3e argument.");
  process.exit(1);
}

const envPath = join(root, ".env");
if (!existsSync(envPath)) {
  console.error(`.env introuvable : ${envPath}`);
  process.exit(1);
}

/** Remplace la ligne KEY=... si elle existe, l'ajoute sinon. */
function setVar(text, name, value) {
  const line = `${name}=${value}`;
  const re = new RegExp(`^${name}=.*$`, "m");
  return re.test(text) ? text.replace(re, line) : `${text.replace(/\n*$/, "\n")}${line}\n`;
}

let text = readFileSync(envPath, "utf8");
text = setVar(text, "OPENAI_BASE_URL", baseUrl);
text = setVar(text, "OPENAI_API_KEY", key);
text = setVar(text, "OPENAI_MODEL", model);
writeFileSync(envPath, text, "utf8");

console.log(`  passerelle : ${baseUrl}`);
console.log(`  modèle     : ${model}`);
console.log(`  clé        : enregistrée (${key.length} caractères)`);
console.log("\nAppliquer :  docker compose -f docker-compose.prod.yml up -d api");
console.log("Puis choisir le modèle « cloud: » dans le skill de génération d'app.");
