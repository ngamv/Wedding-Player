$ErrorActionPreference = 'Stop'
Push-Location -LiteralPath $PSScriptRoot
try {
    $python = @'
from app.openjutsu import preflight
from datetime import datetime, timezone
import json
try:
    result = preflight("color")
except ValueError as error:
    result = {"workflow": "color", "nodes_ready": False, "error": str(error)}
print(json.dumps({"checked_at": datetime.now(timezone.utc).isoformat(), **result}))
'@
    $lines = $python | docker compose exec -T api python -
    if ($LASTEXITCODE -ne 0) {
        Write-Warning 'Diagnostic indisponible : le conteneur API doit etre demarre.'
        return
    }
    $report = $lines | ConvertFrom-Json
    $lines | Set-Content -LiteralPath 'rapport-openjutsu.json' -Encoding utf8
    if ($report.nodes_ready) {
        Write-Host 'OpenJutsu : composants de correction couleur detectes.'
    } elseif ($report.error) {
        Write-Warning $report.error
    } else {
        Write-Warning ('OpenJutsu : noeuds manquants : ' + ($report.missing_nodes -join ', '))
    }
} finally {
    Pop-Location
}
