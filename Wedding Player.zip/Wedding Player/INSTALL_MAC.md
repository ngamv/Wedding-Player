# Installer ORION AI sur Mac Mini (Apple Silicon)

Le Mac Mini est nettement plus rapide que le PC Windows pour ORION : Ollama
utilise le GPU (Metal), donc les réponses IA passent de ~15 s à ~2-3 s.

## 1. Prérequis (à installer une fois)

- **Docker Desktop pour Mac (Apple Silicon)** : https://www.docker.com/products/docker-desktop/
- **Ollama pour Mac** : https://ollama.com/download → puis, dans le Terminal :
  ```bash
  ollama pull qwen2.5:3b
  ```
  (Le Mac Mini peut aussi faire tourner un modèle plus gros et de meilleure
  qualité, ex. `ollama pull qwen2.5:7b`, grâce au GPU.)

## 2. Récupérer le code

Copie le fichier `orion-ai-transfer.bundle` sur le Mac (clé USB / AirDrop /
iCloud), puis dans le Terminal :

```bash
cd ~/Documents
git clone orion-ai-transfer.bundle orion-ai
cd orion-ai
```

## 3. Créer le fichier .env (les secrets ne sont PAS transférés — normal)

```bash
cp .env.example .env
```

Puis édite `.env` (avec TextEdit ou `nano .env`) et renseigne au minimum :
- `JWT_SECRET=` → une longue chaîne aléatoire de ton choix
- `OLLAMA_MODEL=qwen2.5:3b` (ou 7b si tu l'as téléchargé)
- Optionnel : `VERCEL_TOKEN=` (nouveau token, si tu veux le déploiement)
- Optionnel : SMTP si tu veux les emails

> ⚠️ Ne réutilise PAS les anciens tokens du PC Windows : crée-en de nouveaux.

## 4. Démarrer

```bash
docker compose -f docker-compose.prod.yml up -d --build
```

Attends ~1 min (compilation la première fois), puis ouvre : **http://localhost**

## 5. Créer ton compte admin

Le login ayant été retiré, l'accès est direct en tant qu'admin. Si besoin d'un
utilisateur en base, ORION en crée un par défaut au premier appel.

## Notes

- Sur Mac, `host.docker.internal` fonctionne déjà pour joindre Ollama — rien à
  configurer.
- Pour exposer ORION hors du Mac (accès public temporaire) :
  `brew install cloudflared` puis `cloudflared tunnel --url http://localhost:80`.
- Les données (tâches, skills custom, workflows) vivent dans le volume Docker
  `orion_data` — elles restent sur le Mac, indépendantes du PC Windows.
