# ORION AI v1.0

Plateforme d'orchestration multi-agents IA avec 32 agents spécialisés.

## Stack

| Couche | Technologie |
|--------|-------------|
| Frontend | React 18 + Vite + TypeScript + Tailwind |
| Backend | FastAPI (Python 3.11+) |
| IA locale | Ollama (llama3.2, mistral…) |
| Base de données | SQLite (async) |
| Mémoire vectorielle | ChromaDB |

## 30 Agents

| Catégorie | Agents |
|-----------|--------|
| **Core** | Orchestrator, Memory, Router, Logger, Scheduler |
| **SEO** | Audit, Keywords, Content, Backlinks, SERP |
| **Social** | Twitter/X, LinkedIn, Instagram, YouTube, TikTok |
| **Marketing** | Copywriter, Email, Ads, Landing Page, Analytics |
| **Dev** | Code Reviewer, Security, Docs, Tests, DevOps |
| **Data** | Scraper, Parser, Analyzer, Reporter, Visualizer |

## Installation

### Prérequis
- Python 3.11+
- Node.js 20+
- [Ollama](https://ollama.ai) installé et lancé

```bash
# Installer un modèle Ollama
ollama pull llama3.2
```

### Démarrage

**Terminal 1 — API :**
```bash
cd apps/api
python -m venv .venv
.venv\Scripts\activate      # Windows
pip install -r requirements.txt
cp .env.example .env
uvicorn main:app --reload --port 8000
```

**Terminal 2 — Dashboard :**
```bash
cd apps/web
npm install
npm run dev
```

## URLs

| Service | URL |
|---------|-----|
| Dashboard | http://localhost:5173 |
| API | http://localhost:8000 |
| API Docs | http://localhost:8000/docs |

## API Endpoints

```
GET  /agents/          → liste des 32 agents
POST /agents/run       → exécuter une tâche (auto-route ou agent_id)
GET  /tasks/           → historique des tâches
POST /tasks/           → créer et exécuter une tâche
GET  /memory/          → mémoire persistante
GET  /system/health    → santé système + Ollama
GET  /system/stats     → statistiques
```

## Exemple d'utilisation

```bash
# Auto-router — Orion choisit le meilleur agent
curl -X POST http://localhost:8000/agents/run \
  -H "Content-Type: application/json" \
  -d '{"task": "Analyse le SEO de mon site e-commerce"}'

# Agent spécifique
curl -X POST http://localhost:8000/agents/run \
  -H "Content-Type: application/json" \
  -d '{"task": "Écris un tweet viral sur l'\''IA", "agent_id": "social_twitter"}'
```

### Brouillons pour les réseaux sociaux

Le catalogue Agents propose X, Instagram, TikTok, Prospection et Contenu
multicanal. Choisissez un agent et fournissez l’entreprise, l’audience,
l’objectif et les éléments vérifiés à utiliser. Pour les trouver dans l’API,
consultez `GET /agents/`. Vous pouvez les lancer via `POST /agents/run`
avec `task` et `agent_id` (`social_twitter`, `social_instagram`,
`social_tiktok`, `social_prospecting` ou `social_cross_platform`).

Ces cinq agents utilisent le modèle Ollama configuré par ORION et renvoient
du texte à relire. Les métriques, horaires et tendances doivent être étayés
par les éléments fournis dans le brief.

## OpenJutsu dans ORION

Le catalogue reprend les graphes ComfyUI d’[OpenJutsu](https://github.com/D3voz/openjutsu)
au commit `7fe118b`, sous licence MIT. Les quatre nouveaux skills apparaissent
dans **Skills → Intégrations**. Les graphes présents dans le catalogue peuvent
être diagnostiqués par identifiant. ORION peut soumettre la correction couleur
`color`. Les autres modes demandent OpenJutsu pour préparer leurs entrées.

- **ComfyUI** — Démarrez ComfyUI avec VideoHelperSuite, Image Detail Contrast
  et Orion4D_FXMax pour la correction couleur. ORION utilise
  `ORION_COMFYUI_URL`, par défaut `http://127.0.0.1:8188` hors Docker.
  Sous Docker Desktop, le Compose principal utilise
  `http://host.docker.internal:8188`. ComfyUI doit être accessible depuis le conteneur.
- **Workflow ORION** — Dans **Workflows**, créez un workflow avec l’étape
  **OpenJutsu — Correction couleur**. Le corps JSON équivalent pour
  `POST /workflows/` est dans `scripts/openjutsu/correction-couleur.json`.
  Lancez-le avec un nom comme `mariage.mp4`, déjà présent dans ComfyUI/input.
  Consultez ensuite **OpenJutsu — Suivi du rendu** avec le `prompt_id` retourné.
- **MCP** — Avec uv installé, enregistrez le serveur stdio avec
  `codex mcp add orion-openjutsu -- uv run --script "C:/chemin/Wedding Player/apps/api/openjutsu_mcp.py"`.
  Il expose le catalogue, le diagnostic et le suivi en lecture. Configurez
  `ORION_COMFYUI_URL` dans l’environnement du client MCP si nécessaire.
- **Automatisation** — `py -3 scripts/openjutsu-check.py color` écrit un diagnostic
  JSON et renvoie 0 si les nœuds sont présents, 1 s’il en manque, 2 si la
  connexion ou la configuration échoue. Utilisez cette commande dans le
  Planificateur de tâches Windows en définissant le dossier du projet
  comme répertoire de démarrage. Aucun rendu n’est lancé par ce contrôle.

Le diagnostic vérifie les types de nœuds enregistrés, tandis que le rendu
dépend des modèles, fichiers et ressources disponibles dans ComfyUI.

### Démarrage Windows avec Docker Desktop

Dans PowerShell, depuis ce dossier, exécutez `powershell -NoProfile -ExecutionPolicy RemoteSigned -File .\Demarrer-ORION.ps1`.
Le lanceur initialise un fichier `.env` si nécessaire, démarre Docker Compose,
ajoute le workflow pour le compte administrateur initial et ouvre le tableau
de bord (port 8080 pour une nouvelle installation). Il enregistre le dernier
diagnostic couleur dans `rapport-openjutsu.json`.
Ajoutez `-InstallerMCP` pour enregistrer le MCP si Codex CLI et uv sont
installés. Ajoutez `-PlanifierDiagnostic` pour activer le contrôle quotidien
à 09 h, heure locale. Docker et ORION doivent être démarrés au moment du contrôle.
