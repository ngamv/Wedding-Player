# ORION AI v1.0

Plateforme d'orchestration multi-agents IA avec 32 agents spécialisés.

## Stack

| Couche | Technologie |
|--------|-------------|
| Frontend | React 18 + Vite + TypeScript + Tailwind |
| Backend | FastAPI (Python 3.11+) |
| IA locale | Ollama (llama3.2, mistral…) |
| Base de données | SQLite (async) |
| Mémoire vectorielle | ChromaDB |

## 30 Agents

| Catégorie | Agents |
|-----------|--------|
| **Core** | Orchestrator, Memory, Router, Logger, Scheduler |
| **SEO** | Audit, Keywords, Content, Backlinks, SERP |
| **Social** | Twitter/X, LinkedIn, Instagram, YouTube, TikTok |
| **Marketing** | Copywriter, Email, Ads, Landing Page, Analytics |
| **Dev** | Code Reviewer, Security, Docs, Tests, DevOps |
| **Data** | Scraper, Parser, Analyzer, Reporter, Visualizer |

## Installation

### Prérequis
- Python 3.11+
- Node.js 20+
- [Ollama](https://ollama.ai) installé et lancé

```bash
# Installer un modèle Ollama
ollama pull llama3.2
```

### Démarrage

**Terminal 1 — API :**
```bash
cd apps/api
python -m venv .venv
.venv\Scripts\activate      # Windows
pip install -r requirements.txt
cp .env.example .env
uvicorn main:app --reload --port 8000
```

**Terminal 2 — Dashboard :**
```bash
cd apps/web
npm install
npm run dev
```

## URLs

| Service | URL |
|---------|-----|
| Dashboard | http://localhost:5173 |
| API | http://localhost:8000 |
| API Docs | http://localhost:8000/docs |

## API Endpoints

```
GET  /agents/          → liste des 32 agents
POST /agents/run       → exécuter une tâche (auto-route ou agent_id)
GET  /tasks/           → historique des tâches
POST /tasks/           → créer et exécuter une tâche
GET  /memory/          → mémoire persistante
GET  /system/health    → santé système + Ollama
GET  /system/stats     → statistiques
```

## Exemple d'utilisation

```bash
# Auto-router — Orion choisit le meilleur agent
curl -X POST http://localhost:8000/agents/run \
  -H "Content-Type: application/json" \
  -d '{"task": "Analyse le SEO de mon site e-commerce"}'

# Agent spécifique
curl -X POST http://localhost:8000/agents/run \
  -H "Content-Type: application/json" \
  -d '{"task": "Écris un tweet viral sur l'\''IA", "agent_id": "social_twitter"}'
```

### Brouillons pour les réseaux sociaux

Le catalogue Agents propose X, Instagram, TikTok, Prospection et Contenu
multicanal. Choisissez un agent et fournissez l’entreprise, l’audience,
l’objectif et les éléments vérifiés à utiliser. Pour les trouver dans l’API,
consultez `GET /agents/`. Vous pouvez les lancer via `POST /agents/run`
avec `task` et `agent_id` (`social_twitter`, `social_instagram`,
`social_tiktok`, `social_prospecting` ou `social_cross_platform`).

Ces cinq agents utilisent le modèle Ollama configuré par ORION et renvoient
du texte à relire. Les métriques, horaires et tendances doivent être étayés
par les éléments fournis dans le brief.
