#!/usr/bin/env bash
# ORION AI v1.0 — Local development setup
set -euo pipefail

echo "=== ORION AI v1.0 — Local Setup ==="

# .env
if [[ ! -f ".env" ]]; then
  cp .env.example .env
  echo "✔  .env created — edit JWT_SECRET before starting"
fi

# API
echo ""
echo ">>> Installing API dependencies..."
cd apps/api
python3 -m venv .venv
# shellcheck disable=SC1091
source .venv/bin/activate 2>/dev/null || source .venv/Scripts/activate 2>/dev/null || true
pip install --quiet -r requirements.txt
echo "✔  API ready"

# Web
echo ""
echo ">>> Installing Web dependencies..."
cd ../web
npm ci --silent
echo "✔  Web ready"

cd ../..
echo ""
echo "=== Setup complete ==="
echo ""
echo "  Start API  :  cd apps/api && source .venv/bin/activate && uvicorn main:app --reload --port 8000"
echo "  Start Web  :  cd apps/web && npm run dev"
echo "  API docs   :  http://localhost:8000/docs"
echo "  Dashboard  :  http://localhost:5173"
echo ""
echo "  Production :  ./scripts/deploy.sh"
echo "  HTTPS      :  ./scripts/deploy.sh --ssl   (set DOMAIN + ACME_EMAIL in .env first)"
echo "  VAPID keys :  ./scripts/deploy.sh --vapid"
