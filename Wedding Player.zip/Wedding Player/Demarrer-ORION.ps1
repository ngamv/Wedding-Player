param([switch]$InstallerMCP, [switch]$PlanifierDiagnostic)

$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
    throw 'Installez Docker Desktop, puis relancez PowerShell.'
}
docker info --format '{{.ServerVersion}}' 2>$null
if ($LASTEXITCODE -ne 0) {
    throw 'Ouvrez Docker Desktop et attendez le demarrage du moteur.'
}

function New-HexSecret([int]$Size) {
    $bytes = New-Object byte[] $Size
    $generator = [Security.Cryptography.RandomNumberGenerator]::Create()
    try { $generator.GetBytes($bytes) } finally { $generator.Dispose() }
    return [BitConverter]::ToString($bytes).Replace('-', '').ToLowerInvariant()
}

$newSetup = -not (Test-Path -LiteralPath '.env')
if ($newSetup) {
    $secret = New-HexSecret 32
    $password = New-HexSecret 18
    @(
        "JWT_SECRET=$secret"
        "ADMIN_PASSWORD=$password"
        'PORT=8080'
        'ORION_BIND_ADDRESS=127.0.0.1'
        'OLLAMA_BASE_URL=http://host.docker.internal:11434'
        'ORION_COMFYUI_URL=http://host.docker.internal:8188'
    ) | Set-Content -LiteralPath '.env' -Encoding ascii
}

$env:ORION_BIND_ADDRESS = '127.0.0.1'
docker compose up -d --build --wait --wait-timeout 180
if ($LASTEXITCODE -ne 0) {
    docker compose ps
    throw 'ORION ne demarre pas. Voir les details avec docker compose logs api.'
}

$endpoint = docker compose port web 80
if ($LASTEXITCODE -ne 0 -or "$endpoint" -notmatch ':(\d+)$') {
    throw 'Port du tableau de bord introuvable. Lancez docker compose ps.'
}
$base = "http://127.0.0.1:$($Matches[1])"
$health = Invoke-RestMethod -Uri "$base/api/system/health" -TimeoutSec 20
Write-Host "ORION : $base"
Write-Host "Ollama connecte : $($health.ollama)"
if ($newSetup) { Write-Host 'Identifiant : admin. Mot de passe : valeur ADMIN_PASSWORD dans le fichier .env.' }

$adminLine = Get-Content -LiteralPath '.env' | Where-Object { $_ -match '^ADMIN_PASSWORD=[a-f0-9]{36}$' } | Select-Object -First 1
if ($adminLine) {
    try {
        $login = Invoke-RestMethod -Method Post -Uri "$base/api/auth/login" -Body @{
            username = 'admin'
            password = $adminLine.Substring(15)
        } -TimeoutSec 20
        $headers = @{Authorization = "Bearer $($login.access_token)"}
        $template = Get-Content -LiteralPath 'scripts/openjutsu/correction-couleur.json' -Raw
        $name = ($template | ConvertFrom-Json).name
        $workflows = Invoke-RestMethod -Uri "$base/api/workflows/" -Headers $headers -TimeoutSec 20
        if (-not ($workflows | Where-Object { $_.name -eq $name })) {
            $null = Invoke-RestMethod -Method Post -Uri "$base/api/workflows/" -Headers $headers -Body $template -ContentType 'application/json' -TimeoutSec 20
        }
        Write-Host "Workflow ORION : $name"
    } catch {
        Write-Warning 'Creation automatique du workflow indisponible. Ajoutez le skill OpenJutsu - Correction couleur dans Workflows.'
    }
}

& (Join-Path $PSScriptRoot 'Verifier-OpenJutsu.ps1')
if ($InstallerMCP) {
    if (-not (Get-Command codex -ErrorAction SilentlyContinue) -or -not (Get-Command uv -ErrorAction SilentlyContinue)) {
        Write-Warning 'Installez les commandes codex et uv pour enregistrer le MCP.'
    } else {
        codex mcp get orion-openjutsu 2>$null | Out-Null
        if ($LASTEXITCODE -ne 0) {
            codex mcp add orion-openjutsu -- uv run --script (Join-Path $PSScriptRoot 'apps/api/openjutsu_mcp.py')
            if ($LASTEXITCODE -ne 0) { Write-Warning 'Enregistrement MCP en echec.' }
        }
    }
}
if ($PlanifierDiagnostic) {
    $diagnostic = Join-Path $PSScriptRoot 'Verifier-OpenJutsu.ps1'
    $taskName = 'ORION - Diagnostic OpenJutsu'
    if (-not (Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue)) {
        $action = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument ('-NoProfile -ExecutionPolicy RemoteSigned -File "{0}"' -f $diagnostic) -WorkingDirectory $PSScriptRoot
        $trigger = New-ScheduledTaskTrigger -Daily -At 9am
        Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Description 'Diagnostic ComfyUI local et rapport JSON' | Out-Null
        Write-Host 'Diagnostic planifie tous les jours a 09:00, heure locale.'
    }
}
Start-Process $base
