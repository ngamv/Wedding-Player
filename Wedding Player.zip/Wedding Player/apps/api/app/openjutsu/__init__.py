"""Adaptateur ORION pour les graphes ComfyUI d’OpenJutsu."""
import json
import os
from pathlib import Path, PurePosixPath
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
from urllib.request import HTTPRedirectHandler, Request, build_opener
from uuid import UUID

GRAPHS = Path(__file__).resolve().parent / "graphs"
UPSTREAM = "7fe118bb5a61fcfac0148e1bfea3dd29884dbf26"


class LocalRequestHandler(HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None


def request(path: str, body: dict | None = None) -> dict:
    base = os.environ.get("ORION_COMFYUI_URL", "http://127.0.0.1:8188").rstrip("/")
    url = urlsplit(base)
    if url.scheme not in ("http", "https") or not url.hostname or url.username is not None or url.path or url.query or url.fragment:
        raise ValueError("ORION_COMFYUI_URL doit être une origine HTTP(S) sans identifiants.")
    payload = None if body is None else json.dumps(body).encode()
    req = Request(base + path, data=payload, headers={"Content-Type": "application/json"})
    try:
        with build_opener(LocalRequestHandler()).open(req, timeout=20) as response:
            result = json.load(response)
    except HTTPError as error:
        raise ValueError(f"ComfyUI a répondu HTTP {error.code}. Consultez le journal ComfyUI.") from error
    except (URLError, TimeoutError) as error:
        raise ValueError("ComfyUI ne répond pas. Vérifiez ORION_COMFYUI_URL et démarrez le service.") from error
    if not isinstance(result, dict):
        raise ValueError("Réponse ComfyUI invalide.")
    return result


def catalog() -> dict:
    return {
        "source_commit": UPSTREAM,
        "workflows": [
            {"id": name, "execution_orion": name == "color"}
            for name in sorted(path.name.removesuffix(".api.json") for path in GRAPHS.glob("*.api.json"))
        ],
    }


def load_graph(workflow: str) -> dict:
    ids = {entry["id"] for entry in catalog()["workflows"]}
    if workflow not in ids:
        raise ValueError("Workflow OpenJutsu inconnu. Consultez le catalogue.")
    return json.loads((GRAPHS / f"{workflow}.api.json").read_text(encoding="utf-8"))


def preflight(workflow: str) -> dict:
    graph = load_graph(workflow)
    available = request("/object_info")
    required = {node["class_type"] for node in graph.values()}
    missing = sorted(required - available.keys())
    return {"workflow": workflow, "nodes_ready": not missing, "missing_nodes": missing}


def queue_color(video: str) -> dict:
    # ComfyUI resolves names inside input/. ORION accepts no local OS path or URL.
    if not isinstance(video, str) or not video or len(video) > 240:
        raise ValueError("Indiquez un fichier existant dans ComfyUI/input.")
    parts = video.split("/")
    if any(part in ("", ".", "..") for part in parts) or any(
        not (ch.isalnum() or ch in " _-./()") for ch in video
    ) or PurePosixPath(video).suffix.lower() not in (".mp4", ".mov", ".webm", ".mkv", ".avi"):
        raise ValueError("Indiquez un nom de vidéo relatif à ComfyUI/input, par exemple mariage.mp4.")
    readiness = preflight("color")
    if not readiness["nodes_ready"]:
        raise ValueError("Nœuds ComfyUI manquants : " + ", ".join(readiness["missing_nodes"]))
    graph = load_graph("color")
    graph["1"]["inputs"]["video"] = video
    graph["4"]["inputs"]["filename_prefix"] = "ORION/OpenJutsu"
    result = request("/prompt", {"prompt": graph})
    prompt_id = result.get("prompt_id")
    if not isinstance(prompt_id, str):
        raise ValueError("ComfyUI n’a pas confirmé la mise en file.")
    return {"prompt_id": str(UUID(prompt_id)), "status": "queued"}


def render_status(prompt_id: str) -> dict:
    ident = str(UUID(prompt_id))
    result = request(f"/history/{ident}").get(ident)
    if not result:
        return {"prompt_id": ident, "status": "no_history"}
    state = result.get("status", {}).get("status_str", "unknown")
    files = [
        {key: file.get(key) for key in ("filename", "subfolder", "type")}
        for output in result.get("outputs", {}).values()
        for kind in ("gifs", "videos", "images")
        for file in output.get(kind, [])
    ]
    return {"prompt_id": ident, "status": state, "files": files}
