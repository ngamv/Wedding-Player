"""Async email notifier using aiosmtplib (optional — graceful no-op if not configured)."""
import logging
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from app.config import settings

log = logging.getLogger("orion.notifier")


async def send_email(to: str, subject: str, body_html: str) -> bool:
    """Send an email. Returns True on success, False if SMTP not configured."""
    if not settings.smtp_host:
        log.debug("SMTP not configured — notification skipped")
        return False
    try:
        import aiosmtplib

        msg = MIMEMultipart("alternative")
        msg["From"] = settings.smtp_from or settings.smtp_user
        msg["To"] = to
        msg["Subject"] = subject
        msg.attach(MIMEText(body_html, "html", "utf-8"))

        await aiosmtplib.send(
            msg,
            hostname=settings.smtp_host,
            port=settings.smtp_port,
            username=settings.smtp_user or None,
            password=settings.smtp_password or None,
            use_tls=settings.smtp_tls,
        )
        log.info("Email sent to %s: %s", to, subject)
        return True
    except Exception as exc:
        log.warning("Failed to send email to %s: %s", to, exc)
        return False


async def notify_task_failed(user_email: str, task_id: int, title: str, error: str) -> bool:
    subject = f"[ORION AI] Tâche #{task_id} échouée"
    body = f"""
<html><body style="font-family:sans-serif;background:#0f1117;color:#e0e0e0;padding:32px">
<div style="max-width:560px;margin:0 auto;background:#1a1d2e;border-radius:12px;padding:32px;border:1px solid #2a2d3e">
  <h2 style="color:#e74c3c;margin-top:0">⚠ Tâche échouée</h2>
  <p><strong>Tâche :</strong> {title} (#{task_id})</p>
  <p><strong>Erreur :</strong></p>
  <pre style="background:#0f1117;padding:12px;border-radius:8px;overflow:auto;font-size:13px">{error[:500]}</pre>
  <p style="color:#888;font-size:12px;margin-top:24px">ORION AI — Plateforme multi-agents</p>
</div>
</body></html>
"""
    return await send_email(user_email, subject, body)


async def notify_task_completed(user_email: str, task_id: int, title: str) -> bool:
    subject = f"[ORION AI] Tâche #{task_id} terminée"
    body = f"""
<html><body style="font-family:sans-serif;background:#0f1117;color:#e0e0e0;padding:32px">
<div style="max-width:560px;margin:0 auto;background:#1a1d2e;border-radius:12px;padding:32px;border:1px solid #2a2d3e">
  <h2 style="color:#2ecc71;margin-top:0">✓ Tâche terminée</h2>
  <p><strong>Tâche :</strong> {title} (#{task_id})</p>
  <p style="color:#888;font-size:12px;margin-top:24px">ORION AI — Plateforme multi-agents</p>
</div>
</body></html>
"""
    return await send_email(user_email, subject, body)
