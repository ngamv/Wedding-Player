from datetime import datetime, timedelta
from typing import Any
import bcrypt
import jwt
from jwt import PyJWTError
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.config import settings
from app.database import get_session
from app.models import User

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/auth/login", auto_error=False)

TOKEN_EXPIRE_HOURS = 72
ALGORITHM = "HS256"


def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()


def verify_password(plain: str, hashed: str) -> bool:
    return bcrypt.checkpw(plain.encode(), hashed.encode())


def create_token(data: dict[str, Any]) -> str:
    payload = data.copy()
    payload["exp"] = datetime.utcnow() + timedelta(hours=TOKEN_EXPIRE_HOURS)
    return jwt.encode(payload, settings.jwt_secret, algorithm=ALGORITHM)


def decode_token(token: str) -> dict | None:
    try:
        payload = jwt.decode(token, settings.jwt_secret, algorithms=[ALGORITHM])
        return payload if payload.get("sub") else None
    except PyJWTError:
        return None


async def _get_default_user(db: AsyncSession) -> User:
    """Single-user mode: return the default admin, creating it if absent."""
    result = await db.execute(select(User).where(User.role == "admin").order_by(User.id))
    user = result.scalars().first()
    if user is None:
        result = await db.execute(select(User).order_by(User.id))
        user = result.scalars().first()
    if user is None:
        user = User(
            username="admin",
            email="admin@orion.ai",
            hashed_password=hash_password(_bootstrap_admin_password()),
            role="admin",
            is_active=True,
        )
        db.add(user)
        await db.commit()
        await db.refresh(user)
    return user


def _bootstrap_admin_password() -> str:
    """Password for the very first admin account.

    A hardcoded default would ship the same credentials to every deployment,
    so an unset ADMIN_PASSWORD yields a random one, printed once so the
    operator can retrieve it from the startup logs.
    """
    if settings.admin_password:
        return settings.admin_password
    import logging
    import secrets
    pwd = secrets.token_urlsafe(16)
    logging.getLogger("orion.auth").warning(
        "Compte admin cree avec un mot de passe genere : %s "
        "(definissez ADMIN_PASSWORD pour en choisir un)", pwd,
    )
    return pwd


async def get_current_user(
    token: str | None = Depends(oauth2_scheme),
    db: AsyncSession = Depends(get_session),
) -> User:
    if token:
        try:
            payload = jwt.decode(token, settings.jwt_secret, algorithms=[ALGORITHM])
            user_id = payload.get("sub")
            if user_id is not None:
                result = await db.execute(select(User).where(User.id == int(user_id)))
                user = result.scalar_one_or_none()
                if user is not None and user.is_active:
                    return user
        except PyJWTError:
            pass

    # No usable token: refuse, unless the deployment opted into single-user mode.
    if settings.auth_enabled:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentification requise",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return await _get_default_user(db)


async def require_admin(current_user: User = Depends(get_current_user)) -> User:
    if current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Réservé aux administrateurs")
    return current_user


async def require_not_readonly(current_user: User = Depends(get_current_user)) -> User:
    if current_user.role == "readonly":
        raise HTTPException(status_code=403, detail="Accès en lecture seule")
    return current_user
