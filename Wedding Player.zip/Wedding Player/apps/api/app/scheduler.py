"""APScheduler wrapper — starts/stops with the FastAPI lifespan."""
import logging
from datetime import datetime, timedelta, timezone

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger  # used by user-defined jobs
from apscheduler.triggers.interval import IntervalTrigger

log = logging.getLogger("orion.scheduler")
_scheduler = AsyncIOScheduler(timezone="UTC")

# A nightly cron never fires on a desktop that is powered off at night, so
# backups run on a rolling interval and once shortly after every startup.
BACKUP_INTERVAL_HOURS = 6
BACKUP_STARTUP_DELAY_SECONDS = 60


def start() -> None:
    _register_backup_job()
    _scheduler.start()
    log.info("Scheduler started")


def _register_backup_job() -> None:
    """Back up every 6 h, plus once a minute after boot."""
    _scheduler.add_job(
        _run_backup,
        IntervalTrigger(hours=BACKUP_INTERVAL_HOURS),
        id="periodic_backup",
        replace_existing=True,
    )
    _scheduler.add_job(
        _run_backup,
        "date",
        run_date=datetime.now(timezone.utc) + timedelta(seconds=BACKUP_STARTUP_DELAY_SECONDS),
        id="startup_backup",
        replace_existing=True,
    )
    log.info("Backup jobs registered (every %sh + %ss after startup)",
             BACKUP_INTERVAL_HOURS, BACKUP_STARTUP_DELAY_SECONDS)


async def _run_backup() -> None:
    import shutil
    import os
    from app.config import settings

    db_url = settings.database_url
    db_path = db_url.replace("sqlite+aiosqlite:///", "").replace("sqlite:///", "")
    if not os.path.exists(db_path):
        log.warning("Backup skipped: DB not found at %s", db_path)
        return

    backup_dir = settings.backup_dir
    os.makedirs(backup_dir, exist_ok=True)

    # Repeated restarts would otherwise pile up near-identical copies.
    now = datetime.now(timezone.utc)
    recent = [f for f in os.listdir(backup_dir)
              if f.startswith("orion_")
              and now.timestamp() - os.path.getmtime(os.path.join(backup_dir, f)) < 1800]
    if recent:
        log.info("Backup skipped: a copy was made less than 30 min ago")
        return

    dest = os.path.join(backup_dir, f"orion_{now.strftime('%Y%m%d_%H%M%S')}.db")
    shutil.copy2(db_path, dest)
    log.info("Backup created: %s (%s KB)", dest, round(os.path.getsize(dest) / 1024, 1))

    # Prune old backups
    cutoff = now - timedelta(days=settings.backup_keep_days)
    for f in os.listdir(backup_dir):
        fp = os.path.join(backup_dir, f)
        if os.path.isfile(fp) and os.path.getmtime(fp) < cutoff.timestamp():
            os.remove(fp)
            log.info("Pruned old backup: %s", fp)


def shutdown() -> None:
    _scheduler.shutdown(wait=False)
    log.info("Scheduler stopped")


async def add_job(task, user_email: str) -> None:
    """Register or replace a job for a ScheduledTask model instance."""
    job_id = f"scheduled_{task.id}"
    parts = task.cron.strip().split()
    trigger = CronTrigger(
        minute=parts[0],
        hour=parts[1],
        day=parts[2],
        month=parts[3],
        day_of_week=parts[4],
    )
    _scheduler.add_job(
        _run_scheduled_task,
        trigger=trigger,
        id=job_id,
        replace_existing=True,
        kwargs={"task_id": task.id, "agent_id": task.agent_id, "prompt": task.prompt, "user_email": user_email},
    )
    log.info("Scheduled job %s (cron: %s)", job_id, task.cron)


async def remove_job(task_id: int) -> None:
    job_id = f"scheduled_{task_id}"
    if _scheduler.get_job(job_id):
        _scheduler.remove_job(job_id)
        log.info("Removed job %s", job_id)


async def _run_workflow_by_id(db, wf_id: int, task_text: str) -> dict:
    """Exécute un workflow complet (agents et skills) depuis une tâche planifiée."""
    from sqlalchemy import select
    from app.models import Workflow
    from app.agents import AGENT_REGISTRY
    from app.routes.workflows import _run_skill_step

    result = await db.execute(select(Workflow).where(Workflow.id == wf_id))
    wf = result.scalar_one_or_none()
    if not wf:
        raise RuntimeError(f"Workflow #{wf_id} introuvable")

    current, steps_out = task_text, []
    for step in wf.steps:
        sid = step["agent_id"]
        label = step.get("label") or sid
        if sid.startswith("skill:"):
            text = await _run_skill_step(sid.removeprefix("skill:"), current)
        else:
            agent = AGENT_REGISTRY.get(sid)
            if not agent:
                raise RuntimeError(f"Agent {sid} introuvable")
            out = await agent.run(current)
            text = out.get("result", str(out))
        steps_out.append({"label": label, "result": text})
        if step.get("pass_output", True):
            current = f"{task_text}\n\n[Résultat de l'étape précédente ({label})]:\n{text}"
    return {"workflow": wf.name, "steps": steps_out, "result": steps_out[-1]["result"] if steps_out else ""}


async def _run_scheduled_task(task_id: int, agent_id: str, prompt: str, user_email: str) -> None:
    """Execute a scheduled task and update last_run_at."""
    from datetime import datetime
    from app.orchestrator import route_and_run
    from app.database import SessionLocal
    from app.models import ScheduledTask, Task, TaskStatus
    from app.notifier import notify_task_failed

    log.info("Running scheduled task #%s", task_id)
    async with SessionLocal() as db:
        from sqlalchemy import select
        result = await db.execute(select(ScheduledTask).where(ScheduledTask.id == task_id))
        st = result.scalar_one_or_none()
        if not st:
            return

        task = Task(
            user_id=st.user_id,
            title=f"[Planifiée] {st.name}",
            agent_id=agent_id,
            status=TaskStatus.running,
        )
        db.add(task)
        await db.commit()
        await db.refresh(task)

        try:
            if agent_id.startswith("workflow:"):
                output = await _run_workflow_by_id(db, int(agent_id.removeprefix("workflow:")), prompt)
            elif agent_id.startswith("skill:"):
                from app.routes.workflows import _run_skill_step
                output = {"result": await _run_skill_step(agent_id.removeprefix("skill:"), prompt)}
            else:
                output = await route_and_run(prompt, agent_id, None)
            task.status = TaskStatus.completed
            task.output_data = output
        except Exception as exc:
            task.status = TaskStatus.failed
            task.output_data = {"error": str(exc)}
            await notify_task_failed(user_email, task.id, task.title, str(exc))

        st.last_run_at = datetime.utcnow()
        await db.commit()
