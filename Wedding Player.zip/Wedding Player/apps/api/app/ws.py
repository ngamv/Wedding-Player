"""WebSocket connection manager — broadcasts task/workflow events to connected clients."""
import json
from fastapi import WebSocket


class ConnectionManager:
    def __init__(self):
        self._connections: dict[int, list[WebSocket]] = {}  # user_id → sockets
        self._user_info: dict[int, str] = {}  # user_id → username

    async def connect(self, websocket: WebSocket, user_id: int, username: str = ""):
        await websocket.accept()
        first_connection = user_id not in self._connections or not self._connections[user_id]
        self._connections.setdefault(user_id, []).append(websocket)
        self._user_info[user_id] = username or str(user_id)
        if first_connection:
            await self.broadcast("user.joined", {"user_id": user_id, "username": self._user_info[user_id]})

    def disconnect(self, websocket: WebSocket, user_id: int):
        conns = self._connections.get(user_id, [])
        if websocket in conns:
            conns.remove(websocket)
        if not self._connections.get(user_id):
            self._user_info.pop(user_id, None)
            # Schedule broadcast outside — caller must await after disconnect if needed

    async def disconnect_and_broadcast(self, websocket: WebSocket, user_id: int):
        self.disconnect(websocket, user_id)
        if not self._connections.get(user_id):
            await self.broadcast("user.left", {"user_id": user_id})

    def connected_users(self) -> list[dict]:
        return [
            {"user_id": uid, "username": self._user_info.get(uid, str(uid))}
            for uid, sockets in self._connections.items()
            if sockets
        ]

    async def send(self, user_id: int, event: str, data: dict):
        payload = json.dumps({"event": event, "data": data})
        dead = []
        for ws in self._connections.get(user_id, []):
            try:
                await ws.send_text(payload)
            except Exception:
                dead.append(ws)
        for ws in dead:
            self.disconnect(ws, user_id)

    async def broadcast(self, event: str, data: dict):
        payload = json.dumps({"event": event, "data": data})
        for user_id in list(self._connections):
            dead = []
            for ws in self._connections[user_id]:
                try:
                    await ws.send_text(payload)
                except Exception:
                    dead.append(ws)
            for ws in dead:
                self.disconnect(ws, user_id)


manager = ConnectionManager()
