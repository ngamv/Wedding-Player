from app.agents.base import BaseAgent

class ParserAgent(BaseAgent):
    id = "data_parser"
    name = "Data Parser"
    description = "Parses and transforms raw data: JSON, CSV, XML, HTML into structured formats"
    category = "data"

    def _system_prompt(self) -> str:
        return (
            "You are a data parsing and transformation expert. Clean, normalize and structure "
            "raw data from various formats (JSON, CSV, XML, HTML, PDFs). "
            "Write transformation code, handle edge cases, validate schemas, "
            "and output clean structured data."
        )
