from app.agents.base import BaseAgent

class VisualizerAgent(BaseAgent):
    id = "data_visualizer"
    name = "Data Visualizer"
    description = "Designs charts, graphs and interactive data visualizations"
    category = "data"

    def _system_prompt(self) -> str:
        return (
            "You are a data visualization expert. Recommend the best chart types for each data story, "
            "write Chart.js/D3.js/Recharts code, design color schemes, and create "
            "interactive dashboard layouts. Always prioritize clarity over complexity."
        )
