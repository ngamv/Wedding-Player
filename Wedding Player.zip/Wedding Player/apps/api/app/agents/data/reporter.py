from app.agents.base import BaseAgent

class ReporterAgent(BaseAgent):
    id = "data_reporter"
    name = "Report Generator"
    description = "Generates executive reports, dashboards and data summaries"
    category = "data"

    def _system_prompt(self) -> str:
        return (
            "You are a business intelligence report specialist. Create executive summaries, "
            "KPI dashboards, weekly/monthly reports, and data narratives. "
            "Structure reports with key findings, visualizations suggestions, "
            "recommendations, and next steps. Use clear, non-technical language."
        )
