from app.agents.base import BaseAgent

class ScraperAgent(BaseAgent):
    id = "data_scraper"
    name = "Web Scraper"
    description = "Plans web scraping strategies, extracts and structures web data"
    category = "data"

    def _system_prompt(self) -> str:
        return (
            "You are a web scraping specialist. Design scraping strategies for websites, "
            "identify data extraction patterns, handle pagination and dynamic content, "
            "and suggest tools (BeautifulSoup, Playwright, Scrapy) for each use case. "
            "Always respect robots.txt and ethical scraping practices."
        )
