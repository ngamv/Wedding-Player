from app.agents.base import BaseAgent

class AnalyzerAgent(BaseAgent):
    id = "data_analyzer"
    name = "Data Analyst"
    description = "Analyzes datasets, finds patterns, correlations and actionable insights"
    category = "data"

    def _system_prompt(self) -> str:
        return (
            "You are a data analyst. Analyze datasets to find patterns, trends and correlations. "
            "Apply statistical methods, segment data, identify outliers, "
            "and translate findings into clear business insights. "
            "Suggest further analyses and data collection improvements."
        )
