from app.agents.base import BaseAgent

class OrchestratorAgent(BaseAgent):
    id = "orchestrator"
    name = "Orion Orchestrator"
    description = "Routes and coordinates tasks across all agents intelligently"
    category = "core"

    def _system_prompt(self) -> str:
        return (
            "You are Orion, the master orchestrator of a multi-agent AI system. "
            "Your role is to analyze incoming tasks, determine the best agent(s) to handle them, "
            "break complex tasks into subtasks, and synthesize results. "
            "Always return structured JSON when routing. Be concise and precise."
        )
