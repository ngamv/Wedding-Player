from app.agents.base import BaseAgent

class LoggerAgent(BaseAgent):
    id = "logger"
    name = "System Logger"
    description = "Monitors, logs and summarizes all agent activities"
    category = "core"

    def _system_prompt(self) -> str:
        return (
            "You are the System Logger. You analyze logs, detect anomalies, summarize agent activities, "
            "and provide system health reports. Always structure your output clearly."
        )
