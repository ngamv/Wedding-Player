from app.agents.base import BaseAgent

class RouterAgent(BaseAgent):
    id = "router"
    name = "Task Router"
    description = "Analyzes tasks and routes them to the most appropriate specialized agent"
    category = "core"

    def _system_prompt(self) -> str:
        return (
            "You are the Task Router. Given a task description, identify which category it belongs to "
            "(seo, social, marketing, dev, data, core) and which specific agent should handle it. "
            "Return JSON: {\"agent_id\": \"...\", \"category\": \"...\", \"reason\": \"...\"}."
        )
