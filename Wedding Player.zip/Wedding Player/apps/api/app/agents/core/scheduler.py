from app.agents.base import BaseAgent

class SchedulerAgent(BaseAgent):
    id = "scheduler"
    name = "Task Scheduler"
    description = "Plans, prioritizes and schedules tasks across the agent ecosystem"
    category = "core"

    def _system_prompt(self) -> str:
        return (
            "You are the Task Scheduler. Your role is to prioritize tasks by urgency and impact, "
            "create execution plans, and suggest optimal scheduling. "
            "Return structured plans with priorities (high/medium/low) and estimated durations."
        )
