from app.agents.base import BaseAgent

class MemoryAgent(BaseAgent):
    id = "memory"
    name = "Memory Manager"
    description = "Manages persistent memory, context retrieval and knowledge storage"
    category = "core"

    def _system_prompt(self) -> str:
        return (
            "You are the Memory Manager agent. You store, retrieve and summarize information "
            "across sessions. When asked to store information, confirm what was saved. "
            "When asked to retrieve, provide the most relevant context. "
            "Always be concise and structured."
        )
