import json
import re
from abc import ABC, abstractmethod
from typing import Any

from app import ollama

# Skills utilisables par les agents pendant leur raisonnement.
# Exclus : skills LLM (récursion coûteuse) et skills à effets de bord
# (send_email, publish_post, deploy_vercel) — réservés aux workflows explicites.
AGENT_TOOL_SLUGS = (
    "web_search", "scrape_url", "count_tokens", "format_date", "word_count",
    "hash_text", "base64", "regex_extract", "calculate", "seo_audit", "seo_keywords",
)

MAX_TOOL_CALLS = 3

_tool_re = re.compile(r"^\s*OUTIL\s*:\s*([a-z_]+)\s*(\{.*\})?\s*$", re.DOTALL)


def _tool_catalog(tool_slugs: tuple[str, ...]) -> str:
    from app.routes.skills import BUILTIN_SKILLS
    lines = []
    for slug in tool_slugs:
        spec = BUILTIN_SKILLS.get(slug)
        if not spec:
            continue
        params = ", ".join(p["name"] for p in spec.get("params", []) if p.get("required"))
        lines.append(f"- {slug}({params}) : {spec['description']}")
    return "\n".join(lines)


def _tools_instructions(tool_slugs: tuple[str, ...]) -> str:
    return (
        "\n\nRÈGLE IMPORTANTE — OUTILS. Tu disposes d'outils fiables. "
        "Si la tâche implique un calcul, une recherche d'information récente, une URL à analyser, "
        "un comptage ou une conversion, tu DOIS utiliser l'outil correspondant au lieu de deviner : "
        "ta première réponse doit alors être UNIQUEMENT cette ligne, rien d'autre :\n"
        'OUTIL: nom_outil {"param": "valeur"}\n'
        "Exemple — tâche « combien font 12*8+5 ? » → réponse : "
        'OUTIL: calculate {"expression": "12*8+5"}\n'
        "Le résultat te sera renvoyé et tu formuleras ensuite ta réponse finale (sans le mot OUTIL).\n"
        f"Outils disponibles :\n{_tool_catalog(tool_slugs)}"
    )


async def _run_tool(slug: str, params: dict) -> str:
    import inspect
    from app.routes.skills import BUILTIN_RUNNERS
    runner = BUILTIN_RUNNERS[slug]
    if inspect.iscoroutinefunction(runner):
        return await runner(params)
    return runner(params)


class BaseAgent(ABC):
    id: str
    name: str
    description: str
    category: str
    model: str | None = None
    tool_slugs = AGENT_TOOL_SLUGS

    async def run(self, task: str, context: dict | None = None) -> dict[str, Any]:
        messages = self._build_messages(task, context or {})
        tools_used: list[dict] = []

        for _ in range(MAX_TOOL_CALLS + 1):
            response = await ollama.chat(messages, self.model)
            match = _tool_re.match(response.strip()) if self.tool_slugs else None
            if not match or len(tools_used) >= MAX_TOOL_CALLS:
                out: dict[str, Any] = {"agent": self.id, "result": response, "task": task}
                if tools_used:
                    out["tools_used"] = tools_used
                return out

            slug = match.group(1)
            try:
                params = json.loads(match.group(2)) if match.group(2) else {}
            except json.JSONDecodeError:
                params = {}
            if slug not in self.tool_slugs:
                messages.append({"role": "assistant", "content": response})
                messages.append({"role": "user", "content":
                                 f"L'outil « {slug} » n'existe pas. Réponds directement."})
                continue
            try:
                result = await _run_tool(slug, params)
            except Exception as exc:
                result = f"Erreur de l'outil : {exc}"
            tools_used.append({"tool": slug, "params": params, "result": str(result)[:500]})
            messages.append({"role": "assistant", "content": response})
            messages.append({"role": "user", "content":
                             f"Résultat de {slug} :\n{str(result)[:2000]}\n\n"
                             "Utilise ce résultat pour répondre à la tâche initiale."})

        return {"agent": self.id, "result": response, "task": task, "tools_used": tools_used}

    def _build_messages(self, task: str, context: dict) -> list[dict]:
        system = self._system_prompt()
        if self.tool_slugs:
            system += _tools_instructions(self.tool_slugs)
        user_content = task
        if context:
            user_content = f"Context: {context}\n\nTask: {task}"
        return [
            {"role": "system", "content": system},
            {"role": "user", "content": user_content},
        ]

    @abstractmethod
    def _system_prompt(self) -> str:
        ...

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "category": self.category,
        }
