from app.agents.core import OrchestratorAgent, MemoryAgent, RouterAgent, LoggerAgent, SchedulerAgent
from app.agents.seo import SeoAuditAgent, KeywordsAgent, SeoContentAgent, BacklinksAgent, SerpAgent
from app.agents.social import (
    TwitterAgent, LinkedInAgent, InstagramAgent, YouTubeAgent, TikTokAgent,
    ProspectingAgent, CrossPlatformAgent,
)
from app.agents.marketing import CopywriterAgent, EmailAgent, AdsAgent, LandingPageAgent, AnalyticsAgent
from app.agents.dev import CodeReviewerAgent, SecurityAgent, DocWriterAgent, TestWriterAgent, DevOpsAgent
from app.agents.data import ScraperAgent, ParserAgent, AnalyzerAgent, ReporterAgent, VisualizerAgent

AGENT_REGISTRY: dict = {
    a.id: a() for a in [
        OrchestratorAgent, MemoryAgent, RouterAgent, LoggerAgent, SchedulerAgent,
        SeoAuditAgent, KeywordsAgent, SeoContentAgent, BacklinksAgent, SerpAgent,
        TwitterAgent, LinkedInAgent, InstagramAgent, YouTubeAgent, TikTokAgent,
        ProspectingAgent, CrossPlatformAgent,
        CopywriterAgent, EmailAgent, AdsAgent, LandingPageAgent, AnalyticsAgent,
        CodeReviewerAgent, SecurityAgent, DocWriterAgent, TestWriterAgent, DevOpsAgent,
        ScraperAgent, ParserAgent, AnalyzerAgent, ReporterAgent, VisualizerAgent,
    ]
}
