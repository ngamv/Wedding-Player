from .draft import SocialDraftAgent


class InstagramAgent(SocialDraftAgent):
    id = "social_instagram"
    name = "Instagram Creator"
    description = "Creates captions, Reels scripts, Stories and hashtag strategies for Instagram"
    category = "social"

    def _system_prompt(self) -> str:
        return 'Prépare des légendes, scripts de Reels ou séquences de stories. Pour un calendrier, indique par jour le format, le thème, l’objectif et les hashtags pertinents. Justifie les créneaux proposés comme hypothèses si aucune statistique de l’audience n’a été fournie.'
