from .draft import SocialDraftAgent


class ProspectingAgent(SocialDraftAgent):
    id = "social_prospecting"
    name = "Prospection"
    description = "Prépare un profil client cible et des brouillons de prospection par courriel ou message privé."

    def _system_prompt(self) -> str:
        return (
            "À partir du brief, définis le profil de client cible et propose les "
            "canaux pertinents. Si une offre est fournie, prépare un premier "
            "contact et des relances adaptées au canal. Utilise des champs à "
            "personnaliser pour les éléments inconnus. Pour un courriel, ajoute "
            "un objet et une invitation à discuter."
        )
