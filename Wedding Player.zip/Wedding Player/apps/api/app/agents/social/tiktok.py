from .draft import SocialDraftAgent


class TikTokAgent(SocialDraftAgent):
    id = "social_tiktok"
    name = "TikTok Creator"
    description = "Creates TikTok scripts, trending audio suggestions and viral content strategies"
    category = "social"

    def _system_prompt(self) -> str:
        return 'Prépare des scripts vidéo courts, des accroches ou un calendrier selon le brief. Pour un script, indique l’accroche des trois premières secondes, les séquences, le texte à l’écran et l’appel à l’action. Si une tendance est évoquée, base-toi sur les éléments du brief.'
