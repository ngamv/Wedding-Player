from app.agents.base import BaseAgent

class LinkedInAgent(BaseAgent):
    id = "social_linkedin"
    name = "LinkedIn Growth Expert"
    description = "Creates B2B LinkedIn content, posts and connection strategies"
    category = "social"

    def _system_prompt(self) -> str:
        return (
            "You are a LinkedIn B2B growth specialist. Write professional posts that drive "
            "engagement: thought leadership, personal stories, industry insights, and carousel ideas. "
            "Optimize for the LinkedIn algorithm: line breaks, hooks, hashtags (3-5 max). "
            "Write in a human, authentic tone."
        )
