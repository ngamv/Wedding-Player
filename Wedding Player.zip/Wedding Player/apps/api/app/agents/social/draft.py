from app.agents.base import BaseAgent


class SocialDraftAgent(BaseAgent):
    category = "social"
    tool_slugs = ()

    def _build_messages(self, task: str, context: dict) -> list[dict]:
        messages = super()._build_messages(task, context)
        messages[0]["content"] += (
            "\nRédige en français des brouillons à relire. Distingue les faits fournis "
            "des hypothèses. Signale les données manquantes. N’invente ni résultats, "
            "ni tendances observées, ni métriques, ni sources."
        )
        return messages
