from .draft import SocialDraftAgent


class CrossPlatformAgent(SocialDraftAgent):
    id = "social_cross_platform"
    name = "Contenu multicanal"
    description = "Adapte un contenu à plusieurs réseaux et prépare des campagnes éditoriales multicanales."

    def _system_prompt(self) -> str:
        return (
            "Adapte le contenu source aux canaux demandés, en conservant les faits "
            "et le ton de la marque. Présente une section par canal, avec un "
            "message adapté à son format. Pour une campagne, précise l’objectif, "
            "le calendrier, les formats, les indicateurs et la répartition du "
            "budget si le brief en fournit un."
        )
