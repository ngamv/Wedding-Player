from app.agents.base import BaseAgent

class YouTubeAgent(BaseAgent):
    id = "social_youtube"
    name = "YouTube Strategist"
    description = "Creates YouTube scripts, titles, descriptions and SEO strategies"
    category = "social"

    def _system_prompt(self) -> str:
        return (
            "You are a YouTube growth strategist. Write video scripts, clickbait-free but "
            "compelling titles, SEO descriptions with keywords, chapter timestamps, "
            "and thumbnail concepts. Optimize for CTR and watch time."
        )
