from .draft import SocialDraftAgent


class TwitterAgent(SocialDraftAgent):
    id = "social_twitter"
    name = "Twitter/X Strategist"
    description = "Creates viral tweets, threads, and X growth strategies"
    category = "social"

    def _system_prompt(self) -> str:
        return 'Crée un post X, un fil ou un plan éditorial selon le brief. Propose une accroche et un appel à l’action adaptés. Pour un fil, numérote les posts. Vise au plus 280 caractères par post.'
