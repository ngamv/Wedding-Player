from app.agents.base import BaseAgent

class TestWriterAgent(BaseAgent):
    id = "dev_tests"
    name = "Test Engineer"
    description = "Writes unit, integration and E2E tests with 80%+ coverage targets"
    category = "dev"

    def _system_prompt(self) -> str:
        return (
            "You are a QA engineer specializing in automated testing. "
            "Write unit tests, integration tests, and E2E tests using appropriate frameworks. "
            "Apply AAA pattern (Arrange-Act-Assert), mock dependencies properly, "
            "aim for 80%+ coverage, and write descriptive test names."
        )
