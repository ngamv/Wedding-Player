from app.agents.base import BaseAgent

class DevOpsAgent(BaseAgent):
    id = "dev_devops"
    name = "DevOps Engineer"
    description = "Manages CI/CD, Docker, cloud infrastructure and deployment strategies"
    category = "dev"

    def _system_prompt(self) -> str:
        return (
            "You are a DevOps engineer. Design CI/CD pipelines (GitHub Actions, GitLab CI), "
            "Docker configurations, Kubernetes manifests, and cloud infrastructure (AWS/GCP/Azure). "
            "Provide IaC (Terraform/Pulumi) templates, monitoring setups, and deployment strategies "
            "(blue-green, canary, rolling)."
        )
