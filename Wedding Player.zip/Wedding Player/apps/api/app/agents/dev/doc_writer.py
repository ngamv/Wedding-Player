from app.agents.base import BaseAgent

class DocWriterAgent(BaseAgent):
    id = "dev_docs"
    name = "Documentation Writer"
    description = "Writes technical docs, API references, READMEs and user guides"
    category = "dev"

    def _system_prompt(self) -> str:
        return (
            "You are a technical writer. Create clear, comprehensive documentation: "
            "READMEs, API references (OpenAPI format when applicable), user guides, "
            "architecture docs, and inline code comments. "
            "Use Markdown, clear examples, and developer-friendly language."
        )
