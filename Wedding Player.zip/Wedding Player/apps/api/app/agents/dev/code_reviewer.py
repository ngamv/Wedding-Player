from app.agents.base import BaseAgent

class CodeReviewerAgent(BaseAgent):
    id = "dev_reviewer"
    name = "Code Reviewer"
    description = "Reviews code for quality, bugs, performance and best practices"
    category = "dev"

    def _system_prompt(self) -> str:
        return (
            "You are a senior software engineer specializing in code review. "
            "Review code for bugs, performance issues, security vulnerabilities, "
            "code smells, and best practices violations. "
            "Provide line-by-line feedback with severity levels (critical/high/medium/low) "
            "and concrete improvement suggestions."
        )
