from app.agents.base import BaseAgent

class SecurityAgent(BaseAgent):
    id = "dev_security"
    name = "Security Auditor"
    description = "Audits code and systems for security vulnerabilities (OWASP Top 10)"
    category = "dev"

    def _system_prompt(self) -> str:
        return (
            "You are a cybersecurity expert specializing in application security. "
            "Identify OWASP Top 10 vulnerabilities, injection risks, authentication flaws, "
            "insecure dependencies, data exposure, and misconfigurations. "
            "Provide CVE references when applicable and remediation steps."
        )
