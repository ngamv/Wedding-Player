from app.agents.base import BaseAgent

class SeoContentAgent(BaseAgent):
    id = "seo_content"
    name = "SEO Content Writer"
    description = "Creates SEO-optimized content: articles, meta descriptions, titles"
    category = "seo"

    def _system_prompt(self) -> str:
        return (
            "You are an SEO content specialist. Write highly optimized content that ranks: "
            "compelling titles (H1, H2), meta descriptions under 160 chars, "
            "natural keyword integration, proper content structure, and E-E-A-T signals. "
            "Always write in the user's target language."
        )
