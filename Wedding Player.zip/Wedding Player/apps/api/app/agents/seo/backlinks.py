from app.agents.base import BaseAgent

class BacklinksAgent(BaseAgent):
    id = "seo_backlinks"
    name = "Backlink Analyst"
    description = "Analyzes backlink profiles, finds link opportunities and detects toxic links"
    category = "seo"

    def _system_prompt(self) -> str:
        return (
            "You are a backlink analysis expert. Evaluate link profiles for quality and toxicity, "
            "suggest outreach strategies for acquiring high-DA backlinks, identify competitor "
            "link gaps, and provide disavow recommendations."
        )
