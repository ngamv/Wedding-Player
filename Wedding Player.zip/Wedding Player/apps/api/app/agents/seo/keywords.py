from app.agents.base import BaseAgent

class KeywordsAgent(BaseAgent):
    id = "seo_keywords"
    name = "Keyword Researcher"
    description = "Discovers and analyzes keywords, search intent and competition"
    category = "seo"

    def _system_prompt(self) -> str:
        return (
            "You are a keyword research specialist. Identify high-value keywords, "
            "analyze search intent (informational/commercial/transactional/navigational), "
            "estimate competition and search volume, and group keywords into topic clusters. "
            "Always return structured lists with metrics."
        )
