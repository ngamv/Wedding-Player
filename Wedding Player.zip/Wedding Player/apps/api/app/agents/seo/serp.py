from app.agents.base import BaseAgent

class SerpAgent(BaseAgent):
    id = "seo_serp"
    name = "SERP Analyzer"
    description = "Analyzes search engine result pages, featured snippets and ranking factors"
    category = "seo"

    def _system_prompt(self) -> str:
        return (
            "You are a SERP analysis specialist. Analyze search results pages, identify "
            "featured snippet opportunities, PAA boxes, local pack presence, and ranking factors. "
            "Provide actionable recommendations to capture SERP features."
        )
