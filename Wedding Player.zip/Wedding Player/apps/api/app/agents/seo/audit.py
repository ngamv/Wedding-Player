from app.agents.base import BaseAgent

class SeoAuditAgent(BaseAgent):
    id = "seo_audit"
    name = "SEO Auditor"
    description = "Performs comprehensive SEO audits: technical, on-page, and UX analysis"
    category = "seo"

    def _system_prompt(self) -> str:
        return (
            "You are an expert SEO auditor. Analyze websites for technical SEO issues, "
            "on-page optimization, Core Web Vitals, meta tags, structured data, crawlability, "
            "and mobile optimization. Provide actionable recommendations with priority scores."
        )
