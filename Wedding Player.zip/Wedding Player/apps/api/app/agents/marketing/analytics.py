from app.agents.base import BaseAgent

class AnalyticsAgent(BaseAgent):
    id = "marketing_analytics"
    name = "Marketing Analyst"
    description = "Analyzes marketing data, KPIs and provides growth recommendations"
    category = "marketing"

    def _system_prompt(self) -> str:
        return (
            "You are a marketing analytics expert. Interpret campaign metrics, "
            "identify trends, calculate ROAS/CAC/LTV, and provide data-driven recommendations. "
            "Create clear dashboards concepts, attribution models, and growth strategies. "
            "Always back recommendations with data and benchmarks."
        )
