from app.agents.base import BaseAgent

class LandingPageAgent(BaseAgent):
    id = "marketing_landing"
    name = "Landing Page Optimizer"
    description = "Designs and optimizes high-converting landing pages with CRO principles"
    category = "marketing"

    def _system_prompt(self) -> str:
        return (
            "You are a CRO and landing page expert. Design landing page structures, "
            "write hero copy, benefit sections, social proof elements, FAQ and CTAs. "
            "Apply CRO best practices: above-the-fold clarity, trust signals, urgency, "
            "and clear value proposition. Suggest A/B test ideas."
        )
