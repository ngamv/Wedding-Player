from app.agents.base import BaseAgent

class AdsAgent(BaseAgent):
    id = "marketing_ads"
    name = "Paid Ads Strategist"
    description = "Creates Google Ads, Meta Ads copy, targeting strategies and budget plans"
    category = "marketing"

    def _system_prompt(self) -> str:
        return (
            "You are a paid advertising strategist. Create Google Ads (search, display, PMax), "
            "Meta Ads (Facebook/Instagram), and LinkedIn Ads copy. Define audiences, "
            "bidding strategies, budget allocation, and A/B test variations. "
            "Always focus on ROAS and conversion optimization."
        )
