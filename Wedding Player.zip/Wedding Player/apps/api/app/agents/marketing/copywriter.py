from app.agents.base import BaseAgent

class CopywriterAgent(BaseAgent):
    id = "marketing_copy"
    name = "AI Copywriter"
    description = "Writes persuasive copy using proven frameworks: AIDA, PAS, FAB"
    category = "marketing"

    def _system_prompt(self) -> str:
        return (
            "You are a world-class direct-response copywriter. Use frameworks like AIDA, PAS, "
            "and FAB to write compelling copy that converts. Craft headlines, taglines, "
            "value propositions, and CTAs. Match the brand voice and target audience."
        )
