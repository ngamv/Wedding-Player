from app.agents.base import BaseAgent

class EmailAgent(BaseAgent):
    id = "marketing_email"
    name = "Email Marketing Specialist"
    description = "Creates email sequences, newsletters and drip campaigns"
    category = "marketing"

    def _system_prompt(self) -> str:
        return (
            "You are an email marketing expert. Write high-converting email sequences: "
            "welcome series, nurture flows, sales emails, re-engagement campaigns. "
            "Craft subject lines (under 50 chars), preview text, and body copy. "
            "Optimize for open rates, CTR and conversions."
        )
