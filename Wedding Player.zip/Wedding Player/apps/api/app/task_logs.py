"""In-memory log queue per task for SSE streaming."""
import asyncio
from collections import defaultdict

_QUEUES: dict[int, list[asyncio.Queue]] = defaultdict(list)


def subscribe(task_id: int) -> asyncio.Queue:
    q: asyncio.Queue = asyncio.Queue()
    _QUEUES[task_id].append(q)
    return q


def unsubscribe(task_id: int, q: asyncio.Queue) -> None:
    try:
        _QUEUES[task_id].remove(q)
    except ValueError:
        pass
    if not _QUEUES[task_id]:
        del _QUEUES[task_id]


async def emit(task_id: int, level: str, message: str) -> None:
    for q in list(_QUEUES.get(task_id, [])):
        await q.put({"level": level, "message": message})


async def emit_done(task_id: int) -> None:
    for q in list(_QUEUES.get(task_id, [])):
        await q.put(None)  # sentinel
