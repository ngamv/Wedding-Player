import sys
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # ── Database ───────────────────────────────────────────────────────────
    database_url: str = "sqlite+aiosqlite:///./orion.db"

    # ── Auth ───────────────────────────────────────────────────────────────
    # REQUIRED in production — must be a long random string (min 32 chars)
    jwt_secret: str = "change-me-in-production"
    # When false, every request is served as the default admin (single-user
    # local mode). Multi-user features — teams, audit trail, per-user API
    # keys — are meaningless without it, so it defaults to on.
    auth_enabled: bool = True
    # Password given to the bootstrap admin account. Generated randomly and
    # logged once at first startup when left empty.
    admin_password: str = ""

    # ── CORS ──────────────────────────────────────────────────────────────
    cors_origins: str = "http://localhost:5173,http://localhost"

    # ── Ollama (local LLM) ─────────────────────────────────────────────────
    ollama_base_url: str = "http://localhost:11434"
    ollama_model: str = "qwen2.5:3b"
    # Code generation with a larger model routinely exceeds two minutes.
    ollama_timeout: int = 300

    # ── LLM fallback chain ─────────────────────────────────────────────────
    # auto | ollama | openai | anthropic
    llm_provider: str = "auto"
    openai_api_key: str = ""
    openai_model: str = "gpt-4o-mini"
    anthropic_api_key: str = ""
    anthropic_model: str = "claude-haiku-4-5-20251001"
    # Point the OpenAI-compatible client at a self-hosted gateway (LiteLLM,
    # vLLM, LocalAI…) instead of api.openai.com. Empty = official OpenAI.
    openai_base_url: str = ""

    # ── Routage des skills vers le cloud ───────────────────────────────────
    # Skills dont la qualite justifie la passerelle cloud plutot que le modele
    # local. Tout ce qui n'est pas liste reste sur Ollama, donc sur la machine.
    # Liste separee par des virgules ; "*" enverrait tout au cloud.
    cloud_skills: str = (
        "app_generate,write_blog,ugc_script,product_description,customer_reply,"
        "caption_variations,rewrite,seo_meta,seo_content_brief,summarize,translate"
    )

    # ── Integrations ───────────────────────────────────────────────────────
    # Optional: lifts the 60 req/h anonymous GitHub limit and enables writes.
    github_token: str = ""

    # ── SearXNG (self-hosted search — optional) ────────────────────────────
    # When set, the web_search and seo_keywords skills query this instance
    # instead of DuckDuckGo / Google Suggest. Empty = keep the public APIs.
    searxng_url: str = ""

    # ── Backup ────────────────────────────────────────────────────────────
    backup_dir: str = "./backups"
    backup_keep_days: int = 7

    # ── SMTP (optional — email notifications) ─────────────────────────────
    smtp_host: str = ""
    smtp_port: int = 587
    smtp_user: str = ""
    smtp_password: str = ""
    smtp_from: str = ""
    smtp_tls: bool = True
    # Notification preferences (comma-separated: task_failed,task_completed)
    notify_on: str = "task_failed"

    # ── ntfy (notifications push) ─────────────────────────────────────────
    # Jeton d'acces du ntfy auto-heberge, qui refuse tout anonyme. Il n'est
    # envoye qu'a notre propre serveur : l'expedier a ntfy.sh reviendrait a
    # confier a un tiers de quoi publier chez nous.
    ntfy_token: str = ""

    # ── Web Push (VAPID) ──────────────────────────────────────────────────
    vapid_private_key: str = ""
    vapid_public_key: str = ""
    vapid_subject: str = "mailto:admin@orion.local"

    model_config = {"env_file": ".env", "extra": "ignore"}

    def validate_production(self) -> list[str]:
        """Return list of critical warnings for production deployments."""
        warnings: list[str] = []
        if self.jwt_secret == "change-me-in-production":
            warnings.append("JWT_SECRET is using the default value — set a secure random secret!")
        if len(self.jwt_secret) < 32:
            warnings.append(f"JWT_SECRET is too short ({len(self.jwt_secret)} chars) — use at least 32 random chars.")
        if (self.llm_provider in ("auto", "ollama")
                and not self.openai_api_key and not self.anthropic_api_key
                and not self.openai_base_url):
            warnings.append("No LLM fallback set — tasks will fail if Ollama is offline. "
                            "Set OPENAI_BASE_URL (self-hosted gateway) or a cloud API key.")
        return warnings


settings = Settings()


def check_secrets_on_startup() -> None:
    """Log warnings for insecure / missing config. Call once at app startup."""
    import logging
    log = logging.getLogger("orion.config")
    for w in settings.validate_production():
        log.warning("⚠  CONFIG: %s", w)
