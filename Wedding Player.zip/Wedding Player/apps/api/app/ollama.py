import httpx
from app.config import settings

async def chat(messages: list[dict], model: str | None = None) -> str:
    model = model or settings.ollama_model
    async with httpx.AsyncClient(timeout=settings.ollama_timeout) as client:
        res = await client.post(
            f"{settings.ollama_base_url}/api/chat",
            json={"model": model, "messages": messages, "stream": False},
        )
        res.raise_for_status()
        return res.json()["message"]["content"]

async def generate(prompt: str, model: str | None = None) -> str:
    model = model or settings.ollama_model
    async with httpx.AsyncClient(timeout=settings.ollama_timeout) as client:
        res = await client.post(
            f"{settings.ollama_base_url}/api/generate",
            json={"model": model, "prompt": prompt, "stream": False},
        )
        res.raise_for_status()
        return res.json()["response"]

async def list_models() -> list[str]:
    async with httpx.AsyncClient(timeout=10) as client:
        res = await client.get(f"{settings.ollama_base_url}/api/tags")
        if res.status_code != 200:
            return []
        return [m["name"] for m in res.json().get("models", [])]

async def list_models_detail() -> list[dict]:
    """Return full model info (name, size, modified_at, details)."""
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            res = await client.get(f"{settings.ollama_base_url}/api/tags")
            if res.status_code != 200:
                return []
            models = res.json().get("models", [])
            return [
                {
                    "name": m.get("name", ""),
                    "size": m.get("size", 0),
                    "modified_at": m.get("modified_at", ""),
                    "digest": m.get("digest", "")[:12] if m.get("digest") else "",
                    "family": m.get("details", {}).get("family", ""),
                    "parameter_size": m.get("details", {}).get("parameter_size", ""),
                    "quantization_level": m.get("details", {}).get("quantization_level", ""),
                }
                for m in models
            ]
    except Exception:
        return []


async def pull_model(name: str) -> dict:
    """Pull a model from the Ollama registry (streams internally, returns final status)."""
    async with httpx.AsyncClient(timeout=600) as client:
        res = await client.post(
            f"{settings.ollama_base_url}/api/pull",
            json={"name": name, "stream": False},
        )
        res.raise_for_status()
        return res.json()


async def delete_model(name: str) -> bool:
    """Delete a locally stored model."""
    async with httpx.AsyncClient(timeout=30) as client:
        res = await client.request(
            "DELETE",
            f"{settings.ollama_base_url}/api/delete",
            json={"name": name},
        )
        return res.status_code in (200, 204)


async def health() -> bool:
    try:
        async with httpx.AsyncClient(timeout=3) as client:
            res = await client.get(f"{settings.ollama_base_url}/api/tags")
            return res.status_code == 200
    except Exception:
        return False
