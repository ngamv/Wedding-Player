import json
from app.agents import AGENT_REGISTRY
from app import llm

ROUTER_SYSTEM = """You are Orion's task router. Given a task, return ONLY valid JSON:
{"agent_id": "<id>", "confidence": 0.0-1.0, "reason": "<why>"}

Available agents:
""" + "\n".join(f"- {aid}: {a.description}" for aid, a in AGENT_REGISTRY.items())

async def route_and_run(task: str, agent_id: str | None = None, context: dict | None = None, model: str | None = None) -> dict:
    if agent_id and agent_id in AGENT_REGISTRY:
        agent = AGENT_REGISTRY[agent_id]
        result = await agent.run(task, context)
        return {"routed_to": agent_id, "agent_name": agent.name, **result}

    routing_response = await llm.chat(
        [{"role": "user", "content": f"Route this task: {task}"}],
        system=ROUTER_SYSTEM,
        model=model,
    )

    try:
        routing = json.loads(routing_response)
        chosen_id = routing.get("agent_id", "orchestrator")
    except Exception:
        chosen_id = "orchestrator"

    agent = AGENT_REGISTRY.get(chosen_id, AGENT_REGISTRY["orchestrator"])
    result = await agent.run(task, context)
    return {
        "routed_to": chosen_id,
        "agent_name": agent.name,
        "routing_confidence": routing.get("confidence") if "routing" in dir() else 1.0,
        **result,
    }
