"""Web Push notification endpoints (VAPID)."""
import asyncio
import json
import logging
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel
from app.database import get_db
from app.models import PushSubscription, User
from app.auth import get_current_user
from app.config import settings

router = APIRouter(prefix="/push", tags=["push"])
log = logging.getLogger("orion.push")


class SubscribeBody(BaseModel):
    endpoint: str
    p256dh: str
    auth: str


@router.get("/vapid-public-key")
async def get_vapid_public_key():
    """Return the VAPID public key for the browser to use when subscribing."""
    if not settings.vapid_public_key:
        raise HTTPException(503, "Web Push non configuré (VAPID_PUBLIC_KEY manquant)")
    return {"public_key": settings.vapid_public_key}


@router.post("/subscribe", status_code=201)
async def subscribe(
    body: SubscribeBody,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Save or update a push subscription for the authenticated user."""
    existing = (await db.execute(
        select(PushSubscription).where(PushSubscription.endpoint == body.endpoint)
    )).scalar_one_or_none()

    if existing:
        existing.p256dh = body.p256dh
        existing.auth = body.auth
    else:
        db.add(PushSubscription(
            user_id=current_user.id,
            endpoint=body.endpoint,
            p256dh=body.p256dh,
            auth=body.auth,
        ))
    await db.commit()
    return {"subscribed": True}


@router.delete("/unsubscribe")
async def unsubscribe(
    body: SubscribeBody,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    existing = (await db.execute(
        select(PushSubscription).where(
            PushSubscription.endpoint == body.endpoint,
            PushSubscription.user_id == current_user.id,
        )
    )).scalar_one_or_none()
    if existing:
        await db.delete(existing)
        await db.commit()
    return {"unsubscribed": True}


async def send_push(user_id: int, title: str, body: str, db: AsyncSession) -> None:
    """Send a Web Push notification to all subscriptions of a user."""
    if not settings.vapid_private_key or not settings.vapid_public_key:
        return  # Push not configured — silently skip

    try:
        from pywebpush import webpush, WebPushException
    except ImportError:
        log.warning("pywebpush not installed — skipping push notification")
        return

    subs = (await db.execute(
        select(PushSubscription).where(PushSubscription.user_id == user_id)
    )).scalars().all()

    payload = json.dumps({"title": title, "body": body})

    loop = asyncio.get_event_loop()
    for sub in subs:
        try:
            sub_info = {
                "endpoint": sub.endpoint,
                "keys": {"p256dh": sub.p256dh, "auth": sub.auth},
            }
            await loop.run_in_executor(None, lambda s=sub_info: webpush(
                subscription_info=s,
                data=payload,
                vapid_private_key=settings.vapid_private_key,
                vapid_claims={"sub": settings.vapid_subject},
            ))
        except WebPushException as exc:
            log.warning("Push failed for sub %s: %s", sub.id, exc)
            if exc.response and exc.response.status_code in (404, 410):
                await db.delete(sub)
                await db.commit()
        except Exception as exc:
            log.warning("Push error: %s", exc)
