"""SSE endpoint for real-time task log streaming."""
import asyncio
import json
from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.database import get_db
from app.models import Task, TaskLog, User
from app.auth import get_current_user, decode_token
from app import task_logs

router = APIRouter(prefix="/tasks", tags=["task-logs"])


@router.get("/{task_id}/logs/stream")
async def stream_logs(
    task_id: int,
    token: str = Query(...),
    db: AsyncSession = Depends(get_db),
):
    """SSE stream of task logs. Auth via ?token= (browser EventSource cannot set headers)."""
    payload = decode_token(token)
    if not payload:
        raise HTTPException(401, "Token invalide")

    result = await db.execute(select(Task).where(Task.id == task_id))
    task = result.scalar_one_or_none()
    if not task or task.user_id != int(payload["sub"]):
        raise HTTPException(404, "Tâche introuvable")

    # Stream historical logs first, then live
    hist = await db.execute(
        select(TaskLog).where(TaskLog.task_id == task_id).order_by(TaskLog.id)
    )
    historical = hist.scalars().all()

    q = task_logs.subscribe(task_id)

    async def generator():
        try:
            # Replay saved logs
            for log in historical:
                yield _sse({"level": log.level, "message": log.message, "ts": log.created_at.isoformat()})
            # If task already done, close immediately
            if task.status in ("completed", "failed"):
                yield _sse({"level": "info", "message": "__DONE__"})
                return
            # Live stream
            while True:
                try:
                    event = await asyncio.wait_for(q.get(), timeout=30)
                except asyncio.TimeoutError:
                    yield ": keepalive\n\n"
                    continue
                if event is None:
                    yield _sse({"level": "info", "message": "__DONE__"})
                    break
                yield _sse(event)
        finally:
            task_logs.unsubscribe(task_id, q)

    return StreamingResponse(
        generator(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@router.get("/{task_id}/logs")
async def get_logs(
    task_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Return stored logs for a task (non-streaming)."""
    result = await db.execute(select(Task).where(Task.id == task_id, Task.user_id == current_user.id))
    if not result.scalar_one_or_none():
        raise HTTPException(404, "Tâche introuvable")
    logs_result = await db.execute(
        select(TaskLog).where(TaskLog.task_id == task_id).order_by(TaskLog.id)
    )
    return [
        {"level": l.level, "message": l.message, "created_at": l.created_at}
        for l in logs_result.scalars()
    ]


def _sse(data: dict) -> str:
    return f"data: {json.dumps(data)}\n\n"
