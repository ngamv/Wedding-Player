import csv
import io
import json
import zipfile
from datetime import datetime
from fastapi import APIRouter, Depends, UploadFile, File, HTTPException
from fastapi.responses import StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.database import get_db
from app.models import Task, User
from app.auth import get_current_user

router = APIRouter(prefix="/export", tags=["export"])


@router.get("/tasks.csv")
async def export_tasks_csv(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(Task).where(Task.user_id == current_user.id).order_by(Task.created_at.desc())
    )
    tasks = result.scalars().all()

    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(["id", "title", "agent_id", "status", "description", "result", "created_at", "updated_at"])

    for t in tasks:
        result_text = ""
        if t.output_data:
            result_text = t.output_data.get("result", "") if isinstance(t.output_data, dict) else str(t.output_data)
        writer.writerow([
            t.id,
            t.title,
            t.agent_id,
            t.status,
            t.description or "",
            result_text,
            t.created_at.isoformat() if t.created_at else "",
            t.updated_at.isoformat() if t.updated_at else "",
        ])

    buf.seek(0)
    return StreamingResponse(
        iter([buf.getvalue()]),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=orion_tasks.csv"},
    )


@router.get("/tasks.json")
async def export_tasks_json(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(Task).where(Task.user_id == current_user.id).order_by(Task.created_at.desc())
    )
    tasks = result.scalars().all()

    data = [
        {
            "id": t.id,
            "title": t.title,
            "agent_id": t.agent_id,
            "status": t.status,
            "description": t.description,
            "output": t.output_data,
            "created_at": t.created_at.isoformat() if t.created_at else None,
        }
        for t in tasks
    ]

    buf = io.BytesIO(json.dumps(data, ensure_ascii=False, indent=2).encode())
    return StreamingResponse(
        iter([buf.getvalue()]),
        media_type="application/json",
        headers={"Content-Disposition": "attachment; filename=orion_tasks.json"},
    )


@router.get("/download.zip")
async def export_zip(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Full data export as a ZIP archive (tasks, custom agents, workflows, vault names)."""
    from app.models import CustomAgent, Workflow as WorkflowModel
    from app.agents import AGENT_REGISTRY

    tasks_rows = (await db.execute(
        select(Task).where(Task.user_id == current_user.id).order_by(Task.created_at.desc())
    )).scalars().all()
    tasks_data = [
        {"id": t.id, "title": t.title, "agent_id": t.agent_id, "status": t.status,
         "description": t.description, "output": t.output_data,
         "created_at": t.created_at.isoformat() if t.created_at else None}
        for t in tasks_rows
    ]

    ca_rows = (await db.execute(
        select(CustomAgent).where(CustomAgent.user_id == current_user.id)
    )).scalars().all()
    ca_data = [
        {"id": c.id, "name": c.name, "description": c.description,
         "system_prompt": c.system_prompt, "agent_id": c.agent_id,
         "is_public": c.is_public, "created_at": c.created_at.isoformat() if c.created_at else None}
        for c in ca_rows
    ]

    wf_rows = (await db.execute(
        select(WorkflowModel).where(WorkflowModel.user_id == current_user.id)
    )).scalars().all()
    wf_data = [
        {"id": w.id, "name": w.name, "description": w.description,
         "steps": w.steps, "created_at": w.created_at.isoformat() if w.created_at else None}
        for w in wf_rows
    ]

    # Vault: export names only (never values)
    try:
        from app.models import VaultSecret
        vs_rows = (await db.execute(
            select(VaultSecret).where(VaultSecret.user_id == current_user.id)
        )).scalars().all()
        vault_data = [{"id": v.id, "name": v.name, "created_at": v.created_at.isoformat() if v.created_at else None} for v in vs_rows]
    except Exception:
        vault_data = []

    agents_data = [{"id": aid, "name": a.name, "description": a.description, "category": a.category}
                   for aid, a in AGENT_REGISTRY.items()]

    manifest = {
        "exported_by": current_user.username,
        "exported_at": datetime.utcnow().isoformat(),
        "orion_version": "1.0.0",
        "counts": {
            "tasks": len(tasks_data),
            "custom_agents": len(ca_data),
            "workflows": len(wf_data),
            "vault_secrets": len(vault_data),
            "system_agents": len(agents_data),
        },
    }

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2))
        zf.writestr("tasks.json", json.dumps(tasks_data, ensure_ascii=False, indent=2))
        zf.writestr("custom_agents.json", json.dumps(ca_data, ensure_ascii=False, indent=2))
        zf.writestr("workflows.json", json.dumps(wf_data, ensure_ascii=False, indent=2))
        zf.writestr("vault_names.json", json.dumps(vault_data, ensure_ascii=False, indent=2))
        zf.writestr("system_agents.json", json.dumps(agents_data, ensure_ascii=False, indent=2))

    buf.seek(0)
    filename = f"orion_export_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.zip"
    return StreamingResponse(
        iter([buf.getvalue()]),
        media_type="application/zip",
        headers={"Content-Disposition": f"attachment; filename={filename}"},
    )


@router.post("/import")
async def import_zip(
    file: UploadFile = File(...),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Import data from an ORION ZIP export. Skips duplicates by title+agent_id for tasks."""
    if not file.filename or not file.filename.endswith(".zip"):
        raise HTTPException(status_code=400, detail="Le fichier doit être un .zip ORION")

    raw = await file.read()
    try:
        zf = zipfile.ZipFile(io.BytesIO(raw))
    except zipfile.BadZipFile:
        raise HTTPException(status_code=400, detail="Archive ZIP invalide")

    names = zf.namelist()
    if "manifest.json" not in names:
        raise HTTPException(status_code=400, detail="manifest.json manquant — ce n'est pas un export ORION")

    manifest = json.loads(zf.read("manifest.json"))
    if manifest.get("orion_version") is None:
        raise HTTPException(status_code=400, detail="Format d'export non reconnu")

    imported = {"tasks": 0, "custom_agents": 0, "workflows": 0, "skipped": 0}

    # Import custom agents
    if "custom_agents.json" in names:
        from app.models import CustomAgent
        from app.routes.custom_agents import _register_in_memory
        ca_list = json.loads(zf.read("custom_agents.json"))
        for ca in ca_list:
            if not isinstance(ca, dict) or not ca.get("name"):
                continue
            agent_id = ca.get("agent_id") or f"custom_{ca['name'].lower().replace(' ', '_')}"
            existing = (await db.execute(
                select(CustomAgent).where(
                    CustomAgent.user_id == current_user.id,
                    CustomAgent.agent_id == agent_id,
                )
            )).scalar_one_or_none()
            if existing:
                imported["skipped"] += 1
                continue
            new_ca = CustomAgent(
                name=ca["name"],
                description=ca.get("description", ""),
                system_prompt=ca.get("system_prompt", ""),
                agent_id=agent_id,
                user_id=current_user.id,
                is_public=bool(ca.get("is_public", False)),
            )
            db.add(new_ca)
            await db.flush()
            _register_in_memory(new_ca)
            imported["custom_agents"] += 1

    # Import workflows
    if "workflows.json" in names:
        from app.models import Workflow as WorkflowModel
        wf_list = json.loads(zf.read("workflows.json"))
        for wf in wf_list:
            if not isinstance(wf, dict) or not wf.get("name"):
                continue
            new_wf = WorkflowModel(
                name=wf["name"],
                description=wf.get("description", ""),
                steps=wf.get("steps", []),
                user_id=current_user.id,
            )
            db.add(new_wf)
            imported["workflows"] += 1

    # Import tasks (skip if same title+agent_id already exists for user)
    if "tasks.json" in names:
        task_list = json.loads(zf.read("tasks.json"))
        existing_keys = set()
        existing_rows = (await db.execute(
            select(Task.title, Task.agent_id).where(Task.user_id == current_user.id)
        )).all()
        for row in existing_rows:
            existing_keys.add((row.title, row.agent_id))

        for t in task_list:
            if not isinstance(t, dict) or not t.get("title"):
                continue
            key = (t["title"], t.get("agent_id", ""))
            if key in existing_keys:
                imported["skipped"] += 1
                continue
            new_task = Task(
                title=t["title"],
                agent_id=t.get("agent_id", ""),
                status=t.get("status", "completed"),
                description=t.get("description"),
                output_data=t.get("output"),
                user_id=current_user.id,
            )
            db.add(new_task)
            existing_keys.add(key)
            imported["tasks"] += 1

    await db.commit()

    total = imported["tasks"] + imported["custom_agents"] + imported["workflows"]
    return {
        "imported": imported,
        "total": total,
        "message": f"{total} éléments importés ({imported['skipped']} doublons ignorés)",
    }
