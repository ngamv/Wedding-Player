"""
Content-creation skills: UGC scripts, social posts, content calendar,
image generation (Pollinations.ai), voice-over (edge-tts), slideshow video (ffmpeg).
Merged into the main skills registry by skills.py.
"""
import asyncio
import json
import os
import re
import uuid

from app import llm

MEDIA_DIR = os.path.join(os.environ.get("DATA_DIR", "/data"), "media")


def _media_path(ext: str) -> tuple[str, str]:
    """Returns (absolute path, filename) for a new media file."""
    os.makedirs(MEDIA_DIR, exist_ok=True)
    name = f"{uuid.uuid4().hex[:12]}.{ext}"
    return os.path.join(MEDIA_DIR, name), name


CONTENT_SKILLS: dict[str, dict] = {
    "ugc_script": {
        "name": "Script vidéo UGC",
        "description": "Génère un script de vidéo courte (TikTok/Reels) : hook, problème, solution, CTA",
        "icon": "Video",
        "category": "content",
        "params": [
            {"name": "product", "type": "text", "required": True, "label": "Produit / sujet",
             "placeholder": "Gel d'aloe vera Forever Living"},
            {"name": "audience", "type": "text", "required": False, "label": "Audience cible",
             "default": "grand public"},
            {"name": "duration", "type": "select", "options": ["30s", "60s", "90s"],
             "required": False, "label": "Durée", "default": "30s"},
        ],
    },
    "social_post": {
        "name": "Post réseaux sociaux",
        "description": "Rédige un post adapté à la plateforme avec hashtags et emojis",
        "icon": "Share2",
        "category": "content",
        "params": [
            {"name": "topic", "type": "textarea", "required": True, "label": "Sujet du post"},
            {"name": "platform", "type": "select",
             "options": ["Instagram", "Facebook", "TikTok", "LinkedIn", "X"],
             "required": True, "label": "Plateforme", "default": "Instagram"},
            {"name": "tone", "type": "select",
             "options": ["authentique", "vendeur", "éducatif", "inspirant", "humoristique"],
             "required": False, "label": "Ton", "default": "authentique"},
        ],
    },
    "content_calendar": {
        "name": "Calendrier de contenu",
        "description": "Planifie plusieurs jours d'idées de posts sur un thème",
        "icon": "CalendarDays",
        "category": "content",
        "params": [
            {"name": "theme", "type": "text", "required": True, "label": "Thème / activité",
             "placeholder": "bien-être et produits aloe vera"},
            {"name": "days", "type": "select", "options": ["7", "14", "30"],
             "required": False, "label": "Nombre de jours", "default": "7"},
        ],
    },
    "generate_image": {
        "name": "Génération d'image",
        "description": "Crée une image depuis un prompt via Pollinations.ai (gratuit, sans clé)",
        "icon": "Image",
        "category": "content",
        "params": [
            {"name": "prompt", "type": "textarea", "required": True, "label": "Description de l'image",
             "placeholder": "aloe vera plant in a bright modern bathroom, product photography"},
            {"name": "size", "type": "select", "options": ["1024x1024", "1080x1920", "1920x1080"],
             "required": False, "label": "Dimensions", "default": "1024x1024"},
        ],
    },
    "text_to_speech": {
        "name": "Voix off (TTS)",
        "description": "Convertit un texte en voix off MP3 (voix Microsoft gratuites)",
        "icon": "Mic",
        "category": "content",
        "params": [
            {"name": "text", "type": "textarea", "required": True, "label": "Texte à lire"},
            {"name": "voice", "type": "select",
             "options": ["fr-FR-DeniseNeural", "fr-FR-HenriNeural", "fr-FR-VivienneMultilingualNeural",
                          "en-US-JennyNeural", "en-US-GuyNeural"],
             "required": False, "label": "Voix", "default": "fr-FR-DeniseNeural"},
        ],
    },
    "publish_post": {
        "name": "Publier via Postiz",
        "description": "Envoie un post au planificateur Postiz (brouillon ou programmé)",
        "icon": "Send",
        "category": "content",
        "params": [
            {"name": "content", "type": "textarea", "required": True, "label": "Contenu du post"},
            {"name": "api_key", "type": "text", "required": True, "label": "Clé API Postiz",
             "placeholder": "Paramètres Postiz → API"},
            {"name": "schedule_hours", "type": "select", "options": ["brouillon", "1", "4", "24"],
             "required": False, "label": "Programmer dans (heures)", "default": "brouillon"},
        ],
    },
    "slideshow_video": {
        "name": "Vidéo diaporama",
        "description": "Assemble des images (et une voix off optionnelle) en vidéo MP4 via ffmpeg",
        "icon": "Film",
        "category": "content",
        "params": [
            {"name": "images", "type": "textarea", "required": True,
             "label": "Images (une URL ou un nom de fichier média par ligne)"},
            {"name": "audio", "type": "text", "required": False,
             "label": "Fichier audio (nom renvoyé par le skill Voix off)"},
            {"name": "seconds_per_image", "type": "select", "options": ["2", "3", "5"],
             "required": False, "label": "Secondes par image", "default": "3"},
        ],
    },
}


# ---------------------------------------------------------------------------
# Runners
# ---------------------------------------------------------------------------

async def _run_ugc_script(params: dict) -> str:
    product = params.get("product", "")
    audience = params.get("audience", "grand public")
    duration = params.get("duration", "30s")
    return await llm.chat([{"role": "user", "content": (
        f"Écris un script de vidéo UGC de {duration} pour vendre « {product} » à une audience "
        f"« {audience} ». Structure obligatoire :\n"
        "1. HOOK (3s, phrase choc qui arrête le scroll)\n"
        "2. PROBLÈME (le point de douleur de l'audience)\n"
        "3. SOLUTION (le produit, bénéfices concrets, pas de jargon)\n"
        "4. PREUVE (témoignage ou résultat)\n"
        "5. CTA (appel à l'action clair)\n"
        "Indique les plans caméra entre crochets. Ton naturel et parlé, comme une vraie personne. "
        "Reste conforme : pas de promesses médicales."
    )}])


async def _run_social_post(params: dict) -> str:
    topic = params.get("topic", "")
    platform = params.get("platform", "Instagram")
    tone = params.get("tone", "authentique")
    specs = {
        "Instagram": "caption 100-150 mots, 5-10 hashtags pertinents à la fin, emojis",
        "Facebook": "80-120 mots, conversation, 1-3 hashtags max, question d'engagement à la fin",
        "TikTok": "caption courte < 100 caractères + 4-6 hashtags tendance",
        "LinkedIn": "150-250 mots, professionnel, saut de ligne entre les idées, 3-5 hashtags",
        "X": "≤ 280 caractères, percutant, 1-2 hashtags",
    }
    return await llm.chat([{"role": "user", "content": (
        f"Rédige un post {platform} en français, ton {tone}, sur : {topic}\n"
        f"Contraintes {platform} : {specs.get(platform, '')}\n"
        "Retourne uniquement le post, prêt à publier. Pas de promesses médicales ni de revenus garantis."
    )}])


async def _run_content_calendar(params: dict) -> str:
    theme = params.get("theme", "")
    days = params.get("days", "7")
    return await llm.chat([{"role": "user", "content": (
        f"Crée un calendrier de contenu de {days} jours sur le thème : {theme}.\n"
        "Pour chaque jour : | Jour | Format (post photo / reel / story / carrousel) | Idée précise | Objectif (visibilité, confiance, vente) |\n"
        "Varie les formats. Alterne valeur gratuite (conseils) et vente douce (max 30% de posts vendeurs). "
        "Retourne un tableau markdown."
    )}])


async def _run_generate_image(params: dict) -> str:
    import httpx
    prompt = params.get("prompt", "").strip()
    if not prompt:
        raise ValueError("Prompt vide")
    size = params.get("size", "1024x1024")
    w, h = size.split("x")
    url = (f"https://image.pollinations.ai/prompt/{httpx.QueryParams({'p': prompt})['p']}"
           f"?width={w}&height={h}&nologo=true")
    async with httpx.AsyncClient(timeout=90, follow_redirects=True) as client:
        resp = await client.get(url)
        resp.raise_for_status()
    path, name = _media_path("jpg")
    with open(path, "wb") as f:
        f.write(resp.content)
    return json.dumps({
        "file": name,
        "download_url": f"/api/skills/media/{name}",
        "source_url": url,
        "size_kb": len(resp.content) // 1024,
    }, ensure_ascii=False, indent=2)


async def _run_text_to_speech(params: dict) -> str:
    import edge_tts
    text = params.get("text", "").strip()
    if not text:
        raise ValueError("Texte vide")
    voice = params.get("voice", "fr-FR-DeniseNeural")
    path, name = _media_path("mp3")
    communicate = edge_tts.Communicate(text, voice)
    await communicate.save(path)
    return json.dumps({
        "file": name,
        "download_url": f"/api/skills/media/{name}",
        "voice": voice,
        "size_kb": os.path.getsize(path) // 1024,
    }, ensure_ascii=False, indent=2)


async def _run_slideshow_video(params: dict) -> str:
    import httpx
    lines = [l.strip() for l in params.get("images", "").splitlines() if l.strip()]
    if not lines:
        raise ValueError("Aucune image fournie")
    secs = int(params.get("seconds_per_image") or 3)
    audio = (params.get("audio") or "").strip()

    # Resolve each image: URL → download, otherwise a filename in MEDIA_DIR
    local_images: list[str] = []
    async with httpx.AsyncClient(timeout=60, follow_redirects=True) as client:
        for line in lines[:20]:
            if line.startswith("http"):
                resp = await client.get(line)
                resp.raise_for_status()
                p, _ = _media_path("jpg")
                with open(p, "wb") as f:
                    f.write(resp.content)
                local_images.append(p)
            else:
                p = os.path.join(MEDIA_DIR, os.path.basename(line))
                if not os.path.exists(p):
                    raise ValueError(f"Fichier média introuvable : {line}")
                local_images.append(p)

    out_path, out_name = _media_path("mp4")
    concat_path, _ = _media_path("txt")
    with open(concat_path, "w") as f:
        for img in local_images:
            f.write(f"file '{img}'\nduration {secs}\n")
        f.write(f"file '{local_images[-1]}'\n")  # dernière image requise par le demuxer concat

    cmd = ["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", concat_path]
    if audio:
        audio_path = os.path.join(MEDIA_DIR, os.path.basename(audio))
        if not os.path.exists(audio_path):
            raise ValueError(f"Fichier audio introuvable : {audio}")
        cmd += ["-i", audio_path, "-shortest", "-c:a", "aac"]
    cmd += ["-vf", "scale=1080:1920:force_original_aspect_ratio=decrease,"
                    "pad=1080:1920:(ow-iw)/2:(oh-ih)/2:black,format=yuv420p",
            "-r", "30", "-c:v", "libx264", "-preset", "fast", out_path]

    proc = await asyncio.create_subprocess_exec(
        *cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
    _, stderr = await proc.communicate()
    os.unlink(concat_path)
    if proc.returncode != 0:
        tail = stderr.decode(errors="replace")[-400:]
        raise RuntimeError(f"ffmpeg a échoué : {tail}")
    return json.dumps({
        "file": out_name,
        "download_url": f"/api/skills/media/{out_name}",
        "images": len(local_images),
        "audio": bool(audio),
        "size_kb": os.path.getsize(out_path) // 1024,
    }, ensure_ascii=False, indent=2)


async def _run_publish_post(params: dict) -> str:
    import httpx
    from datetime import datetime, timedelta
    content = params.get("content", "").strip()
    api_key = params.get("api_key", "").strip()
    if not content or not api_key:
        raise ValueError("Contenu et clé API Postiz requis")
    base = os.environ.get("POSTIZ_URL", "http://host.docker.internal:5000") + "/public/v1"
    headers = {"Authorization": api_key}
    async with httpx.AsyncClient(timeout=30) as client:
        integ_resp = await client.get(f"{base}/integrations", headers=headers)
        if integ_resp.status_code == 401:
            raise ValueError("Clé API Postiz invalide")
        integ_resp.raise_for_status()
        integrations = integ_resp.json()
        if not integrations:
            raise ValueError("Aucun réseau social connecté dans Postiz. Connectez un compte d'abord.")
        sched = params.get("schedule_hours", "brouillon")
        body = {
            "type": "draft" if sched == "brouillon" else "schedule",
            "date": (datetime.utcnow() + timedelta(hours=int(sched) if sched != "brouillon" else 0)
                     ).strftime("%Y-%m-%dT%H:%M:%S.000Z"),
            "shortLink": False,
            "posts": [
                {"integration": {"id": integ["id"]}, "value": [{"content": content}]}
                for integ in integrations
            ],
        }
        resp = await client.post(f"{base}/posts", headers=headers, json=body)
        resp.raise_for_status()
    return json.dumps({
        "status": "brouillon créé" if sched == "brouillon" else f"programmé dans {sched}h",
        "reseaux": [i.get("name") or i.get("identifier") for i in integrations],
        "postiz": "http://localhost:5000/launches",
    }, ensure_ascii=False, indent=2)


CONTENT_RUNNERS = {
    "publish_post": _run_publish_post,
    "ugc_script": _run_ugc_script,
    "social_post": _run_social_post,
    "content_calendar": _run_content_calendar,
    "generate_image": _run_generate_image,
    "text_to_speech": _run_text_to_speech,
    "slideshow_video": _run_slideshow_video,
}
