from datetime import datetime, timedelta
from fastapi import APIRouter, Depends
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, case, delete
from app import ollama, llm
from app.agents import AGENT_REGISTRY
from app.database import get_db
from app.models import AgentMetric, Task
from app.auth import get_current_user, require_admin

# In-memory per-user retention settings (persists for the process lifetime)
# Stored as {user_id: days}. 0 = disabled.
_retention_settings: dict[int, int] = {}

router = APIRouter(prefix="/system", tags=["system"])


@router.get("/health")
async def health():
    ollama_ok = await ollama.health()
    models = await ollama.list_models() if ollama_ok else []
    active = await llm.active_provider()
    return {
        "status": "ok",
        "ollama": ollama_ok,
        "models": models,
        "agents_count": len(AGENT_REGISTRY),
        "llm": active,
    }


@router.get("/llm-config")
async def get_llm_config(_=Depends(get_current_user)):
    """Return full LLM configuration: current provider, available providers, models."""
    from app.config import settings as s
    active = await llm.active_provider()
    override = llm.get_override()
    ollama_ok = await ollama.health()
    ollama_models = await ollama.list_models() if ollama_ok else []
    return {
        "active": active,
        "override": override,
        "env_provider": s.llm_provider,
        "providers": {
            "ollama": {
                "available": ollama_ok,
                "models": ollama_models,
                "current_model": override.get("ollama_model") or s.ollama_model,
            },
            "openai": {
                "available": bool(s.openai_api_key),
                "models": ["gpt-4o-mini", "gpt-4o", "gpt-4-turbo", "gpt-3.5-turbo"],
                "current_model": override.get("openai_model") or s.openai_model,
            },
            "anthropic": {
                "available": bool(s.anthropic_api_key),
                "models": ["claude-haiku-4-5-20251001", "claude-sonnet-4-6", "claude-opus-4-8"],
                "current_model": override.get("anthropic_model") or s.anthropic_model,
            },
        },
    }


class LLMConfigBody(BaseModel):
    provider: str  # auto | ollama | openai | anthropic
    ollama_model: str | None = None
    openai_model: str | None = None
    anthropic_model: str | None = None


@router.put("/llm-config")
async def set_llm_config(body: LLMConfigBody, _=Depends(require_admin)):
    """Set the active LLM provider at runtime (persisted in data volume)."""
    from fastapi import HTTPException
    valid = {"auto", "ollama", "openai", "anthropic"}
    if body.provider not in valid:
        raise HTTPException(400, f"provider doit être parmi : {', '.join(valid)}")
    llm.set_override(
        provider=body.provider,
        ollama_model=body.ollama_model,
        openai_model=body.openai_model,
        anthropic_model=body.anthropic_model,
    )
    active = await llm.active_provider()
    return {"provider": body.provider, "active": active}


@router.get("/llm-provider")
async def get_llm_provider():
    return await llm.active_provider()


@router.get("/stats")
async def stats():
    categories: dict[str, int] = {}
    for agent in AGENT_REGISTRY.values():
        categories[agent.category] = categories.get(agent.category, 0) + 1
    return {
        "total_agents": len(AGENT_REGISTRY),
        "by_category": categories,
        "agent_ids": list(AGENT_REGISTRY.keys()),
    }


@router.get("/tools")
async def list_tools():
    """List all registered tool plugins."""
    from app.plugins import list_tools as _list
    return {"tools": _list()}


@router.post("/tools/run")
async def run_tool(body: dict):
    """Run a tool plugin by name."""
    from app.plugins import run_tool as _run
    name = body.get("name", "")
    params = body.get("params", {})
    result = await _run(name, params)
    return {"tool": name, "result": result}


@router.get("/analytics")
async def analytics(db: AsyncSession = Depends(get_db)):
    """Real daily task counts for the last 7 days + top agents."""
    today = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
    days = []
    for i in range(6, -1, -1):
        day_start = today - timedelta(days=i)
        day_end = day_start + timedelta(days=1)
        result = await db.execute(
            select(func.count(Task.id)).where(
                Task.created_at >= day_start, Task.created_at < day_end
            )
        )
        count = result.scalar_one()
        days.append({
            "day": day_start.strftime("%a"),
            "date": day_start.strftime("%Y-%m-%d"),
            "tasks": count,
        })

    # Top 5 agents by usage
    top = await db.execute(
        select(Task.agent_id, func.count(Task.id).label("runs"))
        .group_by(Task.agent_id)
        .order_by(func.count(Task.id).desc())
        .limit(5)
    )
    top_agents = [{"agent_id": r.agent_id, "runs": r.runs} for r in top.all()]

    # Success rate overall
    total = (await db.execute(select(func.count(Task.id)))).scalar_one()
    success = (await db.execute(
        select(func.count(Task.id)).where(Task.status == "completed")
    )).scalar_one()

    return {
        "daily": days,
        "top_agents": top_agents,
        "total_tasks": total,
        "success_rate": round(success / total * 100) if total else 0,
    }


@router.get("/status")
async def public_status(db: AsyncSession = Depends(get_db)):
    """Public status endpoint — no auth required. Exposes uptime indicators."""
    ollama_ok = await ollama.health()
    active_provider = await llm.active_provider()

    total_tasks = (await db.execute(select(func.count(Task.id)))).scalar_one()
    success = (await db.execute(
        select(func.count(Task.id)).where(Task.status == "completed")
    )).scalar_one()
    failed = (await db.execute(
        select(func.count(Task.id)).where(Task.status == "error")
    )).scalar_one()
    pending = (await db.execute(
        select(func.count(Task.id)).where(Task.status == "pending")
    )).scalar_one()

    return {
        "status": "operational",
        "version": "1.0.0",
        "timestamp": datetime.utcnow().isoformat(),
        "services": {
            "api": {"status": "operational"},
            "database": {"status": "operational"},
            "ollama": {"status": "operational" if ollama_ok else "degraded"},
            "llm": {"status": "operational", "provider": active_provider.get("provider", "unknown")},
        },
        "agents": len(AGENT_REGISTRY),
        "tasks": {
            "total": total_tasks,
            "success": success,
            "failed": failed,
            "pending": pending,
            "success_rate": round(success / total_tasks * 100) if total_tasks else 100,
        },
    }


@router.get("/analytics/export")
async def export_analytics_pdf(
    db: AsyncSession = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Generate a PDF analytics report."""
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
    from reportlab.lib import colors
    import io

    today = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
    daily = []
    for i in range(6, -1, -1):
        day_start = today - timedelta(days=i)
        day_end = day_start + timedelta(days=1)
        count = (await db.execute(
            select(func.count(Task.id)).where(
                Task.created_at >= day_start, Task.created_at < day_end
            )
        )).scalar_one()
        daily.append([day_start.strftime("%a %d/%m"), str(count)])

    total = (await db.execute(select(func.count(Task.id)))).scalar_one()
    success = (await db.execute(
        select(func.count(Task.id)).where(Task.status == "completed")
    )).scalar_one()
    top = await db.execute(
        select(Task.agent_id, func.count(Task.id).label("runs"))
        .group_by(Task.agent_id).order_by(func.count(Task.id).desc()).limit(5)
    )
    top_agents = top.all()

    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, topMargin=40, bottomMargin=40)
    styles = getSampleStyleSheet()
    story = []

    story.append(Paragraph("ORION AI — Rapport Analytics", styles["Title"]))
    story.append(Paragraph(f"Généré le {datetime.utcnow().strftime('%d/%m/%Y %H:%M')} UTC", styles["Normal"]))
    story.append(Spacer(1, 20))

    story.append(Paragraph("Résumé", styles["Heading2"]))
    story.append(Table(
        [["Total tâches", "Taux de succès"],
         [str(total), f"{round(success/total*100) if total else 0}%"]],
        colWidths=[200, 200],
        style=TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#6366f1")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("ALIGN", (0, 0), (-1, -1), "CENTER"),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.whitesmoke, colors.white]),
        ]),
    ))
    story.append(Spacer(1, 20))

    story.append(Paragraph("Tâches par jour (7 derniers jours)", styles["Heading2"]))
    story.append(Table(
        [["Jour", "Tâches"]] + daily,
        colWidths=[200, 200],
        style=TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#6366f1")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("ALIGN", (0, 0), (-1, -1), "CENTER"),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.whitesmoke, colors.white]),
        ]),
    ))
    story.append(Spacer(1, 20))

    if top_agents:
        story.append(Paragraph("Top agents", styles["Heading2"]))
        story.append(Table(
            [["Agent", "Runs"]] + [[r.agent_id, str(r.runs)] for r in top_agents],
            colWidths=[300, 100],
            style=TableStyle([
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#6366f1")),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                ("ALIGN", (0, 0), (-1, -1), "CENTER"),
                ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
                ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.whitesmoke, colors.white]),
            ]),
        ))

    doc.build(story)
    buf.seek(0)
    return StreamingResponse(
        buf,
        media_type="application/pdf",
        headers={"Content-Disposition": "attachment; filename=orion_analytics.pdf"},
    )


class RetentionConfig(BaseModel):
    days: int = Field(..., ge=0, le=3650, description="0 = disabled, 1-3650 = auto-delete tasks older than N days")


@router.get("/retention")
async def get_retention(current_user=Depends(get_current_user)):
    days = _retention_settings.get(current_user.id, 0)
    return {"days": days, "enabled": days > 0}


@router.post("/retention")
async def set_retention(body: RetentionConfig, current_user=Depends(get_current_user)):
    _retention_settings[current_user.id] = body.days
    return {"days": body.days, "enabled": body.days > 0}


@router.post("/purge")
async def purge_old_tasks(
    body: RetentionConfig,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Delete tasks (and their logs/metrics) older than N days for the current user."""
    if body.days <= 0:
        return {"deleted": 0, "message": "Aucune suppression (jours = 0)"}

    cutoff = datetime.utcnow() - timedelta(days=body.days)

    # Find matching task ids first
    task_rows = await db.execute(
        select(Task.id).where(Task.user_id == current_user.id, Task.created_at < cutoff)
    )
    task_ids = [r[0] for r in task_rows.all()]

    if not task_ids:
        return {"deleted": 0, "message": f"Aucune tâche antérieure à {body.days} jour(s)"}

    # Delete task logs
    from app.models import TaskLog
    await db.execute(delete(TaskLog).where(TaskLog.task_id.in_(task_ids)))

    # Delete agent metrics tied to these tasks (via task_id if it exists, otherwise skip)
    try:
        await db.execute(delete(AgentMetric).where(AgentMetric.task_id.in_(task_ids)))
    except Exception:
        pass

    # Delete the tasks themselves
    await db.execute(
        delete(Task).where(Task.user_id == current_user.id, Task.created_at < cutoff)
    )
    await db.commit()

    return {
        "deleted": len(task_ids),
        "message": f"{len(task_ids)} tâche(s) supprimée(s) (antérieures à {body.days} jour(s))",
    }


@router.get("/token-usage")
async def token_usage(
    db: AsyncSession = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Return token usage stats per agent and totals for the current user."""
    # Filter via task_id → user_id join
    from app.models import Task as _Task
    user_tasks = await db.execute(select(_Task.id).where(_Task.user_id == current_user.id))
    task_ids = [r[0] for r in user_tasks.all()]

    if not task_ids:
        return {"total_in": 0, "total_out": 0, "total": 0, "by_agent": []}

    rows = await db.execute(
        select(
            AgentMetric.agent_id,
            func.sum(AgentMetric.tokens_in).label("tokens_in"),
            func.sum(AgentMetric.tokens_out).label("tokens_out"),
            func.count(AgentMetric.id).label("runs"),
        )
        .where(AgentMetric.task_id.in_(task_ids))
        .group_by(AgentMetric.agent_id)
        .order_by(func.sum(AgentMetric.tokens_in + AgentMetric.tokens_out).desc())
    )
    by_agent = [
        {"agent_id": r.agent_id, "tokens_in": int(r.tokens_in or 0), "tokens_out": int(r.tokens_out or 0), "runs": r.runs}
        for r in rows.all()
    ]
    total_in = sum(a["tokens_in"] for a in by_agent)
    total_out = sum(a["tokens_out"] for a in by_agent)
    return {"total_in": total_in, "total_out": total_out, "total": total_in + total_out, "by_agent": by_agent}


@router.get("/period-stats")
async def period_stats(
    period: str = "week",
    db: AsyncSession = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Return task stats grouped by period: day, week, month, year."""
    now = datetime.utcnow()

    if period == "day":
        # last 24h grouped by hour
        start = now - timedelta(hours=23)
        buckets = []
        for h in range(23, -1, -1):
            bucket_start = now.replace(minute=0, second=0, microsecond=0) - timedelta(hours=h)
            bucket_end = bucket_start + timedelta(hours=1)
            count = (await db.execute(
                select(func.count(Task.id)).where(
                    Task.user_id == current_user.id,
                    Task.created_at >= bucket_start,
                    Task.created_at < bucket_end,
                )
            )).scalar_one()
            success = (await db.execute(
                select(func.count(Task.id)).where(
                    Task.user_id == current_user.id,
                    Task.status == "completed",
                    Task.created_at >= bucket_start,
                    Task.created_at < bucket_end,
                )
            )).scalar_one()
            buckets.append({"label": bucket_start.strftime("%Hh"), "tasks": count, "success": success})
    elif period == "month":
        # last 30 days grouped by day
        buckets = []
        for i in range(29, -1, -1):
            day_start = (now - timedelta(days=i)).replace(hour=0, minute=0, second=0, microsecond=0)
            day_end = day_start + timedelta(days=1)
            count = (await db.execute(
                select(func.count(Task.id)).where(
                    Task.user_id == current_user.id,
                    Task.created_at >= day_start,
                    Task.created_at < day_end,
                )
            )).scalar_one()
            success = (await db.execute(
                select(func.count(Task.id)).where(
                    Task.user_id == current_user.id,
                    Task.status == "completed",
                    Task.created_at >= day_start,
                    Task.created_at < day_end,
                )
            )).scalar_one()
            buckets.append({"label": day_start.strftime("%d/%m"), "tasks": count, "success": success})
    elif period == "year":
        # last 12 months grouped by month
        buckets = []
        for m in range(11, -1, -1):
            month_date = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0) - timedelta(days=30 * m)
            month_start = month_date.replace(day=1)
            if month_start.month == 12:
                month_end = month_start.replace(year=month_start.year + 1, month=1)
            else:
                month_end = month_start.replace(month=month_start.month + 1)
            count = (await db.execute(
                select(func.count(Task.id)).where(
                    Task.user_id == current_user.id,
                    Task.created_at >= month_start,
                    Task.created_at < month_end,
                )
            )).scalar_one()
            success = (await db.execute(
                select(func.count(Task.id)).where(
                    Task.user_id == current_user.id,
                    Task.status == "completed",
                    Task.created_at >= month_start,
                    Task.created_at < month_end,
                )
            )).scalar_one()
            buckets.append({"label": month_start.strftime("%b %Y"), "tasks": count, "success": success})
    else:
        # week (default): last 7 days
        buckets = []
        for i in range(6, -1, -1):
            day_start = (now - timedelta(days=i)).replace(hour=0, minute=0, second=0, microsecond=0)
            day_end = day_start + timedelta(days=1)
            count = (await db.execute(
                select(func.count(Task.id)).where(
                    Task.user_id == current_user.id,
                    Task.created_at >= day_start,
                    Task.created_at < day_end,
                )
            )).scalar_one()
            success = (await db.execute(
                select(func.count(Task.id)).where(
                    Task.user_id == current_user.id,
                    Task.status == "completed",
                    Task.created_at >= day_start,
                    Task.created_at < day_end,
                )
            )).scalar_one()
            buckets.append({"label": day_start.strftime("%a"), "tasks": count, "success": success})

    total = sum(b["tasks"] for b in buckets)
    total_success = sum(b["success"] for b in buckets)
    return {
        "period": period,
        "buckets": buckets,
        "total": total,
        "success": total_success,
        "failed": total - total_success,
        "success_rate": round(total_success / total * 100) if total else 0,
    }


@router.get("/ollama/models")
async def ollama_models(_=Depends(get_current_user)):
    """List locally available Ollama models with full detail."""
    return {"models": await ollama.list_models_detail()}


class PullModelBody(BaseModel):
    name: str = Field(..., min_length=1)


@router.post("/ollama/pull")
async def ollama_pull(body: PullModelBody, _=Depends(get_current_user)):
    """Pull an Ollama model. Blocks until done (can take several minutes)."""
    try:
        result = await ollama.pull_model(body.name)
        return {"status": result.get("status", "success"), "model": body.name}
    except Exception as e:
        from fastapi import HTTPException
        raise HTTPException(status_code=502, detail=f"Ollama pull failed: {e}")


@router.delete("/ollama/models")
async def ollama_delete(name: str, _=Depends(get_current_user)):
    """Delete a local Ollama model (pass name as query param)."""
    from fastapi import HTTPException
    ok = await ollama.delete_model(name)
    if not ok:
        raise HTTPException(status_code=502, detail="Ollama delete failed")
    return {"deleted": name}


@router.get("/metrics")
async def get_metrics(db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(
            AgentMetric.agent_id,
            func.count(AgentMetric.id).label("total_runs"),
            func.sum(case((AgentMetric.status == "success", 1), else_=0)).label("success_count"),
            func.avg(AgentMetric.execution_time_ms).label("avg_time_ms"),
            func.max(AgentMetric.created_at).label("last_run"),
        )
        .group_by(AgentMetric.agent_id)
        .order_by(func.count(AgentMetric.id).desc())
        .limit(20)
    )
    rows = result.all()
    return [
        {
            "agent_id": r.agent_id,
            "total_runs": r.total_runs,
            "success_count": int(r.success_count or 0),
            "fail_count": r.total_runs - int(r.success_count or 0),
            "success_rate": round(int(r.success_count or 0) / r.total_runs * 100) if r.total_runs else 0,
            "avg_time_ms": round(r.avg_time_ms) if r.avg_time_ms else 0,
            "last_run": r.last_run,
        }
        for r in rows
    ]


@router.post("/smtp/test")
async def smtp_test(current_user=Depends(require_admin)):
    """Send a test email to the current admin user."""
    from app.config import settings
    if not settings.smtp_host or not settings.smtp_from:
        from fastapi import HTTPException
        raise HTTPException(400, "SMTP non configuré (SMTP_HOST / SMTP_FROM manquants)")
    if not current_user.email:
        from fastapi import HTTPException
        raise HTTPException(400, "Votre compte n'a pas d'adresse email")
    from app.notifier import send_email
    await send_email(
        current_user.email,
        "ORION AI — Test de notification SMTP",
        "<h2 style='color:#5B6EF5'>Test SMTP réussi ✓</h2><p>Vos notifications par email sont correctement configurées.</p>",
    )
    return {"status": "ok", "sent_to": current_user.email}


@router.get("/smtp/status")
async def smtp_status(current_user=Depends(require_admin)):
    """Return SMTP configuration status (no secrets)."""
    from app.config import settings
    return {
        "configured": bool(settings.smtp_host and settings.smtp_from),
        "host": settings.smtp_host or None,
        "port": settings.smtp_port,
        "from": settings.smtp_from or None,
        "tls": settings.smtp_tls,
        "notify_on": settings.notify_on,
    }
