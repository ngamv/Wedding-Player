import shutil
import os
from datetime import datetime, date, timedelta
from fastapi import APIRouter, Depends
from fastapi.responses import FileResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from pydantic import BaseModel
from app.database import get_db
from app.models import User, Task, AgentMetric
from app.auth import require_admin
from app.config import settings

router = APIRouter(prefix="/admin", tags=["admin"])


class RoleUpdate(BaseModel):
    role: str


@router.get("/users")
async def admin_list_users(
    db: AsyncSession = Depends(get_db),
    _: User = Depends(require_admin),
):
    result = await db.execute(
        select(
            User.id, User.username, User.email, User.role, User.is_active, User.created_at,
            func.count(Task.id).label("task_count"),
        )
        .outerjoin(Task, Task.user_id == User.id)
        .group_by(User.id)
        .order_by(User.created_at.desc())
    )
    rows = result.all()
    return [
        {
            "id": r.id,
            "username": r.username,
            "email": r.email,
            "role": r.role,
            "is_active": r.is_active,
            "created_at": r.created_at,
            "task_count": r.task_count,
        }
        for r in rows
    ]


@router.patch("/users/{user_id}/role")
async def admin_set_role(
    user_id: int,
    body: RoleUpdate,
    db: AsyncSession = Depends(get_db),
    _: User = Depends(require_admin),
):
    if body.role not in ("admin", "user", "readonly"):
        from fastapi import HTTPException
        raise HTTPException(400, "Rôle invalide")
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if not user:
        from fastapi import HTTPException
        raise HTTPException(404, "Utilisateur introuvable")
    user.role = body.role
    await db.commit()
    return {"id": user.id, "username": user.username, "role": user.role}


@router.patch("/users/{user_id}/active")
async def admin_toggle_active(
    user_id: int,
    db: AsyncSession = Depends(get_db),
    current: User = Depends(require_admin),
):
    if user_id == current.id:
        from fastapi import HTTPException
        raise HTTPException(400, "Impossible de désactiver votre propre compte")
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if not user:
        from fastapi import HTTPException
        raise HTTPException(404, "Utilisateur introuvable")
    user.is_active = not user.is_active
    await db.commit()
    return {"id": user.id, "username": user.username, "is_active": user.is_active}


@router.delete("/users/{user_id}")
async def admin_delete_user(
    user_id: int,
    db: AsyncSession = Depends(get_db),
    current: User = Depends(require_admin),
):
    if user_id == current.id:
        from fastapi import HTTPException
        raise HTTPException(400, "Impossible de supprimer votre propre compte")
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if not user:
        from fastapi import HTTPException
        raise HTTPException(404, "Utilisateur introuvable")
    await db.delete(user)
    await db.commit()
    return {"deleted": user_id}


@router.get("/backup/download/{filename}")
async def download_backup_by_name(filename: str, _: User = Depends(require_admin)):
    import re
    from fastapi import HTTPException
    # Sanitize — allow only expected filename pattern
    if not re.match(r"^orion_\d{8}_\d{6}\.db$", filename):
        raise HTTPException(400, "Nom de fichier invalide")
    path = os.path.join(settings.backup_dir, filename)
    if not os.path.isfile(path):
        raise HTTPException(404, "Backup introuvable")
    return FileResponse(path, filename=filename, media_type="application/octet-stream")


@router.get("/stats")
async def admin_stats(
    db: AsyncSession = Depends(get_db),
    _: User = Depends(require_admin),
):
    total_users = (await db.execute(select(func.count(User.id)))).scalar_one()
    total_tasks = (await db.execute(select(func.count(Task.id)))).scalar_one()
    total_runs = (await db.execute(select(func.count(AgentMetric.id)))).scalar_one()

    today_start = datetime.combine(date.today(), datetime.min.time())
    tasks_today = (await db.execute(
        select(func.count(Task.id)).where(Task.created_at >= today_start)
    )).scalar_one()

    success_count = (await db.execute(
        select(func.count(AgentMetric.id)).where(AgentMetric.status == "success")
    )).scalar_one()

    return {
        "total_users": total_users,
        "total_tasks": total_tasks,
        "tasks_today": tasks_today,
        "total_runs": total_runs,
        "global_success_rate": round(success_count / total_runs * 100) if total_runs else 0,
    }


@router.post("/backup")
async def create_backup(_: User = Depends(require_admin)):
    """Create a timestamped copy of the SQLite database."""
    from fastapi import HTTPException
    # Derive DB file path from DATABASE_URL (sqlite+aiosqlite:///./orion.db → ./orion.db)
    db_url = settings.database_url
    db_path = db_url.replace("sqlite+aiosqlite:///", "").replace("sqlite:///", "")
    if not os.path.exists(db_path):
        raise HTTPException(404, f"Base de données introuvable : {db_path}")

    backup_dir = settings.backup_dir
    os.makedirs(backup_dir, exist_ok=True)

    ts = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    dest = os.path.join(backup_dir, f"orion_{ts}.db")
    shutil.copy2(db_path, dest)

    # Prune backups older than backup_keep_days
    cutoff = datetime.utcnow() - timedelta(days=settings.backup_keep_days)
    pruned = 0
    for f in os.listdir(backup_dir):
        fp = os.path.join(backup_dir, f)
        if os.path.isfile(fp) and os.path.getmtime(fp) < cutoff.timestamp():
            os.remove(fp)
            pruned += 1

    size_kb = round(os.path.getsize(dest) / 1024, 1)
    return {"backup": dest, "size_kb": size_kb, "pruned": pruned, "created_at": ts}


@router.get("/backup/download")
async def download_latest_backup(_: User = Depends(require_admin)):
    """Download the most recent backup file."""
    from fastapi import HTTPException
    backup_dir = settings.backup_dir
    if not os.path.isdir(backup_dir):
        raise HTTPException(404, "Aucun backup disponible")
    files = sorted(
        [f for f in os.listdir(backup_dir) if f.endswith(".db")],
        reverse=True,
    )
    if not files:
        raise HTTPException(404, "Aucun backup disponible")
    path = os.path.join(backup_dir, files[0])
    return FileResponse(path, filename=files[0], media_type="application/octet-stream")


@router.get("/backup/list")
async def list_backups(_: User = Depends(require_admin)):
    backup_dir = settings.backup_dir
    if not os.path.isdir(backup_dir):
        return {"backups": []}
    files = sorted(
        [f for f in os.listdir(backup_dir) if f.endswith(".db")],
        reverse=True,
    )
    return {
        "backups": [
            {
                "name": f,
                "size_kb": round(os.path.getsize(os.path.join(backup_dir, f)) / 1024, 1),
                "created_at": datetime.utcfromtimestamp(
                    os.path.getmtime(os.path.join(backup_dir, f))
                ).isoformat(),
            }
            for f in files
        ]
    }
