"""Global full-text search across agents, tasks, workflows, custom agents, and memory."""
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, or_
from app.database import get_db
from app.models import Task, Workflow, CustomAgent, Memory, User
from app.agents import AGENT_REGISTRY
from app.auth import get_current_user

router = APIRouter(prefix="/search", tags=["search"])


@router.get("/")
async def global_search(
    q: str = Query(..., min_length=1, max_length=100),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    term = f"%{q.lower()}%"

    # Tasks (user-scoped) — search title AND output snippet
    task_rows = await db.execute(
        select(Task).where(
            Task.user_id == current_user.id,
            Task.title.ilike(term),
        ).order_by(Task.created_at.desc()).limit(8)
    )
    tasks = []
    for t in task_rows.scalars():
        output_snippet = ""
        if isinstance(t.output_data, dict):
            result_val = t.output_data.get("result", "")
            if result_val:
                output_snippet = str(result_val)[:80]
        tasks.append({
            "type": "task", "id": t.id, "title": t.title,
            "subtitle": output_snippet or t.agent_id,
            "status": t.status, "url": "/tasks",
        })

    # Workflows (user-scoped)
    wf_rows = await db.execute(
        select(Workflow).where(
            Workflow.user_id == current_user.id,
            Workflow.name.ilike(term),
        ).limit(5)
    )
    workflows = [
        {"type": "workflow", "id": w.id, "title": w.name, "subtitle": w.description[:60],
         "url": "/workflows"}
        for w in wf_rows.scalars()
    ]

    # Custom agents (user-scoped + public)
    ca_rows = await db.execute(
        select(CustomAgent).where(
            (CustomAgent.user_id == current_user.id) | (CustomAgent.is_public == True),
            CustomAgent.name.ilike(term),
        ).limit(5)
    )
    custom_agents = [
        {"type": "custom_agent", "id": ca.agent_id, "title": ca.name,
         "subtitle": ca.description[:60], "url": "/custom-agents"}
        for ca in ca_rows.scalars()
    ]

    # Built-in agents (in-memory)
    agents = [
        {"type": "agent", "id": a.id, "title": a.name,
         "subtitle": a.description[:60], "url": "/agents"}
        for a in AGENT_REGISTRY.values()
        if q.lower() in a.name.lower() or q.lower() in a.description.lower()
    ][:5]

    # Memory (global — not user-scoped, keys/values are not private)
    mem_rows = await db.execute(
        select(Memory).where(
            or_(Memory.key.ilike(term), Memory.value.ilike(term))
        ).limit(5)
    )
    memories = [
        {"type": "memory", "id": m.id, "title": m.key,
         "subtitle": m.value[:80], "url": "/agents"}
        for m in mem_rows.scalars()
    ]

    return {
        "query": q,
        "results": tasks + workflows + custom_agents + agents + memories,
        "counts": {
            "tasks": len(tasks),
            "workflows": len(workflows),
            "custom_agents": len(custom_agents),
            "agents": len(agents),
            "memories": len(memories),
        },
    }
