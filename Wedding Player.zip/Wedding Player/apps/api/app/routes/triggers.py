import secrets
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel
from app.database import get_db
from app.models import InboundTrigger, Task, TaskStatus, User
from app.auth import get_current_user
from app.orchestrator import route_and_run

router = APIRouter(tags=["triggers"])


class TriggerCreate(BaseModel):
    name: str
    agent_id: str


class TriggerOut(BaseModel):
    id: int
    name: str
    agent_id: str
    token: str
    is_active: bool
    last_triggered_at: datetime | None
    created_at: datetime

    model_config = {"from_attributes": True}


@router.get("/triggers", response_model=list[TriggerOut])
async def list_triggers(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(InboundTrigger).where(InboundTrigger.user_id == current_user.id)
    )
    return result.scalars().all()


@router.post("/triggers", response_model=TriggerOut, status_code=201)
async def create_trigger(
    body: TriggerCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    trigger = InboundTrigger(
        user_id=current_user.id,
        name=body.name,
        agent_id=body.agent_id,
        token=secrets.token_urlsafe(32),
    )
    db.add(trigger)
    await db.commit()
    await db.refresh(trigger)
    return trigger


@router.delete("/triggers/{trigger_id}", status_code=204)
async def delete_trigger(
    trigger_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(InboundTrigger).where(
            InboundTrigger.id == trigger_id,
            InboundTrigger.user_id == current_user.id,
        )
    )
    trigger = result.scalar_one_or_none()
    if not trigger:
        raise HTTPException(404, "Trigger introuvable")
    await db.delete(trigger)
    await db.commit()


@router.post("/trigger/{token}")
async def fire_trigger(token: str, request: Request, db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(InboundTrigger).where(
            InboundTrigger.token == token, InboundTrigger.is_active == True
        )
    )
    trigger = result.scalar_one_or_none()
    if not trigger:
        raise HTTPException(404, "Trigger introuvable ou inactif")

    try:
        payload = await request.json()
    except Exception:
        payload = {}

    prompt = payload.get("prompt", f"Trigger webhook: {trigger.name}")
    task = Task(
        user_id=trigger.user_id,
        title=f"[Trigger] {trigger.name}",
        agent_id=trigger.agent_id,
        status=TaskStatus.running,
        input_data={"prompt": prompt, "webhook_payload": payload},
    )
    db.add(task)
    await db.commit()
    await db.refresh(task)

    import asyncio
    asyncio.create_task(route_and_run(prompt, trigger.agent_id, {"task_id": task.id, "webhook_payload": payload}))

    trigger.last_triggered_at = datetime.utcnow()
    db.add(trigger)
    await db.commit()

    return {"task_id": task.id, "status": "queued"}
