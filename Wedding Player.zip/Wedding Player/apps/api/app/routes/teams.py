"""Team / multi-tenant routes."""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_
from pydantic import BaseModel
from app.database import get_db
from app.models import Team, TeamMember, User, CustomAgent
from app.auth import get_current_user

router = APIRouter(prefix="/teams", tags=["teams"])


class TeamCreate(BaseModel):
    name: str
    description: str = ""


class InviteBody(BaseModel):
    username: str
    role: str = "member"  # member | viewer


def _check_role(role: str) -> None:
    if role not in ("member", "viewer"):
        raise HTTPException(400, "Rôle invalide (member | viewer)")


async def _get_team_or_404(team_id: int, db: AsyncSession) -> Team:
    result = await db.execute(select(Team).where(Team.id == team_id))
    t = result.scalar_one_or_none()
    if not t:
        raise HTTPException(404, "Équipe introuvable")
    return t


async def _require_owner(team: Team, current_user: User) -> None:
    if team.owner_id != current_user.id:
        raise HTTPException(403, "Seul le propriétaire peut effectuer cette action")


@router.get("/")
async def list_teams(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    owned = await db.execute(select(Team).where(Team.owner_id == current_user.id))
    member_of = await db.execute(
        select(Team).join(TeamMember, TeamMember.team_id == Team.id)
        .where(TeamMember.user_id == current_user.id)
    )
    teams = {t.id: t for t in list(owned.scalars()) + list(member_of.scalars())}
    return [_serialize(t, current_user) for t in teams.values()]


@router.post("/", status_code=201)
async def create_team(
    body: TeamCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    existing = await db.execute(select(Team).where(Team.name == body.name))
    if existing.scalar_one_or_none():
        raise HTTPException(409, "Une équipe avec ce nom existe déjà")
    team = Team(name=body.name, description=body.description, owner_id=current_user.id)
    db.add(team)
    await db.flush()
    member = TeamMember(team_id=team.id, user_id=current_user.id, role="owner")
    db.add(member)
    await db.commit()
    await db.refresh(team)
    return _serialize(team, current_user)


@router.get("/{team_id}")
async def get_team(
    team_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    team = await _get_team_or_404(team_id, db)
    await _assert_member(team_id, current_user.id, db)
    members = await _get_members(team_id, db)
    return {**_serialize(team, current_user), "members": members}


@router.post("/{team_id}/invite")
async def invite_member(
    team_id: int,
    body: InviteBody,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    _check_role(body.role)
    team = await _get_team_or_404(team_id, db)
    await _require_owner(team, current_user)

    result = await db.execute(select(User).where(User.username == body.username))
    target = result.scalar_one_or_none()
    if not target:
        raise HTTPException(404, f"Utilisateur '{body.username}' introuvable")

    existing = await db.execute(
        select(TeamMember).where(and_(TeamMember.team_id == team_id, TeamMember.user_id == target.id))
    )
    if existing.scalar_one_or_none():
        raise HTTPException(409, "Cet utilisateur est déjà membre")

    db.add(TeamMember(team_id=team_id, user_id=target.id, role=body.role))
    await db.commit()
    return {"message": f"{body.username} ajouté avec le rôle {body.role}"}


@router.delete("/{team_id}/members/{user_id}", status_code=204)
async def remove_member(
    team_id: int,
    user_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    team = await _get_team_or_404(team_id, db)
    await _require_owner(team, current_user)
    if user_id == current_user.id:
        raise HTTPException(400, "Le propriétaire ne peut pas se retirer")
    result = await db.execute(
        select(TeamMember).where(and_(TeamMember.team_id == team_id, TeamMember.user_id == user_id))
    )
    member = result.scalar_one_or_none()
    if not member:
        raise HTTPException(404, "Membre introuvable")
    await db.delete(member)
    await db.commit()


@router.delete("/{team_id}", status_code=204)
async def delete_team(
    team_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    team = await _get_team_or_404(team_id, db)
    await _require_owner(team, current_user)
    await db.execute(
        TeamMember.__table__.delete().where(TeamMember.team_id == team_id)
    )
    await db.delete(team)
    await db.commit()


# ── Helpers ────────────────────────────────────────────────────────────────

def _serialize(t: Team, current_user: User) -> dict:
    return {
        "id": t.id,
        "name": t.name,
        "description": t.description,
        "owner_id": t.owner_id,
        "is_owner": t.owner_id == current_user.id,
        "created_at": t.created_at,
    }


async def _assert_member(team_id: int, user_id: int, db: AsyncSession) -> None:
    result = await db.execute(
        select(TeamMember).where(and_(TeamMember.team_id == team_id, TeamMember.user_id == user_id))
    )
    if not result.scalar_one_or_none():
        raise HTTPException(403, "Vous n'êtes pas membre de cette équipe")


async def _get_members(team_id: int, db: AsyncSession) -> list[dict]:
    rows = await db.execute(
        select(TeamMember, User)
        .join(User, User.id == TeamMember.user_id)
        .where(TeamMember.team_id == team_id)
    )
    return [
        {"user_id": m.user_id, "username": u.username, "email": u.email, "role": m.role, "joined_at": m.joined_at}
        for m, u in rows.all()
    ]
