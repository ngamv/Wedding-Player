"""
Skills — réutilisable capabilities that agents can invoke.
Built-in skills: summarize, translate, extract_json, web_search, scrape_url,
                 http_request, send_email, count_tokens
Custom skills: user-defined HTTP endpoints stored in DB.
"""
import json
import re
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, delete
from pydantic import BaseModel
from app.database import get_db
from app.models import Skill, User
from app.auth import get_current_user
from app import llm

router = APIRouter(prefix="/skills", tags=["skills"], redirect_slashes=False)

# ---------------------------------------------------------------------------
# Built-in skill catalogue
# ---------------------------------------------------------------------------

BUILTIN_SKILLS: dict[str, dict] = {
    "summarize": {
        "name": "Résumé",
        "description": "Résume un texte en quelques phrases clés via LLM",
        "icon": "FileText",
        "category": "ai",
        "params": [
            {"name": "text", "type": "textarea", "required": True, "label": "Texte à résumer"},
            {"name": "language", "type": "text", "required": False, "label": "Langue de sortie", "default": "français"},
        ],
    },
    "translate": {
        "name": "Traduction",
        "description": "Traduit un texte vers une langue cible via LLM",
        "icon": "Languages",
        "category": "ai",
        "params": [
            {"name": "text", "type": "textarea", "required": True, "label": "Texte à traduire"},
            {"name": "target_lang", "type": "text", "required": True, "label": "Langue cible", "default": "English"},
        ],
    },
    "extract_json": {
        "name": "Extraction JSON",
        "description": "Extrait des données structurées depuis un texte libre via LLM",
        "icon": "Braces",
        "category": "ai",
        "params": [
            {"name": "text", "type": "textarea", "required": True, "label": "Texte source"},
            {"name": "schema", "type": "text", "required": True, "label": "Structure souhaitée", "placeholder": "{nom, email, age}"},
        ],
    },
    "web_search": {
        "name": "Recherche web",
        "description": "Recherche sur DuckDuckGo (sans clé API)",
        "icon": "Search",
        "category": "web",
        "params": [
            {"name": "query", "type": "text", "required": True, "label": "Requête"},
        ],
    },
    "scrape_url": {
        "name": "Scraping URL",
        "description": "Récupère et parse le contenu textuel d'une URL",
        "icon": "Globe",
        "category": "web",
        "params": [
            {"name": "url", "type": "text", "required": True, "label": "URL à scraper"},
        ],
    },
    "http_request": {
        "name": "Requête HTTP",
        "description": "Effectue une requête HTTP vers n'importe quelle API externe",
        "icon": "Plug",
        "category": "web",
        "params": [
            {"name": "url", "type": "text", "required": True, "label": "URL"},
            {"name": "method", "type": "select", "options": ["GET", "POST", "PUT", "DELETE", "PATCH"],
             "required": True, "label": "Méthode", "default": "GET"},
            {"name": "headers", "type": "json", "required": False, "label": "Headers (JSON)"},
            {"name": "body", "type": "json", "required": False, "label": "Body (JSON)"},
        ],
    },
    "send_email": {
        "name": "Envoyer un email",
        "description": "Envoie un email via le SMTP configuré dans .env",
        "icon": "Mail",
        "category": "communication",
        "params": [
            {"name": "to", "type": "text", "required": True, "label": "Destinataire"},
            {"name": "subject", "type": "text", "required": True, "label": "Objet"},
            {"name": "body", "type": "textarea", "required": True, "label": "Corps du message"},
        ],
    },
    "count_tokens": {
        "name": "Compter les tokens",
        "description": "Estime le nombre de tokens dans un texte (approximation GPT)",
        "icon": "Hash",
        "category": "utility",
        "params": [
            {"name": "text", "type": "textarea", "required": True, "label": "Texte à analyser"},
        ],
    },
    "format_date": {
        "name": "Formater une date",
        "description": "Parse et reformate une date dans différents formats",
        "icon": "Calendar",
        "category": "utility",
        "params": [
            {"name": "date", "type": "text", "required": True, "label": "Date", "placeholder": "2024-01-15T10:00:00"},
            {"name": "format", "type": "select", "options": ["ISO", "DD/MM/YYYY", "MM/DD/YYYY", "relative"],
             "required": False, "label": "Format de sortie", "default": "DD/MM/YYYY"},
        ],
    },
    "word_count": {
        "name": "Statistiques texte",
        "description": "Compte mots, phrases, paragraphes et estime le temps de lecture",
        "icon": "BarChart2",
        "category": "utility",
        "params": [
            {"name": "text", "type": "textarea", "required": True, "label": "Texte à analyser"},
        ],
    },
    "sentiment": {
        "name": "Analyse de sentiment",
        "description": "Détecte le sentiment (positif/négatif/neutre) et l'émotion dominante via LLM",
        "icon": "Smile",
        "category": "ai",
        "params": [
            {"name": "text", "type": "textarea", "required": True, "label": "Texte à analyser"},
        ],
    },
    "rewrite": {
        "name": "Reformulation",
        "description": "Réécrit un texte avec un ton différent via LLM",
        "icon": "PenLine",
        "category": "ai",
        "params": [
            {"name": "text", "type": "textarea", "required": True, "label": "Texte à reformuler"},
            {"name": "tone", "type": "select", "options": ["professionnel", "amical", "persuasif", "simple", "formel", "enthousiaste"],
             "required": True, "label": "Ton", "default": "professionnel"},
        ],
    },
    "keywords": {
        "name": "Extraction de mots-clés",
        "description": "Extrait les mots-clés et sujets principaux d'un texte via LLM",
        "icon": "Tag",
        "category": "ai",
        "params": [
            {"name": "text", "type": "textarea", "required": True, "label": "Texte source"},
            {"name": "count", "type": "text", "required": False, "label": "Nombre de mots-clés", "default": "10"},
        ],
    },
    "hash_text": {
        "name": "Hash de texte",
        "description": "Calcule le hash SHA-256, SHA-1 ou MD5 d'un texte",
        "icon": "Lock",
        "category": "utility",
        "params": [
            {"name": "text", "type": "textarea", "required": True, "label": "Texte à hasher"},
            {"name": "algorithm", "type": "select", "options": ["sha256", "sha1", "md5"],
             "required": True, "label": "Algorithme", "default": "sha256"},
        ],
    },
    "base64": {
        "name": "Base64",
        "description": "Encode ou décode un texte en Base64",
        "icon": "Binary",
        "category": "utility",
        "params": [
            {"name": "text", "type": "textarea", "required": True, "label": "Texte"},
            {"name": "mode", "type": "select", "options": ["encoder", "décoder"],
             "required": True, "label": "Mode", "default": "encoder"},
        ],
    },
    "generate_password": {
        "name": "Générateur de mot de passe",
        "description": "Génère un mot de passe aléatoire sécurisé",
        "icon": "KeyRound",
        "category": "utility",
        "params": [
            {"name": "length", "type": "text", "required": False, "label": "Longueur", "default": "16"},
            {"name": "symbols", "type": "select", "options": ["oui", "non"],
             "required": False, "label": "Symboles", "default": "oui"},
        ],
    },
    "regex_extract": {
        "name": "Extraction regex",
        "description": "Extrait toutes les correspondances d'une expression régulière dans un texte",
        "icon": "Regex",
        "category": "utility",
        "params": [
            {"name": "text", "type": "textarea", "required": True, "label": "Texte source"},
            {"name": "pattern", "type": "text", "required": True, "label": "Expression régulière", "placeholder": r"[\w.]+@[\w.]+"},
        ],
    },
    "calculate": {
        "name": "Calculatrice",
        "description": "Évalue une expression mathématique (opérations, puissances, racines…)",
        "icon": "Calculator",
        "category": "utility",
        "params": [
            {"name": "expression", "type": "text", "required": True, "label": "Expression", "placeholder": "(12 + 8) * 3 / 2"},
        ],
    },
}


# ---------------------------------------------------------------------------
# Built-in execution functions
# ---------------------------------------------------------------------------

async def _run_summarize(params: dict) -> str:
    text = params.get("text", "")
    lang = params.get("language", "français")
    result = await llm.chat(
        [{"role": "user", "content": f"Résume ce texte en 3-5 phrases en {lang} :\n\n{text}"}]
    )
    return result


async def _run_translate(params: dict) -> str:
    text = params.get("text", "")
    target = params.get("target_lang", "English")
    result = await llm.chat(
        [{"role": "user", "content": f"Translate the following text to {target}. Return only the translation, no explanation:\n\n{text}"}]
    )
    return result


async def _run_extract_json(params: dict) -> str:
    text = params.get("text", "")
    schema = params.get("schema", "")
    result = await llm.chat(
        [{"role": "user", "content": f"Extract the following fields from the text and return ONLY valid JSON: {schema}\n\nText:\n{text}"}]
    )
    # Try to parse to validate
    try:
        parsed = json.loads(result)
        return json.dumps(parsed, ensure_ascii=False, indent=2)
    except json.JSONDecodeError:
        # Try to extract JSON block
        m = re.search(r"\{.*\}", result, re.DOTALL)
        return m.group(0) if m else result


async def _searxng_search(query: str) -> str | None:
    """Query a self-hosted SearXNG instance. Returns None if unavailable."""
    from app.config import settings
    if not settings.searxng_url:
        return None
    import httpx
    try:
        async with httpx.AsyncClient(timeout=15) as client:
            resp = await client.get(
                f"{settings.searxng_url.rstrip('/')}/search",
                params={"q": query, "format": "json", "language": "fr"},
                headers={"User-Agent": "ORION-AI/1.0"},
            )
            resp.raise_for_status()
            data = resp.json()
    except Exception:
        return None  # instance down or JSON format disabled → caller falls back

    results = []
    if data.get("answers"):
        results.append(f"**Réponse** : {data['answers'][0]}")
    for r in data.get("results", [])[:6]:
        title = r.get("title", "").strip()
        content = (r.get("content") or "").strip()
        url = r.get("url", "")
        if title:
            results.append(f"- **{title}** — {content}\n  {url}" if content else f"- **{title}**\n  {url}")
    return "\n".join(results) if results else None


async def _run_web_search(params: dict) -> str:
    import httpx
    query = params.get("query", "")

    # Self-hosted first: no query leaves the machine when SearXNG is configured.
    searx = await _searxng_search(query)
    if searx:
        return searx

    url = f"https://api.duckduckgo.com/?q={query}&format=json&no_html=1&skip_disambig=1"
    async with httpx.AsyncClient(timeout=10) as client:
        resp = await client.get(url, headers={"User-Agent": "ORION-AI/1.0"})
        data = resp.json()
    results = []
    if data.get("AbstractText"):
        results.append(f"**{data.get('AbstractSource', 'Source')}**: {data['AbstractText']}")
    for r in data.get("RelatedTopics", [])[:5]:
        if isinstance(r, dict) and r.get("Text"):
            results.append(f"- {r['Text']}")
    if not results:
        return f"Aucun résultat instantané trouvé pour « {query} »."
    return "\n".join(results)


async def _run_scrape_url(params: dict) -> str:
    import httpx
    from bs4 import BeautifulSoup
    url = params.get("url", "")
    if not url.startswith("http"):
        raise ValueError("URL invalide (doit commencer par http:// ou https://)")
    async with httpx.AsyncClient(timeout=15, follow_redirects=True) as client:
        resp = await client.get(url, headers={"User-Agent": "ORION-AI/1.0"})
    soup = BeautifulSoup(resp.text, "html.parser")
    for tag in soup(["script", "style", "nav", "footer", "header"]):
        tag.decompose()
    text = soup.get_text(separator="\n", strip=True)
    # Limit to 3000 chars
    return text[:3000] + ("…" if len(text) > 3000 else "")


async def _run_http_request(params: dict) -> str:
    import httpx
    url = params.get("url", "")
    method = params.get("method", "GET").upper()
    headers_raw = params.get("headers")
    body_raw = params.get("body")
    headers = json.loads(headers_raw) if isinstance(headers_raw, str) and headers_raw.strip() else headers_raw or {}
    body = json.loads(body_raw) if isinstance(body_raw, str) and body_raw.strip() else body_raw
    async with httpx.AsyncClient(timeout=15) as client:
        resp = await client.request(method, url, headers=headers, json=body)
    try:
        return json.dumps(resp.json(), ensure_ascii=False, indent=2)
    except Exception:
        return resp.text[:3000]


async def _run_send_email(params: dict) -> str:
    import aiosmtplib
    from email.mime.text import MIMEText
    from app.config import settings
    if not settings.smtp_host:
        raise RuntimeError("SMTP non configuré. Ajoutez SMTP_HOST dans .env")
    msg = MIMEText(params.get("body", ""), "plain", "utf-8")
    msg["Subject"] = params.get("subject", "(sans objet)")
    msg["From"] = settings.smtp_from or settings.smtp_user
    msg["To"] = params.get("to", "")
    await aiosmtplib.send(
        msg,
        hostname=settings.smtp_host,
        port=settings.smtp_port or 587,
        username=settings.smtp_user or None,
        password=settings.smtp_password or None,
        start_tls=None,  # négociation auto : TLS si le serveur le supporte (Gmail oui, Mailpit non)
    )
    return f"Email envoyé à {params.get('to')}"


def _run_count_tokens(params: dict) -> str:
    text = params.get("text", "")
    # Approximation: 1 token ≈ 4 chars (GPT-style)
    chars = len(text)
    words = len(text.split())
    tokens_approx = chars // 4
    return json.dumps({
        "characters": chars,
        "words": words,
        "tokens_approx": tokens_approx,
        "cost_gpt4_input_usd_approx": round(tokens_approx * 0.00001, 6),
    }, indent=2)


def _run_format_date(params: dict) -> str:
    from datetime import datetime as dt
    raw = params.get("date", "")
    fmt = params.get("format", "DD/MM/YYYY")
    try:
        parsed = dt.fromisoformat(raw.replace("Z", "+00:00"))
    except ValueError:
        return f"Date invalide : {raw}"
    if fmt == "ISO":
        return parsed.isoformat()
    if fmt == "DD/MM/YYYY":
        return parsed.strftime("%d/%m/%Y")
    if fmt == "MM/DD/YYYY":
        return parsed.strftime("%m/%d/%Y")
    if fmt == "relative":
        delta = dt.utcnow() - parsed.replace(tzinfo=None)
        secs = int(delta.total_seconds())
        if secs < 60:
            return f"il y a {secs} secondes"
        if secs < 3600:
            return f"il y a {secs // 60} minutes"
        if secs < 86400:
            return f"il y a {secs // 3600} heures"
        return f"il y a {secs // 86400} jours"
    return parsed.strftime(fmt)


def _run_word_count(params: dict) -> str:
    text = params.get("text", "")
    words = len(text.split())
    sentences = len([s for s in text.split(".") if s.strip()])
    paragraphs = len([p for p in text.split("\n\n") if p.strip()])
    reading_minutes = round(words / 200, 1)
    return json.dumps({
        "words": words,
        "characters": len(text),
        "sentences": sentences,
        "paragraphs": paragraphs,
        "reading_time_minutes": reading_minutes,
    }, indent=2)


async def _run_sentiment(params: dict) -> str:
    text = params.get("text", "")
    result = await llm.chat(
        [{"role": "user", "content": (
            "Analyse le sentiment de ce texte. Réponds UNIQUEMENT en JSON valide avec les clés : "
            '"sentiment" (positif/négatif/neutre/mitigé), "emotion" (émotion dominante), '
            '"confiance" (0-100), "explication" (une phrase).\n\nTexte :\n' + text
        )}]
    )
    try:
        parsed = json.loads(result)
        return json.dumps(parsed, ensure_ascii=False, indent=2)
    except json.JSONDecodeError:
        m = re.search(r"\{.*\}", result, re.DOTALL)
        return m.group(0) if m else result


async def _run_rewrite(params: dict) -> str:
    text = params.get("text", "")
    tone = params.get("tone", "professionnel")
    return await llm.chat(
        [{"role": "user", "content": (
            f"Réécris ce texte avec un ton {tone}, en conservant le sens et la langue d'origine. "
            f"Retourne uniquement le texte réécrit :\n\n{text}"
        )}]
    )


async def _run_keywords(params: dict) -> str:
    text = params.get("text", "")
    count = params.get("count", "10")
    return await llm.chat(
        [{"role": "user", "content": (
            f"Extrais les {count} mots-clés les plus importants de ce texte. "
            f"Retourne une liste à puces, un mot-clé par ligne, sans commentaire :\n\n{text}"
        )}]
    )


def _run_hash_text(params: dict) -> str:
    import hashlib
    text = params.get("text", "").encode("utf-8")
    algo = params.get("algorithm", "sha256")
    if algo not in ("sha256", "sha1", "md5"):
        raise ValueError(f"Algorithme non supporté : {algo}")
    digest = getattr(hashlib, algo)(text).hexdigest()
    return json.dumps({"algorithm": algo, "hash": digest}, indent=2)


def _run_base64(params: dict) -> str:
    import base64 as b64
    text = params.get("text", "")
    mode = params.get("mode", "encoder")
    if mode == "encoder":
        return b64.b64encode(text.encode("utf-8")).decode("ascii")
    try:
        return b64.b64decode(text.strip()).decode("utf-8")
    except Exception:
        raise ValueError("Base64 invalide : impossible de décoder ce texte")


def _run_generate_password(params: dict) -> str:
    import secrets
    import string
    try:
        length = max(8, min(128, int(params.get("length") or 16)))
    except ValueError:
        length = 16
    alphabet = string.ascii_letters + string.digits
    if params.get("symbols", "oui") == "oui":
        alphabet += "!@#$%^&*()-_=+[]{}"
    password = "".join(secrets.choice(alphabet) for _ in range(length))
    return json.dumps({"password": password, "length": length}, indent=2)


def _run_regex_extract(params: dict) -> str:
    text = params.get("text", "")
    pattern = params.get("pattern", "")
    try:
        matches = re.findall(pattern, text)
    except re.error as e:
        raise ValueError(f"Expression régulière invalide : {e}")
    if not matches:
        return "Aucune correspondance trouvée."
    flat = [m if isinstance(m, str) else " | ".join(m) for m in matches[:200]]
    return json.dumps({"count": len(matches), "matches": flat}, ensure_ascii=False, indent=2)


def _run_calculate(params: dict) -> str:
    import ast
    import math
    import operator as op
    expr = params.get("expression", "")
    # Tolérance : les LLM écrivent souvent « math.sqrt(x) » ou « x^2 »
    expr = expr.replace("math.", "").replace("np.", "").replace("^", "**")
    operators = {
        ast.Add: op.add, ast.Sub: op.sub, ast.Mult: op.mul, ast.Div: op.truediv,
        ast.FloorDiv: op.floordiv, ast.Mod: op.mod, ast.Pow: op.pow,
        ast.USub: op.neg, ast.UAdd: op.pos,
    }
    functions = {"sqrt": math.sqrt, "abs": abs, "round": round, "log": math.log,
                 "sin": math.sin, "cos": math.cos, "tan": math.tan, "pi": math.pi, "e": math.e}

    def _eval(node):
        if isinstance(node, ast.Expression):
            return _eval(node.body)
        if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
            return node.value
        if isinstance(node, ast.BinOp) and type(node.op) in operators:
            return operators[type(node.op)](_eval(node.left), _eval(node.right))
        if isinstance(node, ast.UnaryOp) and type(node.op) in operators:
            return operators[type(node.op)](_eval(node.operand))
        if isinstance(node, ast.Name) and node.id in functions and isinstance(functions[node.id], float):
            return functions[node.id]
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in functions:
            return functions[node.func.id](*[_eval(a) for a in node.args])
        raise ValueError("Expression non autorisée")

    try:
        result = _eval(ast.parse(expr, mode="eval"))
    except ValueError:
        raise
    except Exception as e:
        raise ValueError(f"Expression invalide : {e}")
    if isinstance(result, float) and result.is_integer():
        result = int(result)
    return str(result)


from app.routes.skills_content import CONTENT_SKILLS, CONTENT_RUNNERS, MEDIA_DIR
from app.routes.skills_dev import DEV_SKILLS, DEV_RUNNERS
from app.routes.skills_extra import EXTRA_SKILLS, EXTRA_RUNNERS
from app.routes.skills_office import OFFICE_SKILLS, OFFICE_RUNNERS
from app.routes.skills_integrations import INTEGRATION_SKILLS, INTEGRATION_RUNNERS

BUILTIN_SKILLS.update(CONTENT_SKILLS)
BUILTIN_SKILLS.update(DEV_SKILLS)
BUILTIN_SKILLS.update(EXTRA_SKILLS)
BUILTIN_SKILLS.update(OFFICE_SKILLS)
BUILTIN_SKILLS.update(INTEGRATION_SKILLS)

BUILTIN_RUNNERS = {
    "summarize": _run_summarize,
    "translate": _run_translate,
    "extract_json": _run_extract_json,
    "web_search": _run_web_search,
    "scrape_url": _run_scrape_url,
    "http_request": _run_http_request,
    "send_email": _run_send_email,
    "count_tokens": _run_count_tokens,
    "format_date": _run_format_date,
    "word_count": _run_word_count,
    "sentiment": _run_sentiment,
    "rewrite": _run_rewrite,
    "keywords": _run_keywords,
    "hash_text": _run_hash_text,
    "base64": _run_base64,
    "generate_password": _run_generate_password,
    "regex_extract": _run_regex_extract,
    "calculate": _run_calculate,
    **CONTENT_RUNNERS,
    **DEV_RUNNERS,
    **EXTRA_RUNNERS,
    **OFFICE_RUNNERS,
    **INTEGRATION_RUNNERS,
}


# ---------------------------------------------------------------------------
# Pydantic schemas
# ---------------------------------------------------------------------------

class SkillBody(BaseModel):
    name: str
    description: str = ""
    icon: str = "Plug"
    category: str = "custom"
    endpoint_url: str
    method: str = "POST"
    headers: dict | None = None
    body_template: str | None = None  # JSON template with {{param}} placeholders


class RunParams(BaseModel):
    params: dict = {}


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

@router.get("/")
async def list_skills(current_user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    builtin = [
        {"id": f"builtin:{k}", "slug": k, "type": "builtin", **v}
        for k, v in BUILTIN_SKILLS.items()
    ]
    result = await db.execute(
        select(Skill).where(
            (Skill.user_id == current_user.id) | (Skill.is_public == True)
        )
    )
    custom = [
        {
            "id": f"custom:{s.id}",
            "slug": str(s.id),
            "type": "custom",
            "name": s.name,
            "description": s.description,
            "icon": s.icon,
            "category": s.category,
            "params": [],
            "config": s.config,
            "owner_id": s.user_id,
        }
        for s in result.scalars().all()
    ]
    return builtin + custom


@router.post("/")
async def create_skill(body: SkillBody, current_user: User = Depends(get_current_user),
                       db: AsyncSession = Depends(get_db)):
    skill = Skill(
        user_id=current_user.id,
        name=body.name,
        description=body.description,
        icon=body.icon,
        category=body.category,
        config={
            "endpoint_url": body.endpoint_url,
            "method": body.method,
            "headers": body.headers or {},
            "body_template": body.body_template,
        },
    )
    db.add(skill)
    await db.commit()
    await db.refresh(skill)
    return {"id": skill.id, "name": skill.name}


@router.delete("/{skill_id}/")
async def delete_skill(skill_id: int, current_user: User = Depends(get_current_user),
                       db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Skill).where(Skill.id == skill_id))
    skill = result.scalar_one_or_none()
    if not skill:
        raise HTTPException(404, "Skill introuvable")
    if skill.user_id != current_user.id and current_user.role != "admin":
        raise HTTPException(403, "Non autorisé")
    await db.delete(skill)
    await db.commit()
    return {"deleted": True}


@router.get("/media/{filename}/")
@router.get("/media/{filename}")
async def get_media(filename: str):
    """Sert les fichiers générés par les skills contenu (images, audio, vidéos)."""
    import os as _os
    from fastapi.responses import FileResponse
    safe = _os.path.basename(filename)
    path = _os.path.join(MEDIA_DIR, safe)
    if not _os.path.exists(path):
        raise HTTPException(404, "Fichier introuvable")
    return FileResponse(path)


def _routed_model_for(slug: str) -> str | None:
    """Return the model a skill should use, or None to keep the default.

    Only skills explicitly listed go through the cloud gateway: sending
    everything there would hand a third party data that never needed to leave
    the machine.
    """
    from app.config import settings
    if not settings.openai_base_url:
        return None            # no gateway configured — nothing to route to
    listed = {s.strip() for s in settings.cloud_skills.split(",") if s.strip()}
    if "*" in listed or slug in listed:
        return "cloud:"        # empty model name => gateway's default
    return None


@router.post("/builtin/{slug}/run/")
async def run_builtin_skill(slug: str, body: RunParams,
                            current_user: User = Depends(get_current_user)):
    if slug not in BUILTIN_RUNNERS:
        raise HTTPException(404, f"Skill builtin « {slug} » introuvable")
    try:
        runner = BUILTIN_RUNNERS[slug]
        import inspect
        # Route this skill to the cloud gateway when it is listed and a gateway
        # is configured; everything else keeps running on the local model.
        with llm.use_model(_routed_model_for(slug)):
            if inspect.iscoroutinefunction(runner):
                output = await runner(body.params)
            else:
                output = runner(body.params)
        return {"success": True, "output": output}
    except Exception as e:
        raise HTTPException(400, str(e) or f"{type(e).__name__} (délai dépassé ou erreur interne)")


@router.post("/custom/{skill_id}/run/")
async def run_custom_skill(skill_id: int, body: RunParams,
                           current_user: User = Depends(get_current_user),
                           db: AsyncSession = Depends(get_db)):
    import httpx, re as _re
    result = await db.execute(select(Skill).where(Skill.id == skill_id))
    skill = result.scalar_one_or_none()
    if not skill:
        raise HTTPException(404, "Skill introuvable")
    cfg = skill.config or {}
    url = cfg.get("endpoint_url", "")
    method = cfg.get("method", "POST")
    headers = cfg.get("headers", {})
    body_template = cfg.get("body_template", "")
    # Replace {{param}} placeholders in URL and body
    for k, v in body.params.items():
        url = url.replace(f"{{{{{k}}}}}", str(v))
        body_template = body_template.replace(f"{{{{{k}}}}}", str(v)) if body_template else ""
    req_body = None
    if body_template:
        try:
            req_body = json.loads(body_template)
        except json.JSONDecodeError:
            req_body = body_template
    try:
        async with httpx.AsyncClient(timeout=15) as client:
            resp = await client.request(method, url, headers=headers, json=req_body)
        try:
            return {"success": True, "output": json.dumps(resp.json(), ensure_ascii=False, indent=2)}
        except Exception:
            return {"success": True, "output": resp.text[:3000]}
    except Exception as e:
        raise HTTPException(400, str(e))
