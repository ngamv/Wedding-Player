import asyncio
import json
from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Query
from app.ws import manager
from app.auth import decode_token

router = APIRouter()


@router.websocket("/ws/events")
async def ws_events(websocket: WebSocket, token: str | None = Query(None)):
    """Accept token via query param OR first JSON message {"token": "..."}.
    First-message auth avoids logging the JWT in nginx access logs.
    """
    await websocket.accept()

    if not token:
        # Wait up to 5 s for a first-message auth frame
        try:
            raw = await asyncio.wait_for(websocket.receive_text(), timeout=5.0)
            data = json.loads(raw)
            token = data.get("token", "")
        except Exception:
            await websocket.close(code=4001)
            return

    payload = decode_token(token)
    if not payload:
        await websocket.close(code=4001)
        return

    user_id: int = payload.get("sub")
    username: str = payload.get("username", str(user_id))
    await manager.connect(websocket, user_id, username)
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        await manager.disconnect_and_broadcast(websocket, user_id)


@router.get("/system/presence")
async def get_presence():
    """Returns list of currently connected users (username + user_id)."""
    return {"users": manager.connected_users(), "count": len(manager.connected_users())}
