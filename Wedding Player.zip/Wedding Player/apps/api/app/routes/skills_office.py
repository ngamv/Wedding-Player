"""
Skills de livrables bureautiques : Word, Excel, PowerPoint, PDF.

Chaque skill produit un vrai fichier dans MEDIA_DIR et renvoie son chemin,
de sorte que le resultat soit telechargeable comme les autres medias.
Le contenu peut etre fourni tel quel ou redige par le LLM.
Fusionnes dans le registre par skills.py.
"""
import json
import os

from app import llm
from app.routes.skills_content import MEDIA_DIR, _media_path

OFFICE_SKILLS: dict[str, dict] = {
    "docx_report": {
        "name": "Document Word",
        "description": "Genere un document Word (.docx) structure : titre, sections, paragraphes",
        "icon": "FileText",
        "category": "office",
        "params": [
            {"name": "title", "type": "text", "required": True, "label": "Titre du document",
             "placeholder": "Rapport d'activite - T3 2026"},
            {"name": "content", "type": "textarea", "required": False, "label": "Contenu (markdown simple)",
             "placeholder": "## Section 1\nTexte...\n\n## Section 2\nTexte..."},
            {"name": "topic", "type": "text", "required": False, "label": "Ou : sujet a rediger par l'IA",
             "placeholder": "bilan trimestriel d'une agence marketing"},
        ],
    },
    "xlsx_table": {
        "name": "Tableur Excel",
        "description": "Genere un classeur Excel (.xlsx) a partir de donnees CSV ou JSON",
        "icon": "Table",
        "category": "office",
        "params": [
            {"name": "data", "type": "textarea", "required": True, "label": "Donnees (CSV ou JSON)",
             "placeholder": "Produit,Ventes,CA\nAloe Vera,120,2400"},
            {"name": "sheet_name", "type": "text", "required": False, "label": "Nom de la feuille",
             "default": "Donnees"},
        ],
    },
    "pptx_deck": {
        "name": "Presentation PowerPoint",
        "description": "Genere une presentation (.pptx) : titre + slides a puces",
        "icon": "Presentation",
        "category": "office",
        "params": [
            {"name": "title", "type": "text", "required": True, "label": "Titre de la presentation",
             "placeholder": "Strategie 2026"},
            {"name": "slides", "type": "textarea", "required": False, "label": "Slides (une par bloc)",
             "placeholder": "Contexte\n- Point 1\n- Point 2\n\nObjectifs\n- Point 1"},
            {"name": "topic", "type": "text", "required": False, "label": "Ou : sujet a generer par l'IA",
             "placeholder": "lancement d'une gamme de cosmetiques bio"},
        ],
    },
    "pdf_document": {
        "name": "Document PDF",
        "description": "Genere un PDF structure : titre, sections, paragraphes",
        "icon": "FileType",
        "category": "office",
        "params": [
            {"name": "title", "type": "text", "required": True, "label": "Titre du document",
             "placeholder": "Devis - Prestation web"},
            {"name": "content", "type": "textarea", "required": True, "label": "Contenu (markdown simple)",
             "placeholder": "## Prestation\nDetail..."},
        ],
    },
}


async def _outline(topic: str, kind: str) -> str:
    """Ask the LLM for structured content when the user gave only a topic."""
    fmt = {
        "docx": "Utilise '## Titre de section' pour chaque section, puis des paragraphes.",
        "pptx": "Une slide par bloc : premiere ligne = titre, puis 3 a 5 lignes commencant par '- '.",
    }[kind]
    return await llm.chat([{"role": "user", "content": (
        f"Redige le contenu d'un document professionnel sur : {topic}\n{fmt}\n"
        "Reponds uniquement avec le contenu, sans commentaire."
    )}])


def _parse_sections(content: str) -> list[tuple[str, list[str]]]:
    """Split '## Heading' markdown into (heading, paragraphs) pairs."""
    sections: list[tuple[str, list[str]]] = []
    heading, buf = "", []
    for line in content.splitlines():
        stripped = line.strip()
        if stripped.startswith("##"):
            if heading or buf:
                sections.append((heading, buf))
            heading, buf = stripped.lstrip("#").strip(), []
        elif stripped:
            buf.append(stripped)
    if heading or buf:
        sections.append((heading, buf))
    return sections


async def _run_docx_report(params: dict) -> str:
    from docx import Document

    title = params.get("title", "Document")
    content = params.get("content") or ""
    if not content and params.get("topic"):
        content = await _outline(params["topic"], "docx")
    if not content:
        raise ValueError("Fournissez un contenu ou un sujet")

    doc = Document()
    doc.add_heading(title, level=0)
    for heading, paragraphs in _parse_sections(content):
        if heading:
            doc.add_heading(heading, level=1)
        for p in paragraphs:
            doc.add_paragraph(p.lstrip("- ")) if p.startswith("- ") else doc.add_paragraph(p)

    path, name = _media_path("docx")
    doc.save(path)
    return json.dumps({"fichier": name, "chemin": f"/media/{name}",
                       "taille_ko": round(os.path.getsize(path) / 1024, 1)},
                      ensure_ascii=False, indent=2)


async def _run_xlsx_table(params: dict) -> str:
    from openpyxl import Workbook
    from openpyxl.styles import Font

    raw = (params.get("data") or "").strip()
    if not raw:
        raise ValueError("Donnees requises")

    # Accept both JSON (list of objects) and CSV.
    rows: list[list] = []
    try:
        parsed = json.loads(raw)
        if isinstance(parsed, list) and parsed and isinstance(parsed[0], dict):
            headers = list(parsed[0].keys())
            rows = [headers] + [[item.get(h, "") for h in headers] for item in parsed]
    except (json.JSONDecodeError, TypeError):
        pass
    if not rows:
        import csv
        import io
        rows = [r for r in csv.reader(io.StringIO(raw)) if r]
    if not rows:
        raise ValueError("Aucune ligne exploitable")

    wb = Workbook()
    ws = wb.active
    ws.title = (params.get("sheet_name") or "Donnees")[:31]  # Excel caps sheet names
    for row in rows:
        ws.append(row)
    for cell in ws[1]:
        cell.font = Font(bold=True)
    for col in ws.columns:
        width = max((len(str(c.value)) for c in col if c.value is not None), default=8)
        ws.column_dimensions[col[0].column_letter].width = min(width + 2, 50)

    path, name = _media_path("xlsx")
    wb.save(path)
    return json.dumps({"fichier": name, "chemin": f"/media/{name}",
                       "lignes": len(rows) - 1, "colonnes": len(rows[0])},
                      ensure_ascii=False, indent=2)


async def _run_pptx_deck(params: dict) -> str:
    from pptx import Presentation
    from pptx.util import Pt

    title = params.get("title", "Presentation")
    slides_raw = params.get("slides") or ""
    if not slides_raw and params.get("topic"):
        slides_raw = await _outline(params["topic"], "pptx")
    if not slides_raw:
        raise ValueError("Fournissez des slides ou un sujet")

    prs = Presentation()
    cover = prs.slides.add_slide(prs.slide_layouts[0])
    cover.shapes.title.text = title
    if len(cover.placeholders) > 1:
        cover.placeholders[1].text = "Genere par ORION AI"

    count = 0
    for block in [b for b in slides_raw.split("\n\n") if b.strip()]:
        lines = [l.strip() for l in block.splitlines() if l.strip()]
        slide = prs.slides.add_slide(prs.slide_layouts[1])
        slide.shapes.title.text = lines[0].lstrip("#- ")
        body = slide.placeholders[1].text_frame
        body.clear()
        for i, bullet in enumerate([l.lstrip("- ") for l in lines[1:]]):
            para = body.paragraphs[0] if i == 0 else body.add_paragraph()
            para.text = bullet
            para.font.size = Pt(18)
        count += 1

    path, name = _media_path("pptx")
    prs.save(path)
    return json.dumps({"fichier": name, "chemin": f"/media/{name}", "slides": count + 1},
                      ensure_ascii=False, indent=2)


async def _run_pdf_document(params: dict) -> str:
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer

    title = params.get("title", "Document")
    content = params.get("content") or ""
    if not content:
        raise ValueError("Contenu requis")

    path, name = _media_path("pdf")
    styles = getSampleStyleSheet()
    story = [Paragraph(title, styles["Title"]), Spacer(1, 16)]
    for heading, paragraphs in _parse_sections(content):
        if heading:
            story += [Paragraph(heading, styles["Heading2"]), Spacer(1, 6)]
        for p in paragraphs:
            story += [Paragraph(p.lstrip("- "), styles["BodyText"]), Spacer(1, 4)]
    SimpleDocTemplate(path, pagesize=A4, title=title).build(story)

    return json.dumps({"fichier": name, "chemin": f"/media/{name}",
                       "taille_ko": round(os.path.getsize(path) / 1024, 1)},
                      ensure_ascii=False, indent=2)


OFFICE_RUNNERS = {
    "docx_report": _run_docx_report,
    "xlsx_table": _run_xlsx_table,
    "pptx_deck": _run_pptx_deck,
    "pdf_document": _run_pdf_document,
}
