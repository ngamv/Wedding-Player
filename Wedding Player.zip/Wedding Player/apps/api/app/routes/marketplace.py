"""Agent marketplace — browse and clone public custom agents."""
import re
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.database import get_db
from app.models import CustomAgent, User
from app.auth import get_current_user
from app.routes.custom_agents import _register_in_memory

router = APIRouter(prefix="/marketplace", tags=["marketplace"])


@router.get("/")
async def browse(
    db: AsyncSession = Depends(get_db),
    _: User = Depends(get_current_user),
):
    """List all publicly shared agents."""
    result = await db.execute(
        select(CustomAgent).where(CustomAgent.is_public == True)
        .order_by(CustomAgent.created_at.desc())
    )
    agents = result.scalars().all()
    return [_serialize(a) for a in agents]


@router.post("/{agent_id}/publish")
async def publish(
    agent_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Make your agent publicly visible in the marketplace."""
    ca = await _own_agent(agent_id, current_user.id, db)
    ca.is_public = True
    await db.commit()
    return {"message": f"Agent '{ca.name}' publié dans le marketplace"}


@router.post("/{agent_id}/unpublish")
async def unpublish(
    agent_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Remove your agent from the marketplace."""
    ca = await _own_agent(agent_id, current_user.id, db)
    ca.is_public = False
    await db.commit()
    return {"message": f"Agent '{ca.name}' retiré du marketplace"}


@router.post("/{agent_id}/clone", status_code=201)
async def clone(
    agent_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Clone a public agent into your own collection."""
    result = await db.execute(
        select(CustomAgent).where(
            CustomAgent.agent_id == agent_id,
            CustomAgent.is_public == True,
        )
    )
    source = result.scalar_one_or_none()
    if not source:
        raise HTTPException(404, "Agent public introuvable")

    new_id = _unique_id(f"{agent_id}_clone", db)
    clone_agent = CustomAgent(
        user_id=current_user.id,
        agent_id=new_id,
        name=f"{source.name} (clone)",
        description=source.description,
        category=source.category,
        system_prompt=source.system_prompt,
        model=source.model,
        is_public=False,
        env_vars=None,
    )
    db.add(clone_agent)
    await db.commit()
    await db.refresh(clone_agent)
    _register_in_memory(clone_agent)
    return _serialize(clone_agent)


def _unique_id(base: str, _db: AsyncSession) -> str:
    import time
    slug = re.sub(r"[^a-z0-9]+", "_", base.lower()).strip("_")
    return f"{slug}_{int(time.time())}"


async def _own_agent(agent_id: str, user_id: int, db: AsyncSession) -> CustomAgent:
    result = await db.execute(
        select(CustomAgent).where(
            CustomAgent.agent_id == agent_id,
            CustomAgent.user_id == user_id,
        )
    )
    ca = result.scalar_one_or_none()
    if not ca:
        raise HTTPException(404, "Agent introuvable ou vous n'en êtes pas propriétaire")
    return ca


def _serialize(ca: CustomAgent) -> dict:
    return {
        "id": ca.id,
        "agent_id": ca.agent_id,
        "name": ca.name,
        "description": ca.description,
        "category": ca.category,
        "model": ca.model,
        "is_public": ca.is_public,
        "created_at": ca.created_at,
    }
