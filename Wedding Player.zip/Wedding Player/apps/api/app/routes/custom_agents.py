import asyncio
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel, field_validator
import re
from app.database import get_db
from app.models import CustomAgent, User
from app.agents import AGENT_REGISTRY
from app.agents.base import BaseAgent
from app.auth import get_current_user
from app import ollama

_env_var_lock = asyncio.Lock()

router = APIRouter(prefix="/custom-agents", tags=["custom-agents"])

VALID_CATEGORIES = {"core", "seo", "social", "marketing", "dev", "data"}


class CustomAgentBody(BaseModel):
    name: str
    description: str
    category: str = "core"
    system_prompt: str
    model: str | None = None
    env_vars: dict | None = None  # {"MY_KEY": "value"} — injected at runtime
    is_public: bool = False
    rate_limit: int | None = None  # max tasks per hour, None = unlimited

    @field_validator("name")
    @classmethod
    def name_not_empty(cls, v: str) -> str:
        v = v.strip()
        if not v:
            raise ValueError("Le nom ne peut pas être vide")
        return v

    @field_validator("category")
    @classmethod
    def valid_category(cls, v: str) -> str:
        if v not in VALID_CATEGORIES:
            raise ValueError(f"Catégorie invalide. Valeurs possibles : {', '.join(VALID_CATEGORIES)}")
        return v

    @field_validator("system_prompt")
    @classmethod
    def prompt_not_empty(cls, v: str) -> str:
        if not v.strip():
            raise ValueError("Le prompt système ne peut pas être vide")
        return v


class CustomAgentOut(BaseModel):
    id: int
    agent_id: str
    name: str
    description: str
    category: str
    system_prompt: str
    model: str | None
    is_public: bool = False
    env_vars: dict | None = None
    rate_limit: int | None = None

    model_config = {"from_attributes": True}


def _slugify(name: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "_", name.lower()).strip("_")
    return f"custom_{slug}"


def _register_in_memory(ca: CustomAgent) -> None:
    """Injects the custom agent into the live registry without restart."""
    system_prompt_text = ca.system_prompt
    agent_env_vars: dict = ca.env_vars or {}

    class _DynamicAgent(BaseAgent):
        id = ca.agent_id
        name = ca.name
        description = ca.description
        category = ca.category
        model = ca.model

        def _system_prompt(self) -> str:
            return system_prompt_text

        async def run(self, task: str, context: dict | None = None) -> dict:
            import os
            if not agent_env_vars:
                return await super().run(task, context)
            # Serialize env-var mutations to prevent race conditions in async context
            async with _env_var_lock:
                old = {k: os.environ.get(k) for k in agent_env_vars}
                os.environ.update(agent_env_vars)
                try:
                    return await super().run(task, context)
                finally:
                    for k, v in old.items():
                        if v is None:
                            os.environ.pop(k, None)
                        else:
                            os.environ[k] = v

    AGENT_REGISTRY[ca.agent_id] = _DynamicAgent()


def _unregister_from_memory(agent_id: str) -> None:
    AGENT_REGISTRY.pop(agent_id, None)


@router.get("/", response_model=list[CustomAgentOut])
async def list_custom_agents(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(select(CustomAgent).order_by(CustomAgent.created_at.desc()))
    return result.scalars().all()


@router.post("/", response_model=CustomAgentOut, status_code=201)
async def create_custom_agent(
    body: CustomAgentBody,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    agent_id = _slugify(body.name)

    existing = await db.execute(select(CustomAgent).where(CustomAgent.agent_id == agent_id))
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=409, detail=f"Un agent avec l'ID '{agent_id}' existe déjà")

    if agent_id in AGENT_REGISTRY:
        raise HTTPException(status_code=409, detail=f"L'ID '{agent_id}' est déjà utilisé par un agent système")

    ca = CustomAgent(
        agent_id=agent_id,
        name=body.name,
        description=body.description,
        category=body.category,
        system_prompt=body.system_prompt,
        model=body.model,
        is_public=body.is_public,
        env_vars=body.env_vars,
        rate_limit=body.rate_limit,
    )
    db.add(ca)
    await db.commit()
    await db.refresh(ca)
    _register_in_memory(ca)
    return ca


@router.get("/{agent_id}", response_model=CustomAgentOut)
async def get_custom_agent(
    agent_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(select(CustomAgent).where(CustomAgent.agent_id == agent_id))
    ca = result.scalar_one_or_none()
    if not ca:
        raise HTTPException(status_code=404, detail="Agent non trouvé")
    return ca


@router.put("/{agent_id}", response_model=CustomAgentOut)
async def update_custom_agent(
    agent_id: str,
    body: CustomAgentBody,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(select(CustomAgent).where(CustomAgent.agent_id == agent_id))
    ca = result.scalar_one_or_none()
    if not ca:
        raise HTTPException(status_code=404, detail="Agent non trouvé")

    ca.name = body.name
    ca.description = body.description
    ca.category = body.category
    ca.system_prompt = body.system_prompt
    ca.model = body.model
    ca.is_public = body.is_public
    ca.env_vars = body.env_vars
    ca.rate_limit = body.rate_limit
    await db.commit()
    await db.refresh(ca)
    _register_in_memory(ca)
    return ca


@router.delete("/{agent_id}", status_code=204)
async def delete_custom_agent(
    agent_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(select(CustomAgent).where(CustomAgent.agent_id == agent_id))
    ca = result.scalar_one_or_none()
    if not ca:
        raise HTTPException(status_code=404, detail="Agent non trouvé")
    await db.delete(ca)
    await db.commit()
    _unregister_from_memory(agent_id)


class SandboxBody(BaseModel):
    system_prompt: str
    message: str
    model: str | None = None


@router.post("/sandbox")
async def sandbox_run(
    body: SandboxBody,
    current_user: User = Depends(get_current_user),
):
    """Execute a one-shot LLM call with the given system_prompt and message."""
    from app.llm import chat
    if not body.system_prompt.strip():
        raise HTTPException(400, "Le prompt système ne peut pas être vide")
    messages = [{"role": "user", "content": body.message}]
    response = await chat(messages, system=body.system_prompt, model=body.model or None)
    return {"response": response}


class RunBody(BaseModel):
    task: str
    context: dict | None = None


@router.post("/{agent_id}/run")
async def run_custom_agent(
    agent_id: str,
    body: RunBody,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    if agent_id not in AGENT_REGISTRY:
        # try to reload from db
        result = await db.execute(select(CustomAgent).where(CustomAgent.agent_id == agent_id))
        ca = result.scalar_one_or_none()
        if not ca:
            raise HTTPException(status_code=404, detail="Agent non trouvé")
        _register_in_memory(ca)

    agent = AGENT_REGISTRY[agent_id]
    return await agent.run(body.task, body.context)
