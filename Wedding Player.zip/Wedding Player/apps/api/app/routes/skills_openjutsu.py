import asyncio
import json

from app.openjutsu import catalog, preflight, queue_color, render_status


def _param(name, label):
    return {"name": name, "label": label, "required": True, "type": "text"}


def _skill(name, description, params):
    return {"name": name, "description": description, "icon": "Film",
            "category": "integration", "params": params}


OPENJUTSU_SKILLS = {
    "openjutsu_catalogue": _skill("OpenJutsu — Catalogue", "Liste les workflows ComfyUI intégrés.", []),
    "openjutsu_diagnostic": _skill("OpenJutsu — Diagnostic", "Liste les nœuds ComfyUI manquants.",
                                   [_param("workflow", "Identifiant du workflow, par ex. color")]),
    "openjutsu_couleurs": _skill("OpenJutsu — Correction couleur", "Met en file la correction d’une vidéo déjà présente dans ComfyUI/input.",
                                 [_param("video", "Nom relatif de la vidéo ComfyUI")]),
    "openjutsu_statut": _skill("OpenJutsu — Suivi du rendu", "Consulte le résultat d’un rendu ComfyUI.",
                               [_param("prompt_id", "Identifiant de rendu")]),
}


def _catalogue(_):
    return json.dumps(catalog(), ensure_ascii=False, indent=2)


async def _diagnostic(params):
    return json.dumps(await asyncio.to_thread(preflight, params["workflow"]), ensure_ascii=False, indent=2)


async def _couleurs(params):
    return json.dumps(await asyncio.to_thread(queue_color, params["video"]), ensure_ascii=False, indent=2)


async def _statut(params):
    return json.dumps(await asyncio.to_thread(render_status, params["prompt_id"]), ensure_ascii=False, indent=2)


OPENJUTSU_RUNNERS = {
    "openjutsu_catalogue": _catalogue,
    "openjutsu_diagnostic": _diagnostic,
    "openjutsu_couleurs": _couleurs,
    "openjutsu_statut": _statut,
}
