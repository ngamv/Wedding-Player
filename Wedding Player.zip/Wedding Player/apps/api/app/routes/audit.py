from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc
from pydantic import BaseModel
from datetime import datetime
from app.database import get_db
from app.models import AuditLog
from app.auth import get_current_user, require_admin
from app.models import User

router = APIRouter(prefix="/admin/audit", tags=["audit"])


class AuditLogOut(BaseModel):
    id: int
    user_id: int | None
    username: str
    action: str
    resource_type: str
    resource_id: str | None
    details: dict | None
    ip_address: str | None
    created_at: datetime

    model_config = {"from_attributes": True}


async def log_action(
    db: AsyncSession,
    *,
    user: User | None,
    action: str,
    resource_type: str,
    resource_id: str | None = None,
    details: dict | None = None,
    ip: str | None = None,
):
    entry = AuditLog(
        user_id=user.id if user else None,
        username=user.username if user else "system",
        action=action,
        resource_type=resource_type,
        resource_id=str(resource_id) if resource_id is not None else None,
        details=details,
        ip_address=ip,
    )
    db.add(entry)
    await db.commit()


@router.get("/", response_model=list[AuditLogOut])
async def list_audit_logs(
    limit: int = 100,
    db: AsyncSession = Depends(get_db),
    _: User = Depends(require_admin),
):
    result = await db.execute(
        select(AuditLog).order_by(desc(AuditLog.created_at)).limit(min(limit, 500))
    )
    return result.scalars().all()
