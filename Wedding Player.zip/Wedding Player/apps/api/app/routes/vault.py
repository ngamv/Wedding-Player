import base64
import hashlib
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel
from datetime import datetime
from app.database import get_db
from app.models import VaultSecret, User
from app.auth import get_current_user
from app.config import settings


def _fernet():
    from cryptography.fernet import Fernet
    raw = hashlib.sha256(settings.jwt_secret.encode()).digest()
    key = base64.urlsafe_b64encode(raw)
    return Fernet(key)


def encrypt(value: str) -> str:
    return _fernet().encrypt(value.encode()).decode()


def decrypt(value: str) -> str:
    return _fernet().decrypt(value.encode()).decode()


router = APIRouter(prefix="/vault", tags=["vault"])


class SecretCreate(BaseModel):
    name: str
    value: str


class SecretUpdate(BaseModel):
    value: str


class SecretOut(BaseModel):
    id: int
    name: str
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class SecretWithValue(SecretOut):
    value: str


@router.get("/", response_model=list[SecretOut])
async def list_secrets(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(VaultSecret).where(VaultSecret.user_id == current_user.id)
    )
    return result.scalars().all()


@router.post("/", response_model=SecretOut, status_code=201)
async def create_secret(
    body: SecretCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    secret = VaultSecret(
        user_id=current_user.id,
        name=body.name,
        encrypted_value=encrypt(body.value),
    )
    db.add(secret)
    await db.commit()
    await db.refresh(secret)
    return secret


@router.get("/{secret_id}/reveal", response_model=SecretWithValue)
async def reveal_secret(
    secret_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(VaultSecret).where(
            VaultSecret.id == secret_id, VaultSecret.user_id == current_user.id
        )
    )
    s = result.scalar_one_or_none()
    if not s:
        raise HTTPException(404, "Secret introuvable")
    return SecretWithValue(
        id=s.id,
        name=s.name,
        created_at=s.created_at,
        updated_at=s.updated_at,
        value=decrypt(s.encrypted_value),
    )


@router.put("/{secret_id}", response_model=SecretOut)
async def update_secret(
    secret_id: int,
    body: SecretUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(VaultSecret).where(
            VaultSecret.id == secret_id, VaultSecret.user_id == current_user.id
        )
    )
    s = result.scalar_one_or_none()
    if not s:
        raise HTTPException(404, "Secret introuvable")
    s.encrypted_value = encrypt(body.value)
    s.updated_at = datetime.utcnow()
    db.add(s)
    await db.commit()
    await db.refresh(s)
    return s


@router.delete("/{secret_id}", status_code=204)
async def delete_secret(
    secret_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(VaultSecret).where(
            VaultSecret.id == secret_id, VaultSecret.user_id == current_user.id
        )
    )
    s = result.scalar_one_or_none()
    if not s:
        raise HTTPException(404, "Secret introuvable")
    await db.delete(s)
    await db.commit()
