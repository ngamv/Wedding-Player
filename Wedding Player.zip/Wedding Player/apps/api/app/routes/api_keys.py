import hashlib
import secrets
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel
from app.database import get_db
from app.models import ApiKey, User
from app.auth import get_current_user

router = APIRouter(prefix="/api-keys", tags=["api-keys"])


def _generate_key() -> tuple[str, str, str]:
    """Returns (raw_key, prefix, hash)"""
    raw = "ok-" + secrets.token_urlsafe(32)
    prefix = raw[:12]
    key_hash = hashlib.sha256(raw.encode()).hexdigest()
    return raw, prefix, key_hash


async def verify_api_key(key: str, db: AsyncSession) -> ApiKey | None:
    key_hash = hashlib.sha256(key.encode()).hexdigest()
    result = await db.execute(select(ApiKey).where(ApiKey.key_hash == key_hash, ApiKey.is_active == True))
    api_key = result.scalar_one_or_none()
    if api_key:
        api_key.last_used_at = datetime.utcnow()
        await db.commit()
    return api_key


class CreateKeyBody(BaseModel):
    name: str


class ApiKeyOut(BaseModel):
    id: int
    name: str
    key_prefix: str
    is_active: bool
    last_used_at: datetime | None
    created_at: datetime

    model_config = {"from_attributes": True}


class ApiKeyCreated(ApiKeyOut):
    key: str  # only returned once at creation


@router.get("/", response_model=list[ApiKeyOut])
async def list_keys(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(ApiKey).where(ApiKey.user_id == current_user.id).order_by(ApiKey.created_at.desc())
    )
    return result.scalars().all()


@router.post("/", response_model=ApiKeyCreated, status_code=201)
async def create_key(
    body: CreateKeyBody,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    if not body.name.strip():
        raise HTTPException(status_code=422, detail="Le nom ne peut pas être vide")
    raw, prefix, key_hash = _generate_key()
    api_key = ApiKey(user_id=current_user.id, name=body.name.strip(), key_hash=key_hash, key_prefix=prefix)
    db.add(api_key)
    await db.commit()
    await db.refresh(api_key)
    return ApiKeyCreated(**ApiKeyOut.model_validate(api_key).model_dump(), key=raw)


@router.delete("/{key_id}", status_code=204)
async def revoke_key(
    key_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(ApiKey).where(ApiKey.id == key_id, ApiKey.user_id == current_user.id)
    )
    api_key = result.scalar_one_or_none()
    if not api_key:
        raise HTTPException(status_code=404, detail="Clé non trouvée")
    api_key.is_active = False
    await db.commit()
