from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from app.agents import AGENT_REGISTRY
from app.orchestrator import route_and_run

router = APIRouter(prefix="/agents", tags=["agents"])

class RunRequest(BaseModel):
    task: str
    agent_id: str | None = None
    context: dict | None = None

@router.get("/")
async def list_agents():
    return [a.to_dict() for a in AGENT_REGISTRY.values()]

@router.get("/{agent_id}")
async def get_agent(agent_id: str):
    agent = AGENT_REGISTRY.get(agent_id)
    if not agent:
        raise HTTPException(404, f"Agent '{agent_id}' not found")
    return agent.to_dict()

@router.post("/run")
async def run_agent(req: RunRequest):
    try:
        result = await route_and_run(req.task, req.agent_id, req.context)
        return {"success": True, "data": result}
    except Exception as e:
        raise HTTPException(500, str(e))
