from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel
from app.database import get_db
from app.models import Workflow, WorkflowRun, User
from app.agents import AGENT_REGISTRY
from app.auth import get_current_user

router = APIRouter(prefix="/workflows", tags=["workflows"])


def _is_valid_step(step_id: str) -> bool:
    """Une étape est soit un agent, soit un skill builtin préfixé « skill: »."""
    if step_id.startswith("skill:"):
        from app.routes.skills import BUILTIN_RUNNERS
        return step_id.removeprefix("skill:") in BUILTIN_RUNNERS
    return step_id in AGENT_REGISTRY


async def _run_skill_step(slug: str, task: str) -> str:
    """Exécute un skill en injectant le texte dans son premier paramètre requis."""
    import inspect
    from app.routes.skills import BUILTIN_RUNNERS, BUILTIN_SKILLS
    runner = BUILTIN_RUNNERS[slug]
    spec_params = BUILTIN_SKILLS.get(slug, {}).get("params", [])
    target = next((p["name"] for p in spec_params if p.get("required")),
                  spec_params[0]["name"] if spec_params else "text")
    params = {target: task}
    # Compléter les autres paramètres requis avec leur valeur par défaut
    for p in spec_params:
        if p.get("required") and p["name"] != target and p.get("default"):
            params[p["name"]] = p["default"]
    if inspect.iscoroutinefunction(runner):
        return await runner(params)
    return runner(params)


class WorkflowStep(BaseModel):
    agent_id: str
    label: str = ""
    pass_output: bool = True  # inject previous result into next task


class WorkflowBody(BaseModel):
    name: str
    description: str = ""
    steps: list[WorkflowStep]


class WorkflowOut(BaseModel):
    id: int
    name: str
    description: str
    steps: list
    created_at: datetime

    model_config = {"from_attributes": True}


class RunBody(BaseModel):
    task: str


class StepResult(BaseModel):
    step: int
    agent_id: str
    label: str
    result: str
    error: str | None = None


class WorkflowRunOut(BaseModel):
    id: int
    workflow_id: int
    status: str
    input_task: str
    steps_results: list
    created_at: datetime
    completed_at: datetime | None

    model_config = {"from_attributes": True}


@router.get("/", response_model=list[WorkflowOut])
async def list_workflows(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(Workflow).where(Workflow.user_id == current_user.id).order_by(Workflow.created_at.desc())
    )
    return result.scalars().all()


@router.post("/", response_model=WorkflowOut, status_code=201)
async def create_workflow(
    body: WorkflowBody,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    if not body.name.strip():
        raise HTTPException(status_code=422, detail="Le nom ne peut pas être vide")
    if not body.steps:
        raise HTTPException(status_code=422, detail="Un workflow doit avoir au moins une étape")
    for step in body.steps:
        if not _is_valid_step(step.agent_id):
            raise HTTPException(status_code=422, detail=f"Agent ou skill inconnu : {step.agent_id}")

    wf = Workflow(
        user_id=current_user.id,
        name=body.name.strip(),
        description=body.description,
        steps=[s.model_dump() for s in body.steps],
    )
    db.add(wf)
    await db.commit()
    await db.refresh(wf)
    return wf


@router.get("/{wf_id}", response_model=WorkflowOut)
async def get_workflow(
    wf_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(Workflow).where(Workflow.id == wf_id, Workflow.user_id == current_user.id)
    )
    wf = result.scalar_one_or_none()
    if not wf:
        raise HTTPException(status_code=404, detail="Workflow non trouvé")
    return wf


@router.put("/{wf_id}", response_model=WorkflowOut)
async def update_workflow(
    wf_id: int,
    body: WorkflowBody,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(Workflow).where(Workflow.id == wf_id, Workflow.user_id == current_user.id)
    )
    wf = result.scalar_one_or_none()
    if not wf:
        raise HTTPException(status_code=404, detail="Workflow non trouvé")
    for step in body.steps:
        if not _is_valid_step(step.agent_id):
            raise HTTPException(status_code=422, detail=f"Agent ou skill inconnu : {step.agent_id}")
    wf.name = body.name
    wf.description = body.description
    wf.steps = [s.model_dump() for s in body.steps]
    await db.commit()
    await db.refresh(wf)
    return wf


@router.delete("/{wf_id}", status_code=204)
async def delete_workflow(
    wf_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(Workflow).where(Workflow.id == wf_id, Workflow.user_id == current_user.id)
    )
    wf = result.scalar_one_or_none()
    if not wf:
        raise HTTPException(status_code=404, detail="Workflow non trouvé")
    await db.delete(wf)
    await db.commit()


@router.post("/{wf_id}/run", response_model=WorkflowRunOut)
async def run_workflow(
    wf_id: int,
    body: RunBody,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(Workflow).where(Workflow.id == wf_id, Workflow.user_id == current_user.id)
    )
    wf = result.scalar_one_or_none()
    if not wf:
        raise HTTPException(status_code=404, detail="Workflow non trouvé")

    run = WorkflowRun(workflow_id=wf_id, input_task=body.task, steps_results=[])
    db.add(run)
    await db.commit()
    await db.refresh(run)

    steps_results = []
    current_task = body.task
    overall_status = "completed"

    for i, step in enumerate(wf.steps):
        agent_id = step["agent_id"]
        label = step.get("label") or agent_id
        pass_output = step.get("pass_output", True)

        try:
            if agent_id.startswith("skill:"):
                result_text = await _run_skill_step(agent_id.removeprefix("skill:"), current_task)
            else:
                agent = AGENT_REGISTRY.get(agent_id)
                if not agent:
                    raise RuntimeError(f"Agent {agent_id} introuvable")
                out = await agent.run(current_task)
                result_text = out.get("result", str(out))
            steps_results.append({"step": i, "agent_id": agent_id, "label": label,
                                   "result": result_text, "error": None})
            if pass_output and i < len(wf.steps) - 1:
                current_task = f"{body.task}\n\n[Résultat de l'étape précédente ({label})]:\n{result_text}"
        except Exception as e:
            steps_results.append({"step": i, "agent_id": agent_id, "label": label,
                                   "result": "", "error": str(e)})
            overall_status = "failed"
            break

    run.status = overall_status
    run.steps_results = steps_results
    run.completed_at = datetime.utcnow()
    await db.commit()
    await db.refresh(run)
    return run


@router.get("/{wf_id}/runs", response_model=list[WorkflowRunOut])
async def list_runs(wf_id: int, db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(WorkflowRun).where(WorkflowRun.workflow_id == wf_id).order_by(WorkflowRun.created_at.desc())
    )
    return result.scalars().all()


@router.get("/{wf_id}/export")
async def export_workflow(
    wf_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(Workflow).where(Workflow.id == wf_id, Workflow.user_id == current_user.id)
    )
    wf = result.scalar_one_or_none()
    if not wf:
        raise HTTPException(404, "Workflow non trouvé")
    return {
        "orion_workflow_version": "1.0",
        "name": wf.name,
        "description": wf.description,
        "steps": wf.steps,
        "exported_at": datetime.utcnow().isoformat(),
    }


class WorkflowImport(BaseModel):
    orion_workflow_version: str = "1.0"
    name: str
    description: str = ""
    steps: list


@router.post("/import")
async def import_workflow(
    body: WorkflowImport,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    wf = Workflow(
        user_id=current_user.id,
        name=body.name,
        description=body.description,
        steps=body.steps,
    )
    db.add(wf)
    await db.commit()
    await db.refresh(wf)
    return {"id": wf.id, "name": wf.name, "description": wf.description, "steps": wf.steps}
