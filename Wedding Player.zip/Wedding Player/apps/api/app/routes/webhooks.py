from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel, HttpUrl
from datetime import datetime
import httpx
from app.config import settings
from app.database import get_db
from app.models import Webhook, User
from app.auth import get_current_user

router = APIRouter(prefix="/webhooks", tags=["webhooks"])


class WebhookCreate(BaseModel):
    name: str
    url: str
    events: list[str] = ["task.completed", "task.failed"]


def _wh_out(wh: Webhook) -> dict:
    return {
        "id": wh.id,
        "name": wh.name,
        "url": wh.url,
        "events": wh.events,
        "is_active": wh.is_active,
        "created_at": wh.created_at,
    }


@router.get("/")
async def list_webhooks(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(Webhook).where(Webhook.user_id == current_user.id).order_by(Webhook.created_at.desc())
    )
    return [_wh_out(wh) for wh in result.scalars().all()]


@router.post("/", status_code=201)
async def create_webhook(
    body: WebhookCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    valid_events = {"task.completed", "task.failed", "workflow.completed", "workflow.failed"}
    unknown = set(body.events) - valid_events
    if unknown:
        raise HTTPException(400, f"Événements inconnus : {unknown}")
    wh = Webhook(user_id=current_user.id, name=body.name, url=body.url, events=body.events)
    db.add(wh)
    await db.commit()
    await db.refresh(wh)
    return _wh_out(wh)


@router.patch("/{webhook_id}/toggle")
async def toggle_webhook(
    webhook_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(Webhook).where(Webhook.id == webhook_id, Webhook.user_id == current_user.id)
    )
    wh = result.scalar_one_or_none()
    if not wh:
        raise HTTPException(404, "Webhook introuvable")
    wh.is_active = not wh.is_active
    await db.commit()
    await db.refresh(wh)
    return _wh_out(wh)


@router.delete("/{webhook_id}", status_code=204)
async def delete_webhook(
    webhook_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(Webhook).where(Webhook.id == webhook_id, Webhook.user_id == current_user.id)
    )
    wh = result.scalar_one_or_none()
    if not wh:
        raise HTTPException(404, "Webhook introuvable")
    await db.delete(wh)
    await db.commit()


_NTFY_STYLE = {
    # event                -> (title,                priority 1-5, tags)
    "task.failed":        ("Tâche en échec",         4, ["warning"]),
    "task.completed":     ("Tâche terminée",         3, ["white_check_mark"]),
    "workflow.failed":    ("Workflow en échec",      4, ["rotating_light"]),
    "workflow.completed": ("Workflow terminé",       3, ["sparkles"]),
}


def _is_ntfy(url: str) -> bool:
    """A ntfy endpoint is served by a host named/containing 'ntfy'."""
    from urllib.parse import urlparse
    return "ntfy" in (urlparse(url).hostname or "")


def _is_self_hosted(host: str) -> bool:
    """True for our own ntfy: the compose service name or a private address.

    Anything else — ntfy.sh above all — is a third-party server, and what we
    send there is readable by whoever guesses the topic.
    """
    import ipaddress
    if host in ("ntfy", "localhost", "127.0.0.1"):
        return True
    try:
        return ipaddress.ip_address(host).is_private
    except ValueError:
        return False


async def _post_ntfy(client: httpx.AsyncClient, url: str, event: str, payload: dict) -> None:
    """Send a human-readable push instead of raw JSON.

    ntfy shows the request body as the notification text, so posting the raw
    JSON envelope would be unreadable on a phone. Its JSON API is used rather
    than the header-based one because titles contain accents and HTTP headers
    are latin-1 only.
    """
    from urllib.parse import urlparse
    parsed = urlparse(url)
    topic = parsed.path.strip("/") or "orion"
    root = f"{parsed.scheme}://{parsed.netloc}"

    title, priority, tags = _NTFY_STYLE.get(event, (event, 3, ["bell"]))
    self_hosted = _is_self_hosted(parsed.hostname or "")

    if self_hosted:
        lines = [str(payload[k]) for k in ("title", "name") if payload.get(k)]
        if payload.get("error"):
            lines.append(f"Erreur : {payload['error']}")
        message = "\n".join(lines) or f"Événement {event}"
    else:
        # Serveur tiers : on signale qu'il s'est passe quelque chose, sans
        # livrer le nom de la tache ni le message d'erreur, qui exposeraient
        # des chemins, des noms de projets voire des extraits de code.
        message = "Ouvrez ORION pour le détail."

    # Le jeton n'accompagne que les envois vers notre propre serveur. Un
    # `if settings.ntfy_token` seul l'expedierait aussi a ntfy.sh, qui
    # pourrait alors publier sur notre instance.
    headers = ({"Authorization": f"Bearer {settings.ntfy_token}"}
               if self_hosted and settings.ntfy_token else None)

    await client.post(root, headers=headers, json={
        "topic": topic,
        "title": title,
        "message": message,
        "priority": priority,
        "tags": tags,
    })


async def fire_webhooks(db: AsyncSession, event: str, payload: dict) -> None:
    result = await db.execute(select(Webhook).where(Webhook.is_active == True))
    webhooks = result.scalars().all()
    body = {"event": event, "data": payload, "timestamp": datetime.utcnow().isoformat()}
    async with httpx.AsyncClient(timeout=5.0) as client:
        for wh in webhooks:
            if event in (wh.events or []):
                try:
                    if _is_ntfy(wh.url):
                        await _post_ntfy(client, wh.url, event, payload)
                    else:
                        await client.post(wh.url, json=body)
                except Exception:
                    pass
