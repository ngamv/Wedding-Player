"""
Dev & SEO skills: code generation/review/debug, app scaffolding,
technical SEO audit, keyword research (Google Suggest), AI meta tags, UX review.
Merged into the main skills registry by skills.py.
"""
import base64
import json
import os
import re

from app import llm

DEV_SKILLS: dict[str, dict] = {
    "generate_code": {
        "name": "Générer du code",
        "description": "Écrit du code propre depuis une spécification en langage naturel",
        "icon": "Code2",
        "category": "dev",
        "params": [
            {"name": "spec", "type": "textarea", "required": True, "label": "Ce que le code doit faire",
             "placeholder": "Une fonction qui valide un email et renvoie true/false"},
            {"name": "language", "type": "select",
             "options": ["Python", "JavaScript", "TypeScript", "HTML/CSS", "SQL", "Bash"],
             "required": True, "label": "Langage", "default": "Python"},
        ],
    },
    "code_review": {
        "name": "Revue de code",
        "description": "Analyse un code : bugs, sécurité, lisibilité, améliorations",
        "icon": "FileCode2",
        "category": "dev",
        "params": [
            {"name": "code", "type": "textarea", "required": True, "label": "Code à examiner"},
        ],
    },
    "debug_error": {
        "name": "Débugger une erreur",
        "description": "Explique une erreur et propose la correction",
        "icon": "Bug",
        "category": "dev",
        "params": [
            {"name": "error", "type": "textarea", "required": True, "label": "Message d'erreur complet"},
            {"name": "code", "type": "textarea", "required": False, "label": "Code concerné (optionnel)"},
        ],
    },
    "app_scaffold": {
        "name": "Plan d'application",
        "description": "Conçoit l'architecture d'une app : stack, structure de fichiers, étapes",
        "icon": "LayoutTemplate",
        "category": "dev",
        "params": [
            {"name": "idea", "type": "textarea", "required": True, "label": "Idée de l'app",
             "placeholder": "Une app de suivi de commandes pour mes clients Forever Living"},
            {"name": "level", "type": "select", "options": ["débutant", "intermédiaire", "avancé"],
             "required": False, "label": "Mon niveau technique", "default": "débutant"},
        ],
    },
    "app_generate": {
        "name": "Générer une application",
        "description": "Génère les fichiers réels d'une app (web, API, mobile) et renvoie un ZIP prêt à l'emploi",
        "icon": "Rocket",
        "category": "dev",
        "params": [
            {"name": "idea", "type": "textarea", "required": True, "label": "Ce que doit faire l'app",
             "placeholder": "Un suivi de commandes clients avec liste, ajout et statut"},
            {"name": "kind", "type": "select",
             "options": ["site web (HTML/CSS/JS)", "API (FastAPI)", "app React", "app mobile (React Native)"],
             "required": True, "label": "Type de projet", "default": "site web (HTML/CSS/JS)"},
            {"name": "name", "type": "text", "required": False, "label": "Nom du projet",
             "placeholder": "suivi-commandes"},
            # qwen3:8b writes better code but runs at ~4 tokens/s on a CPU-only
            # machine — roughly ten minutes for a project — so it stays opt-in.
            {"name": "model", "type": "select",
             "options": ["qwen2.5:3b", "qwen3:8b", "cloud:"],
             "required": False,
             "label": "Modèle (8b = meilleur code mais ~10 min · cloud: = passerelle configurée)",
             "default": "qwen2.5:3b"},
        ],
    },
    "seo_audit": {
        "name": "Audit SEO technique",
        "description": "Analyse une page : title, meta, Hn, images, liens, Open Graph — avec score",
        "icon": "Gauge",
        "category": "seo",
        "params": [
            {"name": "url", "type": "text", "required": True, "label": "URL de la page",
             "placeholder": "https://monsite.fr"},
        ],
    },
    "seo_keywords": {
        "name": "Recherche de mots-clés",
        "description": "Suggestions réelles Google Autocomplete autour d'un mot-clé",
        "icon": "TrendingUp",
        "category": "seo",
        "params": [
            {"name": "keyword", "type": "text", "required": True, "label": "Mot-clé de départ",
             "placeholder": "aloe vera peau"},
            {"name": "lang", "type": "select", "options": ["fr", "en"], "required": False,
             "label": "Langue", "default": "fr"},
        ],
    },
    "seo_meta": {
        "name": "SEO IA — Title & Meta",
        "description": "Génère title, meta description et Hn optimisés pour un mot-clé via LLM",
        "icon": "FileSearch",
        "category": "seo",
        "params": [
            {"name": "topic", "type": "textarea", "required": True, "label": "Sujet de la page"},
            {"name": "keyword", "type": "text", "required": True, "label": "Mot-clé principal"},
        ],
    },
    "deploy_vercel": {
        "name": "Déployer sur Vercel",
        "description": "Met en ligne une page/app HTML sur Vercel et renvoie l'URL publique",
        "icon": "Rocket",
        "category": "dev",
        "params": [
            {"name": "project", "type": "text", "required": True, "label": "Nom du projet",
             "placeholder": "mon-app (minuscules, tirets)"},
            {"name": "html", "type": "textarea", "required": True,
             "label": "Contenu de index.html"},
            {"name": "css", "type": "textarea", "required": False,
             "label": "style.css (optionnel)"},
            {"name": "js", "type": "textarea", "required": False,
             "label": "script.js (optionnel)"},
        ],
    },
    "ux_review": {
        "name": "Revue UX",
        "description": "Évalue une interface selon les 10 heuristiques de Nielsen via LLM",
        "icon": "Palette",
        "category": "seo",
        "params": [
            {"name": "description", "type": "textarea", "required": True,
             "label": "Description de l'écran / parcours",
             "placeholder": "Page d'accueil : logo, menu 8 entrées, formulaire de contact en popup…"},
            {"name": "audience", "type": "text", "required": False, "label": "Utilisateur type",
             "default": "grand public"},
        ],
    },
}


# ---------------------------------------------------------------------------
# Runners
# ---------------------------------------------------------------------------

async def _run_generate_code(params: dict) -> str:
    spec = params.get("spec", "")
    language = params.get("language", "Python")
    return await llm.chat([{"role": "user", "content": (
        f"Écris du code {language} pour : {spec}\n"
        "Exigences : code propre et commenté en français, gestion des erreurs, "
        "puis un court exemple d'utilisation. Retourne uniquement le code dans un bloc markdown."
    )}])


async def _run_code_review(params: dict) -> str:
    code = params.get("code", "")
    return await llm.chat([{"role": "user", "content": (
        "Fais une revue de ce code. Structure ta réponse :\n"
        "1. BUGS (erreurs réelles)\n2. SÉCURITÉ (failles potentielles)\n"
        "3. LISIBILITÉ (nommage, structure)\n4. AMÉLIORATIONS (avec exemples de code corrigé)\n"
        f"Sois direct et concret.\n\n```\n{code}\n```"
    )}])


async def _run_debug_error(params: dict) -> str:
    error = params.get("error", "")
    code = params.get("code", "")
    prompt = (f"Explique cette erreur en termes simples puis donne la correction :\n\n{error}")
    if code:
        prompt += f"\n\nCode concerné :\n```\n{code}\n```"
    return await llm.chat([{"role": "user", "content": prompt}])


async def _run_app_scaffold(params: dict) -> str:
    idea = params.get("idea", "")
    level = params.get("level", "débutant")
    return await llm.chat([{"role": "user", "content": (
        f"Je veux créer cette app : {idea}\nMon niveau : {level}.\n"
        "Donne-moi :\n1. STACK recommandée (adaptée à mon niveau, gratuite)\n"
        "2. STRUCTURE de fichiers (arborescence)\n3. FONCTIONNALITÉS par ordre de priorité (MVP d'abord)\n"
        "4. ÉTAPES de développement numérotées\n5. HÉBERGEMENT gratuit recommandé et comment déployer\n"
        "Sois concret et actionnable."
    )}])


_MAX_FILES = 25
_MAX_FILE_BYTES = 120_000


def _safe_rel_path(raw: str) -> str | None:
    """Reject anything that would escape the project directory.

    File paths come from the LLM, so '../../etc/passwd', absolute paths and
    Windows drive letters must never reach the filesystem.
    """
    p = (raw or "").strip().replace("\\", "/")
    # Absolute paths are refused rather than silently made relative, so the
    # caller sees them in "ignores" instead of getting a surprising location.
    if not p or p.startswith("/") or p.startswith(".") or ":" in p:
        return None
    if ".." in p.split("/"):
        return None
    return p


async def _run_app_generate(params: dict) -> str:
    import shutil
    import uuid
    import zipfile

    from app.routes.skills_content import MEDIA_DIR

    idea = (params.get("idea") or "").strip()
    if not idea:
        raise ValueError("Décrivez ce que doit faire l'app")
    kind = params.get("kind") or "site web (HTML/CSS/JS)"
    name = _safe_rel_path(params.get("name") or "") or "app"
    name = re.sub(r"[^a-zA-Z0-9._-]", "-", name)[:40]

    raw = await llm.chat([{"role": "user", "content": (
        f"Genere les fichiers d'un projet « {kind} » qui fait : {idea}\n\n"
        "Reponds UNIQUEMENT avec un objet JSON de cette forme, sans texte autour :\n"
        '{"files":[{"path":"index.html","content":"<!DOCTYPE html>\\n<html>...</html>"}]}\n'
        # Small models copy the placeholder verbatim unless told not to.
        "Le champ content doit contenir le CODE COMPLET du fichier. "
        "N'ecris jamais « ... » comme contenu.\n"
        f"Regles : {_MAX_FILES} fichiers maximum, chaque chemin apparait UNE SEULE "
        "fois, chemins relatifs, code complet et fonctionnel, inclus un README.md. "
        "Echappe correctement les sauts de ligne.\n"
        # Mistakes small models make constantly; naming them removes most of them.
        "Contraintes de code :\n"
        "- toute fonction appelee depuis un attribut onclick doit etre globale "
        "(ne pas l'enfermer dans une IIFE ni un module)\n"
        "- preferer addEventListener aux attributs onclick\n"
        "- verifier le sens des booleens (une case cochee vaut true)\n"
        "- persister l'etat apres CHAQUE modification, pas seulement a la creation"
    )}], model=params.get("model") or None)

    # Small local models often wrap the JSON in prose or code fences.
    match = re.search(r"\{.*\}", raw, re.DOTALL)
    if not match:
        raise ValueError("Le modèle n'a pas renvoyé de JSON exploitable — reformulez ou utilisez un modèle plus grand")
    try:
        data = json.loads(match.group(0))
    except json.JSONDecodeError as e:
        raise ValueError(f"JSON invalide renvoyé par le modèle ({e.msg}) — réessayez")

    files = data.get("files") or []
    if not isinstance(files, list) or not files:
        raise ValueError("Aucun fichier généré")

    project_dir = os.path.join(MEDIA_DIR, f"{name}-{uuid.uuid4().hex[:8]}")
    written, skipped = [], []
    try:
        for item in files[:_MAX_FILES]:
            if not isinstance(item, dict):
                continue
            rel = _safe_rel_path(item.get("path", ""))
            content = item.get("content")
            if rel is None or not isinstance(content, str):
                skipped.append(item.get("path"))
                continue
            # Models sometimes emit the same path twice; keeping both would
            # write it once but list it twice and break the zip archive.
            if rel in written:
                skipped.append(item.get("path"))
                continue
            # A model that copies the prompt's placeholder produces files with
            # no real code; shipping that archive would look like a success.
            if len(content.strip()) < 10 or content.strip() in {"...", "…"}:
                skipped.append(item.get("path"))
                continue
            dest = os.path.join(project_dir, rel)
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            with open(dest, "w", encoding="utf-8") as fh:
                fh.write(content[:_MAX_FILE_BYTES])
            written.append(rel)

        if not written:
            raise ValueError("Tous les chemins proposés ont été rejetés")

        zip_name = f"{name}-{uuid.uuid4().hex[:8]}.zip"
        zip_path = os.path.join(MEDIA_DIR, zip_name)
        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
            for rel in written:
                zf.write(os.path.join(project_dir, rel), arcname=os.path.join(name, rel))
    finally:
        # The archive is the deliverable; the loose tree would just pile up.
        shutil.rmtree(project_dir, ignore_errors=True)

    return json.dumps({
        "projet": name,
        "type": kind,
        "fichiers": written,
        "ignores": skipped,
        "archive": f"/media/{zip_name}",
        "taille_ko": round(os.path.getsize(zip_path) / 1024, 1),
    }, ensure_ascii=False, indent=2)


async def _run_seo_audit(params: dict) -> str:
    import httpx
    from bs4 import BeautifulSoup
    url = params.get("url", "").strip()
    if not url.startswith("http"):
        url = "https://" + url
    async with httpx.AsyncClient(timeout=20, follow_redirects=True) as client:
        resp = await client.get(url, headers={"User-Agent": "Mozilla/5.0 (ORION-SEO-Audit)"})
    soup = BeautifulSoup(resp.text, "html.parser")

    title = (soup.title.string or "").strip() if soup.title else ""
    meta_desc = ""
    md = soup.find("meta", attrs={"name": "description"})
    if md:
        meta_desc = (md.get("content") or "").strip()
    h1s = [h.get_text(strip=True) for h in soup.find_all("h1")]
    imgs = soup.find_all("img")
    imgs_no_alt = [i.get("src", "?")[:60] for i in imgs if not (i.get("alt") or "").strip()]
    canonical = soup.find("link", attrs={"rel": "canonical"})
    og_tags = {m.get("property"): (m.get("content") or "")[:80]
               for m in soup.find_all("meta") if (m.get("property") or "").startswith("og:")}
    links = soup.find_all("a", href=True)
    text = soup.get_text(separator=" ", strip=True)
    word_count = len(text.split())

    issues, score = [], 100
    if not title:
        issues.append("CRITIQUE : pas de balise <title>"); score -= 20
    elif not 30 <= len(title) <= 65:
        issues.append(f"Title de {len(title)} caractères (optimal : 30-65)"); score -= 8
    if not meta_desc:
        issues.append("Pas de meta description"); score -= 15
    elif not 70 <= len(meta_desc) <= 160:
        issues.append(f"Meta description de {len(meta_desc)} caractères (optimal : 70-160)"); score -= 5
    if len(h1s) == 0:
        issues.append("Aucun <h1>"); score -= 15
    elif len(h1s) > 1:
        issues.append(f"{len(h1s)} balises <h1> (une seule recommandée)"); score -= 8
    if imgs_no_alt:
        issues.append(f"{len(imgs_no_alt)}/{len(imgs)} images sans attribut alt"); score -= min(15, 3 * len(imgs_no_alt))
    if not canonical:
        issues.append("Pas de balise canonical"); score -= 5
    if not og_tags:
        issues.append("Pas de balises Open Graph (aperçu réseaux sociaux)"); score -= 8
    if word_count < 300:
        issues.append(f"Contenu court : {word_count} mots (300+ recommandé)"); score -= 10

    return json.dumps({
        "url": str(resp.url),
        "score": max(0, score),
        "title": {"texte": title[:100], "longueur": len(title)},
        "meta_description": {"texte": meta_desc[:180], "longueur": len(meta_desc)},
        "h1": h1s[:5],
        "images": {"total": len(imgs), "sans_alt": len(imgs_no_alt)},
        "liens": len(links),
        "mots": word_count,
        "open_graph": list(og_tags.keys()),
        "problemes": issues or ["Aucun problème majeur détecté ✓"],
    }, ensure_ascii=False, indent=2)


async def _suggest(client, variant: str, lang: str) -> list[str]:
    """Autocomplete suggestions: self-hosted SearXNG first, Google Suggest otherwise.

    Both endpoints answer with the same shape: [query, [suggestion, ...]].
    """
    from app.config import settings
    if settings.searxng_url:
        try:
            r = await client.get(f"{settings.searxng_url.rstrip('/')}/autocompleter",
                                 params={"q": variant})
            data = r.json()
            if isinstance(data, list) and len(data) > 1 and data[1]:
                return list(data[1])[:8]
        except Exception:
            pass  # instance down → fall through to Google
    try:
        r = await client.get("https://suggestqueries.google.com/complete/search",
                             params={"client": "firefox", "q": variant, "hl": lang})
        return list(r.json()[1])[:8]
    except Exception:
        return []


async def _run_seo_keywords(params: dict) -> str:
    import httpx
    keyword = params.get("keyword", "").strip()
    lang = params.get("lang", "fr")
    if not keyword:
        raise ValueError("Mot-clé requis")
    suggestions: list[str] = []
    async with httpx.AsyncClient(timeout=15) as client:
        variants = [keyword] + [f"{keyword} {p}" for p in
                                ["comment", "pourquoi", "avis", "prix", "meilleur"][:5 if lang == "fr" else 0]] \
                   + ([f"{keyword} {p}" for p in ["how", "why", "best", "review", "price"]] if lang == "en" else [])
        for v in variants[:6]:
            suggestions.extend(await _suggest(client, v, lang))
    unique = list(dict.fromkeys(s for s in suggestions if s.lower() != keyword.lower()))
    if not unique:
        return "Aucune suggestion trouvée (service d'autocomplétion inaccessible ?)."
    return json.dumps({
        "mot_cle": keyword,
        "total": len(unique),
        "suggestions": unique[:40],
    }, ensure_ascii=False, indent=2)


async def _run_seo_meta(params: dict) -> str:
    topic = params.get("topic", "")
    keyword = params.get("keyword", "")
    return await llm.chat([{"role": "user", "content": (
        f"Page sur : {topic}\nMot-clé principal : « {keyword} »\n"
        "Génère en français :\n"
        "1. TITLE (50-60 caractères, mot-clé au début, incitatif)\n"
        "2. META DESCRIPTION (140-155 caractères, avec appel à l'action)\n"
        "3. H1 (différent du title)\n"
        "4. Plan H2/H3 (5-7 sections couvrant l'intention de recherche)\n"
        "5. 3 questions pour une FAQ (People Also Ask)\n"
        "Propose 2 variantes pour le title et la meta description."
    )}])


async def _run_ux_review(params: dict) -> str:
    description = params.get("description", "")
    audience = params.get("audience", "grand public")
    return await llm.chat([{"role": "user", "content": (
        f"Interface à évaluer : {description}\nUtilisateur type : {audience}\n"
        "Fais une revue UX selon les 10 heuristiques de Nielsen. Pour chaque heuristique "
        "pertinente : problème détecté (ou ✓ si OK) et recommandation concrète. "
        "Termine par le TOP 3 des corrections prioritaires classées par impact."
    )}])


async def _run_deploy_vercel(params: dict) -> str:
    import httpx
    token = os.environ.get("VERCEL_TOKEN", "").strip()
    if not token:
        raise ValueError("VERCEL_TOKEN absent du .env — ajoutez-le puis recréez les conteneurs")
    project = params.get("project", "").strip().lower()
    if not re.fullmatch(r"[a-z0-9][a-z0-9-]{1,51}", project):
        raise ValueError("Nom de projet invalide : minuscules, chiffres et tirets uniquement")
    html = params.get("html", "").strip()
    if not html:
        raise ValueError("Contenu HTML requis")

    files = [{"file": "index.html", "data": base64.b64encode(html.encode()).decode(), "encoding": "base64"}]
    for fname, key in (("style.css", "css"), ("script.js", "js")):
        content = (params.get(key) or "").strip()
        if content:
            files.append({"file": fname, "data": base64.b64encode(content.encode()).decode(),
                          "encoding": "base64"})

    headers = {"Authorization": f"Bearer {token}"}
    async with httpx.AsyncClient(timeout=60) as client:
        user_resp = await client.get("https://api.vercel.com/v2/user", headers=headers)
        user_resp.raise_for_status()
        team_id = user_resp.json().get("user", {}).get("defaultTeamId")
        query = {"teamId": team_id} if team_id else {}
        resp = await client.post(
            "https://api.vercel.com/v13/deployments", headers=headers, params=query,
            json={"name": project, "files": files, "target": "production",
                  "projectSettings": {"framework": None}},
        )
        if resp.status_code >= 400:
            detail = resp.json().get("error", {}).get("message", resp.text[:200])
            raise ValueError(f"Vercel a refusé le déploiement : {detail}")
        data = resp.json()
        # URL publique stable du projet (l'URL de déploiement est protégée par défaut)
        public_url = f"https://{data.get('url', '')}"
        try:
            dom_resp = await client.get(
                f"https://api.vercel.com/v9/projects/{project}/domains",
                headers=headers, params=query)
            domains = dom_resp.json().get("domains", [])
            if domains:
                public_url = f"https://{domains[0]['name']}"
        except Exception:
            pass
    return json.dumps({
        "status": data.get("readyState", "QUEUED"),
        "url": public_url,
        "projet": project,
        "fichiers": [f["file"] for f in files],
        "note": "La mise en ligne prend ~30 s.",
    }, ensure_ascii=False, indent=2)


DEV_RUNNERS = {
    "deploy_vercel": _run_deploy_vercel,
    "generate_code": _run_generate_code,
    "code_review": _run_code_review,
    "debug_error": _run_debug_error,
    "app_scaffold": _run_app_scaffold,
    "app_generate": _run_app_generate,
    "seo_audit": _run_seo_audit,
    "seo_keywords": _run_seo_keywords,
    "seo_meta": _run_seo_meta,
    "ux_review": _run_ux_review,
}
