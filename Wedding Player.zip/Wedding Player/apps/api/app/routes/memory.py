from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc
from pydantic import BaseModel
from app.database import get_db
from app.models import Memory

router = APIRouter(prefix="/memory", tags=["memory"])

class MemoryStore(BaseModel):
    agent_id: str
    key: str
    value: str

@router.get("/")
async def list_memories(agent_id: str | None = None, db: AsyncSession = Depends(get_db)):
    q = select(Memory).order_by(desc(Memory.created_at)).limit(100)
    if agent_id:
        q = q.where(Memory.agent_id == agent_id)
    result = await db.execute(q)
    return result.scalars().all()

@router.post("/")
async def store_memory(body: MemoryStore, db: AsyncSession = Depends(get_db)):
    mem = Memory(agent_id=body.agent_id, key=body.key, value=body.value)
    db.add(mem)
    await db.commit()
    await db.refresh(mem)
    return mem

@router.delete("/{memory_id}")
async def delete_memory(memory_id: int, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Memory).where(Memory.id == memory_id))
    mem = result.scalar_one_or_none()
    if mem:
        await db.delete(mem)
        await db.commit()
    return {"deleted": memory_id}
