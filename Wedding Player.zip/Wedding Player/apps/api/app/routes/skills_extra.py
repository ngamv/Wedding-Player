"""
Skills additionnels : QR code, conversion devises, JSON, slug (utilitaires déterministes)
+ hashtags, variations de légende, description produit, réponse client (via LLM).
Fusionnés dans le registre par skills.py.
"""
import json
import re
import uuid

from app import llm
from app.routes.skills_content import MEDIA_DIR, _media_path

EXTRA_SKILLS: dict[str, dict] = {
    "qr_code": {
        "name": "QR Code",
        "description": "Génère un QR code (vers une URL ou un texte) en image PNG",
        "icon": "QrCode",
        "category": "utility",
        "params": [
            {"name": "data", "type": "text", "required": True, "label": "URL ou texte",
             "placeholder": "https://bilan-aloe.vercel.app"},
        ],
    },
    "currency_convert": {
        "name": "Conversion de devises",
        "description": "Convertit un montant entre devises (taux du jour, sans clé API)",
        "icon": "DollarSign",
        "category": "utility",
        "params": [
            {"name": "amount", "type": "text", "required": True, "label": "Montant", "default": "100"},
            {"name": "from", "type": "text", "required": True, "label": "De (ex. EUR)", "default": "EUR"},
            {"name": "to", "type": "text", "required": True, "label": "Vers (ex. USD)", "default": "USD"},
        ],
    },
    "json_format": {
        "name": "Formater / valider JSON",
        "description": "Indente et valide un JSON, ou signale l'erreur de syntaxe",
        "icon": "Braces",
        "category": "utility",
        "params": [
            {"name": "json_text", "type": "textarea", "required": True, "label": "JSON à formater"},
        ],
    },
    "slugify": {
        "name": "Slug d'URL",
        "description": "Transforme un titre en slug propre pour une URL (accents, espaces)",
        "icon": "Link2",
        "category": "utility",
        "params": [
            {"name": "text", "type": "text", "required": True, "label": "Titre",
             "placeholder": "Les bienfaits de l'aloe vera"},
        ],
    },
    "hashtags": {
        "name": "Générateur de hashtags",
        "description": "Propose des hashtags pertinents pour un sujet de post (via LLM)",
        "icon": "Hash",
        "category": "content",
        "params": [
            {"name": "topic", "type": "textarea", "required": True, "label": "Sujet du post"},
            {"name": "count", "type": "text", "required": False, "label": "Nombre", "default": "15"},
        ],
    },
    "caption_variations": {
        "name": "Variations de légende",
        "description": "Génère 3 variantes d'une légende pour tester (via LLM)",
        "icon": "Repeat",
        "category": "content",
        "params": [
            {"name": "caption", "type": "textarea", "required": True, "label": "Légende de base"},
        ],
    },
    "product_description": {
        "name": "Fiche produit",
        "description": "Rédige une description de vente conforme (bien-être, sans allégation santé)",
        "icon": "Package",
        "category": "content",
        "params": [
            {"name": "product", "type": "text", "required": True, "label": "Produit"},
            {"name": "highlights", "type": "textarea", "required": False, "label": "Points à mettre en avant"},
        ],
    },
    "customer_reply": {
        "name": "Réponse client",
        "description": "Rédige une réponse chaleureuse à un message de prospect/client (via LLM)",
        "icon": "MessageSquare",
        "category": "communication",
        "params": [
            {"name": "message", "type": "textarea", "required": True, "label": "Message reçu"},
            {"name": "intent", "type": "select",
             "options": ["répondre à une question", "relancer en douceur", "remercier", "prendre rendez-vous"],
             "required": False, "label": "Objectif", "default": "répondre à une question"},
        ],
    },
}


# ---------------------------------------------------------------------------
# Runners déterministes
# ---------------------------------------------------------------------------

def _run_qr_code(params: dict) -> str:
    import qrcode
    data = params.get("data", "").strip()
    if not data:
        raise ValueError("URL ou texte requis")
    img = qrcode.make(data)
    path, name = _media_path("png")
    img.save(path)
    return json.dumps({
        "file": name,
        "download_url": f"/api/skills/media/{name}",
        "data": data,
    }, ensure_ascii=False, indent=2)


async def _run_currency_convert(params: dict) -> str:
    import httpx
    amount = params.get("amount", "1")
    src = params.get("from", "EUR").upper().strip()
    dst = params.get("to", "USD").upper().strip()
    try:
        amt = float(str(amount).replace(",", "."))
    except ValueError:
        raise ValueError("Montant invalide")
    async with httpx.AsyncClient(timeout=15) as c:
        r = await c.get(f"https://open.er-api.com/v6/latest/{src}")
        data = r.json()
    rates = data.get("rates", {})
    if data.get("result") != "success" or dst not in rates:
        raise ValueError(f"Devise inconnue ({src} → {dst}). Utilise des codes ISO (EUR, USD, GBP…).")
    rate = rates[dst]
    converted = round(amt * rate, 2)
    return json.dumps({
        "de": f"{amt} {src}", "vers": f"{converted} {dst}",
        "taux": round(rate, 4), "date": data.get("time_last_update_utc", "")[:16],
    }, ensure_ascii=False, indent=2)


def _run_json_format(params: dict) -> str:
    raw = params.get("json_text", "")
    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError as e:
        raise ValueError(f"JSON invalide : {e}")
    return json.dumps(parsed, ensure_ascii=False, indent=2)


def _run_slugify(params: dict) -> str:
    import unicodedata
    text = params.get("text", "")
    text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode()
    slug = re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")
    return slug or "(vide)"


# ---------------------------------------------------------------------------
# Runners LLM
# ---------------------------------------------------------------------------

_COMPLIANCE = ("Règle stricte : aucune allégation santé/médicale "
               "(pas de « soigne », « guérit », « immunité », « détox », « cellules »). "
               "Reste sur le bien-être, l'hydratation, le plaisir, le naturel.")


async def _run_hashtags(params: dict) -> str:
    topic = params.get("topic", "")
    count = params.get("count", "15")
    return await llm.chat([{"role": "user", "content": (
        f"Génère {count} hashtags pertinents pour un post sur : {topic}\n"
        "Mélange hashtags larges et de niche, en français et quelques-uns en anglais. "
        "Retourne-les sur une seule ligne, séparés par des espaces, chacun commençant par #. "
        f"{_COMPLIANCE}"
    )}])


async def _run_caption_variations(params: dict) -> str:
    caption = params.get("caption", "")
    return await llm.chat([{"role": "user", "content": (
        f"Voici une légende : « {caption} »\n"
        "Propose 3 variantes numérotées, chacune avec un angle différent "
        "(1. émotionnel, 2. direct/vendeur doux, 3. question engageante). "
        f"Garde le sens et la langue. {_COMPLIANCE}"
    )}])


async def _run_product_description(params: dict) -> str:
    product = params.get("product", "")
    highlights = params.get("highlights", "")
    prompt = (f"Rédige une description de vente pour : {product}\n"
              "Structure : une accroche, 3-4 bénéfices bien-être concrets, un appel à l'action doux. "
              f"{_COMPLIANCE}")
    if highlights:
        prompt += f"\nPoints à mettre en avant : {highlights}"
    return await llm.chat([{"role": "user", "content": prompt}])


async def _run_customer_reply(params: dict) -> str:
    message = params.get("message", "")
    intent = params.get("intent", "répondre à une question")
    return await llm.chat([{"role": "user", "content": (
        f"Un prospect/client a écrit : « {message} »\n"
        f"Rédige une réponse chaleureuse et professionnelle dont l'objectif est : {intent}. "
        "Ton naturel, tutoiement, courte (2-4 phrases). "
        f"{_COMPLIANCE}"
    )}])


EXTRA_RUNNERS = {
    "qr_code": _run_qr_code,
    "currency_convert": _run_currency_convert,
    "json_format": _run_json_format,
    "slugify": _run_slugify,
    "hashtags": _run_hashtags,
    "caption_variations": _run_caption_variations,
    "product_description": _run_product_description,
    "customer_reply": _run_customer_reply,
}
