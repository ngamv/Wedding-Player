from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc
from pydantic import BaseModel
from app.database import get_db
from app.models import ChatSession, ChatMessage, User
from app.auth import get_current_user
from app.orchestrator import route_and_run

router = APIRouter(prefix="/chat", tags=["chat"])


class SendMsg(BaseModel):
    content: str
    agent_id: str | None = None
    session_id: int | None = None


@router.get("/sessions")
async def list_sessions(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(ChatSession)
        .where(ChatSession.user_id == current_user.id)
        .order_by(desc(ChatSession.updated_at))
        .limit(50)
    )
    sessions = result.scalars().all()
    return [{"id": s.id, "title": s.title, "created_at": s.created_at, "updated_at": s.updated_at} for s in sessions]


@router.post("/sessions")
async def create_session(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    session = ChatSession(user_id=current_user.id)
    db.add(session)
    await db.commit()
    await db.refresh(session)
    return {"id": session.id, "title": session.title, "created_at": session.created_at}


@router.get("/sessions/{session_id}/messages")
async def get_messages(
    session_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    sess = await db.get(ChatSession, session_id)
    if not sess or sess.user_id != current_user.id:
        raise HTTPException(404, "Session introuvable")
    result = await db.execute(
        select(ChatMessage)
        .where(ChatMessage.session_id == session_id)
        .order_by(ChatMessage.created_at)
    )
    msgs = result.scalars().all()
    return [{"id": m.id, "role": m.role, "content": m.content, "agent_name": m.agent_name, "created_at": m.created_at} for m in msgs]


@router.post("/sessions/{session_id}/messages")
async def send_message(
    session_id: int,
    body: SendMsg,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    sess = await db.get(ChatSession, session_id)
    if not sess or sess.user_id != current_user.id:
        raise HTTPException(404, "Session introuvable")

    user_msg = ChatMessage(session_id=session_id, role="user", content=body.content)
    db.add(user_msg)
    await db.commit()

    try:
        result = await route_and_run(body.content, body.agent_id)
        reply = result.get("result", "")
        agent_name = result.get("agent_name")
    except Exception as e:
        reply = f"Erreur : {e}"
        agent_name = None

    assistant_msg = ChatMessage(
        session_id=session_id, role="assistant",
        content=reply, agent_name=agent_name,
    )
    db.add(assistant_msg)

    # Update session title from first user message
    if not sess.title or sess.title == "Nouvelle conversation":
        sess.title = body.content[:60]
    await db.commit()
    await db.refresh(assistant_msg)

    return {
        "id": assistant_msg.id,
        "role": "assistant",
        "content": reply,
        "agent_name": agent_name,
        "created_at": assistant_msg.created_at,
    }


@router.delete("/sessions/{session_id}")
async def delete_session(
    session_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    sess = await db.get(ChatSession, session_id)
    if not sess or sess.user_id != current_user.id:
        raise HTTPException(404, "Session introuvable")
    await db.execute(
        ChatMessage.__table__.delete().where(ChatMessage.session_id == session_id)  # type: ignore[attr-defined]
    )
    await db.delete(sess)
    await db.commit()
    return {"ok": True}
