import time
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, Query


def _estimate_tokens(text: str) -> int:
    """Rough token estimate: ~0.75 words per token (GPT-style)."""
    return max(1, int(len(text.split()) / 0.75))
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc, func, or_
from pydantic import BaseModel
from app.database import get_db
from app.models import Task, TaskStatus, AgentMetric, User, CustomAgent
from app.orchestrator import route_and_run
from app.routes.webhooks import fire_webhooks
from app.auth import get_current_user
from app.ws import manager

router = APIRouter(prefix="/tasks", tags=["tasks"])


class TaskCreate(BaseModel):
    title: str
    description: str | None = None
    agent_id: str | None = None
    input_data: dict | None = None
    model: str | None = None
    tags: list[str] | None = None


@router.get("/")
async def list_tasks(
    search: str | None = Query(None),
    status: str | None = Query(None),
    agent_id: str | None = Query(None),
    tag: str | None = Query(None),
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    q = select(Task).where(Task.user_id == current_user.id)

    if search:
        q = q.where(Task.title.ilike(f"%{search}%"))
    if status and status in ("pending", "running", "completed", "failed"):
        q = q.where(Task.status == status)
    if agent_id:
        q = q.where(Task.agent_id == agent_id)
    if tag:
        from sqlalchemy import cast
        from sqlalchemy.types import Text
        q = q.where(cast(Task.tags, Text).ilike(f'%"{tag}"%'))

    total_result = await db.execute(select(func.count()).select_from(q.subquery()))
    total = total_result.scalar_one()

    q = q.order_by(desc(Task.created_at)).offset((page - 1) * page_size).limit(page_size)
    result = await db.execute(q)
    tasks = result.scalars().all()

    return {
        "tasks": [{"id": t.id, "title": t.title, "agent_id": t.agent_id,
                   "status": t.status, "created_at": t.created_at, "tags": t.tags or []} for t in tasks],
        "total": total,
        "page": page,
        "page_size": page_size,
        "pages": max(1, -(-total // page_size)),
    }


@router.post("/")
async def create_task(
    body: TaskCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    # Rate limit check for custom agents
    if body.agent_id:
        agent_row = await db.execute(
            select(CustomAgent).where(CustomAgent.agent_id == body.agent_id)
        )
        custom_agent = agent_row.scalar_one_or_none()
        if custom_agent and custom_agent.rate_limit:
            from datetime import timedelta
            one_hour_ago = datetime.utcnow() - timedelta(hours=1)
            recent_count = (await db.execute(
                select(func.count(Task.id)).where(
                    Task.user_id == current_user.id,
                    Task.agent_id == body.agent_id,
                    Task.created_at >= one_hour_ago,
                )
            )).scalar_one()
            if recent_count >= custom_agent.rate_limit:
                raise HTTPException(
                    429,
                    f"Rate limit atteint pour l'agent '{body.agent_id}' "
                    f"({custom_agent.rate_limit} tâches/heure max)",
                )

    task = Task(
        user_id=current_user.id,
        title=body.title,
        description=body.description,
        agent_id=body.agent_id or "orchestrator",
        status=TaskStatus.running,
        input_data=body.input_data,
        tags=body.tags or [],
    )
    db.add(task)
    await db.commit()
    await db.refresh(task)

    event = "task.completed"
    t0 = time.monotonic()
    metric_status = "success"
    try:
        result = await route_and_run(body.title, body.agent_id, body.input_data, model=body.model)
        task.status = TaskStatus.completed
        task.output_data = result
        from app.notifier import notify_task_completed
        from app.config import settings
        if "task_completed" in settings.notify_on and current_user.email:
            await notify_task_completed(current_user.email, task.id, task.title)
    except Exception as e:
        task.status = TaskStatus.failed
        task.output_data = {"error": str(e)}
        event = "task.failed"
        metric_status = "fail"
        from app.notifier import notify_task_failed
        from app.config import settings
        if "task_failed" in settings.notify_on and current_user.email:
            await notify_task_failed(current_user.email, task.id, task.title, str(e))

    elapsed_ms = int((time.monotonic() - t0) * 1000)
    output_text = ""
    if isinstance(task.output_data, dict):
        output_text = str(task.output_data.get("result", "") or "")
    metric = AgentMetric(
        agent_id=task.agent_id,
        task_id=task.id,
        execution_time_ms=elapsed_ms,
        status=metric_status,
        tokens_in=_estimate_tokens(body.title),
        tokens_out=_estimate_tokens(output_text),
    )
    db.add(metric)
    await db.commit()
    task_payload = {"id": task.id, "title": task.title, "agent_id": task.agent_id, "status": task.status}
    await fire_webhooks(db, event, task_payload)
    await manager.send(current_user.id, event, task_payload)
    from app.routes.push import send_push
    if task.status == TaskStatus.completed:
        await send_push(current_user.id, "Tâche terminée ✓", task.title[:80], db)
    else:
        await send_push(current_user.id, "Tâche échouée ✗", task.title[:80], db)
    from app.routes.notifications import create_notification
    if task.status == TaskStatus.completed:
        await create_notification(db, user_id=current_user.id, type="task.completed",
            title=f"Tâche terminée : {task.title[:60]}", body=f"Agent : {task.agent_id}")
    else:
        await create_notification(db, user_id=current_user.id, type="task.failed",
            title=f"Tâche échouée : {task.title[:60]}", body=str(task.output_data or ""))
    return {"id": task.id, "status": task.status, "output": task.output_data}


@router.get("/{task_id}")
async def get_task(
    task_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(Task).where(Task.id == task_id, Task.user_id == current_user.id)
    )
    task = result.scalar_one_or_none()
    if not task:
        raise HTTPException(404, "Task not found")
    return task


@router.post("/{task_id}/retry")
async def retry_task(
    task_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Create a new task with the same parameters as an existing one."""
    result = await db.execute(
        select(Task).where(Task.id == task_id, Task.user_id == current_user.id)
    )
    original = result.scalar_one_or_none()
    if not original:
        raise HTTPException(404, "Task not found")

    new_task = Task(
        user_id=current_user.id,
        title=original.title,
        description=original.description,
        agent_id=original.agent_id,
        status=TaskStatus.running,
        input_data=original.input_data,
    )
    db.add(new_task)
    await db.commit()
    await db.refresh(new_task)

    event = "task.completed"
    t0 = time.monotonic()
    metric_status = "success"
    try:
        result_data = await route_and_run(original.title, original.agent_id, original.input_data)
        new_task.status = TaskStatus.completed
        new_task.output_data = result_data
    except Exception as e:
        new_task.status = TaskStatus.failed
        new_task.output_data = {"error": str(e)}
        event = "task.failed"
        metric_status = "fail"

    elapsed_ms = int((time.monotonic() - t0) * 1000)
    db.add(AgentMetric(
        agent_id=new_task.agent_id,
        task_id=new_task.id,
        execution_time_ms=elapsed_ms,
        status=metric_status,
    ))
    await db.commit()
    task_payload = {"id": new_task.id, "title": new_task.title, "agent_id": new_task.agent_id, "status": new_task.status}
    await fire_webhooks(db, event, task_payload)
    await manager.send(current_user.id, event, task_payload)
    return {"id": new_task.id, "status": new_task.status, "original_id": task_id, "output": new_task.output_data}
