"""Scheduled tasks (cron-style) backed by APScheduler."""
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel
from app.database import get_db
from app.models import ScheduledTask, User
from app.auth import get_current_user
from app.scheduler import add_job, remove_job

router = APIRouter(prefix="/scheduled", tags=["scheduled"])


class ScheduledTaskCreate(BaseModel):
    name: str
    agent_id: str
    prompt: str
    cron: str  # e.g. "0 9 * * 1-5"
    is_active: bool = True


class ScheduledTaskUpdate(BaseModel):
    name: str | None = None
    prompt: str | None = None
    cron: str | None = None
    is_active: bool | None = None


@router.get("/")
async def list_scheduled(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(ScheduledTask).where(ScheduledTask.user_id == current_user.id)
        .order_by(ScheduledTask.created_at.desc())
    )
    tasks = result.scalars().all()
    return [_serialize(t) for t in tasks]


@router.post("/", status_code=201)
async def create_scheduled(
    body: ScheduledTaskCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    _validate_cron(body.cron)
    task = ScheduledTask(
        user_id=current_user.id,
        name=body.name,
        agent_id=body.agent_id,
        prompt=body.prompt,
        cron=body.cron,
        is_active=body.is_active,
    )
    db.add(task)
    await db.commit()
    await db.refresh(task)
    if task.is_active:
        await add_job(task, current_user.email)
    return _serialize(task)


@router.patch("/{task_id}")
async def update_scheduled(
    task_id: int,
    body: ScheduledTaskUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(ScheduledTask).where(
            ScheduledTask.id == task_id, ScheduledTask.user_id == current_user.id
        )
    )
    task = result.scalar_one_or_none()
    if not task:
        raise HTTPException(404, "Tâche planifiée introuvable")
    if body.name is not None:
        task.name = body.name
    if body.prompt is not None:
        task.prompt = body.prompt
    if body.cron is not None:
        _validate_cron(body.cron)
        task.cron = body.cron
    if body.is_active is not None:
        task.is_active = body.is_active

    await db.commit()
    await db.refresh(task)
    # Reschedule
    await remove_job(task.id)
    if task.is_active:
        await add_job(task, current_user.email)
    return _serialize(task)


@router.delete("/{task_id}", status_code=204)
async def delete_scheduled(
    task_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(ScheduledTask).where(
            ScheduledTask.id == task_id, ScheduledTask.user_id == current_user.id
        )
    )
    task = result.scalar_one_or_none()
    if not task:
        raise HTTPException(404, "Tâche planifiée introuvable")
    await remove_job(task.id)
    await db.delete(task)
    await db.commit()


def _serialize(t: ScheduledTask) -> dict:
    return {
        "id": t.id,
        "name": t.name,
        "agent_id": t.agent_id,
        "prompt": t.prompt,
        "cron": t.cron,
        "is_active": t.is_active,
        "last_run_at": t.last_run_at,
        "created_at": t.created_at,
    }


def _validate_cron(expr: str) -> None:
    parts = expr.strip().split()
    if len(parts) != 5:
        raise HTTPException(400, "Expression cron invalide (5 champs attendus : min h dom mon dow)")
