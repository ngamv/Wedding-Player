"""
Skills d'integration : GitHub, PostgreSQL, Docker.

Les identifiants proviennent de la configuration (GITHUB_TOKEN, DATABASE_*)
et ne transitent jamais par les parametres du skill.
Fusionnes dans le registre par skills.py.
"""
import json
import os

import httpx

from app.config import settings

GITHUB_API = "https://api.github.com"
DOCKER_SOCKET = "/var/run/docker.sock"

INTEGRATION_SKILLS: dict[str, dict] = {
    "github_repo": {
        "name": "GitHub — dépôt",
        "description": "Infos d'un dépôt : description, langages, étoiles, dernier commit",
        "icon": "Github",
        "category": "integration",
        "params": [
            {"name": "repo", "type": "text", "required": True, "label": "Dépôt (owner/name)",
             "placeholder": "fastapi/fastapi"},
        ],
    },
    "github_issues": {
        "name": "GitHub — issues",
        "description": "Liste les issues ouvertes d'un dépôt, ou en crée une nouvelle",
        "icon": "CircleDot",
        "category": "integration",
        "params": [
            {"name": "repo", "type": "text", "required": True, "label": "Dépôt (owner/name)",
             "placeholder": "mon-org/mon-projet"},
            {"name": "action", "type": "select", "options": ["lister", "créer"],
             "required": True, "label": "Action", "default": "lister"},
            {"name": "title", "type": "text", "required": False, "label": "Titre (création)"},
            {"name": "body", "type": "textarea", "required": False, "label": "Description (création)"},
        ],
    },
    "postgres_query": {
        "name": "PostgreSQL — requête",
        "description": "Exécute une requête SELECT sur une base PostgreSQL et renvoie les lignes",
        "icon": "Database",
        "category": "integration",
        "params": [
            {"name": "dsn", "type": "text", "required": True, "label": "Connexion",
             "placeholder": "postgresql://user:pass@host:5432/base"},
            {"name": "query", "type": "textarea", "required": True, "label": "Requête SELECT",
             "placeholder": "SELECT id, email FROM clients LIMIT 20"},
            {"name": "limit", "type": "text", "required": False, "label": "Lignes max", "default": "100"},
        ],
    },
    "docker_status": {
        "name": "Docker — conteneurs",
        "description": "État des conteneurs : nom, image, statut, ports (lecture seule)",
        "icon": "Container",
        "category": "integration",
        "params": [
            {"name": "filter", "type": "text", "required": False, "label": "Filtre sur le nom",
             "placeholder": "orion"},
        ],
    },
}


def _gh_headers() -> dict:
    headers = {"Accept": "application/vnd.github+json", "User-Agent": "ORION-AI/1.0"}
    if settings.github_token:
        headers["Authorization"] = f"Bearer {settings.github_token}"
    return headers


async def _run_github_repo(params: dict) -> str:
    repo = params.get("repo", "").strip().strip("/")
    if "/" not in repo:
        raise ValueError("Format attendu : owner/name")
    async with httpx.AsyncClient(timeout=20) as client:
        r = await client.get(f"{GITHUB_API}/repos/{repo}", headers=_gh_headers())
        if r.status_code == 404:
            raise ValueError(f"Dépôt introuvable ou privé : {repo}")
        if r.status_code == 403:
            raise ValueError("Quota GitHub atteint — définissez GITHUB_TOKEN")
        r.raise_for_status()
        d = r.json()
        langs = await client.get(f"{GITHUB_API}/repos/{repo}/languages", headers=_gh_headers())
        commits = await client.get(f"{GITHUB_API}/repos/{repo}/commits",
                                   params={"per_page": 1}, headers=_gh_headers())
    last = ""
    if commits.status_code == 200 and commits.json():
        c = commits.json()[0]
        last = f"{c['commit']['message'].splitlines()[0]} ({c['commit']['author']['date'][:10]})"
    return json.dumps({
        "depot": d["full_name"],
        "description": d.get("description"),
        "etoiles": d.get("stargazers_count"),
        "forks": d.get("forks_count"),
        "issues_ouvertes": d.get("open_issues_count"),
        "langages": list(langs.json().keys())[:6] if langs.status_code == 200 else [],
        "licence": (d.get("license") or {}).get("spdx_id"),
        "dernier_commit": last,
    }, ensure_ascii=False, indent=2)


async def _run_github_issues(params: dict) -> str:
    repo = params.get("repo", "").strip().strip("/")
    if "/" not in repo:
        raise ValueError("Format attendu : owner/name")
    action = params.get("action", "lister")

    if action == "créer":
        if not settings.github_token:
            raise ValueError("GITHUB_TOKEN requis pour créer une issue")
        if not params.get("title"):
            raise ValueError("Titre requis")
        async with httpx.AsyncClient(timeout=20) as client:
            r = await client.post(
                f"{GITHUB_API}/repos/{repo}/issues", headers=_gh_headers(),
                json={"title": params["title"], "body": params.get("body", "")},
            )
            r.raise_for_status()
            d = r.json()
        return json.dumps({"cree": True, "numero": d["number"], "url": d["html_url"]},
                          ensure_ascii=False, indent=2)

    async with httpx.AsyncClient(timeout=20) as client:
        r = await client.get(f"{GITHUB_API}/repos/{repo}/issues",
                             params={"state": "open", "per_page": 20}, headers=_gh_headers())
        r.raise_for_status()
        # The issues endpoint also returns pull requests; keep only real issues
        # so that the count matches the listing.
        issues = [i for i in r.json() if "pull_request" not in i]
    return json.dumps({
        "depot": repo,
        "total": len(issues),
        "issues": [{"numero": i["number"], "titre": i["title"], "auteur": i["user"]["login"],
                    "labels": [l["name"] for l in i.get("labels", [])]}
                   for i in issues],
    }, ensure_ascii=False, indent=2)


async def _run_postgres_query(params: dict) -> str:
    query = (params.get("query") or "").strip().rstrip(";")
    if not query:
        raise ValueError("Requête requise")
    # Read-only by design: a skill reachable from an agent must not be able to
    # mutate or drop anything in a business database.
    if not query.lower().lstrip("( ").startswith(("select", "with")):
        raise ValueError("Seules les requêtes SELECT / WITH sont autorisées")

    try:
        import asyncpg
    except ImportError:
        raise ValueError("asyncpg non installé")

    try:
        limit = min(int(params.get("limit") or 100), 1000)
    except ValueError:
        limit = 100

    conn = await asyncpg.connect(params["dsn"], timeout=15)
    try:
        rows = await conn.fetch(f"SELECT * FROM ({query}) AS _q LIMIT {limit}")
    finally:
        await conn.close()

    return json.dumps({
        "lignes": len(rows),
        "colonnes": list(rows[0].keys()) if rows else [],
        "donnees": [{k: (v.isoformat() if hasattr(v, "isoformat") else v)
                     for k, v in dict(r).items()} for r in rows],
    }, ensure_ascii=False, indent=2, default=str)


async def _run_docker_status(params: dict) -> str:
    if not os.path.exists(DOCKER_SOCKET):
        raise ValueError(
            "Socket Docker non monté. Ce skill est désactivé par défaut : monter "
            "/var/run/docker.sock donne au conteneur le contrôle de la machine hôte. "
            "Pour l'activer, ajoutez au service api :\n"
            "  volumes:\n    - /var/run/docker.sock:/var/run/docker.sock:ro"
        )
    transport = httpx.AsyncHTTPTransport(uds=DOCKER_SOCKET)
    async with httpx.AsyncClient(transport=transport, base_url="http://docker", timeout=15) as client:
        r = await client.get("/containers/json", params={"all": "true"})
        r.raise_for_status()
        containers = r.json()

    flt = (params.get("filter") or "").lower()
    out = []
    for c in containers:
        name = (c.get("Names") or ["/?"])[0].lstrip("/")
        if flt and flt not in name.lower():
            continue
        out.append({
            "nom": name,
            "image": c.get("Image"),
            "statut": c.get("Status"),
            "etat": c.get("State"),
            "ports": sorted({f"{p.get('PublicPort')}->{p.get('PrivatePort')}"
                             for p in c.get("Ports", []) if p.get("PublicPort")}),
        })
    return json.dumps({"total": len(out), "conteneurs": out}, ensure_ascii=False, indent=2)


INTEGRATION_RUNNERS = {
    "github_repo": _run_github_repo,
    "github_issues": _run_github_issues,
    "postgres_query": _run_postgres_query,
    "docker_status": _run_docker_status,
}
