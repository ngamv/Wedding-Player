import pyotp
import qrcode
import io
import base64
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from pydantic import BaseModel
from app.database import get_db
from app.models import User
from app.auth import get_current_user

router = APIRouter(prefix="/auth/totp", tags=["totp"])


class TOTPSetupOut(BaseModel):
    secret: str
    qr_data_url: str
    provisioning_uri: str


class TOTPVerifyBody(BaseModel):
    code: str


class TOTPDisableBody(BaseModel):
    code: str


@router.post("/setup", response_model=TOTPSetupOut)
async def setup_totp(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    if current_user.totp_enabled:
        raise HTTPException(400, "2FA déjà activé. Désactivez-le d'abord.")
    secret = pyotp.random_base32()
    current_user.totp_secret = secret
    db.add(current_user)
    await db.commit()
    uri = pyotp.totp.TOTP(secret).provisioning_uri(
        name=current_user.email, issuer_name="ORION AI"
    )
    img = qrcode.make(uri)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    b64 = base64.b64encode(buf.getvalue()).decode()
    return TOTPSetupOut(
        secret=secret,
        qr_data_url=f"data:image/png;base64,{b64}",
        provisioning_uri=uri,
    )


@router.post("/verify")
async def verify_totp(
    body: TOTPVerifyBody,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    if not current_user.totp_secret:
        raise HTTPException(400, "Lancez d'abord /auth/totp/setup")
    totp = pyotp.TOTP(current_user.totp_secret)
    if not totp.verify(body.code, valid_window=1):
        raise HTTPException(400, "Code invalide")
    current_user.totp_enabled = True
    db.add(current_user)
    await db.commit()
    return {"message": "2FA activé"}


@router.post("/disable")
async def disable_totp(
    body: TOTPDisableBody,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    if not current_user.totp_enabled or not current_user.totp_secret:
        raise HTTPException(400, "2FA non activé")
    totp = pyotp.TOTP(current_user.totp_secret)
    if not totp.verify(body.code, valid_window=1):
        raise HTTPException(400, "Code invalide")
    current_user.totp_enabled = False
    current_user.totp_secret = None
    db.add(current_user)
    await db.commit()
    return {"message": "2FA désactivé"}
