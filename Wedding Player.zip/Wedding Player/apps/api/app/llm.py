"""
Unified LLM client.
Priority order (when llm_provider == "auto"):
  1. Ollama (local)
  2. OpenAI (if key set)
  3. Anthropic (if key set)

Runtime override (survives container restarts via Docker volume):
  Stored in DATA_DIR/llm_override.json — takes precedence over env vars.
"""
import json
import logging
import os
from contextlib import contextmanager
from contextvars import ContextVar

from app.config import settings
from app import ollama as _ollama

log = logging.getLogger("orion.llm")

_OVERRIDE_FILE = os.path.join(os.environ.get("DATA_DIR", "/data"), "llm_override.json")
_runtime_override: dict = {}

# Per-request model override set by the skill routing layer. A ContextVar keeps
# concurrent requests isolated, unlike a module-level global.
_routed_model: ContextVar[str | None] = ContextVar("routed_model", default=None)


@contextmanager
def use_model(model: str | None):
    """Force a model for every llm.chat() call made inside this block."""
    token = _routed_model.set(model)
    try:
        yield
    finally:
        _routed_model.reset(token)


def _load_override() -> None:
    global _runtime_override
    try:
        with open(_OVERRIDE_FILE) as f:
            _runtime_override = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        _runtime_override = {}


def _save_override(data: dict) -> None:
    global _runtime_override
    _runtime_override = data
    try:
        os.makedirs(os.path.dirname(_OVERRIDE_FILE), exist_ok=True)
        with open(_OVERRIDE_FILE, "w") as f:
            json.dump(data, f)
    except Exception:
        pass  # non-critical — in-memory override still works


def get_override() -> dict:
    """Return current runtime override (provider + optional model overrides)."""
    return dict(_runtime_override)


def set_override(provider: str | None, ollama_model: str | None = None,
                 openai_model: str | None = None, anthropic_model: str | None = None) -> None:
    data: dict = {}
    if provider is not None:
        data["llm_provider"] = provider
    if ollama_model:
        data["ollama_model"] = ollama_model
    if openai_model:
        data["openai_model"] = openai_model
    if anthropic_model:
        data["anthropic_model"] = anthropic_model
    _save_override(data)


# Load on import
_load_override()


def _provider() -> str:
    return _runtime_override.get("llm_provider") or settings.llm_provider


def _ollama_model() -> str:
    return _runtime_override.get("ollama_model") or settings.ollama_model


def _openai_model() -> str:
    return _runtime_override.get("openai_model") or settings.openai_model


def _anthropic_model() -> str:
    return _runtime_override.get("anthropic_model") or settings.anthropic_model


async def chat(messages: list[dict], system: str | None = None, model: str | None = None) -> str:
    # Callers deep in a skill don't know which model the operator picked for it,
    # so the routing layer sets it here rather than threading it through every
    # signature. An explicit argument always wins.
    model = model or _routed_model.get()
    provider = _provider()

    # Infer provider from model name if a model override is given
    if model:
        # Gateways (Groq, LiteLLM, OpenRouter…) serve models whose names look
        # nothing like OpenAI's, so an explicit "cloud:" prefix is the only
        # reliable way to say "send this through the OpenAI-compatible gateway".
        if model.startswith("cloud:"):
            provider = "openai"
            model = model[len("cloud:"):] or None
        elif model.startswith("gpt-") or model.startswith("o1"):
            provider = "openai"
        elif model.startswith("claude-"):
            provider = "anthropic"
        else:
            provider = "ollama"

    if provider == "auto":
        if await _ollama_available():
            return await _ollama_chat(messages, system, model)
        if settings.openai_api_key or _openai_gateway():
            return await _openai_chat(messages, system, model)
        if settings.anthropic_api_key:
            return await _anthropic_chat(messages, system, model)
        raise RuntimeError("Aucun fournisseur LLM disponible. Démarrez Ollama, "
                           "ou configurez OPENAI_BASE_URL (passerelle auto-hébergée) "
                           "ou OPENAI_API_KEY / ANTHROPIC_API_KEY.")

    if provider == "ollama":
        return await _ollama_chat(messages, system, model)
    if provider == "openai":
        try:
            return await _openai_chat(messages, system, model)
        except Exception as exc:
            # A skill routed to the gateway would otherwise fail outright when
            # the provider is down or out of quota. The local model is slower
            # and weaker, but answering beats erroring.
            if not await _ollama_available():
                raise
            log.warning("Passerelle indisponible (%s) — repli sur le modele local",
                        type(exc).__name__)
            return await _ollama_chat(messages, system, None)
    if provider == "anthropic":
        return await _anthropic_chat(messages, system, model)

    raise ValueError(f"Fournisseur LLM inconnu : {provider}")


async def _ollama_available() -> bool:
    try:
        h = await _ollama.health()
        # ollama.health() renvoie un bool ; compat avec un éventuel dict {"status": "ok"}
        if isinstance(h, dict):
            return h.get("status") == "ok"
        return bool(h)
    except Exception:
        return False


async def _ollama_chat(messages: list[dict], system: str | None, model: str | None = None) -> str:
    msgs = messages
    if system:
        msgs = [{"role": "system", "content": system}] + messages
    return await _ollama.chat(msgs, model=model or _ollama_model())


def _openai_gateway() -> bool:
    """True when the OpenAI-compatible client points at a self-hosted gateway."""
    return bool(settings.openai_base_url)


async def _openai_chat(messages: list[dict], system: str | None, model: str | None = None) -> str:
    from openai import AsyncOpenAI
    # A self-hosted gateway (LiteLLM…) often needs no real key, but the SDK
    # refuses an empty one — send a placeholder in that case.
    api_key = settings.openai_api_key or ("sk-local" if _openai_gateway() else "")
    client = AsyncOpenAI(
        api_key=api_key,
        **({"base_url": settings.openai_base_url} if _openai_gateway() else {}),
    )
    msgs = messages
    if system:
        msgs = [{"role": "system", "content": system}] + messages
    resp = await client.chat.completions.create(
        model=model or _openai_model(),
        messages=msgs,  # type: ignore[arg-type]
    )
    return resp.choices[0].message.content or ""


async def _anthropic_chat(messages: list[dict], system: str | None, model: str | None = None) -> str:
    import anthropic
    client = anthropic.AsyncAnthropic(api_key=settings.anthropic_api_key)
    resp = await client.messages.create(
        model=model or _anthropic_model(),
        max_tokens=2048,
        system=system or "You are a helpful assistant.",
        messages=messages,  # type: ignore[arg-type]
    )
    block = resp.content[0]
    return block.text if hasattr(block, "text") else ""


async def active_provider() -> dict:
    """Return which provider is currently active and its status."""
    provider = _provider()
    if provider == "auto":
        if await _ollama_available():
            return {"provider": "ollama", "model": _ollama_model(), "status": "active"}
        if settings.openai_api_key or _openai_gateway():
            return {"provider": "gateway" if _openai_gateway() else "openai",
                    "model": _openai_model(), "status": "fallback"}
        if settings.anthropic_api_key:
            return {"provider": "anthropic", "model": _anthropic_model(), "status": "fallback"}
        return {"provider": "none", "model": None, "status": "unavailable"}
    return {"provider": provider, "model": _model_for(provider), "status": "configured"}


def _model_for(provider: str) -> str:
    return {
        "ollama": _ollama_model(),
        "openai": _openai_model(),
        "anthropic": _anthropic_model(),
    }.get(provider, "unknown")
