"""
Tool plugin registry.
Agents call tools by name: await run_tool("http_fetch", {"url": "..."})
Each tool is an async callable that accepts a dict and returns a string.
"""
import httpx
from typing import Callable, Awaitable

ToolFn = Callable[[dict], Awaitable[str]]

_REGISTRY: dict[str, ToolFn] = {}


def register(name: str):
    def decorator(fn: ToolFn) -> ToolFn:
        _REGISTRY[name] = fn
        return fn
    return decorator


async def run_tool(name: str, params: dict) -> str:
    fn = _REGISTRY.get(name)
    if not fn:
        return f"[error] Tool '{name}' not found. Available: {', '.join(_REGISTRY)}"
    try:
        return await fn(params)
    except Exception as e:
        return f"[error] Tool '{name}' failed: {e}"


def list_tools() -> list[dict]:
    return [{"name": k, "doc": (fn.__doc__ or "").strip()} for k, fn in _REGISTRY.items()]


# ── Built-in tools ──────────────────────────────────────────────────────────

@register("http_fetch")
async def _http_fetch(params: dict) -> str:
    """Fetch text content from a URL. params: {url, method?, headers?, body?}"""
    url = params.get("url", "")
    if not url.startswith(("http://", "https://")):
        return "[error] url must start with http:// or https://"
    method = params.get("method", "GET").upper()
    headers = params.get("headers", {})
    body = params.get("body")
    async with httpx.AsyncClient(timeout=15, follow_redirects=True) as client:
        resp = await client.request(method, url, headers=headers, content=body)
        text = resp.text[:4000]  # cap at 4k chars
        return f"[HTTP {resp.status_code}]\n{text}"


@register("extract_text")
async def _extract_text(params: dict) -> str:
    """Fetch a URL and extract readable text (strips HTML tags). params: {url}"""
    url = params.get("url", "")
    if not url.startswith(("http://", "https://")):
        return "[error] url must start with http:// or https://"
    async with httpx.AsyncClient(timeout=15, follow_redirects=True) as client:
        resp = await client.get(url, headers={"User-Agent": "OrionBot/1.0"})
        html = resp.text
    # Simple HTML strip — no external lib required
    import re
    text = re.sub(r"<style[^>]*>.*?</style>", " ", html, flags=re.DOTALL | re.IGNORECASE)
    text = re.sub(r"<script[^>]*>.*?</script>", " ", text, flags=re.DOTALL | re.IGNORECASE)
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"\s{2,}", " ", text).strip()
    return text[:3000]


@register("json_fetch")
async def _json_fetch(params: dict) -> str:
    """Fetch JSON from an API endpoint and return it as a string. params: {url, headers?}"""
    url = params.get("url", "")
    if not url.startswith(("http://", "https://")):
        return "[error] url must start with http:// or https://"
    headers = {"Accept": "application/json", **params.get("headers", {})}
    async with httpx.AsyncClient(timeout=15, follow_redirects=True) as client:
        resp = await client.get(url, headers=headers)
        import json
        try:
            data = resp.json()
            return json.dumps(data, ensure_ascii=False, indent=2)[:4000]
        except Exception:
            return resp.text[:4000]


@register("current_datetime")
async def _current_datetime(_params: dict) -> str:
    """Return the current UTC date and time. No params required."""
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
