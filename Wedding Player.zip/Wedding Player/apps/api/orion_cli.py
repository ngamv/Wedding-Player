#!/usr/bin/env python3
"""ORION CLI — interact with the ORION AI platform from the terminal."""
import sys
import json
import os
import urllib.request
import urllib.error
from pathlib import Path

TOKEN_FILE = Path.home() / ".orion_token"
BASE_URL = os.environ.get("ORION_API_URL", "http://localhost:8000/api")


# ---------------------------------------------------------------------------
# HTTP helpers
# ---------------------------------------------------------------------------

def _headers() -> dict:
    token = TOKEN_FILE.read_text().strip() if TOKEN_FILE.exists() else None
    h = {"Content-Type": "application/json"}
    if token:
        h["Authorization"] = f"Bearer {token}"
    return h


def _request(method: str, path: str, body: dict | None = None) -> dict:
    url = BASE_URL + path
    data = json.dumps(body).encode() if body else None
    req = urllib.request.Request(url, data=data, headers=_headers(), method=method)
    try:
        with urllib.request.urlopen(req) as resp:
            return json.loads(resp.read())
    except urllib.error.HTTPError as exc:
        try:
            detail = json.loads(exc.read()).get("detail", exc.reason)
        except Exception:
            detail = exc.reason
        print(f"Erreur {exc.code}: {detail}", file=sys.stderr)
        sys.exit(1)


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------

def cmd_login(args: list[str]) -> None:
    """orion login [--url <api_url>]"""
    import getpass
    global BASE_URL
    if "--url" in args:
        idx = args.index("--url")
        BASE_URL = args[idx + 1]

    username = input("Utilisateur : ").strip()
    password = getpass.getpass("Mot de passe : ")

    result = _request("POST", "/auth/login", {"username": username, "password": password})
    token = result.get("access_token")
    if not token:
        print("Connexion échouée.", file=sys.stderr)
        sys.exit(1)
    TOKEN_FILE.write_text(token)
    TOKEN_FILE.chmod(0o600)
    print(f"Connecté en tant que {username}. Token enregistré dans {TOKEN_FILE}")


def cmd_run(args: list[str]) -> None:
    """orion run <prompt> [--agent <id>] [--model <name>]"""
    if not args:
        print("Usage: orion run <prompt> [--agent <id>] [--model <model>]", file=sys.stderr)
        sys.exit(1)

    agent_id = None
    model = None
    prompt_parts = []
    i = 0
    while i < len(args):
        if args[i] == "--agent" and i + 1 < len(args):
            agent_id = args[i + 1]; i += 2
        elif args[i] == "--model" and i + 1 < len(args):
            model = args[i + 1]; i += 2
        else:
            prompt_parts.append(args[i]); i += 1

    prompt = " ".join(prompt_parts)
    body: dict = {"title": prompt, "input_data": {"prompt": prompt}}
    if agent_id:
        body["agent_id"] = agent_id
    if model:
        body["model"] = model

    print("Envoi de la tâche…")
    result = _request("POST", "/tasks/", body)
    task_id = result.get("id")
    print(f"Tâche #{task_id} créée — statut : {result.get('status')}")

    output = result.get("output_data")
    if output:
        _print_output(output)


def cmd_tasks(args: list[str]) -> None:
    """orion tasks [--limit N]"""
    limit = 10
    if "--limit" in args:
        idx = args.index("--limit")
        limit = int(args[idx + 1])

    result = _request("GET", f"/tasks/?page=1&page_size={limit}")
    tasks = result if isinstance(result, list) else result.get("items", [])

    if not tasks:
        print("Aucune tâche.")
        return

    width_title = max(len(t.get("title", "")) for t in tasks)
    width_title = max(width_title, 5)
    fmt = f"{{:>5}}  {{:<{width_title}}}  {{:<12}}  {{}}"
    print(fmt.format("ID", "TITRE", "STATUT", "CRÉÉE LE"))
    print("-" * (5 + 2 + width_title + 2 + 12 + 2 + 20))
    for t in tasks:
        print(fmt.format(
            t.get("id", ""),
            (t.get("title") or "")[:width_title],
            t.get("status", ""),
            (t.get("created_at") or "")[:19],
        ))


def cmd_agents(args: list[str]) -> None:
    """orion agents"""
    result = _request("GET", "/agents/")
    agents = result if isinstance(result, list) else result.get("items", [])
    if not agents:
        print("Aucun agent.")
        return
    fmt = "{:<20}  {:<12}  {}"
    print(fmt.format("ID", "MODÈLE", "DESCRIPTION"))
    print("-" * 70)
    for a in agents:
        print(fmt.format(
            (a.get("id") or "")[:20],
            (a.get("model") or "")[:12],
            (a.get("description") or "")[:50],
        ))


def cmd_status(args: list[str]) -> None:
    """orion status"""
    result = _request("GET", "/system/health")
    for k, v in result.items():
        print(f"  {k}: {v}")


def cmd_logout(args: list[str]) -> None:
    """orion logout"""
    if TOKEN_FILE.exists():
        TOKEN_FILE.unlink()
        print("Déconnecté.")
    else:
        print("Vous n'étiez pas connecté.")


def _print_output(output: dict | str) -> None:
    if isinstance(output, str):
        print(output)
    elif isinstance(output, dict):
        if "response" in output:
            print(output["response"])
        elif "error" in output:
            print(f"Erreur : {output['error']}", file=sys.stderr)
        else:
            print(json.dumps(output, ensure_ascii=False, indent=2))


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

COMMANDS = {
    "login": cmd_login,
    "run": cmd_run,
    "tasks": cmd_tasks,
    "agents": cmd_agents,
    "status": cmd_status,
    "logout": cmd_logout,
}

HELP = """ORION CLI — client en ligne de commande pour ORION AI

Usage:
  orion login [--url <api_url>]        Se connecter à ORION
  orion run <prompt> [options]         Lancer une tâche
      --agent <id>                     Choisir un agent
      --model <name>                   Choisir un modèle LLM
  orion tasks [--limit N]              Lister les dernières tâches (défaut: 10)
  orion agents                         Lister les agents disponibles
  orion status                         Vérifier l'état de l'API
  orion logout                         Se déconnecter

Variables d'environnement:
  ORION_API_URL    URL de l'API (défaut: http://localhost:8000/api)
"""


def main() -> None:
    argv = sys.argv[1:]
    if not argv or argv[0] in ("-h", "--help", "help"):
        print(HELP)
        return

    cmd = argv[0]
    rest = argv[1:]

    if cmd not in COMMANDS:
        print(f"Commande inconnue : {cmd}\n{HELP}", file=sys.stderr)
        sys.exit(1)

    COMMANDS[cmd](rest)


if __name__ == "__main__":
    main()
