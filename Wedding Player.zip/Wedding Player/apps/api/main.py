from contextlib import asynccontextmanager
from collections import defaultdict
from time import monotonic
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from sqlalchemy import select
from app.config import settings, check_secrets_on_startup
from app.database import init_db, SessionLocal
from app.routes import (agents_router, tasks_router, memory_router, system_router,
                        auth_router, custom_agents_router, export_router, api_keys_router,
                        workflows_router, webhooks_router)
from app.routes.admin import router as admin_router
from app.routes.chat import router as chat_router
from app.routes.ws_router import router as ws_router
from app.routes.scheduled import router as scheduled_router
from app.routes.teams import router as teams_router
from app.routes.marketplace import router as marketplace_router
from app.routes.search import router as search_router
from app.routes.logs import router as logs_router
from app.routes.audit import router as audit_router
from app.routes.totp import router as totp_router
from app.routes.triggers import router as triggers_router
from app.routes.vault import router as vault_router
from app.routes.notifications import router as notifications_router
from app.routes.push import router as push_router
from app.routes.skills import router as skills_router
from app.routes.custom_agents import _register_in_memory
from app import scheduler as _scheduler

@asynccontextmanager
async def lifespan(app: FastAPI):
    check_secrets_on_startup()
    await init_db()
    # SQLite migrations for new columns on existing tables
    from app.database import engine
    from sqlalchemy import text
    async with engine.begin() as conn:
        for stmt in [
            "ALTER TABLE users ADD COLUMN role VARCHAR(20) DEFAULT 'user'",
            "ALTER TABLE tasks ADD COLUMN user_id INTEGER",
            "ALTER TABLE custom_agents ADD COLUMN user_id INTEGER",
            "ALTER TABLE workflows ADD COLUMN user_id INTEGER",
            "ALTER TABLE api_keys ADD COLUMN user_id INTEGER",
            "ALTER TABLE webhooks ADD COLUMN user_id INTEGER",
            "CREATE TABLE IF NOT EXISTS chat_sessions (id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, title VARCHAR(255) DEFAULT 'Nouvelle conversation', created_at DATETIME, updated_at DATETIME)",
            "CREATE TABLE IF NOT EXISTS chat_messages (id INTEGER PRIMARY KEY, session_id INTEGER NOT NULL, role VARCHAR(20), content TEXT, agent_name VARCHAR(100), created_at DATETIME)",
            "CREATE TABLE IF NOT EXISTS scheduled_tasks (id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, name VARCHAR(255), agent_id VARCHAR(100), prompt TEXT, cron VARCHAR(100), is_active BOOLEAN DEFAULT 1, last_run_at DATETIME, created_at DATETIME)",
            "CREATE TABLE IF NOT EXISTS teams (id INTEGER PRIMARY KEY, name VARCHAR(255) UNIQUE, description TEXT DEFAULT '', owner_id INTEGER NOT NULL, created_at DATETIME)",
            "CREATE TABLE IF NOT EXISTS team_members (id INTEGER PRIMARY KEY, team_id INTEGER NOT NULL, user_id INTEGER NOT NULL, role VARCHAR(20) DEFAULT 'member', joined_at DATETIME)",
            "CREATE TABLE IF NOT EXISTS task_logs (id INTEGER PRIMARY KEY, task_id INTEGER NOT NULL, level VARCHAR(20) DEFAULT 'info', message TEXT, created_at DATETIME)",
            "ALTER TABLE custom_agents ADD COLUMN is_public BOOLEAN DEFAULT 0",
            "ALTER TABLE custom_agents ADD COLUMN env_vars JSON",
            "ALTER TABLE users ADD COLUMN totp_secret VARCHAR(255)",
            "ALTER TABLE users ADD COLUMN totp_enabled BOOLEAN DEFAULT 0",
            "CREATE TABLE IF NOT EXISTS audit_logs (id INTEGER PRIMARY KEY, user_id INTEGER, username VARCHAR(80) DEFAULT 'system', action VARCHAR(100), resource_type VARCHAR(50), resource_id VARCHAR(100), details JSON, ip_address VARCHAR(64), created_at DATETIME)",
            "CREATE TABLE IF NOT EXISTS inbound_triggers (id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, name VARCHAR(255), agent_id VARCHAR(100), token VARCHAR(64) UNIQUE, is_active BOOLEAN DEFAULT 1, last_triggered_at DATETIME, created_at DATETIME)",
            "CREATE TABLE IF NOT EXISTS vault_secrets (id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, name VARCHAR(255), encrypted_value TEXT, created_at DATETIME, updated_at DATETIME)",
            "CREATE TABLE IF NOT EXISTS notifications (id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, type VARCHAR(50), title VARCHAR(255), body TEXT DEFAULT '', is_read BOOLEAN DEFAULT 0, created_at DATETIME)",
            "ALTER TABLE agent_metrics ADD COLUMN tokens_in INTEGER DEFAULT 0",
            "ALTER TABLE agent_metrics ADD COLUMN tokens_out INTEGER DEFAULT 0",
            "ALTER TABLE custom_agents ADD COLUMN rate_limit INTEGER",
            "ALTER TABLE tasks ADD COLUMN tags JSON",
            "CREATE TABLE IF NOT EXISTS push_subscriptions (id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, endpoint TEXT UNIQUE, p256dh TEXT, auth TEXT, created_at DATETIME)",
            "CREATE TABLE IF NOT EXISTS skills (id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, name VARCHAR(255), description TEXT DEFAULT '', icon VARCHAR(50) DEFAULT 'Plug', category VARCHAR(50) DEFAULT 'custom', is_public BOOLEAN DEFAULT 0, config JSON, created_at DATETIME)",
        ]:
            try:
                await conn.execute(text(stmt))
            except Exception:
                pass  # column already exists
    # Bootstrap the first admin. Without it, enabling auth on a fresh database
    # would lock everyone out: no user exists, so no one can log in.
    from app.auth import _get_default_user
    async with SessionLocal() as db:
        await _get_default_user(db)

    # Reset tasks that were left in "running" state (e.g. after a crash or restart)
    from app.models import Task, TaskStatus
    async with SessionLocal() as db:
        from sqlalchemy import update
        await db.execute(
            update(Task)
            .where(Task.status == TaskStatus.running)
            .values(status=TaskStatus.failed, output_data={"error": "Interrompu par redémarrage du serveur"})
        )
        await db.commit()

    # Reload custom agents from DB into registry
    from app.models import CustomAgent, ScheduledTask
    async with SessionLocal() as db:
        result = await db.execute(select(CustomAgent))
        for ca in result.scalars().all():
            _register_in_memory(ca)
        # Reload active scheduled tasks
        sched_result = await db.execute(
            select(ScheduledTask).where(ScheduledTask.is_active == True)
        )
        from sqlalchemy import select as sa_select
        from app.models import User as _User
        for st in sched_result.scalars().all():
            user_row = await db.execute(sa_select(_User).where(_User.id == st.user_id))
            user = user_row.scalar_one_or_none()
            if user:
                await _scheduler.add_job(st, user.email)

    _scheduler.start()
    yield
    _scheduler.shutdown()

app = FastAPI(
    title="ORION AI",
    description="Multi-agent AI orchestration platform with 30 specialized agents",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins.split(","),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth_router)
app.include_router(custom_agents_router)
app.include_router(agents_router)
app.include_router(tasks_router)
app.include_router(memory_router)
app.include_router(system_router)
app.include_router(export_router)
app.include_router(api_keys_router)
app.include_router(workflows_router)
app.include_router(webhooks_router)
app.include_router(admin_router)
app.include_router(chat_router)
app.include_router(ws_router)
app.include_router(scheduled_router)
app.include_router(teams_router)
app.include_router(marketplace_router)
app.include_router(search_router)
app.include_router(logs_router)
app.include_router(audit_router)
app.include_router(totp_router)
app.include_router(triggers_router)
app.include_router(vault_router)
app.include_router(notifications_router)
app.include_router(push_router)
app.include_router(skills_router)

RATE_LIMIT = 60  # requests per window
RATE_WINDOW = 60  # seconds
_rate_buckets: dict[str, list[float]] = defaultdict(list)


@app.middleware("http")
async def rate_limit_middleware(request: Request, call_next):
    ip = request.client.host if request.client else "unknown"
    # Skip loopback (tests, local dev, Docker internal)
    if ip in ("127.0.0.1", "::1", "testclient") or request.url.path in ("/", "/api/system/health"):
        return await call_next(request)
    now = monotonic()
    _rate_buckets[ip] = [t for t in _rate_buckets[ip] if now - t < RATE_WINDOW]
    if len(_rate_buckets[ip]) >= RATE_LIMIT:
        return JSONResponse({"detail": "Trop de requêtes. Réessayez dans un moment."}, status_code=429)
    _rate_buckets[ip].append(now)
    response = await call_next(request)
    used = len(_rate_buckets[ip])
    response.headers["X-RateLimit-Limit"] = str(RATE_LIMIT)
    response.headers["X-RateLimit-Remaining"] = str(max(0, RATE_LIMIT - used))
    response.headers["X-RateLimit-Used"] = str(used)
    return response


@app.middleware("http")
async def security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    return response


@app.get("/")
async def root():
    return {"name": "ORION AI", "version": "1.0.0", "agents": 30}
