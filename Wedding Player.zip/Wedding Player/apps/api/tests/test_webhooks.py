import pytest
from httpx import AsyncClient

pytestmark = pytest.mark.asyncio


async def test_list_webhooks_empty(client: AsyncClient, auth: dict):
    r = await client.get("/webhooks/", headers=auth["headers"])
    assert r.status_code == 200
    assert isinstance(r.json(), list)


async def test_create_webhook(client: AsyncClient, auth: dict):
    r = await client.post("/webhooks/", json={
        "name": "Mon webhook test",
        "url": "https://example.com/hook",
        "events": ["task.completed"],
    }, headers=auth["headers"])
    assert r.status_code == 201
    data = r.json()
    assert data["name"] == "Mon webhook test"
    assert data["is_active"] is True
    assert "task.completed" in data["events"]


async def test_create_webhook_invalid_event(client: AsyncClient, auth: dict):
    r = await client.post("/webhooks/", json={
        "name": "Bad hook",
        "url": "https://example.com/bad",
        "events": ["unknown.event"],
    }, headers=auth["headers"])
    assert r.status_code == 400


async def test_toggle_webhook(client: AsyncClient, auth: dict):
    r = await client.post("/webhooks/", json={
        "name": "Toggle test",
        "url": "https://example.com/toggle",
        "events": ["task.failed"],
    }, headers=auth["headers"])
    wh_id = r.json()["id"]

    r2 = await client.patch(f"/webhooks/{wh_id}/toggle", headers=auth["headers"])
    assert r2.status_code == 200
    assert r2.json()["is_active"] is False

    r3 = await client.patch(f"/webhooks/{wh_id}/toggle", headers=auth["headers"])
    assert r3.json()["is_active"] is True


async def test_delete_webhook(client: AsyncClient, auth: dict):
    r = await client.post("/webhooks/", json={
        "name": "To delete",
        "url": "https://example.com/del",
        "events": ["task.completed"],
    }, headers=auth["headers"])
    wh_id = r.json()["id"]

    r2 = await client.delete(f"/webhooks/{wh_id}", headers=auth["headers"])
    assert r2.status_code == 204

    r3 = await client.delete(f"/webhooks/{wh_id}", headers=auth["headers"])
    assert r3.status_code == 404


async def test_webhook_isolation(client: AsyncClient, auth: dict, admin_auth: dict):
    r = await client.post("/webhooks/", json={
        "name": "Webhook de A",
        "url": "https://example.com/a",
        "events": ["task.completed"],
    }, headers=auth["headers"])
    wh_id = r.json()["id"]
    r2 = await client.delete(f"/webhooks/{wh_id}", headers=admin_auth["headers"])
    assert r2.status_code == 404


# --- ntfy : le detail ne doit pas partir vers un serveur tiers -------------

def test_is_self_hosted():
    from app.routes.webhooks import _is_self_hosted
    assert _is_self_hosted("ntfy")            # nom de service compose
    assert _is_self_hosted("127.0.0.1")
    assert _is_self_hosted("10.39.105.13")    # LAN
    assert _is_self_hosted("192.168.1.20")
    assert not _is_self_hosted("ntfy.sh")     # serveur public
    assert not _is_self_hosted("8.8.8.8")


@pytest.mark.parametrize(
    "url,doit_contenir_detail",
    [("http://ntfy/orion", True), ("https://ntfy.sh/orion-xyz", False)],
)
async def test_ntfy_redacts_on_public_server(url, doit_contenir_detail):
    """Sur ntfy.sh, ni le nom de la tache ni l'erreur ne doivent transiter."""
    from unittest.mock import AsyncMock
    from app.routes.webhooks import _post_ntfy

    client = AsyncMock()
    await _post_ntfy(client, url, "task.failed", {
        "title": "Deployer le client Dupont",
        "error": "connexion refusee sur /srv/prod/secret.key",
    })

    envoye = client.post.call_args.kwargs["json"]
    detail = "Deployer le client Dupont" in envoye["message"]
    assert detail is doit_contenir_detail
    if not doit_contenir_detail:
        assert "secret.key" not in envoye["message"]
    # Le titre reste explicite des deux cotes : il ne revele rien de sensible.
    assert envoye["title"] == "Tâche en échec"


@pytest.mark.parametrize(
    "url,doit_etre_authentifie",
    [("http://ntfy/orion", True), ("https://ntfy.sh/orion-xyz", False)],
)
async def test_ntfy_token_never_leaves_for_third_party(url, doit_etre_authentifie, monkeypatch):
    """Le jeton du ntfy auto-heberge ne doit jamais partir vers ntfy.sh."""
    from unittest.mock import AsyncMock
    from app.config import settings
    from app.routes.webhooks import _post_ntfy

    monkeypatch.setattr(settings, "ntfy_token", "tk_secret_ne_doit_pas_fuiter")
    client = AsyncMock()
    await _post_ntfy(client, url, "task.failed", {"title": "x"})

    headers = client.post.call_args.kwargs.get("headers")
    if doit_etre_authentifie:
        assert headers["Authorization"] == "Bearer tk_secret_ne_doit_pas_fuiter"
    else:
        assert not headers
        assert "tk_secret" not in str(client.post.call_args)
