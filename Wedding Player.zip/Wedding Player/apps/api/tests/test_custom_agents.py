import pytest
import time
from httpx import AsyncClient

pytestmark = pytest.mark.asyncio


async def test_crud_custom_agent(client: AsyncClient, auth: dict):
    ts = int(time.time() * 1000)
    payload = {
        "name": f"Agent Test {ts}",
        "description": "Agent de test pytest",
        "category": "core",
        "system_prompt": "Tu es un assistant de test.",
        "model": "qwen3:8b",
    }

    # Create
    r = await client.post("/custom-agents/", json=payload, headers=auth["headers"])
    assert r.status_code == 201
    data = r.json()
    agent_id = data["agent_id"]
    db_id = data["id"]
    assert agent_id.startswith("custom_")

    # List
    r2 = await client.get("/custom-agents/", headers=auth["headers"])
    assert r2.status_code == 200
    ids = [a["agent_id"] for a in r2.json()]
    assert agent_id in ids

    # Get
    r3 = await client.get(f"/custom-agents/{agent_id}", headers=auth["headers"])
    assert r3.status_code == 200
    assert r3.json()["name"] == f"Agent Test {ts}"

    # Update
    r4 = await client.put(f"/custom-agents/{agent_id}", json={
        **payload,
        "name": f"Agent Test Modifié {ts}",
    }, headers=auth["headers"])
    assert r4.status_code == 200
    assert r4.json()["name"] == f"Agent Test Modifié {ts}"

    # Delete
    r5 = await client.delete(f"/custom-agents/{agent_id}", headers=auth["headers"])
    assert r5.status_code == 204

    r6 = await client.get(f"/custom-agents/{agent_id}", headers=auth["headers"])
    assert r6.status_code == 404
