import pytest
from httpx import AsyncClient
from unittest.mock import patch, AsyncMock

pytestmark = pytest.mark.asyncio


async def test_list_tasks(client: AsyncClient, auth: dict):
    r = await client.get("/tasks/", headers=auth["headers"])
    assert r.status_code == 200
    data = r.json()
    assert "tasks" in data
    assert "total" in data
    assert "page" in data
    assert isinstance(data["tasks"], list)


async def test_list_tasks_requires_auth(client: AsyncClient):
    r = await client.get("/tasks/")
    assert r.status_code == 401  # authentification requise


async def test_create_task_mocked(client: AsyncClient, auth: dict):
    mock_result = {"output": "Résultat simulé de l'agent"}
    with patch("app.routes.tasks.route_and_run", new_callable=AsyncMock, return_value=mock_result):
        with patch("app.routes.tasks.fire_webhooks", new_callable=AsyncMock):
            r = await client.post("/tasks/", json={"title": "Test tâche pytest"}, headers=auth["headers"])
    assert r.status_code == 200
    data = r.json()
    assert data["status"] == "completed"
    assert "id" in data


async def test_create_task_agent_failure(client: AsyncClient, auth: dict):
    with patch("app.routes.tasks.route_and_run", new_callable=AsyncMock, side_effect=Exception("LLM down")):
        with patch("app.routes.tasks.fire_webhooks", new_callable=AsyncMock):
            r = await client.post("/tasks/", json={"title": "Tâche qui échoue"}, headers=auth["headers"])
    assert r.status_code == 200
    assert r.json()["status"] == "failed"


async def test_get_task_not_found(client: AsyncClient, auth: dict):
    r = await client.get("/tasks/999999", headers=auth["headers"])
    assert r.status_code == 404


async def test_task_isolation(client: AsyncClient, auth: dict, admin_auth: dict):
    """User A cannot see User B's tasks."""
    mock_result = {"output": "ok"}
    with patch("app.routes.tasks.route_and_run", new_callable=AsyncMock, return_value=mock_result):
        with patch("app.routes.tasks.fire_webhooks", new_callable=AsyncMock):
            r = await client.post("/tasks/", json={"title": "Tâche privée user A"},
                                   headers=auth["headers"])
    task_id = r.json()["id"]

    r2 = await client.get(f"/tasks/{task_id}", headers=admin_auth["headers"])
    assert r2.status_code == 404
