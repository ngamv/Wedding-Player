import pytest
import time
from httpx import AsyncClient

pytestmark = pytest.mark.asyncio


async def test_register(client: AsyncClient):
    ts = int(time.time() * 1000)
    r = await client.post("/auth/register", json={
        "username": f"newuser{ts}",
        "email": f"new{ts}@example.com",
        "password": "securepass",
    })
    assert r.status_code == 201
    data = r.json()
    assert "access_token" in data
    assert data["user"]["username"] == f"newuser{ts}"
    assert data["user"]["role"] == "user"


async def test_register_duplicate(client: AsyncClient):
    ts = int(time.time() * 1000)
    body = {"username": f"dup{ts}", "email": f"dup{ts}@example.com", "password": "pass123"}
    r1 = await client.post("/auth/register", json=body)
    assert r1.status_code == 201
    r2 = await client.post("/auth/register", json=body)
    assert r2.status_code == 409


async def test_register_short_password(client: AsyncClient):
    r = await client.post("/auth/register", json={
        "username": "testuser2", "email": "t2@test.com", "password": "abc"
    })
    assert r.status_code == 422


async def test_login(client: AsyncClient):
    ts = int(time.time() * 1000)
    await client.post("/auth/register", json={
        "username": f"login{ts}", "email": f"login{ts}@test.com", "password": "mypassword",
    })
    r = await client.post("/auth/login", data={
        "username": f"login{ts}", "password": "mypassword"
    })
    assert r.status_code == 200
    assert "access_token" in r.json()


async def test_login_wrong_password(client: AsyncClient):
    r = await client.post("/auth/login", data={
        "username": "nobody", "password": "wrong"
    })
    assert r.status_code == 401


async def test_me(client: AsyncClient, auth: dict):
    r = await client.get("/auth/me", headers=auth["headers"])
    assert r.status_code == 200
    assert r.json()["username"] == auth["user"]["username"]
    assert "role" in r.json()


async def test_me_no_token(client: AsyncClient):
    r = await client.get("/auth/me")
    assert r.status_code == 401  # authentification requise


async def test_list_users_admin_only(client: AsyncClient, auth: dict, admin_auth: dict):
    r = await client.get("/auth/users", headers=auth["headers"])
    assert r.status_code == 403

    r2 = await client.get("/auth/users", headers=admin_auth["headers"])
    assert r2.status_code == 200
    assert isinstance(r2.json(), list)
