import pytest
import pytest_asyncio
from httpx import AsyncClient, ASGITransport
import sys, os

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

# Force the test database: this suite ends with Base.metadata.drop_all(), so
# inheriting a DATABASE_URL from the environment (as in the API container,
# where it is set by docker-compose) would wipe the real database.
os.environ["DATABASE_URL"] = "sqlite+aiosqlite:///./test_orion.db"
os.environ.setdefault("JWT_SECRET", "test-secret-key-for-pytest")
os.environ.setdefault("CORS_ORIGINS", "http://localhost:5173")
os.environ.setdefault("OLLAMA_URL", "http://localhost:11434")
os.environ.setdefault("DEFAULT_MODEL", "qwen3:8b")

from main import app
from app.database import init_db, engine, Base


@pytest_asyncio.fixture(scope="session", autouse=True)
async def setup_db():
    await init_db()
    yield
    # drop test DB
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
    await engine.dispose()
    try:
        os.remove("./test_orion.db")
    except FileNotFoundError:
        pass


@pytest_asyncio.fixture
async def client():
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as c:
        yield c


@pytest_asyncio.fixture
async def auth(client: AsyncClient):
    import time
    ts = time.time_ns()
    r = await client.post("/auth/register", json={
        "username": f"u{ts}",
        "email": f"u{ts}@test.com",
        "password": "password123",
    })
    assert r.status_code == 201
    data = r.json()
    return {"headers": {"Authorization": f"Bearer {data['access_token']}"}, "user": data["user"]}


@pytest_asyncio.fixture
async def admin_auth(client: AsyncClient):
    import time
    ts = time.time_ns()
    r = await client.post("/auth/register", json={
        "username": f"admin{ts}",
        "email": f"admin{ts}@test.com",
        "password": "adminpass123",
    })
    assert r.status_code == 201
    data = r.json()
    token = data["access_token"]
    user_id = data["user"]["id"]
    # Promote to admin via DB
    from app.database import SessionLocal
    from app.models import User
    from sqlalchemy import select
    async with SessionLocal() as db:
        result = await db.execute(select(User).where(User.id == user_id))
        user = result.scalar_one()
        user.role = "admin"
        await db.commit()
    return {"headers": {"Authorization": f"Bearer {token}"}, "user": data["user"]}
