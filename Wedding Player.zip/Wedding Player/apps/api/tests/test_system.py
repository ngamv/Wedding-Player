import pytest
from httpx import AsyncClient
from unittest.mock import patch, AsyncMock

pytestmark = pytest.mark.asyncio


async def test_health(client: AsyncClient):
    with patch("app.ollama.health", new_callable=AsyncMock, return_value=False):
        with patch("app.ollama.list_models", new_callable=AsyncMock, return_value=[]):
            r = await client.get("/system/health")
    assert r.status_code == 200
    data = r.json()
    assert "status" in data
    assert "agents_count" in data


async def test_stats(client: AsyncClient):
    r = await client.get("/system/stats")
    assert r.status_code == 200
    data = r.json()
    assert "total_agents" in data
    assert "by_category" in data


async def test_analytics(client: AsyncClient, auth: dict):
    r = await client.get("/system/analytics", headers=auth["headers"])
    assert r.status_code in (200, 401, 404)  # endpoint may not require auth


async def test_period_stats_requires_auth(client: AsyncClient):
    r = await client.get("/system/period-stats")
    assert r.status_code == 401  # authentification requise


async def test_period_stats_week(client: AsyncClient, auth: dict):
    r = await client.get("/system/period-stats?period=week", headers=auth["headers"])
    assert r.status_code == 200
    data = r.json()
    assert data["period"] == "week"
    assert "buckets" in data
    assert len(data["buckets"]) == 7
    assert "total" in data
    assert "success_rate" in data


async def test_period_stats_day(client: AsyncClient, auth: dict):
    r = await client.get("/system/period-stats?period=day", headers=auth["headers"])
    assert r.status_code == 200
    data = r.json()
    assert data["period"] == "day"
    assert len(data["buckets"]) == 24


async def test_period_stats_month(client: AsyncClient, auth: dict):
    r = await client.get("/system/period-stats?period=month", headers=auth["headers"])
    assert r.status_code == 200
    assert len(r.json()["buckets"]) == 30


async def test_period_stats_year(client: AsyncClient, auth: dict):
    r = await client.get("/system/period-stats?period=year", headers=auth["headers"])
    assert r.status_code == 200
    assert len(r.json()["buckets"]) == 12


async def test_token_usage_requires_auth(client: AsyncClient):
    r = await client.get("/system/token-usage")
    assert r.status_code == 401  # authentification requise


async def test_token_usage(client: AsyncClient, auth: dict):
    r = await client.get("/system/token-usage", headers=auth["headers"])
    assert r.status_code == 200
    data = r.json()
    assert "total_in" in data
    assert "total_out" in data
    assert "total" in data
    assert "by_agent" in data
    assert isinstance(data["by_agent"], list)


async def test_retention_get(client: AsyncClient, auth: dict):
    r = await client.get("/system/retention", headers=auth["headers"])
    assert r.status_code == 200
    data = r.json()
    assert "days" in data
    assert "enabled" in data


async def test_retention_set(client: AsyncClient, auth: dict):
    r = await client.post("/system/retention", json={"days": 30}, headers=auth["headers"])
    assert r.status_code == 200
    assert r.json()["days"] == 30
    assert r.json()["enabled"] is True


async def test_retention_set_zero(client: AsyncClient, auth: dict):
    r = await client.post("/system/retention", json={"days": 0}, headers=auth["headers"])
    assert r.status_code == 200
    assert r.json()["enabled"] is False


async def test_purge_no_tasks(client: AsyncClient, auth: dict):
    r = await client.post("/system/purge", json={"days": 1}, headers=auth["headers"])
    assert r.status_code == 200
    data = r.json()
    assert "deleted" in data


async def test_purge_zero_days(client: AsyncClient, auth: dict):
    r = await client.post("/system/purge", json={"days": 0}, headers=auth["headers"])
    assert r.status_code == 200
    assert r.json()["deleted"] == 0


async def test_ollama_models(client: AsyncClient, auth: dict):
    fake_models = [{"name": "llama3.2", "size": 2_000_000_000, "modified_at": "2024-01-01T00:00:00Z",
                    "digest": "abc123", "family": "llama", "parameter_size": "3B", "quantization_level": "Q4_0"}]
    with patch("app.ollama.list_models_detail", new_callable=AsyncMock, return_value=fake_models):
        r = await client.get("/system/ollama/models", headers=auth["headers"])
    assert r.status_code == 200
    data = r.json()
    assert "models" in data
    assert data["models"][0]["name"] == "llama3.2"


async def test_ollama_pull(client: AsyncClient, auth: dict):
    with patch("app.ollama.pull_model", new_callable=AsyncMock, return_value={"status": "success"}):
        r = await client.post("/system/ollama/pull", json={"name": "mistral"}, headers=auth["headers"])
    assert r.status_code == 200
    assert r.json()["model"] == "mistral"


async def test_ollama_delete(client: AsyncClient, auth: dict):
    with patch("app.ollama.delete_model", new_callable=AsyncMock, return_value=True):
        r = await client.delete("/system/ollama/models?name=mistral", headers=auth["headers"])
    assert r.status_code == 200
    assert r.json()["deleted"] == "mistral"


async def test_ollama_pull_missing_name(client: AsyncClient, auth: dict):
    r = await client.post("/system/ollama/pull", json={"name": ""}, headers=auth["headers"])
    assert r.status_code == 422
