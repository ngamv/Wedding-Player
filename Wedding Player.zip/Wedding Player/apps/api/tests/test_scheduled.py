import pytest
from httpx import AsyncClient

pytestmark = pytest.mark.asyncio


async def test_list_scheduled_empty(client: AsyncClient, auth: dict):
    r = await client.get("/scheduled/", headers=auth["headers"])
    assert r.status_code == 200
    assert r.json() == []


async def test_create_scheduled(client: AsyncClient, auth: dict):
    r = await client.post("/scheduled/", json={
        "name": "Test cron",
        "agent_id": "orchestrator",
        "prompt": "Bonjour",
        "cron": "0 9 * * 1-5",
        "is_active": True,
    }, headers=auth["headers"])
    assert r.status_code == 201
    data = r.json()
    assert data["name"] == "Test cron"
    assert data["cron"] == "0 9 * * 1-5"
    return data["id"]


async def test_create_scheduled_invalid_cron(client: AsyncClient, auth: dict):
    r = await client.post("/scheduled/", json={
        "name": "Bad cron",
        "agent_id": "orchestrator",
        "prompt": "Bonjour",
        "cron": "invalid",
    }, headers=auth["headers"])
    assert r.status_code == 400


async def test_toggle_scheduled(client: AsyncClient, auth: dict):
    r = await client.post("/scheduled/", json={
        "name": "Toggle test",
        "agent_id": "orchestrator",
        "prompt": "Test",
        "cron": "*/5 * * * *",
    }, headers=auth["headers"])
    assert r.status_code == 201
    task_id = r.json()["id"]

    r2 = await client.patch(f"/scheduled/{task_id}", json={"is_active": False}, headers=auth["headers"])
    assert r2.status_code == 200
    assert r2.json()["is_active"] is False


async def test_delete_scheduled(client: AsyncClient, auth: dict):
    r = await client.post("/scheduled/", json={
        "name": "To delete",
        "agent_id": "orchestrator",
        "prompt": "Del",
        "cron": "0 0 * * *",
    }, headers=auth["headers"])
    task_id = r.json()["id"]

    r2 = await client.delete(f"/scheduled/{task_id}", headers=auth["headers"])
    assert r2.status_code == 204

    r3 = await client.patch(f"/scheduled/{task_id}", json={"is_active": False}, headers=auth["headers"])
    assert r3.status_code == 404


async def test_scheduled_requires_auth(client: AsyncClient):
    r = await client.get("/scheduled/")
    assert r.status_code == 401  # authentification requise
