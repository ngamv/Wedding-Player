"""Tests des skills builtin.

Le suite n'en couvrait aucun, et un decorateur @router.post mal place a fait
que /skills/builtin/{slug}/run/ a renvoye la valeur de la fonction utilitaire
_routed_model_for au lieu d'executer le skill — les 52 skills etaient muets,
avec un HTTP 200, donc sans rien pour alerter. D'ou test_run_builtin_executes.
"""
import pytest
from httpx import AsyncClient

from app.routes.skills import _routed_model_for


@pytest.mark.asyncio
async def test_list_builtin(client: AsyncClient, auth: dict):
    r = await client.get("/skills/", headers=auth["headers"])
    assert r.status_code == 200
    slugs = {s["slug"] for s in r.json()}
    # Un echantillon par categorie : si l'un disparait, un registre a saute.
    assert {"slugify", "summarize", "app_generate", "docx_report"} <= slugs


@pytest.mark.asyncio
async def test_run_builtin_executes(client: AsyncClient, auth: dict):
    """La route doit executer le skill, pas renvoyer autre chose avec un 200."""
    r = await client.post(
        "/skills/builtin/slugify/run/",
        headers=auth["headers"],
        json={"params": {"text": "Les bienfaits de l'Aloe Vera"}},
    )
    assert r.status_code == 200
    body = r.json()
    assert body["success"] is True
    assert body["output"] == "les-bienfaits-de-l-aloe-vera"


@pytest.mark.asyncio
async def test_run_builtin_unknown_slug(client: AsyncClient, auth: dict):
    r = await client.post(
        "/skills/builtin/n-existe-pas/run/",
        headers=auth["headers"],
        json={"params": {}},
    )
    assert r.status_code == 404


@pytest.mark.asyncio
async def test_run_builtin_requires_auth(client: AsyncClient):
    r = await client.post("/skills/builtin/slugify/run/", json={"params": {"text": "x"}})
    assert r.status_code == 401


def test_routed_model_without_gateway(monkeypatch):
    """Sans passerelle configuree, aucun skill ne doit partir vers le cloud."""
    from app.config import settings
    monkeypatch.setattr(settings, "openai_base_url", "")
    assert _routed_model_for("app_generate") is None


def test_routed_model_only_listed_skills(monkeypatch):
    """Seuls les skills listes sortent de la machine."""
    from app.config import settings
    monkeypatch.setattr(settings, "openai_base_url", "http://gateway.local/v1")
    monkeypatch.setattr(settings, "cloud_skills", "app_generate,summarize")
    assert _routed_model_for("app_generate") == "cloud:"
    assert _routed_model_for("summarize") == "cloud:"
    assert _routed_model_for("slugify") is None       # non liste => reste local
    assert _routed_model_for("postgres_query") is None


def test_routed_model_wildcard(monkeypatch):
    from app.config import settings
    monkeypatch.setattr(settings, "openai_base_url", "http://gateway.local/v1")
    monkeypatch.setattr(settings, "cloud_skills", "*")
    assert _routed_model_for("n-importe-quoi") == "cloud:"
