import pytest
from httpx import AsyncClient
from unittest.mock import AsyncMock

pytestmark = pytest.mark.asyncio

WORKFLOW_PAYLOAD = {
    "name": "Workflow pytest",
    "description": "Test de workflow",
    "steps": [
        {"agent_id": "orchestrator", "label": "Étape 1", "pass_output": False},
        {"agent_id": "memory", "label": "Étape 2", "pass_output": True},
    ],
}


async def test_create_workflow(client: AsyncClient, auth: dict):
    r = await client.post("/workflows/", json=WORKFLOW_PAYLOAD, headers=auth["headers"])
    assert r.status_code == 201
    data = r.json()
    assert data["name"] == "Workflow pytest"
    assert len(data["steps"]) == 2


async def test_list_workflows(client: AsyncClient, auth: dict):
    await client.post("/workflows/", json=WORKFLOW_PAYLOAD, headers=auth["headers"])
    r = await client.get("/workflows/", headers=auth["headers"])
    assert r.status_code == 200
    assert isinstance(r.json(), list)
    assert len(r.json()) >= 1


async def test_get_workflow(client: AsyncClient, auth: dict):
    r = await client.post("/workflows/", json=WORKFLOW_PAYLOAD, headers=auth["headers"])
    wf_id = r.json()["id"]
    r2 = await client.get(f"/workflows/{wf_id}", headers=auth["headers"])
    assert r2.status_code == 200
    assert r2.json()["id"] == wf_id


async def test_delete_workflow(client: AsyncClient, auth: dict):
    r = await client.post("/workflows/", json=WORKFLOW_PAYLOAD, headers=auth["headers"])
    wf_id = r.json()["id"]
    r2 = await client.delete(f"/workflows/{wf_id}", headers=auth["headers"])
    assert r2.status_code == 204
    r3 = await client.get(f"/workflows/{wf_id}", headers=auth["headers"])
    assert r3.status_code == 404


async def test_workflow_isolation(client: AsyncClient, auth: dict, admin_auth: dict):
    r = await client.post("/workflows/", json=WORKFLOW_PAYLOAD, headers=auth["headers"])
    wf_id = r.json()["id"]
    r2 = await client.get(f"/workflows/{wf_id}", headers=admin_auth["headers"])
    assert r2.status_code == 404


async def test_run_workflow_mocked(client: AsyncClient, auth: dict):
    r = await client.post("/workflows/", json=WORKFLOW_PAYLOAD, headers=auth["headers"])
    wf_id = r.json()["id"]

    from app.agents import AGENT_REGISTRY
    mock_agent = AsyncMock()
    mock_agent.run = AsyncMock(return_value={"result": "Résultat mock"})
    original = {k: AGENT_REGISTRY[k] for k in ["orchestrator", "memory"] if k in AGENT_REGISTRY}
    AGENT_REGISTRY["orchestrator"] = mock_agent
    AGENT_REGISTRY["memory"] = mock_agent
    try:
        r2 = await client.post(f"/workflows/{wf_id}/run", json={"task": "Analyse mon site web"},
                                headers=auth["headers"])
    finally:
        AGENT_REGISTRY.update(original)

    assert r2.status_code == 200
    data = r2.json()
    assert data["status"] == "completed"
    assert len(data["steps_results"]) == 2
