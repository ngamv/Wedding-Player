import io
import json
import zipfile
import pytest
from httpx import AsyncClient

pytestmark = pytest.mark.asyncio


async def test_export_csv(client: AsyncClient, auth: dict):
    r = await client.get("/export/tasks.csv", headers=auth["headers"])
    assert r.status_code == 200
    assert "text/csv" in r.headers["content-type"]
    text = r.text
    assert "id" in text and "title" in text and "status" in text


async def test_export_json(client: AsyncClient, auth: dict):
    r = await client.get("/export/tasks.json", headers=auth["headers"])
    assert r.status_code == 200
    assert "application/json" in r.headers["content-type"]
    data = r.json()
    assert isinstance(data, list)


async def test_export_requires_auth(client: AsyncClient):
    r = await client.get("/export/tasks.csv")
    assert r.status_code == 401  # authentification requise


async def test_export_zip(client: AsyncClient, auth: dict):
    r = await client.get("/export/download.zip", headers=auth["headers"])
    assert r.status_code == 200
    assert "application/zip" in r.headers["content-type"]
    zf = zipfile.ZipFile(io.BytesIO(r.content))
    names = zf.namelist()
    assert "manifest.json" in names
    assert "tasks.json" in names
    assert "custom_agents.json" in names
    manifest = json.loads(zf.read("manifest.json"))
    assert manifest.get("orion_version") == "1.0.0"
    assert "counts" in manifest


async def test_import_zip_roundtrip(client: AsyncClient, auth: dict):
    """Export a ZIP then import it back — totals should match."""
    # Export
    export_r = await client.get("/export/download.zip", headers=auth["headers"])
    assert export_r.status_code == 200

    # Import
    import_r = await client.post(
        "/export/import",
        files={"file": ("orion_export.zip", export_r.content, "application/zip")},
        headers=auth["headers"],
    )
    assert import_r.status_code == 200
    data = import_r.json()
    assert "imported" in data
    assert "message" in data
    # All items should be skipped (duplicates) or zero if DB was empty
    assert data["imported"]["tasks"] >= 0
    assert data["imported"]["custom_agents"] >= 0


async def test_import_zip_invalid_file(client: AsyncClient, auth: dict):
    r = await client.post(
        "/export/import",
        files={"file": ("notazip.zip", b"not a zip", "application/zip")},
        headers=auth["headers"],
    )
    assert r.status_code == 400


async def test_import_zip_wrong_extension(client: AsyncClient, auth: dict):
    r = await client.post(
        "/export/import",
        files={"file": ("data.json", b"{}", "application/json")},
        headers=auth["headers"],
    )
    assert r.status_code == 400


async def test_import_requires_auth(client: AsyncClient):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        zf.writestr("manifest.json", json.dumps({"orion_version": "1.0.0"}))
    r = await client.post(
        "/export/import",
        files={"file": ("orion.zip", buf.getvalue(), "application/zip")},
    )
    assert r.status_code == 401  # authentification requise
