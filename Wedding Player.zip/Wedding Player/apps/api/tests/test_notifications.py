import pytest
from httpx import AsyncClient

pytestmark = pytest.mark.asyncio


async def test_list_notifications_empty(client: AsyncClient, auth: dict):
    r = await client.get("/notifications/", headers=auth["headers"])
    assert r.status_code == 200
    assert isinstance(r.json(), list)


async def test_list_notifications_requires_auth(client: AsyncClient):
    r = await client.get("/notifications/")
    assert r.status_code == 401  # authentification requise


async def test_unread_count(client: AsyncClient, auth: dict):
    r = await client.get("/notifications/unread-count", headers=auth["headers"])
    assert r.status_code == 200
    assert "count" in r.json()
    assert isinstance(r.json()["count"], int)


async def _create_notif(client: AsyncClient, auth: dict, db_session=None) -> int:
    """Helper: create a notification via the DB helper (bypasses API since there's no public POST)."""
    from app.database import SessionLocal
    from app.routes.notifications import create_notification
    user_id = auth["user"]["id"]
    async with SessionLocal() as db:
        await create_notification(db, user_id=user_id, type="info", title="Test notif", body="Corps du test")
    # Fetch to get the ID
    r = await client.get("/notifications/", headers=auth["headers"])
    notifs = r.json()
    assert len(notifs) > 0
    return notifs[0]["id"]


async def test_mark_notification_read(client: AsyncClient, auth: dict):
    notif_id = await _create_notif(client, auth)
    r = await client.post(f"/notifications/{notif_id}/read", headers=auth["headers"])
    assert r.status_code in (200, 204)

    r2 = await client.get("/notifications/", headers=auth["headers"])
    notif = next((n for n in r2.json() if n["id"] == notif_id), None)
    assert notif is not None
    assert notif["is_read"] is True


async def test_mark_all_read(client: AsyncClient, auth: dict):
    await _create_notif(client, auth)
    r = await client.post("/notifications/read-all", headers=auth["headers"])
    assert r.status_code in (200, 204)

    r2 = await client.get("/notifications/unread-count", headers=auth["headers"])
    assert r2.json()["count"] == 0


async def test_delete_notification(client: AsyncClient, auth: dict):
    notif_id = await _create_notif(client, auth)
    r = await client.delete(f"/notifications/{notif_id}", headers=auth["headers"])
    assert r.status_code in (200, 204)

    r2 = await client.get("/notifications/", headers=auth["headers"])
    ids = [n["id"] for n in r2.json()]
    assert notif_id not in ids


async def test_notification_isolation(client: AsyncClient, auth: dict, admin_auth: dict):
    """User A's notifications are invisible to User B."""
    notif_id = await _create_notif(client, auth)
    r = await client.get("/notifications/", headers=admin_auth["headers"])
    ids = [n["id"] for n in r.json()]
    assert notif_id not in ids
