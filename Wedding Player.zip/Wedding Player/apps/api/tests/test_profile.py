import pytest
from httpx import AsyncClient

pytestmark = pytest.mark.asyncio


async def test_get_me(client: AsyncClient, auth: dict):
    r = await client.get("/auth/me", headers=auth["headers"])
    assert r.status_code == 200
    assert "username" in r.json()
    assert "email" in r.json()


async def test_update_username(client: AsyncClient, auth: dict):
    import time
    new_name = f"updated_{time.time_ns()}"
    r = await client.put("/auth/me", json={"username": new_name}, headers=auth["headers"])
    assert r.status_code == 200
    assert r.json()["username"] == new_name


async def test_update_email(client: AsyncClient, auth: dict):
    import time
    new_email = f"new_{time.time_ns()}@test.com"
    r = await client.put("/auth/me", json={"email": new_email}, headers=auth["headers"])
    assert r.status_code == 200
    assert r.json()["email"] == new_email


async def test_change_password(client: AsyncClient, auth: dict):
    r = await client.put("/auth/me", json={
        "current_password": "password123",
        "new_password": "newpassword456",
    }, headers=auth["headers"])
    assert r.status_code == 200


async def test_change_password_wrong_current(client: AsyncClient, auth: dict):
    r = await client.put("/auth/me", json={
        "current_password": "wrongpassword",
        "new_password": "newpassword456",
    }, headers=auth["headers"])
    assert r.status_code == 400


async def test_status_public(client: AsyncClient):
    """Status endpoint requires no auth."""
    r = await client.get("/system/status")
    assert r.status_code == 200
    data = r.json()
    assert "services" in data
    assert "agents" in data
    assert data["status"] == "operational"
