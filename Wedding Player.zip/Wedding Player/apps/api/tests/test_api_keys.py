import pytest
from httpx import AsyncClient

pytestmark = pytest.mark.asyncio


async def test_create_api_key(client: AsyncClient, auth: dict):
    r = await client.post("/api-keys/", json={"name": "Clé pytest"}, headers=auth["headers"])
    assert r.status_code == 201
    data = r.json()
    assert "key" in data
    assert data["key"].startswith("ok-")
    assert len(data["key"]) > 20


async def test_list_api_keys(client: AsyncClient, auth: dict):
    await client.post("/api-keys/", json={"name": "Clé list test"}, headers=auth["headers"])
    r = await client.get("/api-keys/", headers=auth["headers"])
    assert r.status_code == 200
    keys = r.json()
    assert isinstance(keys, list)
    assert any(k["name"] == "Clé list test" for k in keys)


async def test_revoke_api_key(client: AsyncClient, auth: dict):
    r = await client.post("/api-keys/", json={"name": "À révoquer"}, headers=auth["headers"])
    key_id = r.json()["id"]

    r2 = await client.delete(f"/api-keys/{key_id}", headers=auth["headers"])
    assert r2.status_code == 204

    r3 = await client.get("/api-keys/", headers=auth["headers"])
    active_ids = [k["id"] for k in r3.json() if k["is_active"]]
    assert key_id not in active_ids


async def test_revoke_nonexistent(client: AsyncClient, auth: dict):
    r = await client.delete("/api-keys/999999", headers=auth["headers"])
    assert r.status_code == 404


async def test_key_isolation(client: AsyncClient, auth: dict, admin_auth: dict):
    """User A cannot delete User B's key."""
    r = await client.post("/api-keys/", json={"name": "Clé de A"}, headers=auth["headers"])
    key_id = r.json()["id"]
    r2 = await client.delete(f"/api-keys/{key_id}", headers=admin_auth["headers"])
    assert r2.status_code == 404
