# /// script
# requires-python = ">=3.11"
# dependencies = ["mcp>=1.12,<2"]
# ///
from mcp.server.fastmcp import FastMCP
from app import openjutsu

server = FastMCP("ORION OpenJutsu")


@server.tool()
def catalogue() -> dict:
    """Lister les workflows vidéo OpenJutsu intégrés à ORION."""
    return openjutsu.catalog()


@server.tool()
def diagnostic(workflow: str) -> dict:
    """Indiquer les nœuds ComfyUI manquants pour un workflow."""
    return openjutsu.preflight(workflow)


@server.tool()
def statut(prompt_id: str) -> dict:
    """Consulter le résultat d’un rendu déjà soumis via ORION."""
    return openjutsu.render_status(prompt_id)


if __name__ == "__main__":
    server.run(transport="stdio")
