import { create } from "zustand";
import { persist } from "zustand/middleware";

type Lang = "fr" | "en";

const fr = {
  dashboard: "Dashboard",
  agents: "Agents",
  tasks: "Tâches",
  settings: "Paramètres",
  monitor: "Monitoring",
  analytics: "Analytics",
  chat: "Orion Chat",
  workflows: "Workflows",
  apiKeys: "Clés API",
  customAgents: "Mes agents",
  admin: "Administration",
  quickstart: "Guide rapide",
  scheduled: "Planification",
  teams: "Équipes",
  marketplace: "Marketplace",
  profile: "Mon profil",
  status: "Statut système",
  vault: "Coffre-fort",
  triggers: "Webhooks entrants",
  auditLog: "Journal d'audit",
  playground: "Playground",
  tokens: "Tokens LLM",
  compare: "Comparer agents",
  periodStats: "Stats par période",
  ollamaModels: "Modèles Ollama",
  skills: "Skills",
  logout: "Se déconnecter",
  language: "Langue",
  theme: "Thème",
  dark: "Sombre",
  light: "Clair",
};

const en: typeof fr = {
  dashboard: "Dashboard",
  agents: "Agents",
  tasks: "Tasks",
  settings: "Settings",
  monitor: "Monitoring",
  analytics: "Analytics",
  chat: "Orion Chat",
  workflows: "Workflows",
  apiKeys: "API Keys",
  customAgents: "My agents",
  admin: "Administration",
  quickstart: "Quick start",
  scheduled: "Scheduled",
  teams: "Teams",
  marketplace: "Marketplace",
  profile: "My profile",
  status: "System status",
  vault: "Vault",
  triggers: "Inbound webhooks",
  auditLog: "Audit log",
  playground: "Playground",
  tokens: "LLM Tokens",
  compare: "Compare agents",
  periodStats: "Period stats",
  ollamaModels: "Ollama models",
  skills: "Skills",
  logout: "Log out",
  language: "Language",
  theme: "Theme",
  dark: "Dark",
  light: "Light",
};

const translations = { fr, en };

interface I18nStore {
  lang: Lang;
  t: typeof fr;
  setLang: (l: Lang) => void;
}

export const useI18n = create<I18nStore>()(
  persist(
    (set) => ({
      lang: "fr",
      t: fr,
      setLang: (lang) => set({ lang, t: translations[lang] }),
    }),
    { name: "orion-lang" }
  )
);
