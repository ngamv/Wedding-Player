import { create } from "zustand";
import { persist } from "zustand/middleware";

export type WidgetId = "stats" | "activity" | "agents_chart" | "recent_tasks" | "quick_stats";

interface DashboardStore {
  hidden: WidgetId[];
  toggle: (id: WidgetId) => void;
  isVisible: (id: WidgetId) => boolean;
  reset: () => void;
}

export const useDashboardStore = create<DashboardStore>()(
  persist(
    (set, get) => ({
      hidden: [],
      toggle: (id) =>
        set((s) =>
          s.hidden.includes(id)
            ? { hidden: s.hidden.filter((w) => w !== id) }
            : { hidden: [...s.hidden, id] }
        ),
      isVisible: (id) => !get().hidden.includes(id),
      reset: () => set({ hidden: [] }),
    }),
    { name: "orion-dashboard" }
  )
);
