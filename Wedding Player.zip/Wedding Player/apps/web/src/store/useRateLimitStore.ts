import { create } from "zustand";

interface RateLimitStore {
  used: number;
  remaining: number;
  limit: number;
  update: (used: number, remaining: number, limit: number) => void;
}

export const useRateLimitStore = create<RateLimitStore>((set) => ({
  used: 0,
  remaining: 60,
  limit: 60,
  update: (used, remaining, limit) => set({ used, remaining, limit }),
}));
