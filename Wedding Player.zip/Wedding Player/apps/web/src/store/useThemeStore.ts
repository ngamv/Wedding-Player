import { create } from "zustand";
import { persist } from "zustand/middleware";

type Theme = "dark" | "light";

export const ACCENT_PRESETS = [
  { name: "Indigo",  rgb: "99 102 241",  light: "129 140 248" },
  { name: "Violet",  rgb: "139 92 246",  light: "167 139 250" },
  { name: "Cyan",    rgb: "6 182 212",   light: "34 211 238"  },
  { name: "Emerald", rgb: "16 185 129",  light: "52 211 153"  },
  { name: "Rose",    rgb: "244 63 94",   light: "251 113 133" },
  { name: "Orange",  rgb: "249 115 22",  light: "251 146 60"  },
] as const;

interface ThemeStore {
  theme: Theme;
  accent: string;
  accentLight: string;
  toggle: () => void;
  set: (t: Theme) => void;
  setAccent: (rgb: string, light: string) => void;
}

export const useThemeStore = create<ThemeStore>()(
  persist(
    (set) => ({
      theme: "dark",
      accent: ACCENT_PRESETS[0].rgb,
      accentLight: ACCENT_PRESETS[0].light,
      toggle: () =>
        set((s) => {
          const next = s.theme === "dark" ? "light" : "dark";
          applyTheme(next);
          return { theme: next };
        }),
      set: (theme) => {
        applyTheme(theme);
        set({ theme });
      },
      setAccent: (rgb, light) => {
        applyAccent(rgb, light);
        set({ accent: rgb, accentLight: light });
      },
    }),
    { name: "orion-theme" }
  )
);

export function applyAccent(rgb: string, light: string) {
  document.documentElement.style.setProperty("--orion-accent", rgb);
  document.documentElement.style.setProperty("--orion-accent-light", light);
}

export function applyTheme(theme: Theme) {
  const root = document.documentElement;
  if (theme === "light") {
    root.classList.add("light");
    root.classList.remove("dark");
  } else {
    root.classList.add("dark");
    root.classList.remove("light");
  }
}
