import { create } from "zustand";
import type { Agent, Task, Health, Stats } from "@/api/client";

interface OrionStore {
  agents: Agent[];
  tasks: Task[];
  health: Health | null;
  stats: Stats | null;
  loading: boolean;
  activeAgent: Agent | null;
  chatHistory: { role: "user" | "assistant"; content: string; agent?: string; ts?: number }[];
  setAgents: (agents: Agent[]) => void;
  setTasks: (tasks: Task[]) => void;
  setHealth: (health: Health) => void;
  setStats: (stats: Stats) => void;
  setLoading: (v: boolean) => void;
  setActiveAgent: (agent: Agent | null) => void;
  addChat: (msg: { role: "user" | "assistant"; content: string; agent?: string; ts?: number }) => void;
  clearChat: () => void;
}

export const useOrionStore = create<OrionStore>((set) => ({
  agents: [],
  tasks: [],
  health: null,
  stats: null,
  loading: false,
  activeAgent: null,
  chatHistory: [],
  setAgents: (agents) => set({ agents }),
  setTasks: (tasks) => set({ tasks }),
  setHealth: (health) => set({ health }),
  setStats: (stats) => set({ stats }),
  setLoading: (loading) => set({ loading }),
  setActiveAgent: (activeAgent) => set({ activeAgent }),
  addChat: (msg) => set((s) => ({ chatHistory: [...s.chatHistory, msg] })),
  clearChat: () => set({ chatHistory: [] }),
}));
