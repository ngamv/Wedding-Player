import { create } from "zustand";
import { persist } from "zustand/middleware";

const MAX = 20;

interface PromptHistoryStore {
  history: string[];
  push: (prompt: string) => void;
  remove: (prompt: string) => void;
  clear: () => void;
}

export const usePromptHistory = create<PromptHistoryStore>()(
  persist(
    (set) => ({
      history: [],
      push: (prompt) =>
        set((s) => {
          const deduped = s.history.filter((p) => p !== prompt);
          return { history: [prompt, ...deduped].slice(0, MAX) };
        }),
      remove: (prompt) => set((s) => ({ history: s.history.filter((p) => p !== prompt) })),
      clear: () => set({ history: [] }),
    }),
    { name: "orion-prompt-history" }
  )
);
