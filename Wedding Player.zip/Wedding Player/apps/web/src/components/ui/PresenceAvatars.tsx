import { usePresence } from "@/hooks/usePresence";

export function PresenceAvatars() {
  const { users } = usePresence();
  if (users.length === 0) return null;

  return (
    <div className="flex items-center gap-2" title={`${users.length} utilisateur(s) connecté(s)`}>
      <span className="text-orion-muted text-xs hidden sm:block">En ligne :</span>
      <div className="flex -space-x-2">
        {users.slice(0, 5).map((u) => (
          <div
            key={u.user_id}
            title={u.username}
            className="w-7 h-7 rounded-full bg-orion-accent/20 border-2 border-orion-surface flex items-center justify-center text-[10px] text-orion-accent-light font-medium uppercase flex-shrink-0"
          >
            {u.username.slice(0, 2)}
          </div>
        ))}
        {users.length > 5 && (
          <div className="w-7 h-7 rounded-full bg-orion-border border-2 border-orion-surface flex items-center justify-center text-[9px] text-orion-muted flex-shrink-0">
            +{users.length - 5}
          </div>
        )}
      </div>
      <span className="relative flex h-2 w-2">
        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-orion-green opacity-75" />
        <span className="relative inline-flex rounded-full h-2 w-2 bg-orion-green" />
      </span>
    </div>
  );
}
