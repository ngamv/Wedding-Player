interface CodeBlockProps {
  code: string;
  className?: string;
}

type Token = { type: "key" | "string" | "number" | "bool" | "null" | "punct" | "keyword" | "comment" | "plain"; value: string };

function detectLang(code: string): "json" | "python" | "sql" | "js" | "plain" {
  const t = code.trim();
  try {
    const parsed = JSON.parse(t);
    if (typeof parsed === "object" && parsed !== null) return "json";
  } catch {/* not json */}
  if (/^\s*(SELECT|INSERT|UPDATE|DELETE|CREATE|DROP|WITH|ALTER)\s/i.test(t)) return "sql";
  if (/\bdef \w+|import \w+|from \w+ import|print\(|#.*$/.test(t)) return "python";
  if (/\bconst |let |var |function |=>|require\(/.test(t)) return "js";
  return "plain";
}

function tokenizeJson(code: string): Token[] {
  const tokens: Token[] = [];
  const regex = /("(?:\\.|[^"\\])*")\s*:|(\"(?:\\.|[^"\\])*\")|([-+]?\d+\.?\d*(?:[eE][+-]?\d+)?)|(\btrue\b|\bfalse\b)|(\bnull\b)|([{}[\],:])/g;
  let lastIndex = 0;
  let match: RegExpExecArray | null;
  while ((match = regex.exec(code)) !== null) {
    if (match.index > lastIndex) tokens.push({ type: "plain", value: code.slice(lastIndex, match.index) });
    if (match[1]) {
      tokens.push({ type: "key", value: match[1] });
      tokens.push({ type: "punct", value: ":" });
    } else if (match[2]) tokens.push({ type: "string", value: match[2] });
    else if (match[3]) tokens.push({ type: "number", value: match[3] });
    else if (match[4]) tokens.push({ type: "bool", value: match[4] });
    else if (match[5]) tokens.push({ type: "null", value: match[5] });
    else if (match[6]) tokens.push({ type: "punct", value: match[6] });
    lastIndex = regex.lastIndex;
  }
  if (lastIndex < code.length) tokens.push({ type: "plain", value: code.slice(lastIndex) });
  return tokens;
}

function tokenizeCode(code: string, lang: "python" | "sql" | "js"): Token[] {
  const kwPython = /\b(def|class|import|from|return|if|elif|else|for|while|in|not|and|or|is|None|True|False|try|except|with|as|lambda|pass|raise|yield|async|await)\b/;
  const kwSql = /\b(SELECT|FROM|WHERE|JOIN|LEFT|RIGHT|INNER|OUTER|ON|AND|OR|NOT|IN|IS|NULL|AS|GROUP BY|ORDER BY|HAVING|LIMIT|OFFSET|INSERT|INTO|VALUES|UPDATE|SET|DELETE|CREATE|TABLE|INDEX|DROP|ALTER|ADD|COLUMN|PRIMARY|KEY|UNIQUE|DEFAULT|COUNT|SUM|AVG|MAX|MIN|DISTINCT|UNION|ALL)\b/i;
  const kwJs = /\b(const|let|var|function|return|if|else|for|while|do|switch|case|break|continue|new|this|typeof|instanceof|in|of|import|export|default|class|extends|async|await|try|catch|finally|throw|null|undefined|true|false)\b/;
  const kw = lang === "python" ? kwPython : lang === "sql" ? kwSql : kwJs;
  const commentRe = lang === "python" ? /#[^\n]*/g : lang === "sql" ? /--[^\n]*/g : /\/\/[^\n]*/g;
  const stringRe = /("""[\s\S]*?"""|'''[\s\S]*?'''|"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|`(?:\\.|[^`\\])*`)/g;

  const tokens: Token[] = [];

  const regions: { start: number; end: number; type: "comment" | "string" }[] = [];
  let m: RegExpExecArray | null;
  const allRe = new RegExp(`(${commentRe.source})|(${stringRe.source})`, "g");
  while ((m = allRe.exec(code)) !== null) {
    regions.push({ start: m.index, end: m.index + m[0].length, type: m[1] ? "comment" : "string" });
  }

  let pos = 0;
  for (const region of regions) {
    if (region.start > pos) {
      const segment = code.slice(pos, region.start);
      const parts = segment.split(kw);
      for (const part of parts) {
        if (kw.test(part)) tokens.push({ type: "keyword", value: part });
        else if (part) tokens.push({ type: "plain", value: part });
      }
    }
    tokens.push({ type: region.type, value: code.slice(region.start, region.end) });
    pos = region.end;
  }
  if (pos < code.length) {
    const remaining = code.slice(pos);
    const parts = remaining.split(kw);
    for (const part of parts) {
      if (kw.test(part)) tokens.push({ type: "keyword", value: part });
      else if (part) tokens.push({ type: "plain", value: part });
    }
  }
  return tokens;
}

const COLOR: Record<Token["type"], string> = {
  key: "text-blue-300",
  string: "text-green-300",
  number: "text-orange-300",
  bool: "text-purple-300",
  null: "text-purple-300",
  punct: "text-orion-muted",
  keyword: "text-purple-300",
  comment: "text-orion-muted italic",
  plain: "text-white",
};

export function CodeBlock({ code, className = "" }: CodeBlockProps) {
  const lang = detectLang(code);

  let formatted = code;
  if (lang === "json") {
    try { formatted = JSON.stringify(JSON.parse(code), null, 2); } catch {/* keep as-is */}
  }

  const tokens: Token[] =
    lang === "json"
      ? tokenizeJson(formatted)
      : lang === "plain"
      ? [{ type: "plain", value: formatted }]
      : tokenizeCode(formatted, lang);

  return (
    <div className={`relative rounded-lg overflow-hidden bg-orion-bg border border-orion-border/50 ${className}`}>
      {lang !== "plain" && (
        <div className="flex items-center justify-between px-4 py-1.5 bg-orion-surface border-b border-orion-border/50">
          <span className="text-[10px] font-mono text-orion-muted uppercase tracking-wider">{lang}</span>
          <button
            onClick={() => navigator.clipboard.writeText(formatted)}
            className="text-[10px] text-orion-muted hover:text-white transition-colors"
          >
            Copier
          </button>
        </div>
      )}
      <pre className="p-4 text-xs leading-relaxed font-mono overflow-x-auto whitespace-pre-wrap break-words">
        {tokens.map((tok, i) => (
          <span key={i} className={COLOR[tok.type]}>{tok.value}</span>
        ))}
      </pre>
    </div>
  );
}
