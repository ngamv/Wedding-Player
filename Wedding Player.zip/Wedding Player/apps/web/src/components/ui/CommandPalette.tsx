import { useEffect, useRef, useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { Search, X, Bot, ListTodo, GitBranch, Wand2, Brain, Play, FlaskConical } from "lucide-react";
import { api } from "@/api/client";

interface Result {
  type: "task" | "workflow" | "agent" | "custom_agent" | "memory";
  id: string | number;
  title: string;
  subtitle: string;
  url: string;
  status?: string;
}

const TYPE_ICON: Record<string, React.ReactNode> = {
  task: <ListTodo size={14} />,
  workflow: <GitBranch size={14} />,
  agent: <Bot size={14} />,
  custom_agent: <Wand2 size={14} />,
  memory: <Brain size={14} />,
};

const TYPE_LABEL: Record<string, string> = {
  task: "Tâche",
  workflow: "Workflow",
  agent: "Agent",
  custom_agent: "Agent custom",
  memory: "Mémoire",
};

const STATUS_COLOR: Record<string, string> = {
  completed: "text-orion-green",
  failed: "text-orion-red",
  running: "text-orion-accent-light",
  pending: "text-orion-gold",
};

const QUICK_ACTIONS = [
  { icon: <Play size={14} />, label: "Nouvelle tâche", url: "/tasks", hint: "→ /tasks" },
  { icon: <FlaskConical size={14} />, label: "Ouvrir le Playground", url: "/playground", hint: "→ /playground" },
  { icon: <Bot size={14} />, label: "Voir tous les agents", url: "/agents", hint: "→ /agents" },
];

export function CommandPalette({ onClose }: { onClose: () => void }) {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<Result[]>([]);
  const [selected, setSelected] = useState(0);
  const [loading, setLoading] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const search = useCallback(async (q: string) => {
    if (!q.trim()) {
      setResults([]);
      return;
    }
    setLoading(true);
    try {
      const data = await api.get<{ results: Result[] }>(`/search/?q=${encodeURIComponent(q)}`);
      setResults(data.results);
      setSelected(0);
    } catch {
      setResults([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => search(query), 250);
    return () => clearTimeout(timer);
  }, [query, search]);

  function handleKeyDown(e: React.KeyboardEvent) {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setSelected((s) => Math.min(s + 1, results.length - 1));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setSelected((s) => Math.max(s - 1, 0));
    } else if (e.key === "Enter" && results[selected]) {
      navigate(results[selected].url);
      onClose();
    } else if (e.key === "Escape") {
      onClose();
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-24 px-4" onClick={onClose}>
      <div
        className="w-full max-w-xl bg-orion-surface border border-orion-border rounded-xl shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Input */}
        <div className="flex items-center gap-3 px-4 py-3 border-b border-orion-border">
          <Search size={16} className="text-orion-muted flex-shrink-0" />
          <input
            ref={inputRef}
            className="flex-1 bg-transparent text-white placeholder:text-orion-muted text-sm outline-none"
            placeholder="Rechercher tâches, agents, workflows…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={handleKeyDown}
          />
          {loading && (
            <div className="w-4 h-4 border-2 border-orion-accent/30 border-t-orion-accent rounded-full animate-spin" />
          )}
          <button onClick={onClose} className="text-orion-muted hover:text-white">
            <X size={14} />
          </button>
        </div>

        {/* Results */}
        {results.length > 0 && (
          <ul className="max-h-80 overflow-y-auto py-2">
            {results.map((r, i) => (
              <li key={`${r.type}-${r.id}`}>
                <button
                  className={`w-full flex items-center gap-3 px-4 py-2.5 text-left transition-colors ${
                    i === selected ? "bg-orion-accent/15" : "hover:bg-white/5"
                  }`}
                  onClick={() => { navigate(r.url); onClose(); }}
                  onMouseEnter={() => setSelected(i)}
                >
                  <span className="text-orion-muted flex-shrink-0">{TYPE_ICON[r.type]}</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-white truncate">{r.title}</p>
                    {r.subtitle && (
                      <p className="text-xs text-orion-muted truncate">{r.subtitle}</p>
                    )}
                  </div>
                  <div className="flex items-center gap-1.5 flex-shrink-0">
                    {r.status && (
                      <span className={`text-[10px] font-mono ${STATUS_COLOR[r.status] ?? "text-orion-muted"}`}>
                        {r.status}
                      </span>
                    )}
                    <span className="text-[10px] text-orion-muted bg-orion-bg px-2 py-0.5 rounded">
                      {TYPE_LABEL[r.type]}
                    </span>
                  </div>
                </button>
              </li>
            ))}
          </ul>
        )}

        {query && !loading && results.length === 0 && (
          <p className="text-center text-orion-muted text-sm py-8">
            Aucun résultat pour « {query} »
          </p>
        )}

        {!query && (
          <div className="py-2">
            <p className="px-4 py-1 text-[10px] text-orion-muted uppercase tracking-wider">Actions rapides</p>
            <ul>
              {QUICK_ACTIONS.map((a, i) => (
                <li key={a.url}>
                  <button
                    className={`w-full flex items-center gap-3 px-4 py-2.5 text-left transition-colors ${
                      i === selected ? "bg-orion-accent/15" : "hover:bg-white/5"
                    }`}
                    onClick={() => { navigate(a.url); onClose(); }}
                    onMouseEnter={() => setSelected(i)}
                  >
                    <span className="text-orion-muted flex-shrink-0">{a.icon}</span>
                    <span className="flex-1 text-sm text-white">{a.label}</span>
                    <span className="text-[10px] text-orion-muted font-mono">{a.hint}</span>
                  </button>
                </li>
              ))}
            </ul>
            <p className="text-center text-orion-muted text-[10px] py-2 border-t border-orion-border/50 mt-2">
              ↑↓ naviguer · Entrée sélectionner · Échap fermer
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
