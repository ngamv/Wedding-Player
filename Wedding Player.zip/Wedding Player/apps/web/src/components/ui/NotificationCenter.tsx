import { useEffect, useRef, useState } from "react";
import { Bell, Check, CheckCheck, Trash2, X } from "lucide-react";
import { api } from "@/api/client";

interface Notif {
  id: number;
  type: string;
  title: string;
  body: string;
  is_read: boolean;
  created_at: string;
}

const typeColor = (t: string) =>
  t === "task.completed" ? "bg-orion-green/15 text-orion-green" :
  t === "task.failed"    ? "bg-orion-red/15 text-orion-red" :
  "bg-orion-accent/15 text-orion-accent-light";

const typeLabel = (t: string) =>
  t === "task.completed" ? "✓ Terminée" :
  t === "task.failed"    ? "✗ Échouée"  :
  "⚡ Trigger";

export function NotificationCenter() {
  const [open, setOpen] = useState(false);
  const [notifs, setNotifs] = useState<Notif[]>([]);
  const [unread, setUnread] = useState(0);
  const ref = useRef<HTMLDivElement>(null);

  async function load() {
    try {
      const [list, count] = await Promise.all([
        api.get<Notif[]>("/notifications/"),
        api.get<{ count: number }>("/notifications/unread-count"),
      ]);
      setNotifs(list);
      setUnread(count.count);
    } catch { /* offline */ }
  }

  useEffect(() => {
    load();
    const interval = setInterval(load, 30_000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (!open) return;
    function onClick(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, [open]);

  async function markRead(id: number) {
    await api.post(`/notifications/${id}/read`);
    setNotifs((p) => p.map((n) => n.id === id ? { ...n, is_read: true } : n));
    setUnread((c) => Math.max(0, c - 1));
  }

  async function markAllRead() {
    await api.post("/notifications/read-all");
    setNotifs((p) => p.map((n) => ({ ...n, is_read: true })));
    setUnread(0);
  }

  async function remove(id: number) {
    const n = notifs.find((x) => x.id === id);
    await api.delete(`/notifications/${id}`);
    setNotifs((p) => p.filter((x) => x.id !== id));
    if (n && !n.is_read) setUnread((c) => Math.max(0, c - 1));
  }

  return (
    <div ref={ref} className="relative">
      <button
        onClick={() => { setOpen((v) => !v); if (!open) load(); }}
        className="relative p-1.5 rounded-md hover:bg-white/5 text-orion-muted hover:text-white transition-colors"
        aria-label="Notifications"
      >
        <Bell size={15} />
        {unread > 0 && (
          <span className="absolute -top-0.5 -right-0.5 w-4 h-4 rounded-full bg-orion-accent text-white text-[9px] font-bold flex items-center justify-center">
            {unread > 9 ? "9+" : unread}
          </span>
        )}
      </button>

      {open && (
        <div className="absolute right-0 top-9 w-80 bg-orion-surface border border-orion-border rounded-xl shadow-2xl z-50 animate-slide-in">
          <div className="px-4 py-3 border-b border-orion-border flex items-center justify-between">
            <span className="text-white text-sm font-medium">Notifications</span>
            <div className="flex items-center gap-1">
              {unread > 0 && (
                <button
                  onClick={markAllRead}
                  title="Tout marquer comme lu"
                  className="p-1 rounded text-orion-muted hover:text-white transition-colors"
                >
                  <CheckCheck size={13} />
                </button>
              )}
              <button onClick={() => setOpen(false)} className="p-1 rounded text-orion-muted hover:text-white transition-colors">
                <X size={13} />
              </button>
            </div>
          </div>

          <div className="max-h-80 overflow-y-auto">
            {notifs.length === 0 ? (
              <div className="px-4 py-8 text-center text-orion-muted text-xs">Aucune notification</div>
            ) : (
              notifs.map((n) => (
                <div
                  key={n.id}
                  className={`px-4 py-3 border-b border-orion-border/50 flex items-start gap-3 hover:bg-white/3 transition-colors ${!n.is_read ? "bg-orion-accent/5" : ""}`}
                >
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5">
                      <span className={`text-[9px] px-1.5 py-0.5 rounded-full font-medium ${typeColor(n.type)}`}>
                        {typeLabel(n.type)}
                      </span>
                      {!n.is_read && <div className="w-1.5 h-1.5 rounded-full bg-orion-accent flex-shrink-0" />}
                    </div>
                    <p className="text-white text-xs font-medium truncate">{n.title}</p>
                    {n.body && <p className="text-orion-muted text-[10px] truncate mt-0.5">{n.body}</p>}
                    <p className="text-orion-muted/60 text-[9px] mt-1">
                      {new Date(n.created_at).toLocaleString("fr-FR", { day:"2-digit", month:"2-digit", hour:"2-digit", minute:"2-digit" })}
                    </p>
                  </div>
                  <div className="flex flex-col gap-1 flex-shrink-0">
                    {!n.is_read && (
                      <button onClick={() => markRead(n.id)} title="Marquer comme lu" className="p-1 rounded text-orion-muted hover:text-orion-green transition-colors">
                        <Check size={11} />
                      </button>
                    )}
                    <button onClick={() => remove(n.id)} title="Supprimer" className="p-1 rounded text-orion-muted hover:text-orion-red transition-colors">
                      <Trash2 size={11} />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}
