import { useEffect, useState } from "react";
import { CheckCircle, XCircle, Info, X } from "lucide-react";

export type ToastType = "success" | "error" | "info";

export interface Toast {
  id: string;
  type: ToastType;
  message: string;
}

interface ToastProps {
  toast: Toast;
  onRemove: (id: string) => void;
}

const ICONS = { success: CheckCircle, error: XCircle, info: Info };
const COLORS = {
  success: "border-orion-green/30 bg-orion-green/10 text-orion-green",
  error: "border-orion-red/30 bg-orion-red/10 text-orion-red",
  info: "border-orion-accent/30 bg-orion-accent/10 text-orion-accent",
};

function ToastItem({ toast, onRemove }: ToastProps) {
  const Icon = ICONS[toast.type];

  useEffect(() => {
    const t = setTimeout(() => onRemove(toast.id), 4000);
    return () => clearTimeout(t);
  }, [toast.id, onRemove]);

  return (
    <div className={`flex items-center gap-3 px-4 py-3 rounded-xl border text-sm animate-slide-in ${COLORS[toast.type]}`}>
      <Icon size={15} className="flex-shrink-0" />
      <span className="flex-1 text-white">{toast.message}</span>
      <button onClick={() => onRemove(toast.id)} className="text-orion-muted hover:text-white transition-colors">
        <X size={13} />
      </button>
    </div>
  );
}

// Singleton store
type Listener = (toasts: Toast[]) => void;
let toasts: Toast[] = [];
const listeners = new Set<Listener>();
const notify = () => listeners.forEach((l) => l([...toasts]));

export const toast = {
  success: (message: string) => {
    const id = Math.random().toString(36).slice(2);
    toasts = [...toasts, { id, type: "success", message }];
    notify();
  },
  error: (message: string) => {
    const id = Math.random().toString(36).slice(2);
    toasts = [...toasts, { id, type: "error", message }];
    notify();
  },
  info: (message: string) => {
    const id = Math.random().toString(36).slice(2);
    toasts = [...toasts, { id, type: "info", message }];
    notify();
  },
};

export function ToastContainer() {
  const [items, setItems] = useState<Toast[]>([]);

  useEffect(() => {
    listeners.add(setItems);
    return () => { listeners.delete(setItems); };
  }, []);

  const remove = (id: string) => {
    toasts = toasts.filter((t) => t.id !== id);
    notify();
  };

  if (!items.length) return null;

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-2 w-80">
      {items.map((t) => <ToastItem key={t.id} toast={t} onRemove={remove} />)}
    </div>
  );
}
