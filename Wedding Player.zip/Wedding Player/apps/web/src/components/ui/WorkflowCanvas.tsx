import type { WorkflowStep } from "@/api/workflows";
import type { Agent } from "@/api/client";

const CATEGORY_COLORS: Record<string, string> = {
  core: "#6366f1", seo: "#10b981", social: "#f59e0b",
  marketing: "#ec4899", dev: "#3b82f6", data: "#8b5cf6",
};

const NODE_W = 140;
const NODE_H = 52;
const GAP_X = 60;
const PAD_Y = 24;

interface Props {
  steps: WorkflowStep[];
  agents: Agent[];
}

export function WorkflowCanvas({ steps, agents }: Props) {
  if (steps.length === 0) return (
    <div className="flex items-center justify-center h-24 text-orion-muted text-sm opacity-50">
      Aucune étape — ajoutez des étapes pour voir le graphe
    </div>
  );

  const totalW = steps.length * NODE_W + (steps.length - 1) * GAP_X + 40;
  const totalH = NODE_H + PAD_Y * 2;

  return (
    <div className="overflow-x-auto">
      <svg
        viewBox={`0 0 ${totalW} ${totalH}`}
        width={totalW}
        height={totalH}
        xmlns="http://www.w3.org/2000/svg"
        className="block"
      >
        {steps.map((step, i) => {
          const agent = agents.find((a) => a.id === step.agent_id);
          const color = CATEGORY_COLORS[agent?.category ?? ""] ?? "#6366f1";
          const x = 20 + i * (NODE_W + GAP_X);
          const y = PAD_Y;
          const cx = x + NODE_W / 2;
          const arrowStartX = x + NODE_W;
          const arrowEndX = x + NODE_W + GAP_X;
          const midY = y + NODE_H / 2;

          return (
            <g key={i}>
              {/* Arrow to next node */}
              {i < steps.length - 1 && (
                <g>
                  <line
                    x1={arrowStartX}
                    y1={midY}
                    x2={arrowEndX - 8}
                    y2={midY}
                    stroke="#334155"
                    strokeWidth={1.5}
                    strokeDasharray={step.pass_output ? "0" : "4 3"}
                  />
                  <polygon
                    points={`${arrowEndX - 8},${midY - 4} ${arrowEndX},${midY} ${arrowEndX - 8},${midY + 4}`}
                    fill="#334155"
                  />
                </g>
              )}

              {/* Node box */}
              <rect
                x={x}
                y={y}
                width={NODE_W}
                height={NODE_H}
                rx={8}
                fill="#0f172a"
                stroke={color}
                strokeWidth={1.5}
              />
              {/* Color accent top bar */}
              <rect x={x + 1} y={y + 1} width={NODE_W - 2} height={4} rx={7} fill={color} opacity={0.6} />

              {/* Step number badge */}
              <circle cx={x + 16} cy={y + NODE_H / 2 + 3} r={9} fill={color} opacity={0.25} />
              <text x={x + 16} y={y + NODE_H / 2 + 7} textAnchor="middle" fontSize={9} fill={color} fontFamily="monospace" fontWeight="bold">
                {i + 1}
              </text>

              {/* Agent name */}
              <text
                x={cx + 6}
                y={y + NODE_H / 2 - 2}
                textAnchor="middle"
                fontSize={9}
                fill="#94a3b8"
                fontFamily="monospace"
              >
                {agent?.category?.toUpperCase() ?? "—"}
              </text>
              <text
                x={cx + 6}
                y={y + NODE_H / 2 + 12}
                textAnchor="middle"
                fontSize={10}
                fill="white"
                fontFamily="sans-serif"
                fontWeight="600"
              >
                {(step.label || agent?.name || step.agent_id || "Agent").slice(0, 16)}
              </text>
            </g>
          );
        })}
      </svg>
    </div>
  );
}
