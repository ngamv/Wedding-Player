import { useEffect } from "react";
import { X, Keyboard } from "lucide-react";

interface Props {
  onClose: () => void;
}

const SHORTCUTS: { section: string; items: { keys: string[]; desc: string }[] }[] = [
  {
    section: "Navigation",
    items: [
      { keys: ["Ctrl", "K"], desc: "Ouvrir la palette de commandes" },
      { keys: ["?"], desc: "Afficher cette aide" },
      { keys: ["Échap"], desc: "Fermer modal / palette" },
    ],
  },
  {
    section: "Tâches",
    items: [
      { keys: ["Ctrl", "Entrée"], desc: "Exécuter dans le Playground" },
    ],
  },
  {
    section: "Interface",
    items: [
      { keys: ["Alt", "T"], desc: "Basculer thème clair/sombre" },
      { keys: ["Alt", "L"], desc: "Changer la langue FR/EN" },
    ],
  },
];

function Key({ label }: { label: string }) {
  return (
    <kbd className="inline-flex items-center justify-center px-2 py-0.5 min-w-[1.75rem] rounded-md border border-orion-border bg-orion-bg text-white text-[11px] font-mono shadow-sm">
      {label}
    </kbd>
  );
}

export function ShortcutsModal({ onClose }: Props) {
  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (e.key === "Escape") onClose();
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm"
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div className="bg-orion-surface border border-orion-border rounded-2xl shadow-2xl w-full max-w-md mx-4 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-orion-border">
          <div className="flex items-center gap-2">
            <Keyboard size={16} className="text-orion-accent-light" />
            <h2 className="text-white font-semibold text-sm">Raccourcis clavier</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-white/5 text-orion-muted hover:text-white transition-colors"
          >
            <X size={14} />
          </button>
        </div>

        {/* Body */}
        <div className="px-5 py-4 space-y-5">
          {SHORTCUTS.map(({ section, items }) => (
            <div key={section}>
              <p className="text-orion-muted text-[10px] uppercase tracking-widest mb-3">{section}</p>
              <div className="space-y-2.5">
                {items.map(({ keys, desc }) => (
                  <div key={desc} className="flex items-center justify-between">
                    <span className="text-white text-sm">{desc}</span>
                    <div className="flex items-center gap-1 flex-shrink-0 ml-4">
                      {keys.map((k, i) => (
                        <span key={i} className="flex items-center gap-1">
                          <Key label={k} />
                          {i < keys.length - 1 && <span className="text-orion-muted/40 text-[10px]">+</span>}
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="px-5 pb-4">
          <p className="text-orion-muted/40 text-[10px] text-center">Appuyez sur <Key label="?" /> n'importe où pour ouvrir cette aide</p>
        </div>
      </div>
    </div>
  );
}
