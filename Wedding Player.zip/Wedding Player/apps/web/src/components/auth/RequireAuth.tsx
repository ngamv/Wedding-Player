import { useEffect } from "react";
import { Navigate, useLocation } from "react-router-dom";
import { useAuthStore } from "@/store/useAuthStore";
import { api } from "@/api/client";
import type { ReactNode } from "react";

// Gate every private route: without a token the API answers 401, so rendering
// the app would only show an empty shell with no way to sign in.
export function RequireAuth({ children }: { children: ReactNode }) {
  const token = useAuthStore((s) => s.token);
  const user = useAuthStore((s) => s.user);
  const setUser = useAuthStore((s) => s.setUser);
  const logout = useAuthStore((s) => s.logout);
  const location = useLocation();

  useEffect(() => {
    if (!token || user) return;
    api
      .get<{ id: number; username: string; email: string; role: "admin" | "user" | "readonly"; is_active: boolean }>("/auth/me")
      .then(setUser)
      // A stored token the API rejects is stale: drop it so the user lands on
      // the login screen instead of a half-broken session.
      .catch(() => logout());
  }, [token, user, setUser, logout]);

  if (!token) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  return <>{children}</>;
}
