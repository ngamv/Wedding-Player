import { NavLink } from "react-router-dom";
import { LayoutDashboard, Bot, ListTodo, Brain, Activity, Settings, Wand2, GitBranch, KeyRound, ShieldCheck, BarChart2, HelpCircle, Radio, Clock, UserCircle, Users, Store, Lock, Zap, ClipboardList, Sun, Moon, FlaskConical, Coins, GitCompareArrows, CalendarRange, Cpu, Puzzle } from "lucide-react";
import { clsx } from "clsx";
import { useAuthStore } from "@/store/useAuthStore";
import { useThemeStore } from "@/store/useThemeStore";
import { useI18n } from "@/i18n";

const links = [
  { to: "/", icon: LayoutDashboard, labelKey: "dashboard" as const, adminOnly: false },
  { to: "/agents", icon: Bot, labelKey: "agents" as const, adminOnly: false },
  { to: "/chat", icon: Brain, labelKey: "chat" as const, adminOnly: false },
  { to: "/tasks", icon: ListTodo, labelKey: "tasks" as const, adminOnly: false },
  { to: "/monitor", icon: Activity, labelKey: "monitor" as const, adminOnly: false },
  { to: "/custom-agents", icon: Wand2, labelKey: "customAgents" as const, adminOnly: false },
  { to: "/workflows", icon: GitBranch, labelKey: "workflows" as const, adminOnly: false },
  { to: "/api-keys", icon: KeyRound, labelKey: "apiKeys" as const, adminOnly: false },
  { to: "/analytics", icon: BarChart2, labelKey: "analytics" as const, adminOnly: false },
  { to: "/settings", icon: Settings, labelKey: "settings" as const, adminOnly: false },
  { to: "/quickstart", icon: HelpCircle, labelKey: "quickstart" as const, adminOnly: false },
  { to: "/scheduled", icon: Clock, labelKey: "scheduled" as const, adminOnly: false },
  { to: "/teams", icon: Users, labelKey: "teams" as const, adminOnly: false },
  { to: "/marketplace", icon: Store, labelKey: "marketplace" as const, adminOnly: false },
  { to: "/playground", icon: FlaskConical, labelKey: "playground" as const, adminOnly: false },
  { to: "/tokens", icon: Coins, labelKey: "tokens" as const, adminOnly: false },
  { to: "/compare", icon: GitCompareArrows, labelKey: "compare" as const, adminOnly: false },
  { to: "/period-stats", icon: CalendarRange, labelKey: "periodStats" as const, adminOnly: false },
  { to: "/ollama-models", icon: Cpu, labelKey: "ollamaModels" as const, adminOnly: false },
  { to: "/skills", icon: Puzzle, labelKey: "skills" as const, adminOnly: false },
  { to: "/vault", icon: Lock, labelKey: "vault" as const, adminOnly: false },
  { to: "/triggers", icon: Zap, labelKey: "triggers" as const, adminOnly: false },
  { to: "/profile", icon: UserCircle, labelKey: "profile" as const, adminOnly: false },
  { to: "/admin", icon: ShieldCheck, labelKey: "admin" as const, adminOnly: true },
  { to: "/admin/audit", icon: ClipboardList, labelKey: "auditLog" as const, adminOnly: true },
  { to: "/status", icon: Radio, labelKey: "status" as const, adminOnly: false },
];

export function Sidebar() {
  const { user } = useAuthStore();
  const { theme, toggle: toggleTheme } = useThemeStore();
  const { t, lang, setLang } = useI18n();

  return (
    <aside className="w-60 min-h-screen bg-orion-surface border-r border-orion-border flex flex-col">
      {/* Logo */}
      <div className="px-6 py-5 border-b border-orion-border">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-orion-accent flex items-center justify-center orion-glow">
            <span className="text-white font-bold text-sm">O</span>
          </div>
          <div>
            <p className="text-white font-semibold text-sm tracking-wide">ORION AI</p>
            <p className="text-orion-muted text-[10px] uppercase tracking-widest">v1.0</p>
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-4 space-y-0.5 overflow-y-auto">
        {links.filter(({ adminOnly }) => !adminOnly || user?.role === "admin").map(({ to, icon: Icon, labelKey }) => (
          <NavLink
            key={to}
            to={to}
            end={to === "/"}
            className={({ isActive }) =>
              clsx(
                "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all duration-150",
                isActive
                  ? "bg-orion-accent/15 text-orion-accent-light border border-orion-accent/25"
                  : "text-orion-muted hover:text-white hover:bg-white/5"
              )
            }
          >
            <Icon size={16} />
            {t[labelKey]}
          </NavLink>
        ))}
      </nav>

      {/* Theme + Lang toggles */}
      <div className="px-4 py-3 border-t border-orion-border flex items-center gap-2">
        <button
          onClick={toggleTheme}
          title={theme === "dark" ? t.light : t.dark}
          className="p-1.5 rounded-lg hover:bg-white/5 text-orion-muted hover:text-white transition-colors"
        >
          {theme === "dark" ? <Sun size={14} /> : <Moon size={14} />}
        </button>
        <button
          onClick={() => setLang(lang === "fr" ? "en" : "fr")}
          className="text-[10px] font-mono px-2 py-1 rounded border border-orion-border text-orion-muted hover:text-white hover:border-orion-accent/50 transition-colors"
        >
          {lang === "fr" ? "EN" : "FR"}
        </button>
      </div>

      {/* User footer */}
      <div className="px-4 py-4 border-t border-orion-border">
        {user ? (
          <div className="flex items-center justify-between">
            <div className="min-w-0">
              <div className="flex items-center gap-1.5 mb-0.5">
                <p className="text-white text-xs font-medium truncate">{user.username}</p>
                <span className={`text-[9px] px-1.5 py-0.5 rounded-full font-medium uppercase tracking-wider flex-shrink-0 ${
                  user.role === "admin"
                    ? "bg-orion-accent/20 text-orion-accent-light"
                    : user.role === "readonly"
                    ? "bg-orion-muted/20 text-orion-muted"
                    : "bg-orion-green/15 text-orion-green"
                }`}>{user.role}</span>
              </div>
              <p className="text-orion-muted text-[10px] truncate">{user.email}</p>
            </div>
          </div>
        ) : (
          <p className="text-orion-muted text-[10px] text-center">32 agents actifs</p>
        )}
      </div>
    </aside>
  );
}
