import React, { useEffect, useState } from "react";
import { Wifi, WifiOff, RefreshCw } from "lucide-react";
import { api } from "@/api/client";
import { useOrionStore } from "@/store/useOrionStore";
import { NotificationCenter } from "@/components/ui/NotificationCenter";
import { useRateLimitStore } from "@/store/useRateLimitStore";

export function Header({ title, children }: { title: string; children?: React.ReactNode }) {
  const { health, setHealth } = useOrionStore();
  const [checking, setChecking] = useState(false);
  const { used, remaining, limit } = useRateLimitStore();
  const pct = limit > 0 ? (used / limit) * 100 : 0;
  const barColor = pct < 60 ? "bg-orion-green" : pct < 85 ? "bg-yellow-400" : "bg-orion-red";

  async function check() {
    setChecking(true);
    try {
      const h = await api.getHealth();
      setHealth(h);
    } catch {
      // offline
    } finally {
      setChecking(false);
    }
  }

  useEffect(() => { check(); }, []);

  return (
    <header className="h-14 shrink-0 px-3 sm:px-6 flex items-center justify-between gap-2 border-b border-orion-border bg-orion-surface/80 backdrop-blur sticky top-0 z-10">
      <h1 className="text-white font-semibold text-base">{title}</h1>
      <div className="flex items-center gap-3">
        {health ? (
          <div className="hidden sm:flex items-center gap-1.5 text-xs">
            {health.ollama ? (
              <span className="flex items-center gap-1 text-orion-green">
                <Wifi size={13} /> Ollama OK
              </span>
            ) : (
              <span className="flex items-center gap-1 text-orion-red">
                <WifiOff size={13} /> Ollama hors ligne
              </span>
            )}
            <span className="text-orion-border">|</span>
            <span className="text-orion-muted">{health.agents_count} agents</span>
          </div>
        ) : null}
        {children}
        {limit > 0 && (
          <div title={`${remaining}/${limit} requêtes restantes`} className="hidden md:flex items-center gap-1.5 group cursor-default">
            <div className="w-16 h-1.5 bg-orion-border rounded-full overflow-hidden">
              <div className={`h-full rounded-full transition-all duration-500 ${barColor}`} style={{ width: `${pct}%` }} />
            </div>
            <span className="text-[10px] text-orion-muted group-hover:text-white transition-colors">
              {remaining}<span className="opacity-50">/{limit}</span>
            </span>
          </div>
        )}
        <NotificationCenter />
        <button
          onClick={check}
          className="p-1.5 rounded-md hover:bg-white/5 text-orion-muted hover:text-white transition-colors"
          aria-label="Rafraîchir"
        >
          <RefreshCw size={14} className={checking ? "animate-spin" : ""} />
        </button>
      </div>
    </header>
  );
}
