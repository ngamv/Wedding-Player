import { Routes, Route, Navigate } from "react-router-dom";
import { useState, useEffect, useCallback, useRef } from "react";
import { WifiOff } from "lucide-react";
import { Sidebar } from "@/components/layout/Sidebar";
import { ShortcutsModal } from "@/components/ui/ShortcutsModal";
import { useOnlineStatus } from "@/hooks/useOnlineStatus";
import { CommandPalette } from "@/components/ui/CommandPalette";
import { Dashboard } from "@/pages/Dashboard";
import { Agents } from "@/pages/Agents";
import { Chat } from "@/pages/Chat";
import { Tasks } from "@/pages/Tasks";
import { Monitor } from "@/pages/Monitor";
import { Settings } from "@/pages/Settings";
import { CustomAgents } from "@/pages/CustomAgents";
import { Workflows } from "@/pages/Workflows";
import { ApiKeys } from "@/pages/ApiKeys";
import { Admin } from "@/pages/Admin";
import { Analytics } from "@/pages/Analytics";
import { Quickstart } from "@/pages/Quickstart";
import { Profile } from "@/pages/Profile";
import { Scheduled } from "@/pages/Scheduled";
import { Teams } from "@/pages/Teams";
import { Marketplace } from "@/pages/Marketplace";
import { TaskLogs } from "@/pages/TaskLogs";
import { AuditLog } from "@/pages/AuditLog";
import { Playground } from "@/pages/Playground";
import { TokenUsage } from "@/pages/TokenUsage";
import { Compare } from "@/pages/Compare";
import { Presentation } from "@/pages/Presentation";
import { PeriodStats } from "@/pages/PeriodStats";
import { OllamaModels } from "@/pages/OllamaModels";
import { Vault } from "@/pages/Vault";
import { Triggers } from "@/pages/Triggers";
import { Skills } from "@/pages/Skills";
import Status from "@/pages/Status";
import { Login } from "@/pages/Login";
import { ToastContainer } from "@/components/ui/Toast";
import { RequireAuth } from "@/components/auth/RequireAuth";
import { useThemeStore, applyTheme, applyAccent } from "@/store/useThemeStore";
import { useAuthStore } from "@/store/useAuthStore";
import { toast } from "@/components/ui/Toast";

function AppLayout() {
  const [palette, setPalette] = useState(false);
  const [shortcuts, setShortcuts] = useState(false);
  const { theme, accent, accentLight } = useThemeStore();
  const { token, user } = useAuthStore();
  const online = useOnlineStatus();
  const wsRef = useRef<WebSocket | null>(null);

  useEffect(() => { applyTheme(theme); }, [theme]);
  useEffect(() => { applyAccent(accent, accentLight); }, [accent, accentLight]);

  // Teammate task notifications
  useEffect(() => {
    if (!token) return;
    const proto = window.location.protocol === "https:" ? "wss" : "ws";
    const ws = new WebSocket(`${proto}://${window.location.host}/api/ws/events?token=${token}`);
    wsRef.current = ws;
    ws.onmessage = (e) => {
      try {
        const { event, data } = JSON.parse(e.data);
        if (event === "task.completed" && data.user_id && data.user_id !== user?.id) {
          toast.info(`✓ ${data.title ?? "Tâche"} terminée par un coéquipier`);
        }
        if (event === "user.joined" && data.user_id !== user?.id) {
          toast.info(`👤 ${data.username} est en ligne`);
        }
      } catch { /* ignore */ }
    };
    return () => { ws.close(); };
  }, [token, user?.id]);

  const onKey = useCallback((e: KeyboardEvent) => {
    if ((e.ctrlKey || e.metaKey) && e.key === "k") {
      e.preventDefault();
      setPalette((v) => !v);
      return;
    }
    const tag = (e.target as HTMLElement).tagName;
    if (e.key === "?" && tag !== "INPUT" && tag !== "TEXTAREA") {
      setShortcuts((v) => !v);
    }
  }, []);

  useEffect(() => {
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onKey]);

  return (
    <div className="flex flex-col h-screen overflow-hidden bg-orion-bg text-white">
      {!online && (
        <div className="flex items-center justify-center gap-2 px-4 py-2 bg-orion-red/90 text-white text-xs font-medium z-50">
          <WifiOff size={13} /> Connexion perdue — les requêtes API sont suspendues jusqu'au retour en ligne
        </div>
      )}
      <div className="flex flex-1 overflow-hidden">
      <Sidebar />
      {palette && <CommandPalette onClose={() => setPalette(false)} />}

      {shortcuts && <ShortcutsModal onClose={() => setShortcuts(false)} />}
      <div className="flex-1 flex flex-col overflow-hidden min-w-0">
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/agents" element={<Agents />} />
          <Route path="/chat" element={<Chat />} />
          <Route path="/tasks" element={<Tasks />} />
          <Route path="/monitor" element={<Monitor />} />
          <Route path="/custom-agents" element={<CustomAgents />} />
          <Route path="/workflows" element={<Workflows />} />
          <Route path="/api-keys" element={<ApiKeys />} />
          <Route path="/settings" element={<Settings />} />
          <Route path="/admin" element={<Admin />} />
          <Route path="/analytics" element={<Analytics />} />
          <Route path="/quickstart" element={<Quickstart />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/scheduled" element={<Scheduled />} />
          <Route path="/teams" element={<Teams />} />
          <Route path="/marketplace" element={<Marketplace />} />
          <Route path="/tasks/:taskId/logs" element={<TaskLogs />} />
          <Route path="/playground" element={<Playground />} />
          <Route path="/vault" element={<Vault />} />
          <Route path="/triggers" element={<Triggers />} />
          <Route path="/admin/audit" element={<AuditLog />} />
          <Route path="/tokens" element={<TokenUsage />} />
          <Route path="/compare" element={<Compare />} />
          <Route path="/presentation" element={<Presentation />} />
          <Route path="/period-stats" element={<PeriodStats />} />
          <Route path="/ollama-models" element={<OllamaModels />} />
          <Route path="/skills" element={<Skills />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </div>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/status" element={<Status />} />
        <Route
          path="/*"
          element={
            <RequireAuth>
              <AppLayout />
            </RequireAuth>
          }
        />
      </Routes>
      <ToastContainer />
    </>
  );
}
