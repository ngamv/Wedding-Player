import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Eye, EyeOff, Loader2 } from "lucide-react";
import { authApi } from "@/api/auth";
import { useAuthStore } from "@/store/useAuthStore";
import { toast } from "@/components/ui/Toast";

type Mode = "login" | "register";

export function Login() {
  const navigate = useNavigate();
  const setAuth = useAuthStore((s) => s.setAuth);
  const [mode, setMode] = useState<Mode>("login");
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const data =
        mode === "login"
          ? await authApi.login(username, password)
          : await authApi.register(username, email, password);
      setAuth(data.access_token, data.user);
      toast.success(mode === "login" ? "Connexion réussie" : "Compte créé avec succès");
      navigate("/");
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Erreur inconnue";
      setError(msg);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-orion-bg flex items-center justify-center p-4">
      <div className="w-full max-w-sm">
        {/* Logo */}
        <div className="flex flex-col items-center mb-8">
          <div className="w-14 h-14 rounded-2xl bg-orion-accent/15 border border-orion-accent/30 flex items-center justify-center mb-4">
            <span className="text-3xl font-bold text-orion-accent">O</span>
          </div>
          <h1 className="text-white text-2xl font-bold">ORION AI</h1>
          <p className="text-orion-muted text-sm mt-1">Multi-Agent Platform v1.0</p>
        </div>

        {/* Card */}
        <div className="orion-card p-6">
          {/* Tab switcher */}
          <div className="flex rounded-lg bg-orion-bg p-1 mb-6">
            {(["login", "register"] as Mode[]).map((m) => (
              <button
                key={m}
                onClick={() => { setMode(m); setError(""); }}
                className={`flex-1 py-2 text-sm rounded-md transition-colors font-medium ${
                  mode === m
                    ? "bg-orion-card text-white shadow-sm"
                    : "text-orion-muted hover:text-white"
                }`}
              >
                {m === "login" ? "Connexion" : "Inscription"}
              </button>
            ))}
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs text-orion-muted mb-1.5">Nom d'utilisateur</label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
                autoComplete="username"
                placeholder="orion_user"
                className="w-full bg-orion-bg border border-orion-border rounded-lg px-3 py-2.5 text-sm text-white placeholder-orion-muted/50 focus:outline-none focus:border-orion-accent/50 transition-colors"
              />
            </div>

            {mode === "register" && (
              <div>
                <label className="block text-xs text-orion-muted mb-1.5">Email</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  placeholder="vous@exemple.com"
                  className="w-full bg-orion-bg border border-orion-border rounded-lg px-3 py-2.5 text-sm text-white placeholder-orion-muted/50 focus:outline-none focus:border-orion-accent/50 transition-colors"
                />
              </div>
            )}

            <div>
              <label className="block text-xs text-orion-muted mb-1.5">Mot de passe</label>
              <div className="relative">
                <input
                  type={showPass ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  autoComplete={mode === "login" ? "current-password" : "new-password"}
                  placeholder={mode === "register" ? "6 caractères minimum" : "••••••••"}
                  className="w-full bg-orion-bg border border-orion-border rounded-lg px-3 py-2.5 pr-10 text-sm text-white placeholder-orion-muted/50 focus:outline-none focus:border-orion-accent/50 transition-colors"
                />
                <button
                  type="button"
                  onClick={() => setShowPass((v) => !v)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-orion-muted hover:text-white transition-colors"
                >
                  {showPass ? <EyeOff size={14} /> : <Eye size={14} />}
                </button>
              </div>
            </div>

            {error && (
              <p className="text-orion-red text-xs bg-orion-red/10 border border-orion-red/20 rounded-lg px-3 py-2">
                {error}
              </p>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-orion-accent hover:bg-orion-accent/80 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-lg py-2.5 text-sm font-medium transition-colors flex items-center justify-center gap-2"
            >
              {loading && <Loader2 size={14} className="animate-spin" />}
              {mode === "login" ? "Se connecter" : "Créer un compte"}
            </button>
          </form>
        </div>

        <p className="text-center text-orion-muted text-xs mt-6">
          ORION AI — Plateforme d'orchestration multi-agents
        </p>
      </div>
    </div>
  );
}
