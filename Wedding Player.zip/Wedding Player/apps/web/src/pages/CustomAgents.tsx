import { useState, useEffect, useCallback } from "react";
import { Plus, Pencil, Trash2, Play, X, Loader2, Bot, ChevronDown, ChevronUp, FlaskConical, Send } from "lucide-react";
import { customAgentsApi, type CustomAgent, type CustomAgentBody } from "@/api/customAgents";
import { Header } from "@/components/layout/Header";
import { toast } from "@/components/ui/Toast";

const CATEGORIES = ["core", "seo", "social", "marketing", "dev", "data"];
const CATEGORY_COLORS: Record<string, string> = {
  core: "#6366f1", seo: "#10b981", social: "#f59e0b",
  marketing: "#ec4899", dev: "#3b82f6", data: "#8b5cf6",
};

const EMPTY: CustomAgentBody = {
  name: "", description: "", category: "core", system_prompt: "", model: "", rate_limit: null,
};

interface FormProps {
  initial?: CustomAgentBody & { agent_id?: string };
  onSave: (body: CustomAgentBody) => Promise<void>;
  onCancel: () => void;
}

function AgentForm({ initial, onSave, onCancel }: FormProps) {
  const [form, setForm] = useState<CustomAgentBody>(initial ?? EMPTY);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  // Sandbox state
  const [sandboxOpen, setSandboxOpen] = useState(false);
  const [sandboxInput, setSandboxInput] = useState("");
  const [sandboxResult, setSandboxResult] = useState<string | null>(null);
  const [sandboxRunning, setSandboxRunning] = useState(false);

  async function runSandbox() {
    if (!sandboxInput.trim() || !form.system_prompt.trim()) return;
    setSandboxRunning(true);
    setSandboxResult(null);
    try {
      const token = (() => { try { const s = localStorage.getItem("orion-auth"); return s ? JSON.parse(s)?.state?.token : null; } catch { return null; } })();
      const res = await fetch("/api/custom-agents/sandbox", {
        method: "POST",
        headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
        body: JSON.stringify({ system_prompt: form.system_prompt, message: sandboxInput, model: form.model || undefined }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.detail ?? `HTTP ${res.status}`);
      setSandboxResult(data.response);
    } catch (e) {
      setSandboxResult(`Erreur : ${e instanceof Error ? e.message : "inconnue"}`);
    } finally {
      setSandboxRunning(false);
    }
  }

  function set(field: keyof CustomAgentBody, value: string) {
    setForm((f) => ({ ...f, [field]: value }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setSaving(true);
    try {
      await onSave({ ...form, model: form.model || undefined });
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Erreur inconnue");
    } finally {
      setSaving(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className="block text-xs text-orion-muted mb-1.5">Nom de l'agent *</label>
          <input
            value={form.name}
            onChange={(e) => set("name", e.target.value)}
            required
            placeholder="Mon Agent SEO"
            className="w-full bg-orion-bg border border-orion-border rounded-lg px-3 py-2.5 text-sm text-white placeholder-orion-muted/50 focus:outline-none focus:border-orion-accent/50 transition-colors"
          />
        </div>
        <div>
          <label className="block text-xs text-orion-muted mb-1.5">Catégorie *</label>
          <select
            value={form.category}
            onChange={(e) => set("category", e.target.value)}
            className="w-full bg-orion-bg border border-orion-border rounded-lg px-3 py-2.5 text-sm text-white focus:outline-none focus:border-orion-accent/50 transition-colors"
          >
            {CATEGORIES.map((c) => (
              <option key={c} value={c}>{c.charAt(0).toUpperCase() + c.slice(1)}</option>
            ))}
          </select>
        </div>
      </div>

      <div>
        <label className="block text-xs text-orion-muted mb-1.5">Description *</label>
        <input
          value={form.description}
          onChange={(e) => set("description", e.target.value)}
          required
          placeholder="Décrivez ce que fait cet agent"
          className="w-full bg-orion-bg border border-orion-border rounded-lg px-3 py-2.5 text-sm text-white placeholder-orion-muted/50 focus:outline-none focus:border-orion-accent/50 transition-colors"
        />
      </div>

      <div>
        <label className="block text-xs text-orion-muted mb-1.5">
          Prompt système * <span className="text-orion-muted/60">(Instructions données à l'IA)</span>
        </label>
        <textarea
          value={form.system_prompt}
          onChange={(e) => set("system_prompt", e.target.value)}
          required
          rows={5}
          placeholder="Tu es un expert en... Tu dois... Réponds toujours en..."
          className="w-full bg-orion-bg border border-orion-border rounded-lg px-3 py-2.5 text-sm text-white placeholder-orion-muted/50 focus:outline-none focus:border-orion-accent/50 transition-colors resize-none"
        />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className="block text-xs text-orion-muted mb-1.5">
            Modèle Ollama <span className="text-orion-muted/60">(optionnel)</span>
          </label>
          <input
            value={form.model ?? ""}
            onChange={(e) => set("model", e.target.value)}
            placeholder="qwen3:8b, llama3.2, mistral..."
            className="w-full bg-orion-bg border border-orion-border rounded-lg px-3 py-2.5 text-sm text-white placeholder-orion-muted/50 focus:outline-none focus:border-orion-accent/50 transition-colors"
          />
        </div>
        <div>
          <label className="block text-xs text-orion-muted mb-1.5">
            Rate limit <span className="text-orion-muted/60">(tâches/heure, vide = illimité)</span>
          </label>
          <input
            type="number"
            min={1}
            value={form.rate_limit ?? ""}
            onChange={(e) => setForm((f) => ({ ...f, rate_limit: e.target.value ? Number(e.target.value) : null }))}
            placeholder="ex: 10"
            className="w-full bg-orion-bg border border-orion-border rounded-lg px-3 py-2.5 text-sm text-white placeholder-orion-muted/50 focus:outline-none focus:border-orion-accent/50 transition-colors"
          />
        </div>
      </div>

      {/* Sandbox */}
      <div className="border border-orion-border/60 rounded-xl overflow-hidden">
        <button
          type="button"
          onClick={() => setSandboxOpen((v) => !v)}
          className="w-full flex items-center justify-between px-4 py-3 hover:bg-white/3 transition-colors"
        >
          <span className="flex items-center gap-2 text-sm text-orion-muted">
            <FlaskConical size={13} className="text-orion-accent-light" />
            Tester le prompt (sandbox)
          </span>
          {sandboxOpen ? <ChevronUp size={13} className="text-orion-muted" /> : <ChevronDown size={13} className="text-orion-muted" />}
        </button>
        {sandboxOpen && (
          <div className="border-t border-orion-border/60 px-4 py-3 space-y-3 bg-orion-bg/50">
            <p className="text-[10px] text-orion-muted/60">Le prompt système actuel est utilisé sans sauvegarder l'agent.</p>
            <div className="flex gap-2">
              <input
                value={sandboxInput}
                onChange={(e) => setSandboxInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && runSandbox()}
                placeholder="Entrez un message de test…"
                className="flex-1 px-3 py-2 bg-orion-bg border border-orion-border rounded-lg text-sm text-white placeholder-orion-muted/50 focus:outline-none focus:border-orion-accent/50"
              />
              <button
                type="button"
                onClick={runSandbox}
                disabled={sandboxRunning || !sandboxInput.trim() || !form.system_prompt.trim()}
                className="flex items-center gap-1.5 px-3 py-2 bg-orion-accent/20 hover:bg-orion-accent/30 disabled:opacity-40 text-orion-accent-light rounded-lg text-xs transition-colors"
              >
                {sandboxRunning ? <Loader2 size={12} className="animate-spin" /> : <Send size={12} />}
                Tester
              </button>
            </div>
            {sandboxResult !== null && (
              <div className={`rounded-lg px-3 py-2.5 text-xs font-mono whitespace-pre-wrap leading-relaxed ${
                sandboxResult.startsWith("Erreur")
                  ? "bg-orion-red/10 text-orion-red border border-orion-red/20"
                  : "bg-orion-surface border border-orion-border/50 text-white"
              }`}>
                {sandboxResult}
              </div>
            )}
          </div>
        )}
      </div>

      {error && (
        <p className="text-orion-red text-xs bg-orion-red/10 border border-orion-red/20 rounded-lg px-3 py-2">{error}</p>
      )}

      <div className="flex gap-3 justify-end pt-2">
        <button type="button" onClick={onCancel} className="px-4 py-2 text-sm text-orion-muted hover:text-white border border-orion-border rounded-lg hover:bg-white/5 transition-colors">
          Annuler
        </button>
        <button
          type="submit"
          disabled={saving}
          className="flex items-center gap-2 px-4 py-2 text-sm bg-orion-accent hover:bg-orion-accent/80 disabled:opacity-50 text-white rounded-lg transition-colors font-medium"
        >
          {saving && <Loader2 size={13} className="animate-spin" />}
          {initial?.agent_id ? "Enregistrer" : "Créer l'agent"}
        </button>
      </div>
    </form>
  );
}

interface RunPanelProps {
  agent: CustomAgent;
  onClose: () => void;
}

function RunPanel({ agent, onClose }: RunPanelProps) {
  const [task, setTask] = useState("");
  const [result, setResult] = useState("");
  const [running, setRunning] = useState(false);

  async function handleRun() {
    if (!task.trim() || running) return;
    setRunning(true);
    setResult("");
    try {
      const r = await customAgentsApi.run(agent.agent_id, task);
      setResult(r.result);
      toast.success("Tâche exécutée avec succès");
    } catch (err: unknown) {
      setResult(err instanceof Error ? err.message : "Erreur");
      toast.error("Erreur lors de l'exécution");
    } finally {
      setRunning(false);
    }
  }

  return (
    <div className="orion-card p-5 border-orion-accent/30">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-white text-sm font-medium flex items-center gap-2">
          <Play size={14} className="text-orion-accent" />
          Tester — {agent.name}
        </h3>
        <button onClick={onClose} className="text-orion-muted hover:text-white transition-colors">
          <X size={14} />
        </button>
      </div>
      <textarea
        value={task}
        onChange={(e) => setTask(e.target.value)}
        placeholder="Entrez une tâche à confier à cet agent..."
        rows={3}
        className="w-full bg-orion-bg border border-orion-border rounded-lg px-3 py-2.5 text-sm text-white placeholder-orion-muted/50 focus:outline-none focus:border-orion-accent/50 transition-colors resize-none mb-3"
      />
      <button
        onClick={handleRun}
        disabled={!task.trim() || running}
        className="flex items-center gap-2 px-4 py-2 text-sm bg-orion-accent hover:bg-orion-accent/80 disabled:opacity-50 text-white rounded-lg transition-colors"
      >
        {running ? <Loader2 size={13} className="animate-spin" /> : <Play size={13} />}
        {running ? "En cours…" : "Exécuter"}
      </button>
      {result && (
        <div className="mt-4 bg-orion-bg border border-orion-border rounded-lg p-3 text-sm text-slate-200 whitespace-pre-wrap leading-relaxed max-h-64 overflow-y-auto">
          {result}
        </div>
      )}
    </div>
  );
}

export function CustomAgents() {
  const [agents, setAgents] = useState<CustomAgent[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<CustomAgent | null>(null);
  const [runningAgent, setRunningAgent] = useState<CustomAgent | null>(null);
  const [expandedPrompt, setExpandedPrompt] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const data = await customAgentsApi.list();
      setAgents(data);
    } catch {
      toast.error("Impossible de charger les agents personnalisés");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  async function handleCreate(body: CustomAgentBody) {
    await customAgentsApi.create(body);
    toast.success("Agent créé avec succès");
    setShowForm(false);
    load();
  }

  async function handleUpdate(body: CustomAgentBody) {
    if (!editing) return;
    await customAgentsApi.update(editing.agent_id, body);
    toast.success("Agent mis à jour");
    setEditing(null);
    load();
  }

  async function handleDelete(agent: CustomAgent) {
    if (!confirm(`Supprimer l'agent "${agent.name}" ?`)) return;
    await customAgentsApi.delete(agent.agent_id);
    toast.success("Agent supprimé");
    load();
  }

  return (
    <div className="flex-1 flex flex-col">
      <Header title="Agents personnalisés" />
      <main className="flex-1 p-6 overflow-auto space-y-6">

        {/* Header action */}
        <div className="flex items-center justify-between">
          <p className="text-orion-muted text-sm">
            {agents.length} agent{agents.length !== 1 ? "s" : ""} personnalisé{agents.length !== 1 ? "s" : ""}
          </p>
          {!showForm && !editing && (
            <button
              onClick={() => setShowForm(true)}
              className="flex items-center gap-2 px-4 py-2 bg-orion-accent hover:bg-orion-accent/80 text-white text-sm rounded-lg transition-colors font-medium"
            >
              <Plus size={14} />
              Nouvel agent
            </button>
          )}
        </div>

        {/* Create form */}
        {showForm && !editing && (
          <div className="orion-card p-5 border-orion-accent/20">
            <h3 className="text-white text-sm font-medium mb-5 flex items-center gap-2">
              <Plus size={14} className="text-orion-accent" />
              Créer un agent personnalisé
            </h3>
            <AgentForm onSave={handleCreate} onCancel={() => setShowForm(false)} />
          </div>
        )}

        {/* Agents list */}
        {loading ? (
          <div className="flex items-center justify-center py-16">
            <Loader2 size={24} className="animate-spin text-orion-accent" />
          </div>
        ) : agents.length === 0 && !showForm ? (
          <div className="orion-card p-10 flex flex-col items-center text-center">
            <div className="w-14 h-14 rounded-2xl bg-orion-accent/10 border border-orion-accent/20 flex items-center justify-center mb-4">
              <Bot size={24} className="text-orion-accent" />
            </div>
            <p className="text-white font-medium mb-1">Aucun agent personnalisé</p>
            <p className="text-orion-muted text-sm mb-4">Créez votre premier agent IA avec un prompt personnalisé</p>
            <button
              onClick={() => setShowForm(true)}
              className="flex items-center gap-2 px-4 py-2 bg-orion-accent hover:bg-orion-accent/80 text-white text-sm rounded-lg transition-colors"
            >
              <Plus size={14} /> Créer un agent
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            {agents.map((agent) => (
              <div key={agent.id} className="orion-card p-5 animate-slide-in">
                {editing?.id === agent.id ? (
                  <>
                    <h3 className="text-white text-sm font-medium mb-5 flex items-center gap-2">
                      <Pencil size={14} className="text-orion-gold" />
                      Modifier — {agent.name}
                    </h3>
                    <AgentForm
                      initial={{ ...agent, model: agent.model ?? "" }}
                      onSave={handleUpdate}
                      onCancel={() => setEditing(null)}
                    />
                  </>
                ) : (
                  <>
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex items-start gap-3 min-w-0">
                        <span
                          className="mt-0.5 w-2.5 h-2.5 rounded-full flex-shrink-0"
                          style={{ background: CATEGORY_COLORS[agent.category] ?? "#6366f1" }}
                        />
                        <div className="min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <p className="text-white font-medium text-sm">{agent.name}</p>
                            <span
                              className="text-[10px] px-2 py-0.5 rounded-full capitalize"
                              style={{ background: `${CATEGORY_COLORS[agent.category] ?? "#6366f1"}20`, color: CATEGORY_COLORS[agent.category] ?? "#6366f1" }}
                            >
                              {agent.category}
                            </span>
                            {agent.model && (
                              <span className="text-[10px] px-2 py-0.5 rounded-full bg-orion-border text-orion-muted">
                                {agent.model}
                              </span>
                            )}
                            {agent.rate_limit && (
                              <span className="text-[10px] px-2 py-0.5 rounded-full bg-orion-gold/10 text-orion-gold">
                                ≤{agent.rate_limit}/h
                              </span>
                            )}
                          </div>
                          <p className="text-orion-muted text-xs mt-0.5">{agent.description}</p>
                          <p className="text-orion-muted/50 text-[10px] mt-1 font-mono">ID: {agent.agent_id}</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-1 flex-shrink-0">
                        <button
                          onClick={() => setRunningAgent(runningAgent?.id === agent.id ? null : agent)}
                          className="p-2 rounded-lg hover:bg-orion-accent/10 text-orion-muted hover:text-orion-accent transition-colors"
                          title="Tester"
                        >
                          <Play size={14} />
                        </button>
                        <button
                          onClick={() => { setEditing(agent); setRunningAgent(null); setShowForm(false); }}
                          className="p-2 rounded-lg hover:bg-orion-gold/10 text-orion-muted hover:text-orion-gold transition-colors"
                          title="Modifier"
                        >
                          <Pencil size={14} />
                        </button>
                        <button
                          onClick={() => handleDelete(agent)}
                          className="p-2 rounded-lg hover:bg-orion-red/10 text-orion-muted hover:text-orion-red transition-colors"
                          title="Supprimer"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </div>

                    {/* System prompt preview */}
                    <div className="mt-3 ml-5">
                      <button
                        onClick={() => setExpandedPrompt(expandedPrompt === agent.agent_id ? null : agent.agent_id)}
                        className="flex items-center gap-1 text-[11px] text-orion-muted hover:text-white transition-colors"
                      >
                        {expandedPrompt === agent.agent_id ? <ChevronUp size={11} /> : <ChevronDown size={11} />}
                        Voir le prompt système
                      </button>
                      {expandedPrompt === agent.agent_id && (
                        <div className="mt-2 bg-orion-bg border border-orion-border rounded-lg px-3 py-2.5 text-xs text-orion-muted whitespace-pre-wrap leading-relaxed max-h-32 overflow-y-auto">
                          {agent.system_prompt}
                        </div>
                      )}
                    </div>

                    {/* Run panel */}
                    {runningAgent?.id === agent.id && (
                      <div className="mt-4">
                        <RunPanel agent={agent} onClose={() => setRunningAgent(null)} />
                      </div>
                    )}
                  </>
                )}
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
