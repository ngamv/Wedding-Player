import { useState, useEffect } from "react";
import { Zap, TrendingUp, Bot, Loader2 } from "lucide-react";
import { Header } from "@/components/layout/Header";
import { api } from "@/api/client";

interface AgentTokenRow {
  agent_id: string;
  tokens_in: number;
  tokens_out: number;
  runs: number;
}

interface TokenStats {
  total_in: number;
  total_out: number;
  total: number;
  by_agent: AgentTokenRow[];
}

function fmt(n: number): string {
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(1) + "M";
  if (n >= 1_000) return (n / 1_000).toFixed(1) + "k";
  return String(n);
}

export function TokenUsage() {
  const [stats, setStats] = useState<TokenStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get<TokenStats>("/system/token-usage")
      .then(setStats)
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const maxTotal = stats?.by_agent.reduce((m, r) => Math.max(m, r.tokens_in + r.tokens_out), 1) ?? 1;

  return (
    <div className="flex-1 flex flex-col">
      <Header title="Suivi des tokens LLM" />
      <main className="flex-1 p-6 overflow-auto">
        {loading ? (
          <div className="flex justify-center py-20"><Loader2 size={24} className="animate-spin text-orion-accent" /></div>
        ) : !stats || stats.total === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-orion-muted gap-3">
            <Zap size={32} className="opacity-20" />
            <p className="text-sm">Aucune donnée — lancez des tâches pour voir les stats de tokens.</p>
          </div>
        ) : (
          <div className="max-w-3xl space-y-6">
            {/* Summary cards */}
            <div className="grid grid-cols-3 gap-4">
              {[
                { label: "Total tokens", value: fmt(stats.total), icon: Zap, color: "text-orion-accent-light" },
                { label: "Tokens entrée", value: fmt(stats.total_in), icon: TrendingUp, color: "text-orion-green" },
                { label: "Tokens sortie", value: fmt(stats.total_out), icon: Bot, color: "text-violet-400" },
              ].map(({ label, value, icon: Icon, color }) => (
                <div key={label} className="orion-card p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Icon size={14} className={color} />
                    <span className="text-orion-muted text-xs uppercase tracking-wider">{label}</span>
                  </div>
                  <p className={`text-2xl font-bold font-mono ${color}`}>{value}</p>
                </div>
              ))}
            </div>

            {/* Per-agent breakdown */}
            <div className="orion-card p-5">
              <h3 className="text-white text-sm font-medium mb-4">Par agent</h3>
              <div className="space-y-3">
                {stats.by_agent.map((row) => {
                  const total = row.tokens_in + row.tokens_out;
                  const pct = Math.round((total / maxTotal) * 100);
                  return (
                    <div key={row.agent_id}>
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-white text-sm font-mono truncate max-w-xs">{row.agent_id}</span>
                        <div className="flex items-center gap-3 text-xs text-orion-muted flex-shrink-0 ml-3">
                          <span className="text-orion-green">↑{fmt(row.tokens_in)}</span>
                          <span className="text-violet-400">↓{fmt(row.tokens_out)}</span>
                          <span>{fmt(total)} total</span>
                          <span className="text-orion-border">×{row.runs}</span>
                        </div>
                      </div>
                      <div className="h-1.5 bg-orion-bg rounded-full overflow-hidden">
                        <div
                          className="h-full rounded-full bg-orion-accent/60"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <p className="text-orion-muted/50 text-xs text-center">
              Estimations basées sur le comptage de mots × 1,33 — les valeurs exactes dépendent du fournisseur LLM.
            </p>
          </div>
        )}
      </main>
    </div>
  );
}
