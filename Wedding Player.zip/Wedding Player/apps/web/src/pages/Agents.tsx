import { useEffect, useState } from "react";
import { Search } from "lucide-react";
import { api } from "@/api/client";
import { useOrionStore } from "@/store/useOrionStore";
import { Header } from "@/components/layout/Header";
import { toast } from "@/components/ui/Toast";

const CATEGORY_COLORS: Record<string, string> = {
  core: "#6366f1", seo: "#10b981", social: "#f59e0b",
  marketing: "#ec4899", dev: "#3b82f6", data: "#8b5cf6",
};

const CATEGORIES = ["all", "core", "seo", "social", "marketing", "dev", "data"];

export function Agents() {
  const { agents, setAgents } = useOrionStore();
  const [filter, setFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [running, setRunning] = useState<string | null>(null);
  const [results, setResults] = useState<Record<string, string>>({});
  const [task, setTask] = useState("");

  useEffect(() => { api.getAgents().then(setAgents).catch(() => {}); }, []);

  const visible = agents.filter((a) => {
    const matchCat = filter === "all" || a.category === filter;
    const matchSearch = !search || a.name.toLowerCase().includes(search.toLowerCase()) || a.description.toLowerCase().includes(search.toLowerCase());
    return matchCat && matchSearch;
  });

  async function runAgent(id: string) {
    if (!task.trim()) return;
    setRunning(id);
    try {
      const r = await api.runAgent(task, id);
      setResults((prev) => ({ ...prev, [id]: r.result }));
      toast.success(`Agent ${id} a terminé la tâche`);
    } catch {
      setResults((prev) => ({ ...prev, [id]: "Erreur — API hors ligne." }));
      toast.error("Erreur de connexion à l'API");
    } finally {
      setRunning(null);
    }
  }

  return (
    <div className="flex-1 flex flex-col">
      <Header title="Agents IA" />
      <main className="flex-1 p-6">
        {/* Controls */}
        <div className="flex flex-col sm:flex-row gap-3 mb-6">
          <div className="relative flex-1 max-w-xs">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-orion-muted" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Rechercher un agent…"
              className="w-full pl-9 pr-3 py-2 bg-orion-card border border-orion-border rounded-lg text-sm text-white placeholder-orion-muted focus:outline-none focus:border-orion-accent/50"
            />
          </div>
          <div className="flex gap-1.5 flex-wrap">
            {CATEGORIES.map((cat) => (
              <button
                key={cat}
                onClick={() => setFilter(cat)}
                className={`px-3 py-1.5 rounded-lg text-xs capitalize transition-colors ${
                  filter === cat
                    ? "text-white font-medium"
                    : "text-orion-muted hover:text-white hover:bg-white/5"
                }`}
                style={filter === cat ? { background: CATEGORY_COLORS[cat] || "#6366f1" } : {}}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Task input */}
        <div className="mb-6 flex gap-2">
          <input
            value={task}
            onChange={(e) => setTask(e.target.value)}
            placeholder="Décrivez une tâche à exécuter…"
            className="flex-1 px-4 py-2.5 bg-orion-card border border-orion-border rounded-lg text-sm text-white placeholder-orion-muted focus:outline-none focus:border-orion-accent/50"
          />
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {visible.map((agent) => (
            <div key={agent.id} className="orion-card p-5 flex flex-col gap-3">
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="w-2 h-2 rounded-full flex-shrink-0"
                      style={{ background: CATEGORY_COLORS[agent.category] || "#6366f1" }} />
                    <span className="text-[10px] text-orion-muted uppercase tracking-wider">{agent.category}</span>
                  </div>
                  <h3 className="text-white text-sm font-medium">{agent.name}</h3>
                  <p className="text-orion-muted text-xs mt-1 leading-relaxed">{agent.description}</p>
                </div>
              </div>
              {results[agent.id] && (
                <div className="bg-orion-bg border border-orion-border rounded-lg p-3 text-xs text-slate-300 max-h-28 overflow-y-auto whitespace-pre-wrap">
                  {results[agent.id]}
                </div>
              )}
              <button
                onClick={() => runAgent(agent.id)}
                disabled={!task.trim() || running === agent.id}
                className="w-full py-2 rounded-lg text-xs font-medium transition-colors disabled:opacity-40 disabled:cursor-default"
                style={{ background: `${CATEGORY_COLORS[agent.category]}20`, color: CATEGORY_COLORS[agent.category] || "#6366f1",
                  border: `1px solid ${CATEGORY_COLORS[agent.category]}40` }}
              >
                {running === agent.id ? "En cours…" : "Exécuter"}
              </button>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
