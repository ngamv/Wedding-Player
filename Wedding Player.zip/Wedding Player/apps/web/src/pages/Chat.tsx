import { useState, useRef, useEffect, useCallback } from "react";
import { Send, Trash2, Zap, Plus, MessageSquare } from "lucide-react";
import { chatApi } from "@/api/chat";
import type { ChatSession, ChatMsg } from "@/api/chat";
import { createWsConnection } from "@/api/chat";
import { useOrionStore } from "@/store/useOrionStore";
import { Header } from "@/components/layout/Header";
import { toast } from "@/components/ui/Toast";

const CATEGORY_COLORS: Record<string, string> = {
  core: "#6366f1", seo: "#10b981", social: "#f59e0b",
  marketing: "#ec4899", dev: "#3b82f6", data: "#8b5cf6",
};

export function Chat() {
  const { agents, activeAgent, setActiveAgent } = useOrionStore();
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [activeSessionId, setActiveSessionId] = useState<number | null>(null);
  const [messages, setMessages] = useState<ChatMsg[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [wsStatus, setWsStatus] = useState<"connected" | "offline">("offline");
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Load sessions on mount
  useEffect(() => {
    chatApi.listSessions().then(setSessions).catch(() => {});
  }, []);

  // WebSocket — task events
  useEffect(() => {
    const cleanup = createWsConnection((event, data) => {
      setWsStatus("connected");
      if (event === "task.completed" || event === "task.failed") {
        toast.info(`Tâche ${(data as { title: string }).title} : ${event === "task.completed" ? "terminée" : "échouée"}`);
      }
    });
    // Assume connected if ws module initialises (close sets offline)
    setWsStatus("connected");
    return cleanup;
  }, []);

  const loadMessages = useCallback(async (sessionId: number) => {
    const msgs = await chatApi.getMessages(sessionId);
    setMessages(msgs);
  }, []);

  async function selectSession(sessionId: number) {
    setActiveSessionId(sessionId);
    await loadMessages(sessionId);
  }

  async function newSession() {
    const sess = await chatApi.createSession();
    setSessions((prev) => [sess, ...prev]);
    setActiveSessionId(sess.id);
    setMessages([]);
  }

  async function deleteSession(sessionId: number, e: React.MouseEvent) {
    e.stopPropagation();
    await chatApi.deleteSession(sessionId);
    setSessions((prev) => prev.filter((s) => s.id !== sessionId));
    if (activeSessionId === sessionId) {
      setActiveSessionId(null);
      setMessages([]);
    }
  }

  async function handleSend() {
    const text = input.trim();
    if (!text || loading) return;

    let sessionId = activeSessionId;
    if (!sessionId) {
      const sess = await chatApi.createSession();
      setSessions((prev) => [sess, ...prev]);
      setActiveSessionId(sess.id);
      sessionId = sess.id;
    }

    const optimistic: ChatMsg = {
      id: Date.now(), role: "user", content: text,
      agent_name: null, created_at: new Date().toISOString(),
    };
    setMessages((prev) => [...prev, optimistic]);
    setInput("");
    setLoading(true);

    try {
      const reply = await chatApi.sendMessage(sessionId, text, activeAgent?.id);
      setMessages((prev) => [...prev.filter((m) => m.id !== optimistic.id), optimistic, reply]);
      // Update session title in sidebar
      setSessions((prev) => prev.map((s) =>
        s.id === sessionId ? { ...s, title: text.slice(0, 60) } : s
      ));
    } catch {
      setMessages((prev) => [...prev, {
        id: Date.now(), role: "assistant",
        content: "Erreur de connexion. Vérifiez que le serveur API est démarré.",
        agent_name: null, created_at: new Date().toISOString(),
      }]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="flex-1 flex flex-col h-screen">
      <Header title="Orion Chat">
        <div className="flex items-center gap-2">
          <span className={`text-xs px-2 py-0.5 rounded-full ${wsStatus === "connected" ? "bg-orion-green/15 text-orion-green" : "bg-orion-red/15 text-orion-red"}`}>
            {wsStatus === "connected" ? "WS connecté" : "WS hors ligne"}
          </span>
        </div>
      </Header>

      <div className="flex flex-1 overflow-hidden">
        {/* Sessions list */}
        <aside className="w-52 border-r border-orion-border bg-orion-surface flex flex-col">
          <div className="p-3 border-b border-orion-border">
            <button
              onClick={newSession}
              className="w-full flex items-center gap-2 px-3 py-2 bg-orion-accent/15 hover:bg-orion-accent/25 text-orion-accent-light rounded-lg text-xs transition-colors"
            >
              <Plus size={12} /> Nouvelle conversation
            </button>
          </div>
          <div className="flex-1 overflow-y-auto p-2 space-y-0.5">
            {sessions.map((s) => (
              <button
                key={s.id}
                onClick={() => selectSession(s.id)}
                className={`w-full text-left px-2.5 py-2 rounded-lg text-xs transition-colors group flex items-start gap-2 ${
                  activeSessionId === s.id ? "bg-orion-accent/20 text-orion-accent-light" : "text-orion-muted hover:bg-white/5 hover:text-white"
                }`}
              >
                <MessageSquare size={11} className="mt-0.5 flex-shrink-0" />
                <span className="flex-1 truncate">{s.title}</span>
                <span
                  onClick={(e) => deleteSession(s.id, e)}
                  className="opacity-0 group-hover:opacity-100 text-orion-muted hover:text-orion-red transition-colors text-[10px] leading-none mt-0.5"
                  title="Supprimer"
                >✕</span>
              </button>
            ))}
          </div>

          {/* Agent selector */}
          <div className="border-t border-orion-border p-2">
            <p className="text-orion-muted text-[10px] uppercase tracking-wider mb-2 px-1">Agent</p>
            <button
              onClick={() => setActiveAgent(null)}
              className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs mb-0.5 transition-colors ${
                !activeAgent ? "bg-orion-accent/20 text-orion-accent-light" : "text-orion-muted hover:bg-white/5 hover:text-white"
              }`}
            >
              <Zap size={11} className="inline mr-1" /> Auto-router
            </button>
            {agents.slice(0, 8).map((a) => (
              <button
                key={a.id}
                onClick={() => setActiveAgent(a)}
                className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs mb-0.5 transition-colors ${
                  activeAgent?.id === a.id ? "bg-orion-accent/20 text-orion-accent-light" : "text-orion-muted hover:bg-white/5 hover:text-white"
                }`}
              >
                <span className="w-1.5 h-1.5 rounded-full inline-block mr-1.5 align-middle"
                  style={{ background: CATEGORY_COLORS[a.category] || "#6366f1" }} />
                {a.name}
              </button>
            ))}
          </div>
        </aside>

        {/* Chat area */}
        <div className="flex-1 flex flex-col overflow-hidden">
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {messages.length === 0 && (
              <div className="flex items-center justify-center h-full">
                <div className="text-center">
                  <div className="w-16 h-16 rounded-2xl bg-orion-accent/10 border border-orion-accent/25 flex items-center justify-center mx-auto mb-4">
                    <span className="text-2xl font-bold text-orion-accent">O</span>
                  </div>
                  <p className="text-white font-medium">ORION AI prêt</p>
                  <p className="text-orion-muted text-sm mt-1">
                    {activeSessionId ? "Commencez à écrire…" : "Créez ou sélectionnez une conversation"}
                  </p>
                </div>
              </div>
            )}
            {messages.map((m) => (
              <div key={m.id} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                <div className={`max-w-[75%] flex flex-col gap-1 ${m.role === "user" ? "items-end" : "items-start"}`}>
                  <div className="flex items-center gap-2 px-1">
                    {m.role === "assistant" && m.agent_name && (
                      <p className="text-orion-accent text-[10px] font-medium">{m.agent_name}</p>
                    )}
                    <p className="text-orion-muted text-[10px]">
                      {new Date(m.created_at).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}
                    </p>
                  </div>
                  <div className={`px-4 py-2.5 rounded-2xl text-sm whitespace-pre-wrap leading-relaxed ${
                    m.role === "user"
                      ? "bg-orion-accent text-white rounded-tr-sm"
                      : "bg-orion-card border border-orion-border text-slate-200 rounded-tl-sm"
                  }`}>
                    {m.content}
                  </div>
                </div>
              </div>
            ))}
            {loading && (
              <div className="flex justify-start">
                <div className="bg-orion-card border border-orion-border px-4 py-3 rounded-2xl rounded-tl-sm">
                  <div className="flex gap-1 items-center">
                    {[0, 1, 2].map((j) => (
                      <span key={j} className="w-1.5 h-1.5 rounded-full bg-orion-accent animate-pulse-orion"
                        style={{ animationDelay: `${j * 0.2}s` }} />
                    ))}
                  </div>
                </div>
              </div>
            )}
            <div ref={bottomRef} />
          </div>

          {/* Input */}
          <div className="p-4 border-t border-orion-border">
            <div className="flex items-end gap-2">
              <button
                onClick={() => { setMessages([]); setActiveSessionId(null); }}
                className="p-2.5 rounded-lg hover:bg-white/5 text-orion-muted hover:text-orion-red transition-colors"
                title="Nouvelle conversation"
              >
                <Trash2 size={16} />
              </button>
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); handleSend(); } }}
                placeholder={`Message ${activeAgent ? activeAgent.name : "Orion Auto-router"}…`}
                rows={1}
                className="flex-1 bg-orion-card border border-orion-border rounded-xl px-4 py-2.5 text-sm text-white placeholder-orion-muted resize-none focus:outline-none focus:border-orion-accent/50"
                style={{ maxHeight: 120, overflowY: "auto" }}
              />
              <button
                onClick={handleSend}
                disabled={!input.trim() || loading}
                className="p-2.5 rounded-xl bg-orion-accent hover:bg-orion-accent/80 disabled:opacity-40 text-white transition-colors"
              >
                <Send size={16} />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
