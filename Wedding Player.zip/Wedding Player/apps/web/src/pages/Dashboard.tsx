import { useCallback, useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { Activity, ArrowRight, Bot, Brain, ChartNoAxesCombined, Eye, EyeOff, ListTodo, RefreshCw, Settings2, Tv2, Workflow } from "lucide-react";
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { api } from "@/api/client";
import { Header } from "@/components/layout/Header";
import { usePolling } from "@/hooks/usePolling";
import { useDashboardStore, type WidgetId } from "@/store/useDashboardStore";
import { useOrionStore } from "@/store/useOrionStore";

type Period = "week" | "month";
type Report = {
  period: Period;
  buckets: { label: string; tasks: number; success: number }[];
  total: number;
  success: number;
  failed: number;
};
const widgets: Record<WidgetId, string> = {
  stats: "Indicateurs", activity: "Activité", agents_chart: "Catalogue d’agents",
  recent_tasks: "Tâches récentes", quick_stats: "État des services",
};
const categories: Record<string, string> = {
  core: "Orchestration", seo: "SEO", social: "Réseaux sociaux",
  marketing: "Marketing", dev: "Développement", data: "Données",
};
const statuses: Record<string, { label: string; style: string }> = {
  completed: { label: "Terminée", style: "bg-orion-green/10 text-orion-green" },
  failed: { label: "Échec", style: "bg-orion-red/10 text-orion-red" },
  running: { label: "En cours", style: "bg-orion-accent/15 text-orion-accent-light" },
  pending: { label: "En attente", style: "bg-orion-gold/10 text-orion-gold" },
  cancelled: { label: "Annulée", style: "bg-white/5 text-orion-muted" },
};
const panel = "orion-card min-w-0 p-5 sm:p-6";
const button = "inline-flex min-h-10 items-center justify-center gap-2 rounded-xl border border-orion-border px-3 text-xs font-medium text-white transition-colors hover:bg-white/5 focus-visible:outline focus-visible:outline-2 focus-visible:outline-orion-accent-light disabled:opacity-50";
const quietLink = "inline-flex items-center gap-2 rounded text-xs font-medium text-orion-accent-light hover:text-white focus-visible:outline focus-visible:outline-orion-accent-light";
const format = new Intl.NumberFormat("fr-FR");
const time = new Intl.DateTimeFormat("fr-FR", { hour: "2-digit", minute: "2-digit" });
const timestamp = new Intl.DateTimeFormat("fr-FR", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });

export function Dashboard() {
  const { agents, tasks, stats, health, setAgents, setTasks, setStats, setHealth } = useOrionStore();
  const { hidden, toggle, reset } = useDashboardStore();
  const [period, setPeriod] = useState<Period>("week");
  const [report, setReport] = useState<Report | null>(null);
  const [totalTasks, setTotalTasks] = useState<number | null>(null);
  const [updated, setUpdated] = useState<Date | null>(null);
  const [failed, setFailed] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [editing, setEditing] = useState(false);
  const request = useRef(0);

  const refresh = useCallback(async () => {
    const current = ++request.current;
    setRefreshing(true);
    const [catalog, recent, totals, system, activity] = await Promise.allSettled([
      api.getAgents(), api.getTasks(), api.getStats(), api.getHealth(),
      api.get<Report>(`/system/period-stats?period=${period}`),
    ]);
    if (current !== request.current) return;
    if (catalog.status === "fulfilled") setAgents(catalog.value);
    if (recent.status === "fulfilled") {
      setTasks(recent.value.tasks);
      setTotalTasks(recent.value.total);
    }
    if (totals.status === "fulfilled") setStats(totals.value);
    if (system.status === "fulfilled") setHealth(system.value);
    if (activity.status === "fulfilled") setReport(activity.value);
    const incomplete = [catalog, recent, totals, system, activity].some((result) => result.status === "rejected");
    setFailed(incomplete);
    if (!incomplete) setUpdated(new Date());
    setRefreshing(false);
  }, [period, setAgents, setTasks, setStats, setHealth]);

  usePolling(refresh, 30_000, false);
  useEffect(() => {
    void refresh();
    return () => { request.current += 1; };
  }, [refresh]);

  const data = report?.period === period ? report : null;
  const count = stats?.total_agents ?? health?.agents_count;
  const breakdown = Object.entries(stats?.by_category ?? {}).sort((a, b) => b[1] - a[1]);
  const recent = [...tasks].sort((a, b) => b.id - a.id).slice(0, 7);
  const agentNames = Object.fromEntries(agents.map((agent) => [agent.id, agent.name]));
  const show = (widget: WidgetId) => !hidden.includes(widget);
  const number = (value?: number | null) => value == null ? "—" : format.format(value);
  const indicators = [
    { label: "Agents au catalogue", value: number(count), sub: breakdown.length ? `${breakdown.length} catégories` : "Catalogue ORION", Icon: Bot },
    { label: "Tâches enregistrées", value: number(totalTasks), sub: "Toutes périodes", Icon: ListTodo },
    { label: "Tâches terminées", value: number(data?.success), sub: period === "week" ? "7 derniers jours" : "30 derniers jours", Icon: ChartNoAxesCombined },
    { label: "Moteur Ollama", value: health ? (health.ollama ? "Connecté" : "Hors ligne") : "—", sub: health?.models?.[0] ?? "Modèle local", Icon: Brain },
  ];

  return (
    <div className="flex min-w-0 flex-1 flex-col">
      <Header title="Tableau de bord" />
      <main className="orion-dashboard flex-1 overflow-auto bg-orion-bg">
        <div className="mx-auto max-w-[1480px] space-y-5 p-4 text-white sm:p-7">
          <section className="dashboard-hero relative overflow-hidden rounded-2xl border border-[#353751] bg-[#171927] p-5 sm:p-8">
            <div aria-hidden="true" className="dashboard-glow pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_#312858_0%,_transparent_67%)]" />
            <div className="relative flex flex-wrap items-end justify-between gap-5">
              <div>
                <div className="mb-3 flex items-center gap-2 text-xs text-slate-300">
                  <Activity size={15} aria-hidden="true" /> Wedding Player
                </div>
                <h2 className="text-3xl font-semibold tracking-tight sm:text-4xl">Vue d’ensemble</h2>
                <p className="mt-2 text-sm text-slate-300">Suivez les exécutions et pilotez vos agents et automatisations.</p>
              </div>
              <div className="flex flex-wrap gap-2">
                <Link to="/workflows" className={button}><Workflow size={15} aria-hidden="true" /> Workflows</Link>
                <Link to="/agents" className={`${button} dashboard-primary border-indigo-400/40 bg-indigo-600 hover:bg-indigo-500`}>
                  Explorer les agents <ArrowRight size={15} aria-hidden="true" />
                </Link>
              </div>
            </div>
          </section>

          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-300" aria-live="polite">
              <span className="flex items-center gap-2"><span aria-hidden="true" className="h-2 w-2 rounded-full bg-indigo-400" />
                Actualisation toutes les 30 s
              </span>
              <span>{updated ? `Dernière mise à jour complète à ${time.format(updated)}` : "En attente de données"}</span>
              {failed && <span className="text-orion-gold">Certaines données sont indisponibles</span>}
            </div>
            <div className="flex flex-wrap gap-2">
              <button className={button} onClick={refresh} disabled={refreshing}>
                <RefreshCw size={14} aria-hidden="true" className={refreshing ? "motion-safe:animate-spin" : ""} /> Actualiser
              </button>
              <Link to="/presentation" className={button}><Tv2 size={14} aria-hidden="true" /> Présentation</Link>
              <button className={button} aria-expanded={editing} onClick={() => setEditing(!editing)}>
                <Settings2 size={14} aria-hidden="true" /> Personnaliser
              </button>
            </div>
          </div>

          {editing && (
            <section className={`${panel} flex flex-wrap gap-2`} aria-label="Visibilité des widgets">
              {(Object.entries(widgets) as [WidgetId, string][]).map(([id, label]) => (
                <button key={id} type="button" aria-pressed={show(id)} className={button} onClick={() => toggle(id)}>
                  {show(id) ? <Eye size={14} aria-hidden="true" /> : <EyeOff size={14} aria-hidden="true" />}
                  {label}
                </button>
              ))}
              <button className={button} onClick={reset} disabled={!hidden.length}>Tout afficher</button>
            </section>
          )}

          {show("stats") && <section aria-label="Indicateurs" className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
            {indicators.map(({ label, value, sub, Icon }) => (
              <article className={panel} key={label}>
                <div className="flex items-center gap-3">
                  <span className="rounded-xl bg-indigo-400/10 p-2.5 text-indigo-300"><Icon size={17} aria-hidden="true" /></span>
                  <h3 className="text-sm font-medium text-slate-300">{label}</h3>
                </div>
                <p className="mt-4 truncate text-2xl font-semibold tabular-nums tracking-tight">{value}</p>
                <p className="mt-1 truncate text-xs text-orion-muted" title={sub}>{sub}</p>
              </article>
            ))}
          </section>}

          <div className="grid gap-4 xl:grid-cols-[minmax(0,2fr)_minmax(0,1fr)]">
            {show("activity") && <section className={`${panel} ${!show("agents_chart") ? "xl:col-span-2" : ""}`}>
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div><h3 className="font-semibold">Activité des tâches</h3><p className="mt-1 text-xs text-orion-muted">Exécutions enregistrées par jour</p></div>
                <div className="flex gap-1 rounded-xl border border-orion-border p-1" role="group" aria-label="Période">
                  {(["week", "month"] as const).map((key) => (
                    <button key={key} aria-pressed={period === key} onClick={() => setPeriod(key)}
                      className={`rounded-lg px-3 py-1.5 text-xs focus-visible:outline focus-visible:outline-orion-accent-light ${period === key ? "bg-indigo-500/25 text-indigo-200" : "text-slate-400 hover:text-white"}`}>
                      {key === "week" ? "7 jours" : "30 jours"}
                    </button>
                  ))}
                </div>
              </div>
              <div className="my-5 flex flex-wrap gap-6 text-xs text-slate-300">
                <span><strong className="mr-1.5 text-lg text-white">{number(data?.total)}</strong> Tâches</span>
                <span><strong className="mr-1.5 text-lg text-orion-green">{number(data?.success)}</strong> Terminées</span>
                <span><strong className="mr-1.5 text-lg text-white">{number(data?.failed)}</strong> Non terminées</span>
              </div>
              {!data?.total ? <div className="grid min-h-48 place-items-center rounded-xl border border-dashed border-orion-border px-4 text-center text-sm text-slate-300">
                {data ? "Aucune tâche sur cette période." : refreshing ? "Chargement de l’activité…" : "Données d’activité indisponibles."}
              </div> : (
                <div className="h-56 min-w-0">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart accessibilityLayer data={data.buckets} margin={{ left: -24, right: 8, top: 8 }}>
                      <defs><linearGradient id="dashboard-activity-fill" x2="0" y2="1"><stop stopColor="#818cf8" stopOpacity={0.28} /><stop offset="100%" stopColor="#818cf8" stopOpacity={0.02} /></linearGradient></defs>
                      <CartesianGrid vertical={false} stroke="#303449" strokeDasharray="4 5" />
                      <XAxis dataKey="label" axisLine={false} tickLine={false} minTickGap={16} tick={{ fill: "#a8b0c3", fontSize: 11 }} />
                      <YAxis allowDecimals={false} axisLine={false} tickLine={false} tick={{ fill: "#a8b0c3", fontSize: 11 }} />
                      <Tooltip contentStyle={{ background: "var(--dashboard-tooltip, #171927)", border: "1px solid var(--dashboard-tooltip-border, #353751)", borderRadius: 10 }} itemStyle={{ color: "inherit" }} />
                      <Area name="Tâches" dataKey="tasks" type="linear" stroke="#a5b4fc" strokeWidth={2} fill="url(#dashboard-activity-fill)" isAnimationActive={false} />
                      <Area name="Terminées" dataKey="success" type="linear" stroke="#6ee7b7" strokeWidth={2} fill="none" isAnimationActive={false} />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              )}
            </section>}

            {show("agents_chart") && <section className={`${panel} ${!show("activity") ? "xl:col-span-2" : ""}`}>
              <div className="flex flex-wrap items-center justify-between gap-2"><h3 className="font-semibold">Catalogue d’agents</h3><Link to="/agents" className={quietLink}>Catalogue <ArrowRight size={14} aria-hidden="true" /></Link></div>
              <p className="mt-1 text-xs text-orion-muted">Répartition par spécialité</p>
              {!breakdown.length && <p className="mt-6 text-sm text-slate-300">Répartition indisponible.</p>}
              <div className="mt-5 space-y-3">
                {breakdown.map(([category, value]) => (
                  <div key={category}>
                    <div className="mb-1.5 flex justify-between gap-2 text-xs"><span className="text-slate-300">{categories[category] ?? category}</span><span className="tabular-nums">{number(value)}</span></div>
                    <div aria-hidden="true" className="h-1.5 rounded-full bg-orion-border">
                      <div className="h-full rounded-full bg-indigo-400/85" style={{ width: `${Math.min(100, 100 * value / Math.max(count ?? 0, 1))}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            </section>}
          </div>

          <div className="grid gap-4 xl:grid-cols-[minmax(0,2fr)_minmax(0,1fr)]">
            {show("recent_tasks") && <section className={`${panel} ${!show("quick_stats") ? "xl:col-span-2" : ""}`}>
              <div className="flex flex-wrap items-center justify-between gap-2"><h3 className="font-semibold">Tâches récentes</h3><Link to="/tasks" className={quietLink}>Toutes les tâches <ArrowRight size={14} aria-hidden="true" /></Link></div>
              {recent.length ? <ul className="mt-3 divide-y divide-orion-border">
                {recent.map((task) => {
                  const status = statuses[task.status];
                  const created = new Date(task.created_at);
                  return <li key={task.id}>
                    <Link to={`/tasks/${task.id}/logs`} className="flex flex-wrap items-center justify-between gap-x-3 gap-y-1 rounded-lg px-2 py-3 hover:bg-white/5 focus-visible:outline focus-visible:outline-orion-accent-light">
                      <div className="min-w-0 flex-1 basis-36"><p className="truncate text-sm font-medium">{task.title}</p><p className="truncate text-xs text-orion-muted">{agentNames[task.agent_id] ?? (task.agent_id || "Agent automatique")}</p></div>
                      <span className={`rounded-full px-2 py-1 text-xs ${status?.style ?? "bg-white/5 text-slate-300"}`}>{status?.label ?? task.status}</span>
                      {!Number.isNaN(created.getTime()) && <time dateTime={created.toISOString()} className="text-xs text-orion-muted">{timestamp.format(created)}</time>}
                      <ArrowRight size={14} className="text-orion-muted" aria-hidden="true" />
                    </Link>
                  </li>;
                })}
              </ul> : <p className="py-8 text-sm text-slate-300">{totalTasks === 0 ? "Aucune tâche enregistrée." : "Historique indisponible."}</p>}
            </section>}
            {show("quick_stats") && <section className={`${panel} ${!show("recent_tasks") ? "xl:col-span-2" : ""}`}>
              <div className="flex flex-wrap items-center justify-between gap-2"><h3 className="font-semibold">État des services</h3><Link to="/monitor" className={quietLink}>Supervision <ArrowRight size={14} aria-hidden="true" /></Link></div>
              <dl className="mt-4 divide-y divide-orion-border text-sm">
                <div className="flex justify-between gap-3 py-3"><dt className="text-slate-300">API ORION</dt><dd>{health ? (health.status === "ok" ? "Opérationnelle" : health.status) : "Indisponible"}</dd></div>
                <div className="flex justify-between gap-3 py-3"><dt className="text-slate-300">Ollama</dt><dd>{health ? (health.ollama ? "Connecté" : "Hors ligne") : "Indisponible"}</dd></div>
                <div className="flex justify-between gap-3 py-3"><dt className="text-slate-300">Actualisation</dt><dd>Toutes les 30 s</dd></div>
              </dl>
            </section>}
          </div>
        </div>
      </main>
    </div>
  );
}
