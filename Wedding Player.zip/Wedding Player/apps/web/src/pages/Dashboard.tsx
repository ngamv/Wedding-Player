import { useCallback, useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { Bot, ListTodo, Zap, Brain, RefreshCw, TrendingUp, Radio, Settings2, Eye, EyeOff, RotateCcw, Tv2 } from "lucide-react";
import {
  RadialBarChart, RadialBar, ResponsiveContainer, Tooltip,
  AreaChart, Area, XAxis, YAxis, CartesianGrid,
} from "recharts";
import { api, getToken } from "@/api/client";
import { useOrionStore } from "@/store/useOrionStore";
import { useDashboardStore, type WidgetId } from "@/store/useDashboardStore";
import { Header } from "@/components/layout/Header";
import { usePolling } from "@/hooks/usePolling";

const WS_URL = (import.meta.env.VITE_API_URL ?? "http://localhost:8000")
  .replace(/^http/, "ws");

function useLiveTasks(onNewTask: (task: { id: number; status: string; title: string; agent_id: string }) => void) {
  const wsRef = useRef<WebSocket | null>(null);
  const [liveCount, setLiveCount] = useState(0);

  useEffect(() => {
    const token = getToken();
    if (!token) return;
    const ws = new WebSocket(`${WS_URL}/ws/tasks?token=${encodeURIComponent(token)}`);
    wsRef.current = ws;

    ws.onmessage = (e) => {
      try {
        const data = JSON.parse(e.data);
        if (data.type === "task_update" || data.type === "task_created") {
          onNewTask(data.task ?? data);
          setLiveCount((c) => c + 1);
        }
      } catch { /* ignore */ }
    };

    return () => { ws.close(); };
  }, [onNewTask]);

  return { liveCount };
}

const CATEGORY_COLORS: Record<string, string> = {
  core: "#6366f1", seo: "#10b981", social: "#f59e0b",
  marketing: "#ec4899", dev: "#3b82f6", data: "#8b5cf6",
};

function buildActivityData(taskCount: number) {
  const days = ["Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim"];
  return days.map((day, i) => ({
    day,
    tâches: Math.max(0, Math.round((taskCount / 7) * (0.5 + Math.sin(i + 1) * 0.4 + Math.random() * 0.3))),
  }));
}

const WIDGET_LABELS: Record<WidgetId, string> = {
  stats: "Cartes statistiques",
  activity: "Graphe d'activité",
  agents_chart: "Agents par catégorie",
  recent_tasks: "Tâches récentes",
  quick_stats: "Vue d'ensemble",
};

function WidgetWrapper({
  id,
  editing,
  children,
  className = "",
}: {
  id: WidgetId;
  editing: boolean;
  children: React.ReactNode;
  className?: string;
}) {
  const { isVisible, toggle } = useDashboardStore();
  const visible = isVisible(id);

  if (!editing && !visible) return null;

  return (
    <div className={`relative ${className} ${!visible && editing ? "opacity-40" : ""}`}>
      {editing && (
        <button
          onClick={() => toggle(id)}
          title={visible ? "Masquer ce widget" : "Afficher ce widget"}
          className="absolute top-2 right-2 z-10 p-1.5 rounded-lg bg-orion-surface border border-orion-border hover:border-orion-accent/50 text-orion-muted hover:text-white transition-colors"
        >
          {visible ? <Eye size={13} /> : <EyeOff size={13} />}
        </button>
      )}
      {children}
    </div>
  );
}

export function Dashboard() {
  const navigate = useNavigate();
  const { tasks, stats, health, setAgents, setTasks, setStats, setHealth } = useOrionStore();
  const { hidden, reset } = useDashboardStore();
  const [lastRefresh, setLastRefresh] = useState<Date>(new Date());
  const [refreshing, setRefreshing] = useState(false);
  const [wsConnected, setWsConnected] = useState(false);
  const [liveEvents, setLiveEvents] = useState(0);
  const [editing, setEditing] = useState(false);

  const refresh = useCallback(async () => {
    setRefreshing(true);
    await Promise.all([
      api.getAgents().then(setAgents).catch(() => {}),
      api.getTasks().then((r) => setTasks(r.tasks)).catch(() => {}),
      api.getStats().then(setStats).catch(() => {}),
      api.getHealth().then(setHealth).catch(() => {}),
    ]);
    setLastRefresh(new Date());
    setRefreshing(false);
  }, [setAgents, setTasks, setStats, setHealth]);

  usePolling(refresh, 30_000);

  const handleLiveTask = useCallback(() => {
    setLiveEvents((n) => n + 1);
    setTimeout(() => {
      api.getTasks().then((r) => setTasks(r.tasks)).catch(() => {});
    }, 500);
  }, [setTasks]);

  const { liveCount } = useLiveTasks(handleLiveTask);

  useEffect(() => {
    setWsConnected(liveCount > 0 || false);
  }, [liveCount]);

  const chartData = stats
    ? Object.entries(stats.by_category).map(([cat, count]) => ({
        name: cat, value: count, fill: CATEGORY_COLORS[cat] || "#6366f1",
      }))
    : [];

  const activityData = buildActivityData(tasks.length);
  const completedTasks = tasks.filter((t) => t.status === "completed").length;
  const pendingTasks = tasks.filter((t) => t.status === "pending").length;
  const recentTasks = [...tasks].reverse().slice(0, 8);

  const statCards = [
    { label: "Agents actifs", value: stats?.total_agents ?? 30, sub: "6 catégories", icon: Bot, color: "text-orion-accent", bg: "bg-orion-accent/10" },
    { label: "Tâches totales", value: tasks.length, sub: `${completedTasks} complétées`, icon: ListTodo, color: "text-orion-green", bg: "bg-orion-green/10" },
    { label: "Modèle Ollama", value: health?.models?.[0]?.split(":")[0] ?? "—", sub: health?.models?.[0] ?? "non détecté", icon: Brain, color: "text-orion-gold", bg: "bg-orion-gold/10" },
    { label: "Statut système", value: health?.status === "ok" ? "Opérationnel" : "Hors ligne", sub: `Ollama ${health?.ollama ? "connecté" : "déconnecté"}`, icon: Zap, color: health?.status === "ok" ? "text-orion-green" : "text-orion-red", bg: health?.status === "ok" ? "bg-orion-green/10" : "bg-orion-red/10" },
  ];

  return (
    <div className="flex-1 flex flex-col">
      <Header title="Dashboard">
        <div className="flex items-center gap-3 text-xs text-orion-muted">
          <div className="flex items-center gap-1.5">
            <Radio size={11} className={wsConnected ? "text-orion-green animate-pulse" : "text-orion-muted"} />
            <span className={wsConnected ? "text-orion-green" : ""}>
              {wsConnected ? `Live (${liveEvents})` : "Live"}
            </span>
          </div>
          <span>Rafraîchi à {lastRefresh.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}</span>
          <button onClick={refresh} disabled={refreshing} className="p-1.5 rounded-lg hover:bg-white/5 transition-colors disabled:opacity-40" title="Rafraîchir">
            <RefreshCw size={13} className={refreshing ? "animate-spin" : ""} />
          </button>
          <button
            onClick={() => navigate("/presentation")}
            title="Mode présentation (NOC)"
            className="p-1.5 rounded-lg hover:bg-white/5 text-orion-muted hover:text-white transition-colors"
          >
            <Tv2 size={13} />
          </button>
          <button
            onClick={() => setEditing((v) => !v)}
            title="Personnaliser le dashboard"
            className={`p-1.5 rounded-lg transition-colors ${editing ? "bg-orion-accent/20 text-orion-accent-light" : "hover:bg-white/5 text-orion-muted hover:text-white"}`}
          >
            <Settings2 size={13} />
          </button>
        </div>
      </Header>

      {/* Edit mode banner */}
      {editing && (
        <div className="px-6 py-2 bg-orion-accent/10 border-b border-orion-accent/20 flex items-center justify-between">
          <p className="text-orion-accent-light text-xs flex items-center gap-2">
            <Eye size={12} /> Cliquez sur <Eye size={12} className="inline" /> / <EyeOff size={12} className="inline" /> pour afficher ou masquer les widgets
            {hidden.length > 0 && <span className="text-orion-muted ml-2">({hidden.length} masqué{hidden.length > 1 ? "s" : ""})</span>}
          </p>
          <div className="flex items-center gap-2">
            {hidden.length > 0 && (
              <button onClick={reset} className="flex items-center gap-1 text-xs text-orion-muted hover:text-white transition-colors">
                <RotateCcw size={10} /> Tout afficher
              </button>
            )}
            <button onClick={() => setEditing(false)} className="text-xs text-orion-accent-light hover:text-white transition-colors">
              Terminer
            </button>
          </div>
        </div>
      )}

      {/* Widget palette in edit mode */}
      {editing && (
        <div className="px-6 py-3 border-b border-orion-border flex items-center gap-2 flex-wrap">
          {(Object.keys(WIDGET_LABELS) as WidgetId[]).map((id) => {
            const vis = !hidden.includes(id);
            return (
              <button
                key={id}
                onClick={() => useDashboardStore.getState().toggle(id)}
                className={`flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-lg border transition-colors ${vis ? "border-orion-accent/40 text-orion-accent-light bg-orion-accent/10" : "border-orion-border text-orion-muted hover:text-white"}`}
              >
                {vis ? <Eye size={10} /> : <EyeOff size={10} />}
                {WIDGET_LABELS[id]}
              </button>
            );
          })}
        </div>
      )}

      <main className="flex-1 p-6 space-y-6 overflow-auto">
        {/* Stat cards */}
        <WidgetWrapper id="stats" editing={editing}>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {statCards.map(({ label, value, sub, icon: Icon, color, bg }) => (
              <div key={label} className="orion-card p-5 hover:border-white/10 transition-colors">
                <div className="flex items-start justify-between mb-4">
                  <div className={`${bg} p-2 rounded-lg`}>
                    <Icon size={16} className={color} />
                  </div>
                </div>
                <p className={`text-2xl font-bold ${color} leading-tight`}>{value}</p>
                <p className="text-orion-muted text-xs mt-1">{label}</p>
                <p className="text-white/40 text-[10px] mt-0.5">{sub}</p>
              </div>
            ))}
          </div>
        </WidgetWrapper>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Activity chart */}
          <WidgetWrapper id="activity" editing={editing} className="lg:col-span-2">
            <div className="orion-card p-5 h-full">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-white text-sm font-medium">Activité des 7 derniers jours</h3>
                <div className="flex items-center gap-1.5 text-orion-green text-xs">
                  <TrendingUp size={12} /><span>Tâches</span>
                </div>
              </div>
              <div className="h-44">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={activityData} margin={{ top: 4, right: 4, left: -24, bottom: 0 }}>
                    <defs>
                      <linearGradient id="grad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#6366f1" stopOpacity={0.25} />
                        <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#2a2a3d" vertical={false} />
                    <XAxis dataKey="day" tick={{ fill: "#6b7280", fontSize: 11 }} axisLine={false} tickLine={false} />
                    <YAxis tick={{ fill: "#6b7280", fontSize: 11 }} axisLine={false} tickLine={false} allowDecimals={false} />
                    <Tooltip contentStyle={{ background: "#1a1a26", border: "1px solid #2a2a3d", borderRadius: 8, fontSize: 12 }} labelStyle={{ color: "#fff" }} cursor={{ stroke: "#2a2a3d" }} />
                    <Area type="monotone" dataKey="tâches" stroke="#6366f1" strokeWidth={2} fill="url(#grad)" dot={false} activeDot={{ r: 4, fill: "#6366f1" }} />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>
          </WidgetWrapper>

          {/* Agents par catégorie */}
          <WidgetWrapper id="agents_chart" editing={editing}>
            <div className="orion-card p-5 h-full">
              <h3 className="text-white text-sm font-medium mb-3">Agents par catégorie</h3>
              <div className="h-32">
                <ResponsiveContainer width="100%" height="100%">
                  <RadialBarChart cx="50%" cy="50%" innerRadius="25%" outerRadius="90%" data={chartData}>
                    <RadialBar dataKey="value" background={{ fill: "#1a1a26" }} cornerRadius={4} />
                    <Tooltip contentStyle={{ background: "#1a1a26", border: "1px solid #2a2a3d", borderRadius: 8, fontSize: 12 }} />
                  </RadialBarChart>
                </ResponsiveContainer>
              </div>
              <div className="mt-3 space-y-2">
                {chartData.map((d) => (
                  <div key={d.name} className="flex items-center justify-between">
                    <span className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full" style={{ background: d.fill }} />
                      <span className="text-orion-muted text-xs capitalize">{d.name}</span>
                    </span>
                    <div className="flex items-center gap-2">
                      <div className="w-16 h-1 rounded-full bg-orion-border overflow-hidden">
                        <div className="h-full rounded-full" style={{ background: d.fill, width: `${(d.value / (stats?.total_agents ?? 30)) * 100}%` }} />
                      </div>
                      <span className="text-white text-xs font-medium w-4 text-right">{d.value}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </WidgetWrapper>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Recent tasks */}
          <WidgetWrapper id="recent_tasks" editing={editing} className="lg:col-span-2">
            <div className="orion-card p-5 h-full">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-white text-sm font-medium">Tâches récentes</h3>
                {pendingTasks > 0 && (
                  <span className="text-xs bg-orion-gold/15 text-orion-gold px-2 py-0.5 rounded-full">{pendingTasks} en attente</span>
                )}
              </div>
              {recentTasks.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-10 text-orion-muted">
                  <ListTodo size={28} className="mb-2 opacity-40" />
                  <p className="text-sm">Aucune tâche pour l'instant</p>
                  <p className="text-xs opacity-60 mt-1">Lancez un agent depuis la page Agents</p>
                </div>
              ) : (
                <div className="space-y-1">
                  {recentTasks.map((t) => (
                    <div key={t.id} className="flex items-center justify-between py-2.5 px-3 rounded-lg hover:bg-white/5 transition-colors">
                      <div className="min-w-0 flex-1">
                        <p className="text-white text-sm truncate">{t.title}</p>
                        <p className="text-orion-muted text-xs truncate">{t.agent_id ?? "auto-routé"}</p>
                      </div>
                      <span className={`ml-3 text-[11px] px-2 py-0.5 rounded-full flex-shrink-0 ${
                        t.status === "completed" ? "bg-orion-green/15 text-orion-green" :
                        t.status === "failed" ? "bg-orion-red/15 text-orion-red" :
                        "bg-orion-gold/15 text-orion-gold"
                      }`}>{t.status}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </WidgetWrapper>

          {/* Quick stats */}
          <WidgetWrapper id="quick_stats" editing={editing}>
            <div className="orion-card p-5 flex flex-col gap-4 h-full">
              <h3 className="text-white text-sm font-medium">Vue d'ensemble</h3>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between text-xs mb-1.5">
                    <span className="text-orion-muted">Tâches complétées</span>
                    <span className="text-orion-green">{tasks.length > 0 ? Math.round((completedTasks / tasks.length) * 100) : 0}%</span>
                  </div>
                  <div className="h-1.5 bg-orion-border rounded-full overflow-hidden">
                    <div className="h-full bg-orion-green rounded-full transition-all duration-700" style={{ width: `${tasks.length > 0 ? (completedTasks / tasks.length) * 100 : 0}%` }} />
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-xs mb-1.5">
                    <span className="text-orion-muted">Agents disponibles</span>
                    <span className="text-orion-accent">100%</span>
                  </div>
                  <div className="h-1.5 bg-orion-border rounded-full overflow-hidden">
                    <div className="h-full bg-orion-accent rounded-full" style={{ width: "100%" }} />
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-xs mb-1.5">
                    <span className="text-orion-muted">Ollama connecté</span>
                    <span className={health?.ollama ? "text-orion-green" : "text-orion-red"}>{health?.ollama ? "Oui" : "Non"}</span>
                  </div>
                  <div className="h-1.5 bg-orion-border rounded-full overflow-hidden">
                    <div className={`h-full rounded-full transition-all duration-700 ${health?.ollama ? "bg-orion-green" : "bg-orion-red"}`} style={{ width: health?.ollama ? "100%" : "0%" }} />
                  </div>
                </div>
              </div>
              <div className="mt-auto pt-4 border-t border-orion-border">
                <p className="text-orion-muted text-xs mb-3">Agents disponibles</p>
                <div className="flex flex-wrap gap-1.5">
                  {Object.entries(CATEGORY_COLORS).map(([cat, color]) => (
                    <span key={cat} className="text-[10px] px-2 py-0.5 rounded-full capitalize" style={{ background: `${color}20`, color }}>
                      {cat}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </WidgetWrapper>
        </div>
      </main>
    </div>
  );
}
