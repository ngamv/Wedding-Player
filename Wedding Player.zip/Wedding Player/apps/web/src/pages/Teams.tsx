import { useEffect, useState } from "react";
import { api } from "@/api/client";
import { toast } from "@/components/ui/Toast";
import { Users, Plus, Trash2, UserPlus, Crown } from "lucide-react";

interface Team {
  id: number;
  name: string;
  description: string;
  owner_id: number;
  is_owner: boolean;
  created_at: string;
}

interface Member {
  user_id: number;
  username: string;
  email: string;
  role: string;
  joined_at: string;
}

interface TeamDetail extends Team {
  members: Member[];
}

export function Teams() {
  const [teams, setTeams] = useState<Team[]>([]);
  const [selected, setSelected] = useState<TeamDetail | null>(null);
  const [showCreate, setShowCreate] = useState(false);
  const [newName, setNewName] = useState("");
  const [newDesc, setNewDesc] = useState("");
  const [inviteUser, setInviteUser] = useState("");
  const [inviteRole, setInviteRole] = useState("member");
  const [creating, setCreating] = useState(false);

  async function load() {
    try {
      const data = await api.get<Team[]>("/teams/");
      setTeams(data);
    } catch {
      toast.error("Erreur de chargement des équipes");
    }
  }

  async function loadDetail(id: number) {
    try {
      const data = await api.get<TeamDetail>(`/teams/${id}`);
      setSelected(data);
    } catch {
      toast.error("Erreur de chargement");
    }
  }

  useEffect(() => { load(); }, []);

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    setCreating(true);
    try {
      const t = await api.post<Team>("/teams/", { name: newName, description: newDesc });
      setTeams((prev) => [t, ...prev]);
      setNewName(""); setNewDesc(""); setShowCreate(false);
      toast.success("Équipe créée");
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Erreur");
    } finally {
      setCreating(false);
    }
  }

  async function handleInvite(e: React.FormEvent) {
    e.preventDefault();
    if (!selected) return;
    try {
      await api.post(`/teams/${selected.id}/invite`, { username: inviteUser, role: inviteRole });
      toast.success(`${inviteUser} invité`);
      setInviteUser("");
      await loadDetail(selected.id);
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Erreur");
    }
  }

  async function handleRemoveMember(userId: number) {
    if (!selected) return;
    try {
      await api.delete(`/teams/${selected.id}/members/${userId}`);
      await loadDetail(selected.id);
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Impossible de retirer ce membre");
    }
  }

  async function handleDeleteTeam(id: number) {
    if (!confirm("Supprimer cette équipe ?")) return;
    try {
      await api.delete(`/teams/${id}`);
      setTeams((prev) => prev.filter((t) => t.id !== id));
      if (selected?.id === id) setSelected(null);
      toast.success("Équipe supprimée");
    } catch {
      toast.error("Erreur lors de la suppression");
    }
  }

  return (
    <div className="flex-1 flex overflow-hidden">
      {/* Left: list */}
      <div className="w-72 border-r border-orion-border flex flex-col">
        <div className="p-4 border-b border-orion-border flex items-center justify-between">
          <h1 className="text-sm font-bold text-white">Équipes</h1>
          <button
            onClick={() => setShowCreate((v) => !v)}
            className="p-1.5 rounded-lg text-orion-muted hover:text-white hover:bg-white/5"
          >
            <Plus size={14} />
          </button>
        </div>

        {showCreate && (
          <form onSubmit={handleCreate} className="p-4 border-b border-orion-border space-y-2">
            <input
              required
              className="w-full bg-orion-bg border border-orion-border rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-orion-accent/60"
              placeholder="Nom de l'équipe"
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
            />
            <input
              className="w-full bg-orion-bg border border-orion-border rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none"
              placeholder="Description (optionnel)"
              value={newDesc}
              onChange={(e) => setNewDesc(e.target.value)}
            />
            <button
              type="submit"
              disabled={creating}
              className="w-full py-1.5 bg-orion-accent text-white text-xs rounded-lg disabled:opacity-50"
            >
              {creating ? "Création…" : "Créer"}
            </button>
          </form>
        )}

        <ul className="flex-1 overflow-y-auto">
          {teams.length === 0 && (
            <li className="text-center py-8 text-orion-muted text-xs">
              <Users size={24} className="mx-auto mb-2 opacity-30" />
              Aucune équipe
            </li>
          )}
          {teams.map((t) => (
            <li key={t.id}>
              <button
                onClick={() => loadDetail(t.id)}
                className={`w-full flex items-center gap-2 px-4 py-3 text-left transition-colors ${
                  selected?.id === t.id ? "bg-orion-accent/10 border-r-2 border-orion-accent" : "hover:bg-white/5"
                }`}
              >
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-white truncate">{t.name}</p>
                  {t.description && (
                    <p className="text-xs text-orion-muted truncate">{t.description}</p>
                  )}
                </div>
                {t.is_owner && <Crown size={12} className="text-orion-accent-light flex-shrink-0" />}
              </button>
            </li>
          ))}
        </ul>
      </div>

      {/* Right: detail */}
      <div className="flex-1 overflow-auto p-6">
        {!selected ? (
          <div className="flex flex-col items-center justify-center h-full text-orion-muted">
            <Users size={40} className="mb-3 opacity-20" />
            <p className="text-sm">Sélectionnez une équipe</p>
          </div>
        ) : (
          <>
            <div className="flex items-start justify-between mb-6">
              <div>
                <h2 className="text-lg font-bold text-white">{selected.name}</h2>
                {selected.description && (
                  <p className="text-orion-muted text-sm mt-0.5">{selected.description}</p>
                )}
              </div>
              {selected.is_owner && (
                <button
                  onClick={() => handleDeleteTeam(selected.id)}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-orion-red border border-orion-red/30 rounded-lg hover:bg-orion-red/10"
                >
                  <Trash2 size={12} /> Supprimer
                </button>
              )}
            </div>

            {/* Members */}
            <div className="bg-orion-surface border border-orion-border rounded-xl divide-y divide-orion-border mb-6">
              <div className="px-5 py-3 text-xs font-semibold text-orion-muted uppercase tracking-wider">
                {selected.members.length} membre{selected.members.length > 1 ? "s" : ""}
              </div>
              {selected.members.map((m) => (
                <div key={m.user_id} className="flex items-center justify-between px-5 py-3">
                  <div>
                    <p className="text-sm text-white">{m.username}</p>
                    <p className="text-xs text-orion-muted">{m.email}</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${
                      m.role === "owner"
                        ? "bg-orion-accent/20 text-orion-accent-light"
                        : "bg-orion-muted/20 text-orion-muted"
                    }`}>
                      {m.role}
                    </span>
                    {selected.is_owner && m.role !== "owner" && (
                      <button
                        onClick={() => handleRemoveMember(m.user_id)}
                        className="p-1 rounded text-orion-muted hover:text-orion-red"
                      >
                        <Trash2 size={12} />
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {/* Invite */}
            {selected.is_owner && (
              <form onSubmit={handleInvite} className="bg-orion-surface border border-orion-border rounded-xl p-5">
                <h3 className="text-sm font-semibold text-white mb-3 flex items-center gap-2">
                  <UserPlus size={14} /> Inviter un membre
                </h3>
                <div className="flex gap-2">
                  <input
                    required
                    className="flex-1 bg-orion-bg border border-orion-border rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-orion-accent/60"
                    placeholder="Nom d'utilisateur"
                    value={inviteUser}
                    onChange={(e) => setInviteUser(e.target.value)}
                  />
                  <select
                    className="bg-orion-bg border border-orion-border rounded-lg px-3 py-2 text-sm text-white focus:outline-none"
                    value={inviteRole}
                    onChange={(e) => setInviteRole(e.target.value)}
                  >
                    <option value="member">Membre</option>
                    <option value="viewer">Lecteur</option>
                  </select>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-orion-accent hover:bg-orion-accent/80 text-white text-sm rounded-lg"
                  >
                    Inviter
                  </button>
                </div>
              </form>
            )}
          </>
        )}
      </div>
    </div>
  );
}
