import { useState, useEffect } from "react";
import { Play, StopCircle, FlaskConical, ChevronDown, History, Trash2, Clock } from "lucide-react";
import { CodeBlock } from "@/components/ui/CodeBlock";
import { api } from "@/api/client";
import { useOrionStore } from "@/store/useOrionStore";
import { usePromptHistory } from "@/store/usePromptHistory";
import { Header } from "@/components/layout/Header";

interface RunResult {
  agent_id: string;
  status: string;
  output: Record<string, unknown> | null;
  elapsed_ms?: number;
}

const EXAMPLES = [
  "Rédige un email de relance commercial pour un prospect inactif",
  "Analyse les mots-clés SEO pour une boutique de chaussures en ligne",
  "Génère 5 idées de posts LinkedIn pour un consultant en IA",
  "Écris un script Python pour lire un fichier CSV et afficher les stats",
];

interface OllamaModel { name: string }

export function Playground() {
  const { agents } = useOrionStore();
  const { history, push, remove, clear } = usePromptHistory();
  const [agentId, setAgentId] = useState("");
  const [modelOverride, setModelOverride] = useState("");
  const [ollamaModels, setOllamaModels] = useState<OllamaModel[]>([]);
  const [prompt, setPrompt] = useState("");

  useEffect(() => {
    api.get<OllamaModel[]>("/system/ollama/models").then(setOllamaModels).catch(() => {});
  }, []);
  const [running, setRunning] = useState(false);
  const [result, setResult] = useState<RunResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [elapsed, setElapsed] = useState<number | null>(null);
  const [leftTab, setLeftTab] = useState<"examples" | "history">("examples");

  async function run() {
    if (!prompt.trim()) return;
    setRunning(true);
    setResult(null);
    setError(null);
    const t0 = performance.now();
    try {
      const data = await api.post<RunResult>("/tasks/", {
        title: prompt,
        agent_id: agentId || undefined,
        model: modelOverride || undefined,
      });
      setElapsed(Math.round(performance.now() - t0));
      setResult(data);
      push(prompt.trim());
    } catch (e) {
      setError(e instanceof Error ? e.message : "Erreur inconnue");
    } finally {
      setRunning(false);
    }
  }

  const selectedAgent = agents.find((a) => a.id === agentId);
  const outputText = result?.output
    ? typeof result.output === "object"
      ? (result.output as Record<string, unknown>).result as string
        ?? JSON.stringify(result.output, null, 2)
      : String(result.output)
    : null;

  return (
    <div className="flex-1 flex flex-col">
      <Header title="Agent Playground" />

      <main className="flex-1 p-6 grid grid-cols-1 lg:grid-cols-2 gap-6 overflow-auto">
        {/* Input panel */}
        <div className="space-y-4">
          {/* Agent selector */}
          <div className="orion-card p-5 space-y-4">
            <div className="flex items-center gap-2">
              <FlaskConical size={16} className="text-orion-accent-light" />
              <h3 className="text-white text-sm font-medium">Configuration</h3>
            </div>

            <div>
              <label className="block text-orion-muted text-xs mb-2">Agent</label>
              <div className="relative">
                <select
                  value={agentId}
                  onChange={(e) => setAgentId(e.target.value)}
                  className="w-full appearance-none px-3 py-2.5 bg-orion-bg border border-orion-border rounded-lg text-sm text-white focus:outline-none focus:border-orion-accent/50 pr-8"
                >
                  <option value="">🔀 Auto-routeur (recommandé)</option>
                  {agents.map((a) => (
                    <option key={a.id} value={a.id}>{a.name}</option>
                  ))}
                </select>
                <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-orion-muted pointer-events-none" />
              </div>
              {selectedAgent && (
                <p className="text-orion-muted text-xs mt-1.5 italic">{selectedAgent.description}</p>
              )}
            </div>

            <div>
              <label className="block text-orion-muted text-xs mb-2">Modèle LLM</label>
              <div className="relative">
                <select
                  value={modelOverride}
                  onChange={(e) => setModelOverride(e.target.value)}
                  className="w-full appearance-none px-3 py-2.5 bg-orion-bg border border-orion-border rounded-lg text-sm text-white focus:outline-none focus:border-orion-accent/50 pr-8"
                >
                  <option value="">Modèle par défaut</option>
                  {ollamaModels.map((m) => (
                    <option key={m.name} value={m.name}>{m.name}</option>
                  ))}
                  <optgroup label="Cloud">
                    <option value="gpt-4o-mini">gpt-4o-mini</option>
                    <option value="gpt-4o">gpt-4o</option>
                    <option value="claude-haiku-4-5-20251001">claude-haiku-4-5-20251001</option>
                    <option value="claude-sonnet-4-6">claude-sonnet-4-6</option>
                  </optgroup>
                </select>
                <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-orion-muted pointer-events-none" />
              </div>
            </div>

            <div>
              <label className="block text-orion-muted text-xs mb-2">Prompt</label>
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="Décrivez la tâche à exécuter…"
                rows={6}
                className="w-full px-3 py-2.5 bg-orion-bg border border-orion-border rounded-lg text-sm text-white placeholder-orion-muted focus:outline-none focus:border-orion-accent/50 resize-none font-mono"
                onKeyDown={(e) => {
                  if ((e.ctrlKey || e.metaKey) && e.key === "Enter") { e.preventDefault(); run(); }
                }}
              />
              <p className="text-orion-muted/50 text-[10px] mt-1">Ctrl+Entrée pour exécuter</p>
            </div>

            <button
              onClick={running ? undefined : run}
              disabled={!prompt.trim() || running}
              className="w-full flex items-center justify-center gap-2 py-2.5 bg-orion-accent hover:bg-orion-accent/80 disabled:opacity-40 text-white rounded-lg text-sm font-medium transition-colors"
            >
              {running ? (
                <><StopCircle size={15} className="animate-pulse" />Exécution en cours…</>
              ) : (
                <><Play size={15} />Exécuter</>
              )}
            </button>
          </div>

          {/* Examples / History tabs */}
          <div className="orion-card overflow-hidden">
            <div className="flex border-b border-orion-border">
              <button
                onClick={() => setLeftTab("examples")}
                className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 text-xs transition-colors ${leftTab === "examples" ? "text-white border-b-2 border-orion-accent" : "text-orion-muted hover:text-white"}`}
              >
                <FlaskConical size={11} /> Exemples
              </button>
              <button
                onClick={() => setLeftTab("history")}
                className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 text-xs transition-colors ${leftTab === "history" ? "text-white border-b-2 border-orion-accent" : "text-orion-muted hover:text-white"}`}
              >
                <History size={11} /> Historique
                {history.length > 0 && <span className="bg-orion-accent/20 text-orion-accent-light text-[9px] px-1.5 py-0.5 rounded-full">{history.length}</span>}
              </button>
            </div>

            <div className="p-4">
              {leftTab === "examples" ? (
                <div className="space-y-1.5">
                  {EXAMPLES.map((ex) => (
                    <button
                      key={ex}
                      onClick={() => setPrompt(ex)}
                      className="w-full text-left px-3 py-2 rounded-lg text-xs text-orion-muted hover:text-white hover:bg-white/5 transition-colors truncate"
                    >
                      → {ex}
                    </button>
                  ))}
                </div>
              ) : history.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-6 text-orion-muted gap-2">
                  <Clock size={20} className="opacity-30" />
                  <p className="text-xs">Aucun prompt dans l'historique</p>
                </div>
              ) : (
                <div className="space-y-1">
                  <div className="flex justify-end mb-2">
                    <button
                      onClick={clear}
                      className="text-[10px] text-orion-muted hover:text-orion-red transition-colors flex items-center gap-1"
                    >
                      <Trash2 size={9} /> Tout effacer
                    </button>
                  </div>
                  <div className="space-y-1 max-h-48 overflow-y-auto">
                    {history.map((p, i) => (
                      <div key={i} className="flex items-center gap-2 group">
                        <button
                          onClick={() => setPrompt(p)}
                          className="flex-1 text-left px-3 py-2 rounded-lg text-xs text-orion-muted hover:text-white hover:bg-white/5 transition-colors truncate"
                        >
                          <span className="text-orion-muted/40 mr-2 font-mono">{i + 1}.</span>{p}
                        </button>
                        <button
                          onClick={() => remove(p)}
                          className="opacity-0 group-hover:opacity-100 p-1 text-orion-muted hover:text-orion-red transition-all flex-shrink-0"
                        >
                          <Trash2 size={10} />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Output panel */}
        <div className="orion-card flex flex-col overflow-hidden">
          <div className="px-5 py-4 border-b border-orion-border flex items-center justify-between">
            <h3 className="text-white text-sm font-medium">Résultat</h3>
            <div className="flex items-center gap-3">
              {result && (
                <span className={`text-xs px-2 py-0.5 rounded-full ${
                  result.status === "completed" ? "bg-orion-green/15 text-orion-green" : "bg-orion-red/15 text-orion-red"
                }`}>
                  {result.status}
                </span>
              )}
              {elapsed !== null && (
                <span className="text-orion-muted text-xs">{(elapsed / 1000).toFixed(1)}s</span>
              )}
            </div>
          </div>

          <div className="flex-1 overflow-auto p-5">
            {running && (
              <div className="flex flex-col items-center justify-center h-full gap-3">
                <div className="w-8 h-8 rounded-full border-2 border-orion-accent/30 border-t-orion-accent animate-spin" />
                <p className="text-orion-muted text-sm">
                  {selectedAgent ? `${selectedAgent.name} en cours…` : "Routage et exécution…"}
                </p>
              </div>
            )}

            {!running && !result && !error && (
              <div className="flex flex-col items-center justify-center h-full gap-2 text-orion-muted">
                <FlaskConical size={32} className="opacity-20" />
                <p className="text-sm">Le résultat apparaîtra ici</p>
                <p className="text-xs opacity-60">Entrez un prompt et cliquez sur Exécuter</p>
              </div>
            )}

            {error && (
              <div className="p-4 rounded-lg bg-orion-red/10 border border-orion-red/30">
                <p className="text-orion-red text-sm font-medium mb-1">Erreur</p>
                <p className="text-orion-red/80 text-xs font-mono">{error}</p>
              </div>
            )}

            {outputText && !running && (
              <div className="space-y-2">
                {result?.agent_id && (
                  <p className="text-orion-muted text-xs font-mono mb-3">
                    Exécuté par : <span className="text-orion-accent-light">{result.agent_id}</span>
                  </p>
                )}
                <CodeBlock code={outputText} />
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
