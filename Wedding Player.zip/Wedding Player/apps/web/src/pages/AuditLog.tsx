import { useEffect, useState } from "react";
import { ShieldCheck, RefreshCw } from "lucide-react";
import { api } from "@/api/client";
import { Header } from "@/components/layout/Header";

interface AuditEntry {
  id: number;
  username: string;
  action: string;
  resource_type: string;
  resource_id: string | null;
  details: Record<string, unknown> | null;
  ip_address: string | null;
  created_at: string;
}

export function AuditLog() {
  const [entries, setEntries] = useState<AuditEntry[]>([]);
  const [loading, setLoading] = useState(false);

  async function load() {
    setLoading(true);
    try {
      const data = await api.get<AuditEntry[]>("/admin/audit/");
      setEntries(data);
    } catch {
      // silently ignore
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); }, []);

  return (
    <div className="flex-1 flex flex-col">
      <Header title="Journal d'audit">
        <button
          onClick={load}
          disabled={loading}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-orion-muted hover:text-white border border-orion-border rounded-lg hover:bg-white/5 transition-colors"
        >
          <RefreshCw size={12} className={loading ? "animate-spin" : ""} />
          Actualiser
        </button>
      </Header>

      <main className="flex-1 p-6 overflow-auto">
        <div className="orion-card overflow-hidden">
          <div className="px-5 py-4 border-b border-orion-border flex items-center gap-2">
            <ShieldCheck size={16} className="text-orion-accent-light" />
            <h3 className="text-white text-sm font-medium">
              Actions admin
              <span className="text-orion-muted ml-2 font-normal">{entries.length} entrée{entries.length !== 1 ? "s" : ""}</span>
            </h3>
          </div>

          {entries.length === 0 && !loading ? (
            <div className="p-12 text-center text-orion-muted text-sm">Aucune action enregistrée</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-orion-border text-orion-muted text-xs uppercase tracking-wider">
                    <th className="px-5 py-3 text-left">Date</th>
                    <th className="px-5 py-3 text-left">Utilisateur</th>
                    <th className="px-5 py-3 text-left">Action</th>
                    <th className="px-5 py-3 text-left">Ressource</th>
                    <th className="px-5 py-3 text-left">IP</th>
                    <th className="px-5 py-3 text-left">Détails</th>
                  </tr>
                </thead>
                <tbody>
                  {entries.map((e) => (
                    <tr key={e.id} className="border-b border-orion-border/50 hover:bg-white/3 transition-colors">
                      <td className="px-5 py-3 text-orion-muted text-xs whitespace-nowrap">
                        {new Date(e.created_at).toLocaleString("fr-FR")}
                      </td>
                      <td className="px-5 py-3 text-white text-xs font-mono">{e.username}</td>
                      <td className="px-5 py-3">
                        <span className="text-xs px-2 py-0.5 rounded-full bg-orion-accent/15 text-orion-accent-light font-mono">
                          {e.action}
                        </span>
                      </td>
                      <td className="px-5 py-3 text-orion-muted text-xs">
                        {e.resource_type}{e.resource_id ? ` #${e.resource_id}` : ""}
                      </td>
                      <td className="px-5 py-3 text-orion-muted text-xs font-mono">{e.ip_address || "—"}</td>
                      <td className="px-5 py-3 text-orion-muted text-xs max-w-xs truncate">
                        {e.details ? JSON.stringify(e.details) : "—"}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
