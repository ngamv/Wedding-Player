import { useEffect, useState } from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";
import { TrendingUp, CheckCircle, ListTodo, Zap, RefreshCw, FileDown } from "lucide-react";
import { api, getToken } from "@/api/client";
import type { Analytics as AnalyticsData, Tool } from "@/api/client";
import { Header } from "@/components/layout/Header";
import { toast } from "@/components/ui/Toast";

const BASE_URL = import.meta.env.VITE_API_URL ?? "http://localhost:8000";

const AGENT_COLORS = ["#6366f1", "#10b981", "#f59e0b", "#ec4899", "#3b82f6"];

export function Analytics() {
  const [data, setData] = useState<AnalyticsData | null>(null);
  const [tools, setTools] = useState<Tool[]>([]);
  const [refreshing, setRefreshing] = useState(false);

  async function load() {
    setRefreshing(true);
    await Promise.all([
      api.getAnalytics().then(setData).catch(() => {}),
      api.getTools().then((r) => setTools(r.tools)).catch(() => {}),
    ]);
    setRefreshing(false);
  }

  function exportPdf() {
    const token = getToken();
    const url = `${BASE_URL}/system/analytics/export`;
    const a = document.createElement("a");
    a.href = url;
    a.download = "orion_analytics.pdf";
    // Use fetch to attach auth header
    fetch(url, { headers: { Authorization: `Bearer ${token}` } })
      .then((r) => r.blob())
      .then((blob) => {
        const blobUrl = URL.createObjectURL(blob);
        a.href = blobUrl;
        a.click();
        setTimeout(() => URL.revokeObjectURL(blobUrl), 1000);
        toast.success("Rapport PDF téléchargé");
      })
      .catch(() => toast.error("Erreur lors de l'export PDF"));
  }

  useEffect(() => { load(); }, []);

  return (
    <div className="flex-1 flex flex-col">
      <Header title="Analytics">
        <div className="flex items-center gap-2">
          <button
            onClick={exportPdf}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-orion-muted hover:text-white border border-orion-border rounded-lg hover:bg-white/5 transition-colors"
          >
            <FileDown size={12} /> PDF
          </button>
          <button
            onClick={load}
            disabled={refreshing}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-orion-muted hover:text-white border border-orion-border rounded-lg hover:bg-white/5 transition-colors"
          >
            <RefreshCw size={12} className={refreshing ? "animate-spin" : ""} />
            Actualiser
          </button>
        </div>
      </Header>

      <main className="flex-1 p-6 space-y-6 overflow-auto">
        {/* KPIs */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: "Tâches totales", value: data?.total_tasks ?? 0, icon: <ListTodo size={14} />, color: "text-orion-accent" },
            { label: "Taux de succès", value: `${data?.success_rate ?? 0}%`, icon: <CheckCircle size={14} />, color: "text-orion-green" },
            { label: "Agents utilisés", value: data?.top_agents.length ?? 0, icon: <Zap size={14} />, color: "text-orion-gold" },
            { label: "Outils disponibles", value: tools.length, icon: <TrendingUp size={14} />, color: "text-orion-accent-light" },
          ].map(({ label, value, icon, color }) => (
            <div key={label} className="orion-card p-4">
              <div className={`flex items-center gap-2 mb-2 ${color}`}>{icon}<span className="text-xs uppercase tracking-wider text-orion-muted">{label}</span></div>
              <p className={`text-2xl font-bold ${color}`}>{value}</p>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Daily tasks bar chart */}
          <div className="orion-card p-5">
            <h3 className="text-white text-sm font-medium mb-4">Tâches par jour (7 derniers jours)</h3>
            <div className="h-48">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={data?.daily ?? []} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#2a2a3d" vertical={false} />
                  <XAxis dataKey="day" tick={{ fill: "#6b7280", fontSize: 11 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: "#6b7280", fontSize: 11 }} axisLine={false} tickLine={false} allowDecimals={false} />
                  <Tooltip
                    contentStyle={{ background: "#1a1a26", border: "1px solid #2a2a3d", borderRadius: 8, fontSize: 12 }}
                    labelStyle={{ color: "#fff" }}
                    cursor={{ fill: "rgba(99,102,241,0.08)" }}
                  />
                  <Bar dataKey="tasks" radius={[4, 4, 0, 0]}>
                    {(data?.daily ?? []).map((_, i) => (
                      <Cell key={i} fill={i === 6 ? "#6366f1" : "#6366f140"} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Top agents */}
          <div className="orion-card p-5">
            <h3 className="text-white text-sm font-medium mb-4">Top agents</h3>
            {!data?.top_agents.length ? (
              <div className="flex items-center justify-center h-48 text-orion-muted text-sm">Aucune donnée</div>
            ) : (
              <div className="space-y-3 mt-2">
                {data.top_agents.map((a, i) => {
                  const max = data.top_agents[0].runs;
                  return (
                    <div key={a.agent_id}>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="font-mono text-white">{a.agent_id}</span>
                        <span className="text-orion-muted">{a.runs} run{a.runs !== 1 ? "s" : ""}</span>
                      </div>
                      <div className="h-2 bg-orion-border rounded-full overflow-hidden">
                        <div
                          className="h-full rounded-full transition-all duration-700"
                          style={{ width: `${(a.runs / max) * 100}%`, background: AGENT_COLORS[i % AGENT_COLORS.length] }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Tool plugins */}
        <div className="orion-card overflow-hidden">
          <div className="px-5 py-4 border-b border-orion-border">
            <h3 className="text-white text-sm font-medium">Plugins d'outils disponibles</h3>
          </div>
          <div className="p-5 grid grid-cols-1 md:grid-cols-2 gap-3">
            {tools.map((t) => (
              <div key={t.name} className="flex items-start gap-3 p-3 rounded-lg bg-orion-bg border border-orion-border/50">
                <div className="w-2 h-2 rounded-full bg-orion-green mt-1.5 flex-shrink-0" />
                <div>
                  <p className="text-white text-xs font-mono font-medium">{t.name}</p>
                  <p className="text-orion-muted text-xs mt-0.5">{t.doc || "—"}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}
