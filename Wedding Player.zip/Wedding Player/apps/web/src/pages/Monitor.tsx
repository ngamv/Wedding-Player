import { useEffect, useState } from "react";
import { api } from "@/api/client";
import type { AgentMetric } from "@/api/client";
import { useOrionStore } from "@/store/useOrionStore";
import { Header } from "@/components/layout/Header";
import { RefreshCw, CheckCircle, XCircle, Clock } from "lucide-react";

function formatMs(ms: number): string {
  if (ms < 1000) return `${ms}ms`;
  return `${(ms / 1000).toFixed(1)}s`;
}

function formatDate(d: string | null): string {
  if (!d) return "—";
  return new Date(d).toLocaleString("fr-FR", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
}

export function Monitor() {
  const { health, stats, setHealth, setStats } = useOrionStore();
  const [metrics, setMetrics] = useState<AgentMetric[]>([]);
  const [refreshing, setRefreshing] = useState(false);

  async function load() {
    setRefreshing(true);
    await Promise.all([
      api.getHealth().then(setHealth).catch(() => {}),
      api.getStats().then(setStats).catch(() => {}),
      api.getMetrics().then(setMetrics).catch(() => {}),
    ]);
    setRefreshing(false);
  }

  useEffect(() => { load(); }, []);

  const totalRuns = metrics.reduce((s, m) => s + m.total_runs, 0);
  const totalFails = metrics.reduce((s, m) => s + m.fail_count, 0);
  const avgSuccessRate = metrics.length
    ? Math.round(metrics.reduce((s, m) => s + m.success_rate, 0) / metrics.length)
    : 0;
  const avgTime = metrics.length
    ? Math.round(metrics.reduce((s, m) => s + m.avg_time_ms, 0) / metrics.length)
    : 0;

  return (
    <div className="flex-1 flex flex-col">
      <Header title="Monitoring système">
        <button
          onClick={load}
          disabled={refreshing}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-orion-muted hover:text-white border border-orion-border rounded-lg hover:bg-white/5 transition-colors"
        >
          <RefreshCw size={12} className={refreshing ? "animate-spin" : ""} />
          Actualiser
        </button>
      </Header>
      <main className="flex-1 p-6 space-y-6 overflow-auto">

        {/* KPIs métriques */}
        {metrics.length > 0 && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { label: "Exécutions totales", value: totalRuns, icon: <Clock size={14} /> },
              { label: "Taux de succès moyen", value: `${avgSuccessRate}%`, icon: <CheckCircle size={14} className="text-orion-green" /> },
              { label: "Erreurs totales", value: totalFails, icon: <XCircle size={14} className="text-orion-red" /> },
              { label: "Temps moyen global", value: formatMs(avgTime), icon: <Clock size={14} className="text-orion-gold" /> },
            ].map(({ label, value, icon }) => (
              <div key={label} className="orion-card p-4">
                <div className="flex items-center gap-2 mb-2 text-orion-muted">{icon}<span className="text-xs uppercase tracking-wider">{label}</span></div>
                <p className="text-white text-xl font-semibold">{value}</p>
              </div>
            ))}
          </div>
        )}

        {/* Métriques par agent */}
        <div className="orion-card overflow-hidden">
          <div className="px-5 py-4 border-b border-orion-border flex items-center justify-between">
            <h3 className="text-white text-sm font-medium">Performances par agent</h3>
            <span className="text-orion-muted text-xs">{metrics.length} agents actifs</span>
          </div>
          {metrics.length === 0 ? (
            <div className="p-12 text-center">
              <Clock size={28} className="text-orion-muted/30 mx-auto mb-2" />
              <p className="text-orion-muted text-sm">Aucune exécution enregistrée</p>
              <p className="text-orion-muted/60 text-xs mt-1">Les métriques apparaissent après les premières tâches</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-orion-border text-orion-muted text-xs uppercase tracking-wider">
                    <th className="px-5 py-3 text-left">Agent</th>
                    <th className="px-5 py-3 text-right">Exécutions</th>
                    <th className="px-5 py-3 text-left min-w-[140px]">Taux de succès</th>
                    <th className="px-5 py-3 text-right">Temps moy.</th>
                    <th className="px-5 py-3 text-left">Dernière utilisation</th>
                  </tr>
                </thead>
                <tbody>
                  {metrics.map((m) => (
                    <tr key={m.agent_id} className="border-b border-orion-border/50 hover:bg-white/3 transition-colors">
                      <td className="px-5 py-3 font-mono text-xs text-orion-accent-light">{m.agent_id}</td>
                      <td className="px-5 py-3 text-white text-right">{m.total_runs}</td>
                      <td className="px-5 py-3">
                        <div className="flex items-center gap-2">
                          <div className="flex-1 h-1.5 bg-orion-border rounded-full overflow-hidden">
                            <div
                              className={`h-full rounded-full transition-all ${m.success_rate >= 80 ? "bg-orion-green" : m.success_rate >= 50 ? "bg-orion-gold" : "bg-orion-red"}`}
                              style={{ width: `${m.success_rate}%` }}
                            />
                          </div>
                          <span className={`text-xs w-10 text-right ${m.success_rate >= 80 ? "text-orion-green" : m.success_rate >= 50 ? "text-orion-gold" : "text-orion-red"}`}>
                            {m.success_rate}%
                          </span>
                        </div>
                      </td>
                      <td className="px-5 py-3 text-orion-muted text-right font-mono text-xs">{formatMs(m.avg_time_ms)}</td>
                      <td className="px-5 py-3 text-orion-muted text-xs">{formatDate(m.last_run)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Ollama + Agents */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="orion-card p-5">
            <h3 className="text-white text-sm font-medium mb-4">Ollama</h3>
            <div className="space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-orion-muted">Statut</span>
                <span className={health?.ollama ? "text-orion-green" : "text-orion-red"}>
                  {health?.ollama ? "Connecté" : "Hors ligne"}
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-orion-muted">Modèles</span>
                <span className="text-white">{health?.models?.length ?? 0}</span>
              </div>
              {health?.models?.map((m) => (
                <div key={m} className="text-xs font-mono text-orion-accent bg-orion-accent/10 px-3 py-1.5 rounded-lg">{m}</div>
              ))}
            </div>
          </div>

          <div className="orion-card p-5">
            <h3 className="text-white text-sm font-medium mb-4">Agents par catégorie</h3>
            <div className="space-y-2.5">
              {stats && Object.entries(stats.by_category).map(([cat, count]) => (
                <div key={cat} className="flex justify-between items-center text-sm">
                  <span className="text-orion-muted capitalize">{cat}</span>
                  <div className="flex items-center gap-2">
                    <div className="w-20 h-1.5 bg-orion-border rounded-full overflow-hidden">
                      <div className="h-full bg-orion-accent rounded-full" style={{ width: `${(count / 5) * 100}%` }} />
                    </div>
                    <span className="text-white text-xs w-4 text-right">{count}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

      </main>
    </div>
  );
}
