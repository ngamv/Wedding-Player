import { useState } from "react";
import { GitCompareArrows, Play, Loader2, Copy, CheckCircle, XCircle, Bot, Cpu } from "lucide-react";
import { api } from "@/api/client";
import { useOrionStore } from "@/store/useOrionStore";
import { Header } from "@/components/layout/Header";

interface RunResult {
  agent_id: string;
  status: string;
  output: Record<string, unknown> | null;
}

interface AgentRun {
  id: string;
  label: string;
  status: "idle" | "running" | "done" | "error";
  result: string | null;
  elapsed: number | null;
  error: string | null;
}

function extractText(output: Record<string, unknown> | null): string {
  if (!output) return "";
  return (output.result as string) ?? JSON.stringify(output, null, 2);
}

const CLOUD_MODELS = [
  { value: "gpt-4o-mini", label: "GPT-4o mini", group: "OpenAI" },
  { value: "gpt-4o", label: "GPT-4o", group: "OpenAI" },
  { value: "claude-haiku-4-5-20251001", label: "Claude Haiku 4.5", group: "Anthropic" },
  { value: "claude-sonnet-4-6", label: "Claude Sonnet 4.6", group: "Anthropic" },
];

type Mode = "agents" | "models";

export function Compare() {
  const { agents } = useOrionStore();
  const [mode, setMode] = useState<Mode>("models");
  const [prompt, setPrompt] = useState("");

  // Agent mode
  const [selectedAgentIds, setSelectedAgentIds] = useState<string[]>([]);

  // Model mode
  const [selectedModels, setSelectedModels] = useState<string[]>([]);
  const [modelAgent, setModelAgent] = useState("");

  const [runs, setRuns] = useState<AgentRun[]>([]);
  const [running, setRunning] = useState(false);

  function toggleAgent(id: string) {
    setSelectedAgentIds((prev) =>
      prev.includes(id) ? prev.filter((a) => a !== id) : prev.length < 3 ? [...prev, id] : prev
    );
  }

  function toggleModel(val: string) {
    setSelectedModels((prev) =>
      prev.includes(val) ? prev.filter((m) => m !== val) : prev.length < 3 ? [...prev, val] : prev
    );
  }

  async function compare() {
    if (!prompt.trim()) return;
    const targets: Array<{ id: string; label: string; agent_id: string; model?: string }> =
      mode === "agents"
        ? selectedAgentIds.map((id) => ({
            id,
            label: agents.find((a) => a.id === id)?.name ?? id,
            agent_id: id,
          }))
        : selectedModels.map((m) => ({
            id: m,
            label: CLOUD_MODELS.find((c) => c.value === m)?.label ?? m,
            agent_id: modelAgent || "orchestrator",
            model: m,
          }));

    if (targets.length < 2) return;
    setRunning(true);

    const initial: AgentRun[] = targets.map((t) => ({
      id: t.id,
      label: t.label,
      status: "running",
      result: null,
      elapsed: null,
      error: null,
    }));
    setRuns(initial);

    await Promise.all(
      targets.map(async (target, idx) => {
        const t0 = performance.now();
        try {
          const data = await api.post<RunResult>("/tasks/", {
            title: prompt,
            agent_id: target.agent_id,
            ...(target.model ? { model: target.model } : {}),
          });
          const elapsed = Math.round(performance.now() - t0);
          setRuns((prev) =>
            prev.map((r, i) =>
              i === idx ? { ...r, status: "done", result: extractText(data.output), elapsed } : r
            )
          );
        } catch (e) {
          setRuns((prev) =>
            prev.map((r, i) =>
              i === idx
                ? { ...r, status: "error", error: e instanceof Error ? e.message : "Erreur", elapsed: Math.round(performance.now() - t0) }
                : r
            )
          );
        }
      })
    );
    setRunning(false);
  }

  const colClass =
    runs.length === 2 ? "grid-cols-2" : runs.length === 3 ? "grid-cols-3" : "grid-cols-1";

  const canRun =
    prompt.trim().length > 0 &&
    (mode === "agents" ? selectedAgentIds.length >= 2 : selectedModels.length >= 2);

  return (
    <div className="flex-1 flex flex-col">
      <Header title="Comparaison" />

      <main className="flex-1 p-6 space-y-6 overflow-auto">
        <div className="orion-card p-5 space-y-5">
          {/* Mode toggle */}
          <div className="flex items-center gap-1 p-1 bg-orion-bg border border-orion-border rounded-lg w-fit">
            {([["agents", Bot, "Agents"], ["models", Cpu, "Modèles"]] as const).map(([m, Icon, label]) => (
              <button
                key={m}
                onClick={() => { setMode(m); setRuns([]); }}
                className={`flex items-center gap-1.5 px-4 py-1.5 text-xs rounded-md transition-colors ${
                  mode === m
                    ? "bg-orion-accent/20 text-orion-accent-light font-medium"
                    : "text-orion-muted hover:text-white"
                }`}
              >
                <Icon size={12} /> {label}
              </button>
            ))}
          </div>

          {/* Agent mode: pick agents */}
          {mode === "agents" && (
            <div>
              <label className="block text-orion-muted text-xs mb-2">
                Agents à comparer <span className="text-orion-muted/50">(2–3 agents)</span>
              </label>
              <div className="flex flex-wrap gap-2">
                {agents.map((a) => {
                  const sel = selectedAgentIds.includes(a.id);
                  const disabled = !sel && selectedAgentIds.length >= 3;
                  return (
                    <button
                      key={a.id}
                      onClick={() => toggleAgent(a.id)}
                      disabled={disabled}
                      className={`text-xs px-3 py-1.5 rounded-lg border transition-colors ${
                        sel
                          ? "border-orion-accent/50 bg-orion-accent/15 text-orion-accent-light"
                          : disabled
                          ? "border-orion-border/40 text-orion-muted/30 cursor-not-allowed"
                          : "border-orion-border text-orion-muted hover:text-white hover:border-orion-border/80"
                      }`}
                    >
                      {a.name}
                    </button>
                  );
                })}
              </div>
              {selectedAgentIds.length > 0 && (
                <p className="text-orion-muted/50 text-[10px] mt-2">Sélectionné{selectedAgentIds.length > 1 ? "s" : ""} : {selectedAgentIds.length}/3</p>
              )}
            </div>
          )}

          {/* Model mode: pick models + optional agent */}
          {mode === "models" && (
            <div className="space-y-4">
              <div>
                <label className="block text-orion-muted text-xs mb-2">
                  Modèles à comparer <span className="text-orion-muted/50">(2–3 modèles)</span>
                </label>
                <div className="flex flex-wrap gap-2">
                  {CLOUD_MODELS.map((m) => {
                    const sel = selectedModels.includes(m.value);
                    const disabled = !sel && selectedModels.length >= 3;
                    return (
                      <button
                        key={m.value}
                        onClick={() => toggleModel(m.value)}
                        disabled={disabled}
                        className={`text-xs px-3 py-1.5 rounded-lg border transition-colors ${
                          sel
                            ? "border-orion-accent/50 bg-orion-accent/15 text-orion-accent-light"
                            : disabled
                            ? "border-orion-border/40 text-orion-muted/30 cursor-not-allowed"
                            : "border-orion-border text-orion-muted hover:text-white"
                        }`}
                      >
                        <span className="text-orion-muted/50 mr-1">{m.group}</span>
                        {m.label}
                      </button>
                    );
                  })}
                </div>
                {selectedModels.length > 0 && (
                  <p className="text-orion-muted/50 text-[10px] mt-2">Sélectionné{selectedModels.length > 1 ? "s" : ""} : {selectedModels.length}/3</p>
                )}
              </div>
              <div>
                <label className="block text-orion-muted text-xs mb-2">
                  Agent routeur <span className="text-orion-muted/50">(optionnel — orchestre le prompt)</span>
                </label>
                <select
                  value={modelAgent}
                  onChange={(e) => setModelAgent(e.target.value)}
                  className="px-3 py-2 bg-orion-bg border border-orion-border rounded-lg text-sm text-white focus:outline-none focus:border-orion-accent/50"
                >
                  <option value="">Auto (orchestrator)</option>
                  {agents.map((a) => <option key={a.id} value={a.id}>{a.name}</option>)}
                </select>
              </div>
            </div>
          )}

          {/* Common prompt */}
          <div>
            <label className="block text-orion-muted text-xs mb-2">Prompt commun</label>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              rows={4}
              placeholder="Ex: Rédige un pitch court pour une startup de livraison de repas…"
              className="w-full px-3 py-2.5 bg-orion-bg border border-orion-border rounded-lg text-sm text-white placeholder-orion-muted focus:outline-none focus:border-orion-accent/50 resize-none font-mono"
              onKeyDown={(e) => { if ((e.ctrlKey || e.metaKey) && e.key === "Enter") { e.preventDefault(); compare(); } }}
            />
            <p className="text-orion-muted/50 text-[10px] mt-1">Ctrl+Entrée pour lancer</p>
          </div>

          <button
            onClick={compare}
            disabled={running || !canRun}
            className="flex items-center gap-2 px-5 py-2.5 bg-orion-accent hover:bg-orion-accent/80 disabled:opacity-40 text-white rounded-lg text-sm font-medium transition-colors"
          >
            {running ? <Loader2 size={14} className="animate-spin" /> : <Play size={14} />}
            {running
              ? "Comparaison en cours…"
              : `Comparer ${mode === "agents" ? `(${selectedAgentIds.length} agents)` : `(${selectedModels.length} modèles)`}`}
          </button>
        </div>

        {/* Results */}
        {runs.length > 0 && (
          <div className={`grid ${colClass} gap-4`}>
            {runs.map((run) => (
              <div key={run.id} className="orion-card flex flex-col overflow-hidden">
                <div className={`px-4 py-3 border-b border-orion-border flex items-center justify-between ${
                  run.status === "done" ? "bg-orion-green/5" :
                  run.status === "error" ? "bg-orion-red/5" : "bg-orion-accent/5"
                }`}>
                  <div className="flex items-center gap-2 min-w-0">
                    {run.status === "done" && <CheckCircle size={13} className="text-orion-green flex-shrink-0" />}
                    {run.status === "error" && <XCircle size={13} className="text-orion-red flex-shrink-0" />}
                    {run.status === "running" && <Loader2 size={13} className="text-orion-accent animate-spin flex-shrink-0" />}
                    <span className="text-white text-sm font-medium truncate">{run.label}</span>
                  </div>
                  {run.elapsed !== null && (
                    <span className="text-orion-muted text-xs flex-shrink-0 ml-2">{(run.elapsed / 1000).toFixed(1)}s</span>
                  )}
                </div>

                <div className="flex-1 p-4 overflow-auto min-h-[12rem]">
                  {run.status === "running" && (
                    <div className="flex items-center justify-center h-full">
                      <div className="w-6 h-6 rounded-full border-2 border-orion-accent/30 border-t-orion-accent animate-spin" />
                    </div>
                  )}
                  {run.status === "error" && (
                    <p className="text-orion-red text-xs font-mono">{run.error}</p>
                  )}
                  {run.status === "done" && run.result && (
                    <pre className="text-white text-xs whitespace-pre-wrap font-mono leading-relaxed break-words">
                      {run.result}
                    </pre>
                  )}
                </div>

                {run.status === "done" && run.result && (
                  <div className="px-4 pb-3 border-t border-orion-border/50 pt-2">
                    <button
                      onClick={() => navigator.clipboard.writeText(run.result!)}
                      className="flex items-center gap-1 text-[10px] text-orion-muted hover:text-white transition-colors"
                    >
                      <Copy size={10} /> Copier
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {runs.length === 0 && (
          <div className="orion-card p-12 flex flex-col items-center text-center text-orion-muted gap-3">
            <GitCompareArrows size={36} className="opacity-20" />
            <p className="text-sm">
              {mode === "agents"
                ? "Sélectionnez 2 ou 3 agents, entrez un prompt, et lancez la comparaison"
                : "Sélectionnez 2 ou 3 modèles, entrez un prompt, et comparez les réponses en parallèle"}
            </p>
            <p className="text-xs opacity-60">Les exécutions sont parallèles — les résultats apparaissent au fur et à mesure</p>
          </div>
        )}
      </main>
    </div>
  );
}
