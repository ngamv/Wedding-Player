import { useState, useEffect } from "react";
import { Download, Trash2, RefreshCw, HardDrive, Loader2, CheckCircle, AlertCircle, Package } from "lucide-react";
import { api } from "@/api/client";
import { Header } from "@/components/layout/Header";
import { toast } from "@/components/ui/Toast";

interface OllamaModel {
  name: string;
  size: number;
  modified_at: string;
  digest: string;
  family: string;
  parameter_size: string;
  quantization_level: string;
}

function fmtSize(bytes: number): string {
  if (bytes === 0) return "—";
  const gb = bytes / 1024 ** 3;
  if (gb >= 1) return `${gb.toFixed(1)} GB`;
  const mb = bytes / 1024 ** 2;
  return `${mb.toFixed(0)} MB`;
}

function fmtDate(iso: string): string {
  if (!iso) return "—";
  try {
    return new Date(iso).toLocaleDateString("fr-FR", { day: "2-digit", month: "short", year: "numeric" });
  } catch { return "—"; }
}

const POPULAR_MODELS = [
  "llama3.2", "llama3.1", "llama3", "mistral", "mixtral",
  "phi3", "gemma2", "qwen2.5", "deepseek-r1", "codellama",
  "nomic-embed-text", "mxbai-embed-large",
];

export function OllamaModels() {
  const [models, setModels] = useState<OllamaModel[]>([]);
  const [loading, setLoading] = useState(false);
  const [pullName, setPullName] = useState("");
  const [pulling, setPulling] = useState(false);
  const [deleting, setDeleting] = useState<string | null>(null);
  const [confirm, setConfirm] = useState<string | null>(null);

  async function load() {
    setLoading(true);
    try {
      const res = await api.get<{ models: OllamaModel[] }>("/system/ollama/models");
      setModels(res.models);
    } catch {
      toast.error("Impossible de contacter Ollama");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); }, []);

  async function pull() {
    const name = pullName.trim();
    if (!name) return;
    setPulling(true);
    try {
      await api.post("/system/ollama/pull", { name });
      toast.success(`Modèle "${name}" téléchargé`);
      setPullName("");
      await load();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Erreur lors du pull");
    } finally {
      setPulling(false);
    }
  }

  async function deleteModel(name: string) {
    setDeleting(name);
    setConfirm(null);
    try {
      await api.delete(`/system/ollama/models?name=${encodeURIComponent(name)}`);
      toast.success(`Modèle "${name}" supprimé`);
      setModels((prev) => prev.filter((m) => m.name !== name));
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Erreur lors de la suppression");
    } finally {
      setDeleting(null);
    }
  }

  const totalSize = models.reduce((s, m) => s + m.size, 0);

  return (
    <div className="flex-1 flex flex-col">
      <Header title="Gestionnaire de modèles Ollama" />

      <main className="flex-1 p-6 space-y-6 overflow-auto">
        {/* Summary */}
        <div className="grid grid-cols-3 gap-4">
          <div className="orion-card p-4">
            <p className="text-orion-muted text-xs mb-1">Modèles installés</p>
            <p className="text-white text-2xl font-bold">{models.length}</p>
          </div>
          <div className="orion-card p-4">
            <div className="flex items-center gap-1.5 mb-1">
              <HardDrive size={11} className="text-orion-accent-light" />
              <p className="text-orion-muted text-xs">Espace utilisé</p>
            </div>
            <p className="text-white text-2xl font-bold">{fmtSize(totalSize)}</p>
          </div>
          <div className="orion-card p-4">
            <p className="text-orion-muted text-xs mb-1">Statut Ollama</p>
            <div className="flex items-center gap-1.5 mt-1">
              {loading ? (
                <Loader2 size={13} className="text-orion-muted animate-spin" />
              ) : (
                <CheckCircle size={13} className="text-orion-green" />
              )}
              <p className="text-white text-sm font-medium">{loading ? "Chargement…" : "En ligne"}</p>
            </div>
          </div>
        </div>

        {/* Pull a model */}
        <div className="orion-card p-5 space-y-4">
          <div className="flex items-center gap-2">
            <Download size={15} className="text-orion-accent-light" />
            <h3 className="text-white text-sm font-medium">Télécharger un modèle</h3>
          </div>

          <div className="flex gap-3">
            <input
              type="text"
              value={pullName}
              onChange={(e) => setPullName(e.target.value)}
              placeholder="Ex: llama3.2, mistral, phi3:mini…"
              className="flex-1 px-3 py-2 bg-orion-bg border border-orion-border rounded-lg text-sm text-white placeholder-orion-muted focus:outline-none focus:border-orion-accent/50"
              onKeyDown={(e) => { if (e.key === "Enter") pull(); }}
              disabled={pulling}
            />
            <button
              onClick={pull}
              disabled={pulling || !pullName.trim()}
              className="flex items-center gap-2 px-4 py-2 bg-orion-accent hover:bg-orion-accent/80 disabled:opacity-40 text-white rounded-lg text-sm font-medium transition-colors"
            >
              {pulling ? <Loader2 size={14} className="animate-spin" /> : <Download size={14} />}
              {pulling ? "Téléchargement…" : "Pull"}
            </button>
          </div>

          {pulling && (
            <div className="flex items-center gap-2 text-xs text-orion-muted bg-orion-bg border border-orion-border rounded-lg px-3 py-2.5">
              <Loader2 size={12} className="animate-spin text-orion-accent" />
              Pull en cours — cela peut prendre plusieurs minutes selon la taille du modèle…
            </div>
          )}

          <div>
            <p className="text-xs text-orion-muted mb-2">Suggestions rapides :</p>
            <div className="flex flex-wrap gap-2">
              {POPULAR_MODELS.map((m) => (
                <button
                  key={m}
                  onClick={() => setPullName(m)}
                  className="text-[10px] px-2.5 py-1 rounded border border-orion-border text-orion-muted hover:text-white hover:border-orion-accent/50 transition-colors font-mono"
                >
                  {m}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Model list */}
        <div className="orion-card overflow-hidden">
          <div className="px-5 py-3 border-b border-orion-border flex items-center justify-between">
            <h3 className="text-white text-sm font-medium">Modèles installés</h3>
            <button
              onClick={load}
              className="p-1.5 rounded hover:bg-white/5 text-orion-muted hover:text-white transition-colors"
            >
              <RefreshCw size={13} className={loading ? "animate-spin" : ""} />
            </button>
          </div>

          {loading && models.length === 0 ? (
            <div className="p-12 flex items-center justify-center">
              <Loader2 size={20} className="animate-spin text-orion-accent" />
            </div>
          ) : models.length === 0 ? (
            <div className="p-12 flex flex-col items-center text-center text-orion-muted gap-3">
              <Package size={32} className="opacity-20" />
              <p className="text-sm">Aucun modèle installé</p>
              <p className="text-xs opacity-60">Utilisez le formulaire ci-dessus pour télécharger votre premier modèle</p>
            </div>
          ) : (
            <div className="divide-y divide-orion-border/40">
              {models.map((m) => (
                <div key={m.name} className="px-5 py-4 flex items-center justify-between hover:bg-white/2 transition-colors">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <p className="text-white text-sm font-medium font-mono truncate">{m.name}</p>
                      {m.parameter_size && (
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-orion-accent/15 text-orion-accent-light flex-shrink-0">
                          {m.parameter_size}
                        </span>
                      )}
                      {m.quantization_level && (
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-white/5 text-orion-muted flex-shrink-0">
                          {m.quantization_level}
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-3 text-[10px] text-orion-muted">
                      {m.family && <span>{m.family}</span>}
                      <span>{fmtSize(m.size)}</span>
                      <span>Modifié {fmtDate(m.modified_at)}</span>
                      {m.digest && <span className="font-mono opacity-60">{m.digest}</span>}
                    </div>
                  </div>

                  <div className="flex items-center gap-2 ml-4 flex-shrink-0">
                    {confirm === m.name ? (
                      <>
                        <span className="text-xs text-orion-red">Supprimer ?</span>
                        <button
                          onClick={() => deleteModel(m.name)}
                          disabled={deleting === m.name}
                          className="text-xs px-2.5 py-1 bg-orion-red/20 hover:bg-orion-red/30 text-orion-red rounded border border-orion-red/30 transition-colors"
                        >
                          {deleting === m.name ? <Loader2 size={11} className="animate-spin" /> : "Oui"}
                        </button>
                        <button
                          onClick={() => setConfirm(null)}
                          className="text-xs px-2.5 py-1 bg-white/5 hover:bg-white/10 text-orion-muted rounded border border-orion-border transition-colors"
                        >
                          Non
                        </button>
                      </>
                    ) : (
                      <button
                        onClick={() => setConfirm(m.name)}
                        disabled={!!deleting}
                        className="p-1.5 rounded hover:bg-orion-red/10 text-orion-muted hover:text-orion-red transition-colors"
                        title="Supprimer ce modèle"
                      >
                        <Trash2 size={13} />
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Warning */}
        <div className="flex items-start gap-2.5 px-4 py-3 rounded-lg bg-yellow-500/5 border border-yellow-500/20 text-yellow-400 text-xs">
          <AlertCircle size={13} className="flex-shrink-0 mt-0.5" />
          <p>La suppression d'un modèle est irréversible. ORION AI utilisera le modèle par défaut configuré dans <code className="font-mono bg-white/10 px-1 rounded">OLLAMA_MODEL</code> si le modèle actif est supprimé.</p>
        </div>
      </main>
    </div>
  );
}
