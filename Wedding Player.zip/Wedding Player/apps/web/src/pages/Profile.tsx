import { useState } from "react";
import { useAuthStore } from "@/store/useAuthStore";
import { api } from "@/api/client";
import { toast } from "@/components/ui/Toast";
import { User, Lock, Save, ShieldCheck, ShieldOff, QrCode } from "lucide-react";

export function Profile() {
  const { user, setUser } = useAuthStore();
  const [username, setUsername] = useState(user?.username ?? "");
  const [email, setEmail] = useState(user?.email ?? "");
  const [currentPw, setCurrentPw] = useState("");
  const [newPw, setNewPw] = useState("");
  const [confirmPw, setConfirmPw] = useState("");
  const [saving, setSaving] = useState(false);

  // 2FA state
  const [totpStep, setTotpStep] = useState<"idle" | "setup" | "disable">("idle");
  const [totpQr, setTotpQr] = useState("");
  const [totpCode, setTotpCode] = useState("");
  const [totpEnabled, setTotpEnabled] = useState(false);

  async function startSetup2FA() {
    try {
      const data = await api.post<{ qr_data_url: string }>("/auth/totp/setup");
      setTotpQr(data.qr_data_url);
      setTotpStep("setup");
    } catch {
      toast.error("Erreur lors de la configuration 2FA");
    }
  }

  async function confirm2FA() {
    try {
      await api.post("/auth/totp/verify", { code: totpCode });
      setTotpEnabled(true);
      setTotpStep("idle");
      setTotpCode("");
      toast.success("2FA activé !");
    } catch {
      toast.error("Code invalide");
    }
  }

  async function disable2FA() {
    try {
      await api.post("/auth/totp/disable", { code: totpCode });
      setTotpEnabled(false);
      setTotpStep("idle");
      setTotpCode("");
      toast.success("2FA désactivé");
    } catch {
      toast.error("Code invalide");
    }
  }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    if (newPw && newPw !== confirmPw) {
      toast.error("Les mots de passe ne correspondent pas");
      return;
    }
    setSaving(true);
    try {
      const body: Record<string, string> = {};
      if (username !== user?.username) body.username = username;
      if (email !== user?.email) body.email = email;
      if (newPw) {
        body.current_password = currentPw;
        body.new_password = newPw;
      }
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const updated = await api.put<any>("/auth/me", body);
      setUser(updated);
      toast.success("Profil mis à jour");
      setCurrentPw("");
      setNewPw("");
      setConfirmPw("");
    } catch (err: unknown) {
      const msg =
        err instanceof Error ? err.message : "Erreur lors de la mise à jour";
      toast.error(msg);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="flex-1 overflow-auto p-6 max-w-2xl mx-auto w-full">
      <h1 className="text-xl font-bold text-white mb-6">Mon profil</h1>

      <form onSubmit={handleSave} className="space-y-6">
        {/* Info section */}
        <div className="bg-orion-surface border border-orion-border rounded-xl p-5 space-y-4">
          <div className="flex items-center gap-2 mb-2">
            <User size={16} className="text-orion-accent-light" />
            <h2 className="text-sm font-semibold text-white">Informations</h2>
          </div>

          <div>
            <label className="block text-orion-muted text-xs mb-1.5">
              Nom d'utilisateur
            </label>
            <input
              className="w-full bg-orion-bg border border-orion-border rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-orion-accent/60"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              minLength={3}
              required
            />
          </div>

          <div>
            <label className="block text-orion-muted text-xs mb-1.5">
              Email
            </label>
            <input
              type="email"
              className="w-full bg-orion-bg border border-orion-border rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-orion-accent/60"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>

          <div>
            <label className="block text-orion-muted text-xs mb-1.5">
              Rôle
            </label>
            <input
              disabled
              className="w-full bg-orion-bg/50 border border-orion-border/50 rounded-lg px-3 py-2 text-sm text-orion-muted"
              value={user?.role ?? "user"}
            />
          </div>
        </div>

        {/* Password section */}
        <div className="bg-orion-surface border border-orion-border rounded-xl p-5 space-y-4">
          <div className="flex items-center gap-2 mb-2">
            <Lock size={16} className="text-orion-accent-light" />
            <h2 className="text-sm font-semibold text-white">
              Changer le mot de passe
            </h2>
            <span className="text-orion-muted text-xs">(optionnel)</span>
          </div>

          <div>
            <label className="block text-orion-muted text-xs mb-1.5">
              Mot de passe actuel
            </label>
            <input
              type="password"
              className="w-full bg-orion-bg border border-orion-border rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-orion-accent/60"
              value={currentPw}
              onChange={(e) => setCurrentPw(e.target.value)}
              placeholder="••••••••"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-orion-muted text-xs mb-1.5">
                Nouveau mot de passe
              </label>
              <input
                type="password"
                className="w-full bg-orion-bg border border-orion-border rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-orion-accent/60"
                value={newPw}
                onChange={(e) => setNewPw(e.target.value)}
                placeholder="min. 6 caractères"
                minLength={newPw ? 6 : undefined}
              />
            </div>
            <div>
              <label className="block text-orion-muted text-xs mb-1.5">
                Confirmer
              </label>
              <input
                type="password"
                className="w-full bg-orion-bg border border-orion-border rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-orion-accent/60"
                value={confirmPw}
                onChange={(e) => setConfirmPw(e.target.value)}
                placeholder="••••••••"
              />
            </div>
          </div>
        </div>

        <button
          type="submit"
          disabled={saving}
          className="flex items-center gap-2 px-5 py-2.5 bg-orion-accent hover:bg-orion-accent/80 disabled:opacity-50 text-white rounded-lg text-sm font-medium transition-colors"
        >
          <Save size={14} />
          {saving ? "Enregistrement…" : "Enregistrer les modifications"}
        </button>
      </form>

      {/* 2FA section */}
      <div className="mt-6 bg-orion-surface border border-orion-border rounded-xl p-5 space-y-4">
        <div className="flex items-center gap-2">
          <ShieldCheck size={16} className="text-orion-accent-light" />
          <h2 className="text-sm font-semibold text-white">Authentification à deux facteurs (2FA / TOTP)</h2>
          {totpEnabled && (
            <span className="text-xs px-2 py-0.5 rounded-full bg-orion-green/15 text-orion-green">Activé</span>
          )}
        </div>

        {totpStep === "idle" && (
          <div className="flex gap-3">
            {!totpEnabled ? (
              <button
                onClick={startSetup2FA}
                className="flex items-center gap-2 px-4 py-2 bg-orion-accent hover:bg-orion-accent/80 text-white rounded-lg text-sm transition-colors"
              >
                <QrCode size={14} /> Configurer le 2FA
              </button>
            ) : (
              <button
                onClick={() => setTotpStep("disable")}
                className="flex items-center gap-2 px-4 py-2 bg-orion-red/15 hover:bg-orion-red/25 text-orion-red rounded-lg text-sm transition-colors"
              >
                <ShieldOff size={14} /> Désactiver le 2FA
              </button>
            )}
          </div>
        )}

        {totpStep === "setup" && totpQr && (
          <div className="space-y-3">
            <p className="text-orion-muted text-xs">Scannez ce QR code avec votre application d'authentification (Google Authenticator, Authy…)</p>
            <img src={totpQr} alt="QR 2FA" className="w-40 h-40 rounded-lg" />
            <div className="flex gap-2">
              <input
                value={totpCode}
                onChange={(e) => setTotpCode(e.target.value)}
                placeholder="Code à 6 chiffres"
                maxLength={6}
                className="px-3 py-2 bg-orion-bg border border-orion-border rounded-lg text-sm text-white font-mono focus:outline-none focus:border-orion-accent/50 w-40"
              />
              <button
                onClick={confirm2FA}
                disabled={totpCode.length !== 6}
                className="px-4 py-2 bg-orion-accent hover:bg-orion-accent/80 disabled:opacity-40 text-white rounded-lg text-sm transition-colors"
              >
                Vérifier et activer
              </button>
              <button
                onClick={() => { setTotpStep("idle"); setTotpCode(""); }}
                className="px-4 py-2 border border-orion-border rounded-lg text-sm text-orion-muted hover:text-white transition-colors"
              >
                Annuler
              </button>
            </div>
          </div>
        )}

        {totpStep === "disable" && (
          <div className="space-y-3">
            <p className="text-orion-muted text-xs">Entrez votre code TOTP pour confirmer la désactivation</p>
            <div className="flex gap-2">
              <input
                value={totpCode}
                onChange={(e) => setTotpCode(e.target.value)}
                placeholder="Code à 6 chiffres"
                maxLength={6}
                className="px-3 py-2 bg-orion-bg border border-orion-border rounded-lg text-sm text-white font-mono focus:outline-none focus:border-orion-accent/50 w-40"
              />
              <button
                onClick={disable2FA}
                disabled={totpCode.length !== 6}
                className="px-4 py-2 bg-orion-red/15 hover:bg-orion-red/25 disabled:opacity-40 text-orion-red rounded-lg text-sm transition-colors"
              >
                Confirmer
              </button>
              <button
                onClick={() => { setTotpStep("idle"); setTotpCode(""); }}
                className="px-4 py-2 border border-orion-border rounded-lg text-sm text-orion-muted hover:text-white transition-colors"
              >
                Annuler
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
