import { useState, useEffect, useCallback } from "react";
import { Plus, Trash2, Copy, Eye, EyeOff, Key, Loader2, Check } from "lucide-react";
import { Header } from "@/components/layout/Header";
import { toast } from "@/components/ui/Toast";

interface ApiKey {
  id: number;
  name: string;
  key_prefix: string;
  is_active: boolean;
  last_used_at: string | null;
  created_at: string;
}

interface ApiKeyCreated extends ApiKey {
  key: string;
}

async function req<T>(path: string, options: RequestInit = {}): Promise<T> {
  const token = (() => { try { const s = localStorage.getItem("orion-auth"); return s ? JSON.parse(s)?.state?.token : null; } catch { return null; } })();
  const res = await fetch(`/api/api-keys${path}`, {
    ...options,
    headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}), ...options.headers },
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.detail ?? `HTTP ${res.status}`);
  }
  if (res.status === 204) return undefined as T;
  return res.json();
}

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);
  async function copy() {
    await navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }
  return (
    <button onClick={copy} className="p-1.5 rounded hover:bg-white/5 text-orion-muted hover:text-white transition-colors">
      {copied ? <Check size={13} className="text-orion-green" /> : <Copy size={13} />}
    </button>
  );
}

export function ApiKeys() {
  const [keys, setKeys] = useState<ApiKey[]>([]);
  const [loading, setLoading] = useState(true);
  const [newName, setNewName] = useState("");
  const [creating, setCreating] = useState(false);
  const [newKey, setNewKey] = useState<ApiKeyCreated | null>(null);
  const [showKey, setShowKey] = useState(false);
  const [formError, setFormError] = useState("");

  const load = useCallback(async () => {
    const data = await req<ApiKey[]>("/").catch(() => []);
    setKeys(data);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    if (!newName.trim()) return;
    setCreating(true); setFormError("");
    try {
      const created = await req<ApiKeyCreated>("/", {
        method: "POST",
        body: JSON.stringify({ name: newName.trim() }),
      });
      setNewKey(created);
      setNewName("");
      toast.success("Clé API créée — copiez-la maintenant, elle ne sera plus affichée");
      load();
    } catch (err: unknown) {
      setFormError(err instanceof Error ? err.message : "Erreur");
    } finally {
      setCreating(false);
    }
  }

  async function handleRevoke(key: ApiKey) {
    if (!confirm(`Révoquer la clé "${key.name}" ?`)) return;
    await req(`/${key.id}`, { method: "DELETE" }).catch(() => {});
    toast.success("Clé révoquée");
    load();
  }

  return (
    <div className="flex-1 flex flex-col">
      <Header title="Clés API" />
      <main className="flex-1 p-6 overflow-auto space-y-6">

        {/* New key revealed */}
        {newKey && (
          <div className="orion-card p-5 border-orion-green/30 bg-orion-green/5 animate-slide-in">
            <div className="flex items-start gap-3">
              <Key size={16} className="text-orion-green mt-0.5 flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-orion-green text-sm font-medium mb-1">Clé créée — copiez-la maintenant !</p>
                <p className="text-orion-muted text-xs mb-3">Elle ne sera plus affichée après fermeture de ce message.</p>
                <div className="flex items-center gap-2 bg-orion-bg border border-orion-border rounded-lg px-3 py-2">
                  <code className="text-white text-xs flex-1 truncate font-mono">
                    {showKey ? newKey.key : newKey.key.slice(0, 12) + "•".repeat(24)}
                  </code>
                  <button onClick={() => setShowKey((v) => !v)} className="text-orion-muted hover:text-white transition-colors">
                    {showKey ? <EyeOff size={13} /> : <Eye size={13} />}
                  </button>
                  <CopyButton text={newKey.key} />
                </div>
              </div>
              <button onClick={() => setNewKey(null)} className="text-orion-muted hover:text-white transition-colors text-lg leading-none">×</button>
            </div>
          </div>
        )}

        {/* Create form */}
        <div className="orion-card p-5">
          <h3 className="text-white text-sm font-medium mb-4">Créer une clé API</h3>
          <form onSubmit={handleCreate} className="flex gap-3">
            <input
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              required
              placeholder="Ex: Application mobile, Script Python..."
              className="flex-1 bg-orion-bg border border-orion-border rounded-lg px-3 py-2.5 text-sm text-white placeholder-orion-muted/50 focus:outline-none focus:border-orion-accent/50 transition-colors"
            />
            <button
              type="submit"
              disabled={creating || !newName.trim()}
              className="flex items-center gap-2 px-4 py-2 text-sm bg-orion-accent hover:bg-orion-accent/80 disabled:opacity-50 text-white rounded-lg transition-colors font-medium whitespace-nowrap"
            >
              {creating ? <Loader2 size={13} className="animate-spin" /> : <Plus size={13} />}
              Générer
            </button>
          </form>
          {formError && <p className="text-orion-red text-xs mt-2">{formError}</p>}
        </div>

        {/* Usage */}
        <div className="orion-card p-5">
          <h3 className="text-white text-sm font-medium mb-3">Utilisation</h3>
          <p className="text-orion-muted text-xs mb-2">Ajoutez l'en-tête <code className="text-orion-accent bg-orion-bg px-1 rounded">X-API-Key</code> à vos requêtes :</p>
          <div className="bg-orion-bg border border-orion-border rounded-lg px-4 py-3 font-mono text-xs text-slate-300 overflow-x-auto">
            <span className="text-orion-green">curl</span>{" "}
            <span className="text-orion-gold">-H</span>{" "}
            <span className="text-white">"X-API-Key: ok-votre-cle"</span>{" "}
            <span className="text-orion-accent">http://localhost:8000/agents/run</span>{" "}
            <span className="text-orion-gold">-d</span>{" "}
            <span className="text-white">'&#123;"task":"Analyse SEO de mon site"&#125;'</span>
          </div>
        </div>

        {/* Keys list */}
        <div className="orion-card p-5">
          <h3 className="text-white text-sm font-medium mb-4">Clés actives</h3>
          {loading ? (
            <div className="flex items-center justify-center py-8"><Loader2 size={20} className="animate-spin text-orion-accent" /></div>
          ) : keys.filter((k) => k.is_active).length === 0 ? (
            <div className="text-center py-8">
              <Key size={28} className="text-orion-muted/40 mx-auto mb-2" />
              <p className="text-orion-muted text-sm">Aucune clé active</p>
            </div>
          ) : (
            <div className="space-y-2">
              {keys.filter((k) => k.is_active).map((key) => (
                <div key={key.id} className="flex items-center justify-between py-3 px-4 rounded-xl bg-orion-bg border border-orion-border hover:border-white/10 transition-colors animate-slide-in">
                  <div className="flex items-center gap-3 min-w-0">
                    <Key size={14} className="text-orion-accent flex-shrink-0" />
                    <div className="min-w-0">
                      <p className="text-white text-sm font-medium truncate">{key.name}</p>
                      <div className="flex items-center gap-3">
                        <code className="text-orion-muted text-[11px] font-mono">{key.key_prefix}••••••••</code>
                        <span className="text-orion-muted/50 text-[10px]">
                          {key.last_used_at
                            ? `Utilisée ${new Date(key.last_used_at).toLocaleDateString("fr-FR")}`
                            : "Jamais utilisée"}
                        </span>
                      </div>
                    </div>
                  </div>
                  <button
                    onClick={() => handleRevoke(key)}
                    className="p-2 rounded-lg hover:bg-orion-red/10 text-orion-muted hover:text-orion-red transition-colors flex-shrink-0"
                    title="Révoquer"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
