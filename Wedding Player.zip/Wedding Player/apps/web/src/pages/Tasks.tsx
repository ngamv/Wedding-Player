import { useEffect, useState, useCallback, useRef } from "react";
import { Plus, Download, Search, ChevronDown, Terminal, RotateCcw, Loader2, Tag, X } from "lucide-react";
import { Link } from "react-router-dom";
import { api } from "@/api/client";
import type { Task } from "@/api/client";
import { useOrionStore } from "@/store/useOrionStore";
import { Header } from "@/components/layout/Header";
import { toast } from "@/components/ui/Toast";

function downloadUrl(url: string, filename: string) {
  const a = document.createElement("a");
  a.href = url; a.download = filename; a.click();
}

const STATUS_OPTIONS = ["", "pending", "running", "completed", "failed"];

const statusColor = (s: string) =>
  s === "completed" ? "bg-orion-green/15 text-orion-green" :
  s === "failed" ? "bg-orion-red/15 text-orion-red" :
  s === "running" ? "bg-orion-accent/15 text-orion-accent-light" :
  "bg-orion-gold/15 text-orion-gold";

export function Tasks() {
  const { agents } = useOrionStore();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [total, setTotal] = useState(0);
  const [hasMore, setHasMore] = useState(false);
  const pageRef = useRef(1);

  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [agentFilter, setAgentFilter] = useState("");

  const [tagFilter, setTagFilter] = useState("");

  const [title, setTitle] = useState("");
  const [agentId, setAgentId] = useState("");
  const [modelOverride, setModelOverride] = useState("");
  const [newTags, setNewTags] = useState<string[]>([]);
  const [tagInput, setTagInput] = useState("");
  const [creating, setCreating] = useState(false);
  const [loading, setLoading] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);
  const [retrying, setRetrying] = useState<number | null>(null);

  useEffect(() => {
    const t = setTimeout(() => setDebouncedSearch(search), 300);
    return () => clearTimeout(t);
  }, [search]);

  const load = useCallback(async (reset: boolean) => {
    const p = reset ? 1 : pageRef.current;
    if (reset) { setLoading(true); } else { setLoadingMore(true); }
    try {
      const res = await api.getTasks({
        search: debouncedSearch || undefined,
        status: statusFilter || undefined,
        agent_id: agentFilter || undefined,
        tag: tagFilter || undefined,
        page: p,
        page_size: 20,
      });
      setTasks((prev) => reset ? res.tasks : [...prev, ...res.tasks]);
      setTotal(res.total);
      setHasMore(p < res.pages);
      pageRef.current = p + 1;
    } catch {
      if (reset) toast.error("Erreur de chargement des tâches");
    } finally {
      setLoading(false);
      setLoadingMore(false);
    }
  }, [debouncedSearch, statusFilter, agentFilter, tagFilter]);

  useEffect(() => {
    pageRef.current = 1;
    load(true);
  }, [debouncedSearch, statusFilter, agentFilter, tagFilter]);

  async function retryTask(taskId: number) {
    setRetrying(taskId);
    try {
      await api.post(`/tasks/${taskId}/retry`);
      toast.success("Tâche relancée");
      pageRef.current = 1;
      await load(true);
    } catch {
      toast.error("Erreur lors du retry");
    } finally {
      setRetrying(null);
    }
  }

  async function createTask() {
    if (!title.trim()) return;
    setCreating(true);
    try {
      await api.post("/tasks/", {
        title,
        agent_id: agentId || undefined,
        model: modelOverride || undefined,
        tags: newTags.length > 0 ? newTags : undefined,
      });
      setTitle("");
      setNewTags([]);
      pageRef.current = 1;
      await load(true);
      toast.success("Tâche créée");
    } catch {
      toast.error("Erreur lors de la création");
    } finally {
      setCreating(false);
    }
  }

  return (
    <div className="flex-1 flex flex-col">
      <Header title="Gestion des tâches">
        <div className="flex items-center gap-2">
          <button
            onClick={() => { downloadUrl("/api/export/tasks.csv", "orion_tasks.csv"); toast.info("Export CSV en cours…"); }}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-orion-muted hover:text-white border border-orion-border rounded-lg hover:bg-white/5 transition-colors"
          >
            <Download size={12} /> CSV
          </button>
          <button
            onClick={() => { downloadUrl("/api/export/tasks.json", "orion_tasks.json"); toast.info("Export JSON en cours…"); }}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-orion-muted hover:text-white border border-orion-border rounded-lg hover:bg-white/5 transition-colors"
          >
            <Download size={12} /> JSON
          </button>
        </div>
      </Header>

      <main className="flex-1 p-6 space-y-4 overflow-auto">
        {/* Create */}
        <div className="orion-card p-5">
          <h3 className="text-white text-sm font-medium mb-4">Nouvelle tâche</h3>
          <div className="flex gap-3 flex-wrap">
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Décrivez la tâche…"
              className="flex-1 min-w-[200px] px-4 py-2.5 bg-orion-bg border border-orion-border rounded-lg text-sm text-white placeholder-orion-muted focus:outline-none focus:border-orion-accent/50"
              onKeyDown={(e) => e.key === "Enter" && createTask()}
            />
            <div className="relative">
              <select
                value={agentId}
                onChange={(e) => setAgentId(e.target.value)}
                className="appearance-none pl-3 pr-7 py-2.5 bg-orion-bg border border-orion-border rounded-lg text-sm text-white focus:outline-none focus:border-orion-accent/50"
              >
                <option value="">Auto-router</option>
                {agents.map((a) => (
                  <option key={a.id} value={a.id}>{a.name}</option>
                ))}
              </select>
              <ChevronDown size={12} className="absolute right-2 top-1/2 -translate-y-1/2 text-orion-muted pointer-events-none" />
            </div>
            <div className="relative">
              <select
                value={modelOverride}
                onChange={(e) => setModelOverride(e.target.value)}
                className="appearance-none pl-3 pr-7 py-2.5 bg-orion-bg border border-orion-border rounded-lg text-sm text-white focus:outline-none focus:border-orion-accent/50"
              >
                <option value="">Modèle par défaut</option>
                <option value="gpt-4o-mini">gpt-4o-mini</option>
                <option value="gpt-4o">gpt-4o</option>
                <option value="claude-haiku-4-5-20251001">claude-haiku</option>
              </select>
              <ChevronDown size={12} className="absolute right-2 top-1/2 -translate-y-1/2 text-orion-muted pointer-events-none" />
            </div>
            <button
              onClick={createTask}
              disabled={!title.trim() || creating}
              className="px-4 py-2.5 bg-orion-accent hover:bg-orion-accent/80 disabled:opacity-40 text-white rounded-lg text-sm flex items-center gap-2 transition-colors"
            >
              <Plus size={16} />
              {creating ? "En cours…" : "Créer"}
            </button>
          </div>
          {/* Tag input */}
          <div className="mt-3 flex items-center gap-2 flex-wrap">
            <Tag size={12} className="text-orion-muted flex-shrink-0" />
            {newTags.map((t) => (
              <span key={t} className="flex items-center gap-1 text-xs px-2 py-0.5 rounded-full bg-orion-accent/15 text-orion-accent-light">
                {t}
                <button onClick={() => setNewTags((prev) => prev.filter((x) => x !== t))} className="hover:text-white">
                  <X size={10} />
                </button>
              </span>
            ))}
            <input
              value={tagInput}
              onChange={(e) => setTagInput(e.target.value)}
              onKeyDown={(e) => {
                if ((e.key === "Enter" || e.key === ",") && tagInput.trim()) {
                  e.preventDefault();
                  const tag = tagInput.trim().toLowerCase().replace(/[^a-z0-9_-]/g, "");
                  if (tag && !newTags.includes(tag)) setNewTags((prev) => [...prev, tag]);
                  setTagInput("");
                }
              }}
              placeholder="Ajouter un tag (Entrée)"
              className="text-xs px-2 py-1 bg-orion-bg border border-orion-border/60 rounded-lg text-white placeholder-orion-muted/40 focus:outline-none focus:border-orion-accent/40 w-36"
            />
          </div>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-3">
          <div className="relative flex-1 min-w-[200px]">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-orion-muted" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Rechercher une tâche…"
              className="w-full pl-9 pr-4 py-2 bg-orion-surface border border-orion-border rounded-lg text-sm text-white placeholder-orion-muted focus:outline-none focus:border-orion-accent/50"
            />
          </div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 bg-orion-surface border border-orion-border rounded-lg text-sm text-white focus:outline-none focus:border-orion-accent/50"
          >
            {STATUS_OPTIONS.map((s) => (
              <option key={s} value={s}>{s || "Tous les statuts"}</option>
            ))}
          </select>
          <select
            value={agentFilter}
            onChange={(e) => setAgentFilter(e.target.value)}
            className="px-3 py-2 bg-orion-surface border border-orion-border rounded-lg text-sm text-white focus:outline-none focus:border-orion-accent/50"
          >
            <option value="">Tous les agents</option>
            {agents.map((a) => (
              <option key={a.id} value={a.id}>{a.name}</option>
            ))}
          </select>
          <div className="relative">
            <Tag size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-orion-muted" />
            <input
              value={tagFilter}
              onChange={(e) => setTagFilter(e.target.value)}
              placeholder="Tag…"
              className="pl-7 pr-3 py-2 bg-orion-surface border border-orion-border rounded-lg text-sm text-white placeholder-orion-muted focus:outline-none focus:border-orion-accent/50 w-28"
            />
          </div>
        </div>

        {/* Table */}
        <div className="orion-card overflow-hidden">
          <div className="px-5 py-4 border-b border-orion-border flex items-center justify-between">
            <h3 className="text-white text-sm font-medium">
              Historique
              <span className="text-orion-muted ml-2 font-normal">{total} tâche{total !== 1 ? "s" : ""}</span>
            </h3>
            {loading && <span className="text-orion-muted text-xs">Chargement…</span>}
          </div>

          {tasks.length === 0 && !loading ? (
            <div className="p-12 text-center text-orion-muted text-sm">Aucune tâche</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-orion-border text-orion-muted text-xs uppercase tracking-wider">
                    <th className="px-5 py-3 text-left">#</th>
                    <th className="px-5 py-3 text-left">Tâche</th>
                    <th className="px-5 py-3 text-left">Agent</th>
                    <th className="px-5 py-3 text-left">Statut</th>
                    <th className="px-5 py-3 text-left">Tags</th>
                    <th className="px-5 py-3 text-left">Date</th>
                    <th className="px-5 py-3 text-left">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {tasks.map((t) => (
                    <tr key={t.id} className="border-b border-orion-border/50 hover:bg-white/3 transition-colors">
                      <td className="px-5 py-3 text-orion-muted font-mono">{t.id}</td>
                      <td className="px-5 py-3 text-white max-w-xs truncate">{t.title}</td>
                      <td className="px-5 py-3 text-orion-muted font-mono text-xs">{t.agent_id}</td>
                      <td className="px-5 py-3">
                        <span className={`text-xs px-2 py-0.5 rounded-full ${statusColor(t.status)}`}>{t.status}</span>
                      </td>
                      <td className="px-5 py-3">
                        <div className="flex gap-1 flex-wrap">
                          {((t as any).tags ?? []).map((tag: string) => (
                            <button
                              key={tag}
                              onClick={() => setTagFilter(tagFilter === tag ? "" : tag)}
                              className={`text-[10px] px-1.5 py-0.5 rounded-full transition-colors ${
                                tagFilter === tag
                                  ? "bg-orion-accent/30 text-orion-accent-light"
                                  : "bg-orion-accent/10 text-orion-accent-light/70 hover:bg-orion-accent/20"
                              }`}
                            >
                              {tag}
                            </button>
                          ))}
                        </div>
                      </td>
                      <td className="px-5 py-3 text-orion-muted text-xs">
                        {new Date(t.created_at).toLocaleString("fr-FR")}
                      </td>
                      <td className="px-5 py-3">
                        <div className="flex items-center gap-1">
                          <Link
                            to={`/tasks/${t.id}/logs`}
                            className="p-1.5 rounded-lg text-orion-muted hover:text-white hover:bg-white/5 transition-colors inline-flex"
                            title="Voir les logs"
                          >
                            <Terminal size={12} />
                          </Link>
                          {t.status === "failed" && (
                            <button
                              onClick={() => retryTask(t.id)}
                              disabled={retrying === t.id}
                              className="p-1.5 rounded-lg text-orion-muted hover:text-orion-gold hover:bg-orion-gold/10 transition-colors disabled:opacity-40"
                              title="Relancer la tâche"
                            >
                              <RotateCcw size={12} className={retrying === t.id ? "animate-spin" : ""} />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* Load more */}
          {hasMore && (
            <div className="px-5 py-3 border-t border-orion-border flex justify-center">
              <button
                onClick={() => load(false)}
                disabled={loadingMore}
                className="flex items-center gap-2 px-4 py-2 text-xs text-orion-muted hover:text-white border border-orion-border rounded-lg hover:bg-white/5 transition-colors disabled:opacity-40"
              >
                {loadingMore ? <Loader2 size={12} className="animate-spin" /> : null}
                {loadingMore ? "Chargement…" : `Charger plus (${total - tasks.length} restante${total - tasks.length > 1 ? "s" : ""})`}
              </button>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
