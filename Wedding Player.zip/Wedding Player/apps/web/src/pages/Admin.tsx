import { useEffect, useState } from "react";
import { Users, BarChart2, CheckCircle, Clock, ToggleLeft, ToggleRight, Trash2, HardDrive, Download } from "lucide-react";
import { api } from "@/api/client";
import type { AdminUser, AdminStats } from "@/api/client";
import { Header } from "@/components/layout/Header";
import { toast } from "@/components/ui/Toast";

interface BackupEntry { name: string; size_kb: number; created_at: string }

function adminReq<T>(path: string, options: RequestInit = {}): Promise<T> {
  const token = (() => { try { const s = localStorage.getItem("orion-auth"); return s ? JSON.parse(s)?.state?.token : null; } catch { return null; } })();
  return fetch(`/api/admin${path}`, {
    ...options,
    headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}), ...options.headers },
  }).then(async (res) => {
    if (!res.ok) { const b = await res.json().catch(() => ({})); throw new Error(b.detail ?? `HTTP ${res.status}`); }
    if (res.status === 204) return undefined as T;
    return res.json();
  });
}

const ROLES = ["user", "admin", "readonly"];

const roleBadge = (role: string) =>
  role === "admin" ? "bg-blue-500/15 text-blue-400" :
  role === "readonly" ? "bg-gray-500/15 text-gray-400" :
  "bg-orion-green/15 text-orion-green";

export function Admin() {
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [backups, setBackups] = useState<BackupEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [creatingBackup, setCreatingBackup] = useState(false);

  async function load() {
    setLoading(true);
    const [sRes, uRes, bRes] = await Promise.allSettled([
      api.adminStats(),
      api.adminUsers(),
      adminReq<{ backups: BackupEntry[] }>("/backup/list"),
    ]);
    if (sRes.status === "fulfilled") setStats(sRes.value);
    else toast.error("Impossible de charger les statistiques");
    if (uRes.status === "fulfilled") setUsers(uRes.value);
    else toast.error("Impossible de charger les utilisateurs");
    if (bRes.status === "fulfilled") setBackups(bRes.value.backups);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  async function changeRole(userId: number, role: string) {
    try {
      await api.adminSetRole(userId, role);
      setUsers((prev) => prev.map((u) => u.id === userId ? { ...u, role } : u));
      toast.success("Rôle mis à jour");
    } catch {
      toast.error("Erreur lors de la mise à jour");
    }
  }

  async function toggleActive(userId: number) {
    try {
      const r = await adminReq<{ is_active: boolean }>(`/users/${userId}/active`, { method: "PATCH" });
      setUsers((prev) => prev.map((u) => u.id === userId ? { ...u, is_active: r.is_active } : u));
      toast.success(r.is_active ? "Compte réactivé" : "Compte désactivé");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Erreur");
    }
  }

  async function deleteUser(userId: number, username: string) {
    if (!confirm(`Supprimer définitivement l'utilisateur "${username}" et toutes ses données ?`)) return;
    try {
      await adminReq(`/users/${userId}`, { method: "DELETE" });
      setUsers((prev) => prev.filter((u) => u.id !== userId));
      toast.success("Utilisateur supprimé");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Erreur");
    }
  }

  async function createBackup() {
    setCreatingBackup(true);
    try {
      const r = await adminReq<{ backup: string; size_kb: number }>("/backup", { method: "POST" });
      toast.success(`Backup créé (${r.size_kb} KB)`);
      const b = await adminReq<{ backups: BackupEntry[] }>("/backup/list");
      setBackups(b.backups);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Erreur backup");
    } finally {
      setCreatingBackup(false);
    }
  }

  function downloadBackup(filename: string) {
    const token = (() => { try { const s = localStorage.getItem("orion-auth"); return s ? JSON.parse(s)?.state?.token : null; } catch { return null; } })();
    fetch(`/api/admin/backup/download/${filename}`, { headers: token ? { Authorization: `Bearer ${token}` } : {} })
      .then((r) => r.blob())
      .then((blob) => {
        const a = document.createElement("a");
        a.href = URL.createObjectURL(blob);
        a.download = filename;
        a.click();
      });
  }

  if (loading) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <p className="text-orion-muted text-sm">Chargement…</p>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col">
      <Header title="Tableau de bord admin" />

      <main className="flex-1 p-6 space-y-6 overflow-auto">
        {/* KPIs */}
        {stats && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { label: "Utilisateurs", value: stats.total_users, icon: <Users size={14} /> },
              { label: "Tâches totales", value: stats.total_tasks, icon: <BarChart2 size={14} /> },
              { label: "Tâches aujourd'hui", value: stats.tasks_today, icon: <Clock size={14} className="text-orion-gold" /> },
              { label: "Taux de succès global", value: `${stats.global_success_rate}%`, icon: <CheckCircle size={14} className="text-orion-green" /> },
            ].map(({ label, value, icon }) => (
              <div key={label} className="orion-card p-4">
                <div className="flex items-center gap-2 mb-2 text-orion-muted">
                  {icon}
                  <span className="text-xs uppercase tracking-wider">{label}</span>
                </div>
                <p className="text-white text-xl font-semibold">{value}</p>
              </div>
            ))}
          </div>
        )}

        {/* Users table */}
        <div className="orion-card overflow-hidden">
          <div className="px-5 py-4 border-b border-orion-border">
            <h3 className="text-white text-sm font-medium">
              Utilisateurs
              <span className="text-orion-muted ml-2 font-normal">{users.length}</span>
            </h3>
          </div>

          {users.length === 0 ? (
            <div className="p-12 text-center text-orion-muted text-sm">Aucun utilisateur</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-orion-border text-orion-muted text-xs uppercase tracking-wider">
                    <th className="px-5 py-3 text-left">#</th>
                    <th className="px-5 py-3 text-left">Utilisateur</th>
                    <th className="px-5 py-3 text-left">Email</th>
                    <th className="px-5 py-3 text-left">Rôle</th>
                    <th className="px-5 py-3 text-right">Tâches</th>
                    <th className="px-5 py-3 text-left">Inscrit le</th>
                    <th className="px-5 py-3 text-left">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {users.map((u) => (
                    <tr key={u.id} className="border-b border-orion-border/50 hover:bg-white/3 transition-colors">
                      <td className="px-5 py-3 text-orion-muted font-mono text-xs">{u.id}</td>
                      <td className="px-5 py-3 text-white font-medium">{u.username}</td>
                      <td className="px-5 py-3 text-orion-muted text-xs">{u.email || "—"}</td>
                      <td className="px-5 py-3">
                        <select
                          value={u.role}
                          onChange={(e) => changeRole(u.id, e.target.value)}
                          className={`text-xs px-2 py-1 rounded-full border-0 cursor-pointer focus:outline-none focus:ring-1 focus:ring-orion-accent/50 ${roleBadge(u.role)}`}
                          style={{ background: "transparent" }}
                        >
                          {ROLES.map((r) => (
                            <option key={r} value={r} className="bg-orion-surface text-white">{r}</option>
                          ))}
                        </select>
                      </td>
                      <td className="px-5 py-3 text-white text-right">{u.task_count}</td>
                      <td className="px-5 py-3 text-orion-muted text-xs">
                        {new Date(u.created_at).toLocaleDateString("fr-FR")}
                      </td>
                      <td className="px-5 py-3">
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => toggleActive(u.id)}
                            title={u.is_active ? "Désactiver" : "Réactiver"}
                            className="text-orion-muted hover:text-white transition-colors"
                          >
                            {u.is_active
                              ? <ToggleRight size={16} className="text-orion-green" />
                              : <ToggleLeft size={16} />}
                          </button>
                          <button
                            onClick={() => deleteUser(u.id, u.username)}
                            title="Supprimer"
                            className="p-1 rounded hover:bg-orion-red/10 text-orion-muted hover:text-orion-red transition-colors"
                          >
                            <Trash2 size={13} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
        {/* Backups */}
        <div className="orion-card overflow-hidden">
          <div className="px-5 py-4 border-b border-orion-border flex items-center justify-between">
            <div className="flex items-center gap-2">
              <HardDrive size={14} className="text-orion-accent" />
              <h3 className="text-white text-sm font-medium">Sauvegardes de la base de données</h3>
            </div>
            <button
              onClick={createBackup}
              disabled={creatingBackup}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs bg-orion-accent hover:bg-orion-accent/80 disabled:opacity-50 text-white rounded-lg transition-colors"
            >
              {creatingBackup ? "Création…" : "+ Créer maintenant"}
            </button>
          </div>
          <p className="px-5 py-2 text-orion-muted text-xs border-b border-orion-border/50">
            Backup automatique chaque nuit à 02:00 UTC · Conservation {7} jours
          </p>
          {backups.length === 0 ? (
            <div className="p-8 text-center text-orion-muted text-sm">Aucun backup disponible</div>
          ) : (
            <ul className="divide-y divide-orion-border/40">
              {backups.map((b) => (
                <li key={b.name} className="flex items-center gap-4 px-5 py-3 hover:bg-white/3 transition-colors">
                  <HardDrive size={13} className="text-orion-muted flex-shrink-0" />
                  <span className="font-mono text-xs text-white flex-1">{b.name}</span>
                  <span className="text-xs text-orion-muted">{b.size_kb} KB</span>
                  <span className="text-xs text-orion-muted">{new Date(b.created_at).toLocaleString("fr-FR")}</span>
                  <button
                    onClick={() => downloadBackup(b.name)}
                    title="Télécharger"
                    className="p-1.5 rounded-lg hover:bg-orion-accent/10 text-orion-muted hover:text-orion-accent-light transition-colors"
                  >
                    <Download size={13} />
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>

      </main>
    </div>
  );
}
