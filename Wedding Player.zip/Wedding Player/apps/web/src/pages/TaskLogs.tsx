import { useEffect, useRef, useState } from "react";
import { useParams } from "react-router-dom";
import { Terminal, AlertCircle, Info, CheckCircle } from "lucide-react";
import { getToken } from "@/api/client";

interface LogLine {
  level: string;
  message: string;
  ts?: string;
}

const BASE_URL = (import.meta.env.VITE_API_URL ?? "http://localhost:8000");

export function TaskLogs() {
  const { taskId } = useParams<{ taskId: string }>();
  const [logs, setLogs] = useState<LogLine[]>([]);
  const [done, setDone] = useState(false);
  const [connected, setConnected] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!taskId) return;
    const token = getToken();
    if (!token) return;

    const url = `${BASE_URL}/tasks/${taskId}/logs/stream?token=${encodeURIComponent(token)}`;
    const es = new EventSource(url);

    es.onopen = () => setConnected(true);

    es.onmessage = (e) => {
      try {
        const data: LogLine = JSON.parse(e.data);
        if (data.message === "__DONE__") {
          setDone(true);
          es.close();
        } else {
          setLogs((prev) => [...prev, data]);
        }
      } catch { /* ignore malformed */ }
    };

    es.onerror = () => {
      setConnected(false);
      es.close();
    };

    return () => es.close();
  }, [taskId]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [logs]);

  const levelIcon = (level: string) => {
    if (level === "error") return <AlertCircle size={12} className="text-orion-red flex-shrink-0" />;
    if (level === "warn") return <AlertCircle size={12} className="text-yellow-400 flex-shrink-0" />;
    return <Info size={12} className="text-orion-muted flex-shrink-0" />;
  };

  const levelColor = (level: string) => {
    if (level === "error") return "text-orion-red";
    if (level === "warn") return "text-yellow-400";
    return "text-orion-muted";
  };

  return (
    <div className="flex-1 overflow-hidden flex flex-col p-6">
      <div className="flex items-center gap-3 mb-4">
        <Terminal size={18} className="text-orion-accent-light" />
        <h1 className="text-lg font-bold text-white">Logs — Tâche #{taskId}</h1>
        <div className={`flex items-center gap-1.5 text-xs ${connected ? "text-orion-green" : "text-orion-muted"}`}>
          <div className={`w-1.5 h-1.5 rounded-full ${connected ? "bg-orion-green animate-pulse" : "bg-orion-muted"}`} />
          {connected ? "En direct" : "Déconnecté"}
        </div>
        {done && (
          <div className="flex items-center gap-1.5 text-xs text-orion-green">
            <CheckCircle size={12} /> Terminé
          </div>
        )}
      </div>

      <div className="flex-1 bg-orion-bg border border-orion-border rounded-xl overflow-y-auto font-mono text-xs p-4 space-y-1">
        {logs.length === 0 && !done && (
          <p className="text-orion-muted">En attente des logs…</p>
        )}
        {logs.map((log, i) => (
          <div key={i} className="flex items-start gap-2">
            {levelIcon(log.level)}
            <span className={`${levelColor(log.level)} leading-5 break-all`}>{log.message}</span>
            {log.ts && (
              <span className="text-orion-muted/50 ml-auto flex-shrink-0 text-[10px] leading-5">
                {new Date(log.ts).toLocaleTimeString()}
              </span>
            )}
          </div>
        ))}
        {done && logs.length > 0 && (
          <div className="pt-2 border-t border-orion-border/50 text-orion-green text-[10px]">
            ─── Exécution terminée ───
          </div>
        )}
        <div ref={bottomRef} />
      </div>
    </div>
  );
}
