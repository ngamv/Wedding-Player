import { useEffect, useState } from "react";
import { Plus, Trash2, Zap, Copy, Check } from "lucide-react";
import { api } from "@/api/client";
import { useOrionStore } from "@/store/useOrionStore";
import { Header } from "@/components/layout/Header";
import { toast } from "@/components/ui/Toast";

interface Trigger {
  id: number;
  name: string;
  agent_id: string;
  token: string;
  is_active: boolean;
  last_triggered_at: string | null;
  created_at: string;
}

const BASE_URL = import.meta.env.VITE_API_URL ?? "http://localhost:8000";

export function Triggers() {
  const { agents } = useOrionStore();
  const [triggers, setTriggers] = useState<Trigger[]>([]);
  const [name, setName] = useState("");
  const [agentId, setAgentId] = useState("");
  const [creating, setCreating] = useState(false);
  const [copied, setCopied] = useState<number | null>(null);

  async function load() {
    try {
      const data = await api.get<Trigger[]>("/triggers");
      setTriggers(data);
    } catch { /* ignore */ }
  }

  useEffect(() => { load(); }, []);

  async function create() {
    if (!name.trim() || !agentId) return;
    setCreating(true);
    try {
      await api.post("/triggers", { name, agent_id: agentId });
      setName(""); setAgentId("");
      await load();
      toast.success("Trigger créé");
    } catch {
      toast.error("Erreur lors de la création");
    } finally {
      setCreating(false);
    }
  }

  async function remove(id: number) {
    try {
      await api.delete(`/triggers/${id}`);
      setTriggers((p) => p.filter((t) => t.id !== id));
      toast.success("Trigger supprimé");
    } catch {
      toast.error("Erreur lors de la suppression");
    }
  }

  function copyUrl(token: string, id: number) {
    const url = `${BASE_URL}/trigger/${token}`;
    navigator.clipboard.writeText(url);
    setCopied(id);
    setTimeout(() => setCopied(null), 2000);
    toast.info("URL copiée");
  }

  return (
    <div className="flex-1 flex flex-col">
      <Header title="Webhooks entrants (Triggers)" />

      <main className="flex-1 p-6 space-y-6 overflow-auto">
        <div className="orion-card p-5">
          <div className="flex items-center gap-2 mb-4">
            <Zap size={16} className="text-orion-accent-light" />
            <h3 className="text-white text-sm font-medium">Nouveau trigger</h3>
          </div>
          <div className="flex gap-3 flex-wrap">
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Nom du trigger"
              className="flex-1 min-w-[180px] px-4 py-2.5 bg-orion-bg border border-orion-border rounded-lg text-sm text-white placeholder-orion-muted focus:outline-none focus:border-orion-accent/50"
            />
            <select
              value={agentId}
              onChange={(e) => setAgentId(e.target.value)}
              className="px-3 py-2.5 bg-orion-bg border border-orion-border rounded-lg text-sm text-white focus:outline-none focus:border-orion-accent/50"
            >
              <option value="">Choisir un agent…</option>
              {agents.map((a) => (
                <option key={a.id} value={a.id}>{a.name}</option>
              ))}
            </select>
            <button
              onClick={create}
              disabled={!name.trim() || !agentId || creating}
              className="px-4 py-2.5 bg-orion-accent hover:bg-orion-accent/80 disabled:opacity-40 text-white rounded-lg text-sm flex items-center gap-2 transition-colors"
            >
              <Plus size={16} /> Créer
            </button>
          </div>
        </div>

        <div className="orion-card overflow-hidden">
          <div className="px-5 py-4 border-b border-orion-border">
            <h3 className="text-white text-sm font-medium">Triggers actifs</h3>
          </div>
          {triggers.length === 0 ? (
            <div className="p-12 text-center text-orion-muted text-sm">
              Aucun trigger. Créez-en un pour déclencher un agent via webhook.
            </div>
          ) : (
            <div className="divide-y divide-orion-border/50">
              {triggers.map((t) => (
                <div key={t.id} className="px-5 py-4 space-y-2">
                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <p className="text-white text-sm font-medium">{t.name}</p>
                      <p className="text-orion-muted text-xs font-mono">{t.agent_id}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      {t.last_triggered_at && (
                        <span className="text-orion-muted text-xs hidden sm:block">
                          Dernier : {new Date(t.last_triggered_at).toLocaleDateString("fr-FR")}
                        </span>
                      )}
                      <button
                        onClick={() => remove(t.id)}
                        className="p-1.5 rounded-lg text-orion-muted hover:text-orion-red hover:bg-orion-red/10 transition-colors"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 p-2 bg-orion-bg rounded-lg border border-orion-border/50">
                    <code className="flex-1 text-xs text-orion-green font-mono truncate">
                      POST {BASE_URL}/trigger/{t.token}
                    </code>
                    <button
                      onClick={() => copyUrl(t.token, t.id)}
                      className="p-1 rounded text-orion-muted hover:text-white transition-colors flex-shrink-0"
                    >
                      {copied === t.id ? <Check size={12} className="text-orion-green" /> : <Copy size={12} />}
                    </button>
                  </div>
                  <p className="text-orion-muted text-[10px]">
                    Body JSON optionnel : <code className="text-orion-accent-light">{`{"prompt": "..."}`}</code>
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
