import { useEffect, useState } from "react";
import { api } from "@/api/client";
import { toast } from "@/components/ui/Toast";
import { Plus, Trash2, Power, PowerOff, Clock } from "lucide-react";

interface ScheduledTask {
  id: number;
  name: string;
  agent_id: string;
  prompt: string;
  cron: string;
  is_active: boolean;
  last_run_at: string | null;
  created_at: string;
}

const EMPTY: Omit<ScheduledTask, "id" | "last_run_at" | "created_at"> = {
  name: "",
  agent_id: "",
  prompt: "",
  cron: "0 9 * * 1-5",
  is_active: true,
};

interface RunnableOption { id: string; name: string }

export function Scheduled() {
  const [tasks, setTasks] = useState<ScheduledTask[]>([]);
  const [form, setForm] = useState({ ...EMPTY });
  const [creating, setCreating] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [agents, setAgents] = useState<RunnableOption[]>([]);
  const [workflows, setWorkflows] = useState<RunnableOption[]>([]);
  const [skills, setSkills] = useState<RunnableOption[]>([]);

  async function load() {
    try {
      const data = await api.get<ScheduledTask[]>("/scheduled/");
      setTasks(data);
    } catch {
      toast.error("Erreur lors du chargement des tâches planifiées");
    }
    const [ags, wfs, sks] = await Promise.all([
      api.get<{ id: string; name: string }[]>("/agents/").catch(() => []),
      api.get<{ id: number; name: string }[]>("/workflows/").catch(() => []),
      api.get<{ slug: string; name: string; type: string }[]>("/skills/").catch(() => []),
    ]);
    setAgents(ags.map((a) => ({ id: a.id, name: a.name })));
    setWorkflows(wfs.map((w) => ({ id: `workflow:${w.id}`, name: w.name })));
    setSkills(sks.filter((s) => s.type === "builtin").map((s) => ({ id: `skill:${s.slug}`, name: s.name })));
  }

  useEffect(() => {
    load();
  }, []);

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    setCreating(true);
    try {
      const created = await api.post<ScheduledTask>("/scheduled/", form);
      setTasks((prev) => [created, ...prev]);
      setForm({ ...EMPTY });
      setShowForm(false);
      toast.success("Tâche planifiée créée");
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Erreur de création");
    } finally {
      setCreating(false);
    }
  }

  async function toggleActive(task: ScheduledTask) {
    try {
      const updated = await api.patch<ScheduledTask>(`/scheduled/${task.id}`, {
        is_active: !task.is_active,
      });
      setTasks((prev) => prev.map((t) => (t.id === task.id ? updated : t)));
    } catch {
      toast.error("Impossible de modifier la tâche");
    }
  }

  async function handleDelete(id: number) {
    if (!confirm("Supprimer cette tâche planifiée ?")) return;
    try {
      await api.delete(`/scheduled/${id}`);
      setTasks((prev) => prev.filter((t) => t.id !== id));
      toast.success("Tâche supprimée");
    } catch {
      toast.error("Erreur lors de la suppression");
    }
  }

  return (
    <div className="flex-1 overflow-auto p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl font-bold text-white">Tâches planifiées</h1>
          <p className="text-orion-muted text-xs mt-0.5">
            Automatisez l'exécution d'agents selon une expression cron
          </p>
        </div>
        <button
          onClick={() => setShowForm((v) => !v)}
          className="flex items-center gap-2 px-3 py-2 bg-orion-accent hover:bg-orion-accent/80 text-white rounded-lg text-sm transition-colors"
        >
          <Plus size={14} />
          Nouvelle tâche
        </button>
      </div>

      {/* Create form */}
      {showForm && (
        <form
          onSubmit={handleCreate}
          className="bg-orion-surface border border-orion-border rounded-xl p-5 mb-6 space-y-4"
        >
          <h2 className="text-sm font-semibold text-white mb-3">
            Nouvelle tâche planifiée
          </h2>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-orion-muted text-xs mb-1.5">
                Nom
              </label>
              <input
                required
                className="w-full bg-orion-bg border border-orion-border rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-orion-accent/60"
                value={form.name}
                onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
                placeholder="Rapport quotidien"
              />
            </div>
            <div>
              <label className="block text-orion-muted text-xs mb-1.5">
                À exécuter
              </label>
              <select
                required
                className="w-full bg-orion-bg border border-orion-border rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-orion-accent/60"
                value={form.agent_id}
                onChange={(e) => setForm((f) => ({ ...f, agent_id: e.target.value }))}
              >
                <option value="">— Choisir —</option>
                {workflows.length > 0 && (
                  <optgroup label="Workflows">
                    {workflows.map((w) => <option key={w.id} value={w.id}>⚙ {w.name}</option>)}
                  </optgroup>
                )}
                {skills.length > 0 && (
                  <optgroup label="Skills">
                    {skills.map((s) => <option key={s.id} value={s.id}>🧩 {s.name}</option>)}
                  </optgroup>
                )}
                <optgroup label="Agents">
                  {agents.map((a) => <option key={a.id} value={a.id}>{a.name}</option>)}
                </optgroup>
              </select>
            </div>
          </div>
          <div>
            <label className="block text-orion-muted text-xs mb-1.5">
              Prompt
            </label>
            <textarea
              required
              rows={2}
              className="w-full bg-orion-bg border border-orion-border rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-orion-accent/60 resize-none"
              value={form.prompt}
              onChange={(e) => setForm((f) => ({ ...f, prompt: e.target.value }))}
              placeholder="Analyse les performances SEO et génère un rapport"
            />
          </div>
          <div>
            <label className="block text-orion-muted text-xs mb-1.5">
              Expression cron{" "}
              <span className="text-orion-muted/60">
                (min h dom mon dow) — ex: "0 9 * * 1-5" = lun–ven 9h
              </span>
            </label>
            <input
              required
              className="w-full bg-orion-bg border border-orion-border rounded-lg px-3 py-2 text-sm font-mono text-white focus:outline-none focus:border-orion-accent/60"
              value={form.cron}
              onChange={(e) => setForm((f) => ({ ...f, cron: e.target.value }))}
              placeholder="0 9 * * 1-5"
            />
          </div>
          <div className="flex gap-3">
            <button
              type="submit"
              disabled={creating}
              className="px-4 py-2 bg-orion-accent hover:bg-orion-accent/80 disabled:opacity-50 text-white rounded-lg text-sm font-medium transition-colors"
            >
              {creating ? "Création…" : "Créer"}
            </button>
            <button
              type="button"
              onClick={() => setShowForm(false)}
              className="px-4 py-2 border border-orion-border text-orion-muted hover:text-white rounded-lg text-sm transition-colors"
            >
              Annuler
            </button>
          </div>
        </form>
      )}

      {/* Task list */}
      {tasks.length === 0 ? (
        <div className="text-center py-16 text-orion-muted">
          <Clock size={32} className="mx-auto mb-3 opacity-30" />
          <p className="text-sm">Aucune tâche planifiée</p>
        </div>
      ) : (
        <div className="space-y-3">
          {tasks.map((task) => (
            <div
              key={task.id}
              className="bg-orion-surface border border-orion-border rounded-xl px-5 py-4 flex items-center gap-4"
            >
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-0.5">
                  <p className="text-sm font-medium text-white truncate">
                    {task.name}
                  </p>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-orion-accent/15 text-orion-accent-light font-mono flex-shrink-0">
                    {task.agent_id}
                  </span>
                  {!task.is_active && (
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-orion-muted/20 text-orion-muted">
                      pausée
                    </span>
                  )}
                </div>
                <p className="text-orion-muted text-xs truncate">{task.prompt}</p>
                <div className="flex items-center gap-3 mt-1">
                  <span className="text-[10px] font-mono text-orion-muted/80 bg-orion-bg px-2 py-0.5 rounded">
                    {task.cron}
                  </span>
                  {task.last_run_at && (
                    <span className="text-[10px] text-orion-muted">
                      Dernière exéc.:{" "}
                      {new Date(task.last_run_at).toLocaleString()}
                    </span>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-2 flex-shrink-0">
                <button
                  onClick={() => toggleActive(task)}
                  title={task.is_active ? "Mettre en pause" : "Activer"}
                  className={`p-1.5 rounded-lg transition-colors ${
                    task.is_active
                      ? "text-orion-green hover:bg-orion-green/10"
                      : "text-orion-muted hover:bg-white/5"
                  }`}
                >
                  {task.is_active ? <Power size={14} /> : <PowerOff size={14} />}
                </button>
                <button
                  onClick={() => handleDelete(task.id)}
                  title="Supprimer"
                  className="p-1.5 rounded-lg text-orion-muted hover:text-orion-red hover:bg-orion-red/10 transition-colors"
                >
                  <Trash2 size={14} />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
