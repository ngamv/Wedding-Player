import { useEffect, useState } from "react";
import { CheckCircle, AlertTriangle, XCircle, RefreshCw } from "lucide-react";

interface ServiceStatus {
  status: "operational" | "degraded" | "down";
  provider?: string;
}

interface StatusData {
  status: string;
  version: string;
  timestamp: string;
  services: Record<string, ServiceStatus>;
  agents: number;
  tasks: {
    total: number;
    success: number;
    failed: number;
    pending: number;
    success_rate: number;
  };
}

function StatusBadge({ status }: { status: string }) {
  if (status === "operational") {
    return (
      <span className="flex items-center gap-1.5 text-orion-green text-sm font-medium">
        <CheckCircle size={14} /> Opérationnel
      </span>
    );
  }
  if (status === "degraded") {
    return (
      <span className="flex items-center gap-1.5 text-yellow-400 text-sm font-medium">
        <AlertTriangle size={14} /> Dégradé
      </span>
    );
  }
  return (
    <span className="flex items-center gap-1.5 text-orion-red text-sm font-medium">
      <XCircle size={14} /> Hors service
    </span>
  );
}

const SERVICE_LABELS: Record<string, string> = {
  api: "API Backend",
  database: "Base de données",
  ollama: "Ollama (LLM local)",
  llm: "Fournisseur LLM actif",
};

export default function Status() {
  const [data, setData] = useState<StatusData | null>(null);
  const [error, setError] = useState(false);
  const [loading, setLoading] = useState(true);
  const [lastChecked, setLastChecked] = useState<Date | null>(null);

  async function fetchStatus() {
    setLoading(true);
    setError(false);
    try {
      const base = import.meta.env.VITE_API_URL ?? "http://localhost:8000";
      const res = await fetch(`${base}/system/status`);
      if (!res.ok) throw new Error("non-200");
      setData(await res.json());
      setLastChecked(new Date());
    } catch {
      setError(true);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    fetchStatus();
    const id = setInterval(fetchStatus, 30_000);
    return () => clearInterval(id);
  }, []);

  const allOperational =
    data && Object.values(data.services).every((s) => s.status === "operational");

  return (
    <div className="min-h-screen bg-orion-bg text-white flex flex-col items-center py-16 px-4">
      {/* Header */}
      <div className="text-center mb-10">
        <div className="w-12 h-12 rounded-xl bg-orion-accent mx-auto mb-4 flex items-center justify-center orion-glow">
          <span className="text-white font-bold text-lg">O</span>
        </div>
        <h1 className="text-3xl font-bold tracking-tight">ORION AI — Statut</h1>
        <p className="text-orion-muted text-sm mt-2">
          {lastChecked
            ? `Dernière vérification : ${lastChecked.toLocaleTimeString()}`
            : "Chargement…"}
        </p>
      </div>

      {error && (
        <div className="w-full max-w-2xl bg-orion-red/10 border border-orion-red/30 rounded-xl px-6 py-4 mb-6 text-center">
          <p className="text-orion-red font-medium">Impossible de joindre l'API.</p>
          <p className="text-orion-muted text-sm mt-1">Vérifiez que le backend est démarré.</p>
        </div>
      )}

      {data && (
        <>
          {/* Global banner */}
          <div
            className={`w-full max-w-2xl rounded-xl px-6 py-4 mb-8 border text-center ${
              allOperational
                ? "bg-orion-green/10 border-orion-green/30"
                : "bg-yellow-400/10 border-yellow-400/30"
            }`}
          >
            <p
              className={`font-semibold text-lg ${
                allOperational ? "text-orion-green" : "text-yellow-400"
              }`}
            >
              {allOperational
                ? "Tous les systèmes sont opérationnels"
                : "Dégradation partielle détectée"}
            </p>
            <p className="text-orion-muted text-xs mt-0.5">
              ORION AI v{data.version} · {data.agents} agents actifs
            </p>
          </div>

          {/* Services */}
          <div className="w-full max-w-2xl bg-orion-surface border border-orion-border rounded-xl divide-y divide-orion-border mb-6">
            {Object.entries(data.services).map(([key, svc]) => (
              <div key={key} className="flex items-center justify-between px-6 py-4">
                <div>
                  <p className="text-sm font-medium text-white">
                    {SERVICE_LABELS[key] ?? key}
                  </p>
                  {svc.provider && (
                    <p className="text-orion-muted text-xs mt-0.5">
                      Fournisseur : {svc.provider}
                    </p>
                  )}
                </div>
                <StatusBadge status={svc.status} />
              </div>
            ))}
          </div>

          {/* Task stats */}
          <div className="w-full max-w-2xl grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
            {[
              { label: "Tâches totales", value: data.tasks.total },
              { label: "Réussies", value: data.tasks.success },
              { label: "Échouées", value: data.tasks.failed },
              { label: "Taux de succès", value: `${data.tasks.success_rate}%` },
            ].map(({ label, value }) => (
              <div
                key={label}
                className="bg-orion-surface border border-orion-border rounded-xl px-4 py-3 text-center"
              >
                <p className="text-xl font-bold text-white">{value}</p>
                <p className="text-orion-muted text-xs mt-0.5">{label}</p>
              </div>
            ))}
          </div>

          {/* Refresh */}
          <button
            onClick={fetchStatus}
            disabled={loading}
            className="flex items-center gap-2 px-4 py-2 rounded-lg border border-orion-border text-orion-muted hover:text-white hover:border-orion-accent/50 transition-colors text-sm disabled:opacity-50"
          >
            <RefreshCw size={14} className={loading ? "animate-spin" : ""} />
            Rafraîchir
          </button>
        </>
      )}
    </div>
  );
}
