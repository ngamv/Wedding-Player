import { useState, useEffect } from "react";
import { BarChart2, TrendingUp, CheckCircle, XCircle } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { api } from "@/api/client";
import { Header } from "@/components/layout/Header";

type Period = "day" | "week" | "month" | "year";

interface PeriodData {
  period: Period;
  buckets: { label: string; tasks: number; success: number }[];
  total: number;
  success: number;
  failed: number;
  success_rate: number;
}

const PERIODS: { key: Period; label: string }[] = [
  { key: "day", label: "24 heures" },
  { key: "week", label: "7 jours" },
  { key: "month", label: "30 jours" },
  { key: "year", label: "12 mois" },
];

interface CustomTooltipProps {
  active?: boolean;
  payload?: { value: number; name: string }[];
  label?: string;
}

function CustomTooltip({ active, payload, label }: CustomTooltipProps) {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-orion-surface border border-orion-border rounded-lg px-3 py-2 text-xs shadow-xl">
      <p className="text-orion-muted mb-1">{label}</p>
      {payload.map((p, i) => (
        <p key={i} className={p.name === "tasks" ? "text-orion-accent-light" : "text-orion-green"}>
          {p.name === "tasks" ? "Total" : "Succès"}: {p.value}
        </p>
      ))}
    </div>
  );
}

export function PeriodStats() {
  const [period, setPeriod] = useState<Period>("week");
  const [data, setData] = useState<PeriodData | null>(null);
  const [loading, setLoading] = useState(false);

  async function load(p: Period) {
    setLoading(true);
    try {
      const res = await api.get<PeriodData>(`/system/period-stats?period=${p}`);
      setData(res);
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(period); }, [period]);

  function select(p: Period) {
    setPeriod(p);
  }

  const buckets = data?.buckets ?? [];
  const maxVal = Math.max(...buckets.map((b) => b.tasks), 1);

  return (
    <div className="flex-1 flex flex-col">
      <Header title="Statistiques par période" />

      <main className="flex-1 p-6 space-y-6 overflow-auto">
        {/* Period selector */}
        <div className="flex items-center gap-2">
          {PERIODS.map((p) => (
            <button
              key={p.key}
              onClick={() => select(p.key)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                period === p.key
                  ? "bg-orion-accent text-white"
                  : "bg-orion-surface border border-orion-border text-orion-muted hover:text-white hover:border-orion-accent/50"
              }`}
            >
              {p.label}
            </button>
          ))}
        </div>

        {/* Summary cards */}
        {data && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="orion-card p-4">
              <p className="text-orion-muted text-xs mb-1">Total tâches</p>
              <p className="text-white text-2xl font-bold">{data.total}</p>
            </div>
            <div className="orion-card p-4">
              <div className="flex items-center gap-1.5 mb-1">
                <CheckCircle size={11} className="text-orion-green" />
                <p className="text-orion-muted text-xs">Succès</p>
              </div>
              <p className="text-orion-green text-2xl font-bold">{data.success}</p>
            </div>
            <div className="orion-card p-4">
              <div className="flex items-center gap-1.5 mb-1">
                <XCircle size={11} className="text-orion-red" />
                <p className="text-orion-muted text-xs">Échecs</p>
              </div>
              <p className="text-orion-red text-2xl font-bold">{data.failed}</p>
            </div>
            <div className="orion-card p-4">
              <div className="flex items-center gap-1.5 mb-1">
                <TrendingUp size={11} className="text-orion-accent-light" />
                <p className="text-orion-muted text-xs">Taux de succès</p>
              </div>
              <p className="text-orion-accent-light text-2xl font-bold">{data.success_rate}%</p>
            </div>
          </div>
        )}

        {/* Bar chart */}
        <div className="orion-card p-5">
          <div className="flex items-center gap-2 mb-4">
            <BarChart2 size={16} className="text-orion-accent-light" />
            <h3 className="text-white text-sm font-medium">Tâches par période</h3>
          </div>

          {loading ? (
            <div className="h-64 flex items-center justify-center">
              <div className="w-6 h-6 rounded-full border-2 border-orion-accent/30 border-t-orion-accent animate-spin" />
            </div>
          ) : buckets.length > 0 ? (
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={buckets} margin={{ top: 4, right: 8, left: -16, bottom: 4 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                <XAxis
                  dataKey="label"
                  tick={{ fill: "#888", fontSize: 10 }}
                  axisLine={false}
                  tickLine={false}
                  interval={period === "month" ? 4 : period === "day" ? 3 : 0}
                />
                <YAxis
                  tick={{ fill: "#888", fontSize: 10 }}
                  axisLine={false}
                  tickLine={false}
                  allowDecimals={false}
                />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="tasks" name="tasks" fill="#6366f1" radius={[3, 3, 0, 0]} maxBarSize={40} />
                <Bar dataKey="success" name="success" fill="#22c55e" radius={[3, 3, 0, 0]} maxBarSize={40} />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-64 flex items-center justify-center text-orion-muted text-sm">
              Aucune donnée pour cette période
            </div>
          )}

          <div className="flex items-center gap-4 mt-3">
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-sm bg-orion-accent inline-block" />
              <span className="text-xs text-orion-muted">Total</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-sm bg-orion-green inline-block" />
              <span className="text-xs text-orion-muted">Succès</span>
            </div>
          </div>
        </div>

        {/* Table detail */}
        {buckets.length > 0 && (
          <div className="orion-card overflow-hidden">
            <div className="px-5 py-3 border-b border-orion-border">
              <h3 className="text-white text-sm font-medium">Détail par bucket</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-orion-border">
                    <th className="text-left px-5 py-2.5 text-orion-muted font-medium">Période</th>
                    <th className="text-right px-5 py-2.5 text-orion-muted font-medium">Total</th>
                    <th className="text-right px-5 py-2.5 text-orion-muted font-medium">Succès</th>
                    <th className="text-right px-5 py-2.5 text-orion-muted font-medium">Échecs</th>
                    <th className="text-right px-5 py-2.5 text-orion-muted font-medium">Taux</th>
                    <th className="px-5 py-2.5" />
                  </tr>
                </thead>
                <tbody>
                  {buckets.map((b) => {
                    const rate = b.tasks > 0 ? Math.round((b.success / b.tasks) * 100) : 0;
                    const pct = (b.tasks / maxVal) * 100;
                    return (
                      <tr key={b.label} className="border-b border-orion-border/40 hover:bg-white/2">
                        <td className="px-5 py-2.5 text-white font-mono">{b.label}</td>
                        <td className="px-5 py-2.5 text-right text-white">{b.tasks}</td>
                        <td className="px-5 py-2.5 text-right text-orion-green">{b.success}</td>
                        <td className="px-5 py-2.5 text-right text-orion-red">{b.tasks - b.success}</td>
                        <td className="px-5 py-2.5 text-right text-orion-muted">{b.tasks > 0 ? `${rate}%` : "—"}</td>
                        <td className="px-5 py-2.5 w-24">
                          <div className="h-1 bg-orion-border rounded-full overflow-hidden">
                            <div className="h-full bg-orion-accent rounded-full" style={{ width: `${pct}%` }} />
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
