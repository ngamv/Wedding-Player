import { useState, useEffect, useCallback, useRef } from "react";
import { Plus, Play, Trash2, Pencil, X, Loader2, GitBranch, ChevronDown, ChevronUp, CheckCircle, XCircle, ArrowRight, Download, Upload, LayoutList, Network } from "lucide-react";
import { PresenceAvatars } from "@/components/ui/PresenceAvatars";
import { workflowsApi, type Workflow, type WorkflowStep, type WorkflowRun } from "@/api/workflows";
import { api } from "@/api/client";
import type { Agent } from "@/api/client";
import { Header } from "@/components/layout/Header";
import { toast } from "@/components/ui/Toast";
import { WorkflowCanvas } from "@/components/ui/WorkflowCanvas";

const CATEGORY_COLORS: Record<string, string> = {
  core: "#6366f1", seo: "#10b981", social: "#f59e0b",
  marketing: "#ec4899", dev: "#3b82f6", data: "#8b5cf6",
};

const EMPTY_STEP: WorkflowStep = { agent_id: "", label: "", pass_output: true };

function StepBuilder({ steps, agents, onChange }: {
  steps: WorkflowStep[];
  agents: Agent[];
  onChange: (steps: WorkflowStep[]) => void;
}) {
  function addStep() { onChange([...steps, { ...EMPTY_STEP }]); }
  function removeStep(i: number) { onChange(steps.filter((_, idx) => idx !== i)); }
  function updateStep(i: number, patch: Partial<WorkflowStep>) {
    onChange(steps.map((s, idx) => idx === i ? { ...s, ...patch } : s));
  }

  return (
    <div className="space-y-2">
      {steps.map((step, i) => {
        const agent = agents.find((a) => a.id === step.agent_id);
        return (
          <div key={i} className="flex items-center gap-2">
            <div className="flex items-center justify-center w-6 h-6 rounded-full bg-orion-accent/20 text-orion-accent text-xs font-bold flex-shrink-0">
              {i + 1}
            </div>
            <select
              value={step.agent_id}
              onChange={(e) => {
                const a = agents.find((ag) => ag.id === e.target.value);
                updateStep(i, { agent_id: e.target.value, label: a?.name ?? "" });
              }}
              className="flex-1 bg-orion-bg border border-orion-border rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-orion-accent/50 transition-colors"
            >
              <option value="">— Choisir un agent —</option>
              {agents.map((a) => (
                <option key={a.id} value={a.id}>{a.name}</option>
              ))}
            </select>
            <input
              value={step.label}
              onChange={(e) => updateStep(i, { label: e.target.value })}
              placeholder="Étiquette"
              className="w-32 bg-orion-bg border border-orion-border rounded-lg px-3 py-2 text-sm text-white placeholder-orion-muted/50 focus:outline-none focus:border-orion-accent/50 transition-colors"
            />
            <label className="flex items-center gap-1.5 text-xs text-orion-muted whitespace-nowrap">
              <input
                type="checkbox"
                checked={step.pass_output}
                onChange={(e) => updateStep(i, { pass_output: e.target.checked })}
                className="accent-orion-accent"
              />
              Enchaîner
            </label>
            {agent && (
              <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: CATEGORY_COLORS[agent.category] ?? "#6366f1" }} />
            )}
            <button onClick={() => removeStep(i)} className="text-orion-muted hover:text-orion-red transition-colors flex-shrink-0">
              <X size={14} />
            </button>
          </div>
        );
      })}
      <button
        type="button"
        onClick={addStep}
        className="flex items-center gap-1.5 text-xs text-orion-accent hover:text-orion-accent/80 transition-colors mt-1"
      >
        <Plus size={12} /> Ajouter une étape
      </button>
    </div>
  );
}

function RunResult({ run }: { run: WorkflowRun }) {
  const [expanded, setExpanded] = useState<number | null>(null);
  return (
    <div className="bg-orion-bg border border-orion-border rounded-xl p-4 space-y-2 animate-slide-in">
      <div className="flex items-center justify-between mb-3">
        <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
          run.status === "completed" ? "bg-orion-green/15 text-orion-green" : "bg-orion-red/15 text-orion-red"
        }`}>{run.status}</span>
        <span className="text-orion-muted text-xs">
          {run.completed_at ? new Date(run.completed_at).toLocaleTimeString("fr-FR") : "—"}
        </span>
      </div>
      {run.steps_results.map((sr, i) => (
        <div key={i} className="border border-orion-border rounded-lg overflow-hidden">
          <button
            onClick={() => setExpanded(expanded === i ? null : i)}
            className="w-full flex items-center justify-between px-3 py-2 hover:bg-white/5 transition-colors"
          >
            <div className="flex items-center gap-2">
              {sr.error ? <XCircle size={13} className="text-orion-red" /> : <CheckCircle size={13} className="text-orion-green" />}
              <span className="text-white text-xs font-medium">{sr.label || sr.agent_id}</span>
            </div>
            {expanded === i ? <ChevronUp size={12} className="text-orion-muted" /> : <ChevronDown size={12} className="text-orion-muted" />}
          </button>
          {expanded === i && (
            <div className="px-3 pb-3 text-xs text-orion-muted whitespace-pre-wrap border-t border-orion-border pt-2 leading-relaxed max-h-40 overflow-y-auto">
              {sr.error ?? sr.result}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

function WorkflowStepsView({ steps, agents }: { steps: WorkflowStep[]; agents: Agent[] }) {
  const [view, setView] = useState<"list" | "canvas">("list");
  return (
    <div>
      <div className="flex items-center gap-2 mb-2">
        <button
          onClick={() => setView("list")}
          className={`flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-md transition-colors ${view === "list" ? "bg-orion-accent/15 text-orion-accent-light" : "text-orion-muted hover:text-white"}`}
        >
          <LayoutList size={10} /> Liste
        </button>
        <button
          onClick={() => setView("canvas")}
          className={`flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-md transition-colors ${view === "canvas" ? "bg-orion-accent/15 text-orion-accent-light" : "text-orion-muted hover:text-white"}`}
        >
          <Network size={10} /> Graphe
        </button>
      </div>
      {view === "list" ? (
        <div className="flex items-center gap-1.5 flex-wrap">
          {steps.map((step, i) => {
            const agent = agents.find((a) => a.id === step.agent_id);
            return (
              <div key={i} className="flex items-center gap-1.5">
                <span className="flex items-center gap-1.5 bg-orion-bg border border-orion-border rounded-lg px-2.5 py-1 text-xs">
                  <span className="w-1.5 h-1.5 rounded-full" style={{ background: CATEGORY_COLORS[agent?.category ?? "core"] }} />
                  <span className="text-white">{step.label || step.agent_id}</span>
                </span>
                {i < steps.length - 1 && <ArrowRight size={11} className="text-orion-muted flex-shrink-0" />}
              </div>
            );
          })}
        </div>
      ) : (
        <div className="bg-orion-bg/50 border border-orion-border/50 rounded-xl p-3 overflow-hidden">
          <WorkflowCanvas steps={steps} agents={agents} />
        </div>
      )}
    </div>
  );
}

export function Workflows() {
  const [workflows, setWorkflows] = useState<Workflow[]>([]);
  const [agents, setAgents] = useState<Agent[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Workflow | null>(null);
  const [formName, setFormName] = useState("");
  const [formDesc, setFormDesc] = useState("");
  const [formSteps, setFormSteps] = useState<WorkflowStep[]>([{ ...EMPTY_STEP }]);
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState("");
  const [runningId, setRunningId] = useState<number | null>(null);
  const [runTask, setRunTask] = useState<Record<number, string>>({});
  const [runResults, setRunResults] = useState<Record<number, WorkflowRun>>({});
  const [showRunPanel, setShowRunPanel] = useState<number | null>(null);
  const importRef = useRef<HTMLInputElement>(null);

  const load = useCallback(async () => {
    const [wfs, ags, skills] = await Promise.all([
      workflowsApi.list().catch(() => []),
      api.getAgents().catch(() => []),
      api.get<{ slug: string; name: string; type: string }[]>("/skills/").catch(() => []),
    ]);
    // Les skills builtin sont utilisables comme étapes, préfixés « skill: »
    const skillOptions = (skills as { slug: string; name: string; type: string }[])
      .filter((s) => s.type === "builtin")
      .map((s) => ({ id: `skill:${s.slug}`, name: `🧩 Skill — ${s.name}`, description: "", category: "skill" }));
    setWorkflows(wfs);
    setAgents([...ags, ...skillOptions]);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  function openCreate() {
    setEditing(null); setFormName(""); setFormDesc(""); setFormSteps([{ ...EMPTY_STEP }]);
    setFormError(""); setShowForm(true);
  }

  function openEdit(wf: Workflow) {
    setEditing(wf); setFormName(wf.name); setFormDesc(wf.description);
    setFormSteps(wf.steps.map((s) => ({ ...s }))); setFormError(""); setShowForm(true);
  }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    if (!formSteps.length || formSteps.some((s) => !s.agent_id)) {
      setFormError("Toutes les étapes doivent avoir un agent sélectionné"); return;
    }
    setSaving(true); setFormError("");
    try {
      if (editing) {
        await workflowsApi.update(editing.id, { name: formName, description: formDesc, steps: formSteps });
        toast.success("Workflow mis à jour");
      } else {
        await workflowsApi.create({ name: formName, description: formDesc, steps: formSteps });
        toast.success("Workflow créé");
      }
      setShowForm(false); load();
    } catch (err: unknown) {
      setFormError(err instanceof Error ? err.message : "Erreur");
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(wf: Workflow) {
    if (!confirm(`Supprimer "${wf.name}" ?`)) return;
    await workflowsApi.delete(wf.id); toast.success("Workflow supprimé"); load();
  }

  async function handleRun(wf: Workflow) {
    const task = runTask[wf.id]?.trim();
    if (!task) return;
    setRunningId(wf.id);
    try {
      const run = await workflowsApi.run(wf.id, task);
      setRunResults((r) => ({ ...r, [wf.id]: run }));
      toast.success(run.status === "completed" ? "Workflow terminé" : "Workflow échoué");
    } catch {
      toast.error("Erreur lors de l'exécution");
    } finally {
      setRunningId(null);
    }
  }

  return (
    <div className="flex-1 flex flex-col">
      <Header title="Workflows">
        <PresenceAvatars />
      </Header>
      {/* Hidden import input */}
      <input
        ref={importRef} type="file" accept=".json" className="hidden"
        onChange={async (e) => {
          const file = e.target.files?.[0];
          if (!file) return;
          try {
            const text = await file.text();
            const data = JSON.parse(text);
            await workflowsApi.importWorkflow(data);
            toast.success("Workflow importé");
            load();
          } catch { toast.error("Fichier invalide"); }
          e.target.value = "";
        }}
      />
      <main className="flex-1 p-6 overflow-auto space-y-6">
        <div className="flex items-center justify-between">
          <p className="text-orion-muted text-sm">{workflows.length} workflow{workflows.length !== 1 ? "s" : ""}</p>
          <div className="flex items-center gap-2">
            <button
              onClick={() => importRef.current?.click()}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-orion-muted hover:text-white border border-orion-border rounded-lg hover:bg-white/5 transition-colors"
            >
              <Upload size={12} /> Importer
            </button>
            {!showForm && (
              <button onClick={openCreate} className="flex items-center gap-2 px-4 py-2 bg-orion-accent hover:bg-orion-accent/80 text-white text-sm rounded-lg transition-colors font-medium">
                <Plus size={14} /> Nouveau workflow
              </button>
            )}
          </div>
        </div>

        {/* Form */}
        {showForm && (
          <div className="orion-card p-5 border-orion-accent/20">
            <h3 className="text-white text-sm font-medium mb-5">
              {editing ? `Modifier — ${editing.name}` : "Créer un workflow"}
            </h3>
            <form onSubmit={handleSave} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs text-orion-muted mb-1.5">Nom *</label>
                  <input value={formName} onChange={(e) => setFormName(e.target.value)} required placeholder="Pipeline SEO" className="w-full bg-orion-bg border border-orion-border rounded-lg px-3 py-2.5 text-sm text-white placeholder-orion-muted/50 focus:outline-none focus:border-orion-accent/50 transition-colors" />
                </div>
                <div>
                  <label className="block text-xs text-orion-muted mb-1.5">Description</label>
                  <input value={formDesc} onChange={(e) => setFormDesc(e.target.value)} placeholder="Décrivez ce workflow" className="w-full bg-orion-bg border border-orion-border rounded-lg px-3 py-2.5 text-sm text-white placeholder-orion-muted/50 focus:outline-none focus:border-orion-accent/50 transition-colors" />
                </div>
              </div>
              <div>
                <label className="block text-xs text-orion-muted mb-2">Étapes *</label>
                <StepBuilder steps={formSteps} agents={agents} onChange={setFormSteps} />
              </div>
              {formSteps.some((s) => s.agent_id) && (
                <div>
                  <label className="block text-xs text-orion-muted mb-2">Aperçu graphique</label>
                  <div className="bg-orion-bg border border-orion-border/50 rounded-xl p-3 overflow-hidden">
                    <WorkflowCanvas steps={formSteps} agents={agents} />
                  </div>
                </div>
              )}
              {formError && <p className="text-orion-red text-xs bg-orion-red/10 border border-orion-red/20 rounded-lg px-3 py-2">{formError}</p>}
              <div className="flex gap-3 justify-end pt-2">
                <button type="button" onClick={() => setShowForm(false)} className="px-4 py-2 text-sm text-orion-muted hover:text-white border border-orion-border rounded-lg hover:bg-white/5 transition-colors">Annuler</button>
                <button type="submit" disabled={saving} className="flex items-center gap-2 px-4 py-2 text-sm bg-orion-accent hover:bg-orion-accent/80 disabled:opacity-50 text-white rounded-lg transition-colors font-medium">
                  {saving && <Loader2 size={13} className="animate-spin" />}
                  {editing ? "Enregistrer" : "Créer"}
                </button>
              </div>
            </form>
          </div>
        )}

        {/* List */}
        {loading ? (
          <div className="flex items-center justify-center py-16"><Loader2 size={24} className="animate-spin text-orion-accent" /></div>
        ) : workflows.length === 0 && !showForm ? (
          <div className="orion-card p-10 flex flex-col items-center text-center">
            <div className="w-14 h-14 rounded-2xl bg-orion-accent/10 border border-orion-accent/20 flex items-center justify-center mb-4">
              <GitBranch size={24} className="text-orion-accent" />
            </div>
            <p className="text-white font-medium mb-1">Aucun workflow</p>
            <p className="text-orion-muted text-sm mb-4">Chaînez plusieurs agents pour automatiser des tâches complexes</p>
            <button onClick={openCreate} className="flex items-center gap-2 px-4 py-2 bg-orion-accent hover:bg-orion-accent/80 text-white text-sm rounded-lg transition-colors">
              <Plus size={14} /> Créer un workflow
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            {workflows.map((wf) => (
              <div key={wf.id} className="orion-card p-5 animate-slide-in">
                <div className="flex items-start justify-between gap-4 mb-3">
                  <div>
                    <p className="text-white font-medium text-sm">{wf.name}</p>
                    {wf.description && <p className="text-orion-muted text-xs mt-0.5">{wf.description}</p>}
                  </div>
                  <div className="flex items-center gap-1 flex-shrink-0">
                    <button onClick={() => setShowRunPanel(showRunPanel === wf.id ? null : wf.id)} className="p-2 rounded-lg hover:bg-orion-accent/10 text-orion-muted hover:text-orion-accent transition-colors" title="Exécuter">
                      <Play size={14} />
                    </button>
                    <button
                      onClick={async () => {
                        const data = await workflowsApi.exportWorkflow(wf.id);
                        const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
                        const a = document.createElement("a"); a.href = URL.createObjectURL(blob);
                        a.download = `${wf.name.replace(/\s+/g, "_")}.json`; a.click();
                        toast.success("Workflow exporté");
                      }}
                      className="p-2 rounded-lg hover:bg-orion-accent/10 text-orion-muted hover:text-orion-accent-light transition-colors" title="Exporter"
                    >
                      <Download size={14} />
                    </button>
                    <button onClick={() => openEdit(wf)} className="p-2 rounded-lg hover:bg-orion-gold/10 text-orion-muted hover:text-orion-gold transition-colors" title="Modifier">
                      <Pencil size={14} />
                    </button>
                    <button onClick={() => handleDelete(wf)} className="p-2 rounded-lg hover:bg-orion-red/10 text-orion-muted hover:text-orion-red transition-colors" title="Supprimer">
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>

                {/* Steps visualization — toggleable */}
                <WorkflowStepsView steps={wf.steps} agents={agents} />

                {/* Run panel */}
                {showRunPanel === wf.id && (
                  <div className="mt-4 space-y-3">
                    <div className="flex gap-2">
                      <input
                        value={runTask[wf.id] ?? ""}
                        onChange={(e) => setRunTask((t) => ({ ...t, [wf.id]: e.target.value }))}
                        placeholder="Tâche de départ pour ce workflow..."
                        className="flex-1 bg-orion-bg border border-orion-border rounded-lg px-3 py-2.5 text-sm text-white placeholder-orion-muted/50 focus:outline-none focus:border-orion-accent/50 transition-colors"
                      />
                      <button
                        onClick={() => handleRun(wf)}
                        disabled={!runTask[wf.id]?.trim() || runningId === wf.id}
                        className="flex items-center gap-2 px-4 py-2 text-sm bg-orion-accent hover:bg-orion-accent/80 disabled:opacity-50 text-white rounded-lg transition-colors"
                      >
                        {runningId === wf.id ? <Loader2 size={13} className="animate-spin" /> : <Play size={13} />}
                        {runningId === wf.id ? "Exécution…" : "Lancer"}
                      </button>
                    </div>
                    {runResults[wf.id] && <RunResult run={runResults[wf.id]} />}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
