import { useEffect, useState, useCallback, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { X, Radio, Bot, ListTodo, CheckCircle, Zap } from "lucide-react";
import { api, getToken } from "@/api/client";
import { useOrionStore } from "@/store/useOrionStore";

const WS_URL = (import.meta.env.VITE_API_URL ?? "http://localhost:8000").replace(/^http/, "ws");

const STATUS_COLOR: Record<string, string> = {
  completed: "#10b981",
  failed: "#ef4444",
  running: "#6366f1",
  pending: "#f59e0b",
};

function Clock() {
  const [time, setTime] = useState(new Date());
  useEffect(() => {
    const id = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(id);
  }, []);
  return (
    <span className="font-mono tabular-nums">
      {time.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit", second: "2-digit" })}
    </span>
  );
}

export function Presentation() {
  const navigate = useNavigate();
  const { tasks, stats, health, setTasks, setStats, setHealth, setAgents } = useOrionStore();
  const [live, setLive] = useState(false);
  const [liveCount, setLiveCount] = useState(0);
  const wsRef = useRef<WebSocket | null>(null);

  const refresh = useCallback(async () => {
    await Promise.all([
      api.getAgents().then(setAgents).catch(() => {}),
      api.getTasks({ page_size: 12 }).then((r) => setTasks(r.tasks)).catch(() => {}),
      api.getStats().then(setStats).catch(() => {}),
      api.getHealth().then(setHealth).catch(() => {}),
    ]);
  }, [setAgents, setTasks, setStats, setHealth]);

  useEffect(() => {
    refresh();
    const id = setInterval(refresh, 15_000);
    return () => clearInterval(id);
  }, [refresh]);

  useEffect(() => {
    const token = getToken();
    if (!token) return;
    // Token sent as first message to avoid JWT appearing in nginx access logs
    const ws = new WebSocket(`${WS_URL}/ws/events`);
    wsRef.current = ws;
    ws.onopen = () => {
      ws.send(JSON.stringify({ token }));
      setLive(true);
    };
    ws.onclose = () => setLive(false);
    ws.onmessage = () => {
      setLiveCount((n) => n + 1);
      setTimeout(() => api.getTasks({ page_size: 12 }).then((r) => setTasks(r.tasks)).catch(() => {}), 400);
    };
    return () => ws.close();
  }, [setTasks]);

  // Exit on Escape
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") navigate("/"); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [navigate]);

  const completed = tasks.filter((t) => t.status === "completed").length;
  const failed = tasks.filter((t) => t.status === "failed").length;
  const running = tasks.filter((t) => t.status === "running").length;
  const rate = tasks.length > 0 ? Math.round((completed / tasks.length) * 100) : 0;

  return (
    <div className="fixed inset-0 bg-[#080810] text-white z-50 flex flex-col overflow-hidden select-none">
      {/* Top bar */}
      <div className="flex items-center justify-between px-8 py-4 border-b border-white/5">
        <div className="flex items-center gap-3">
          <div className="w-2 h-2 rounded-full bg-orion-accent animate-pulse" />
          <span className="text-xl font-bold tracking-tight text-white/90">ORION</span>
          <span className="text-xs text-white/30 uppercase tracking-widest ml-2">NOC Display</span>
        </div>
        <div className="flex items-center gap-6 text-sm">
          <div className="flex items-center gap-1.5 text-xs">
            <Radio size={11} className={live ? "text-orion-green animate-pulse" : "text-white/20"} />
            <span className={live ? "text-orion-green" : "text-white/30"}>
              {live ? `LIVE +${liveCount}` : "Hors ligne"}
            </span>
          </div>
          <span className="text-white/40 text-sm"><Clock /></span>
          <button
            onClick={() => navigate("/")}
            title="Quitter (Échap)"
            className="p-1.5 rounded-lg hover:bg-white/10 text-white/40 hover:text-white transition-colors"
          >
            <X size={16} />
          </button>
        </div>
      </div>

      {/* KPI row */}
      <div className="grid grid-cols-4 gap-px border-b border-white/5 bg-white/5">
        {[
          { label: "Agents", value: stats?.total_agents ?? "—", icon: <Bot size={14} />, color: "#6366f1" },
          { label: "Tâches totales", value: tasks.length, icon: <ListTodo size={14} />, color: "#6366f1" },
          { label: "Taux de succès", value: `${rate}%`, icon: <CheckCircle size={14} />, color: "#10b981" },
          { label: "Système", value: health?.status === "ok" ? "Opérationnel" : "Hors ligne", icon: <Zap size={14} />, color: health?.status === "ok" ? "#10b981" : "#ef4444" },
        ].map(({ label, value, icon, color }) => (
          <div key={label} className="bg-[#080810] px-8 py-5 flex items-center gap-4">
            <span style={{ color }}>{icon}</span>
            <div>
              <p className="text-3xl font-bold leading-none" style={{ color }}>{value}</p>
              <p className="text-white/40 text-xs mt-1 uppercase tracking-widest">{label}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Status bar */}
      <div className="flex items-center gap-6 px-8 py-3 border-b border-white/5 text-xs text-white/40">
        {[
          { label: "Complétées", count: completed, color: "#10b981" },
          { label: "Échouées", count: failed, color: "#ef4444" },
          { label: "En cours", count: running, color: "#6366f1" },
        ].map(({ label, count, color }) => (
          <span key={label} className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full" style={{ background: color }} />
            <span style={{ color }}>{count}</span>
            <span>{label}</span>
          </span>
        ))}
        <div className="ml-auto h-1 w-48 bg-white/10 rounded-full overflow-hidden">
          <div className="h-full bg-orion-green rounded-full transition-all duration-1000" style={{ width: `${rate}%` }} />
        </div>
      </div>

      {/* Task feed */}
      <div className="flex-1 overflow-hidden p-8">
        <div className="grid grid-cols-3 gap-3 h-full auto-rows-fr">
          {tasks.slice(0, 12).map((t) => (
            <div
              key={t.id}
              className="rounded-xl border border-white/5 bg-white/3 px-4 py-3 flex flex-col gap-2 overflow-hidden hover:border-white/10 transition-colors"
            >
              <div className="flex items-center justify-between gap-2">
                <span className="text-white/30 font-mono text-xs">#{t.id}</span>
                <span
                  className="text-[10px] px-2 py-0.5 rounded-full font-medium"
                  style={{ background: `${STATUS_COLOR[t.status]}20`, color: STATUS_COLOR[t.status] }}
                >
                  {t.status}
                </span>
              </div>
              <p className="text-white text-sm font-medium leading-snug line-clamp-2">{t.title}</p>
              <p className="text-white/30 text-xs mt-auto font-mono truncate">{t.agent_id}</p>
            </div>
          ))}
          {/* Fill empty cells */}
          {Array.from({ length: Math.max(0, 12 - tasks.slice(0, 12).length) }).map((_, i) => (
            <div key={`empty-${i}`} className="rounded-xl border border-white/3 bg-white/1" />
          ))}
        </div>
      </div>

      {/* Footer */}
      <div className="px-8 py-2 border-t border-white/5 flex items-center justify-between text-[10px] text-white/20">
        <span>ORION AI Platform v1.0</span>
        <span>Échap pour quitter · Rafraîchissement auto 15s</span>
      </div>
    </div>
  );
}
