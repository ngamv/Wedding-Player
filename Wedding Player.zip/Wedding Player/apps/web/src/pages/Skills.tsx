import { useState, useEffect, useCallback } from "react";
import {
  FileText, Languages, Braces, Search, Globe, Plug, Mail, Hash, Calendar,
  BarChart2, Plus, Play, Trash2, ChevronRight, X, Loader2, CheckCircle2, AlertCircle,
  Smile, PenLine, Tag, Lock, Binary, KeyRound, Regex, Calculator,
  Video, Share2, CalendarDays, Image, Mic, Film, Send,
  Code2, FileCode2, Bug, LayoutTemplate, Gauge, TrendingUp, FileSearch, Palette, Rocket,
  QrCode, DollarSign, Link2, Repeat, Package, MessageSquare,
} from "lucide-react";
import { api } from "@/api/client";
import { toast } from "@/components/ui/Toast";
import { useAuthStore } from "@/store/useAuthStore";

// ─── icon map ───────────────────────────────────────────────────────────────
const ICONS: Record<string, React.ElementType> = {
  FileText, Languages, Braces, Search, Globe, Plug, Mail, Hash, Calendar, BarChart2,
  Smile, PenLine, Tag, Lock, Binary, KeyRound, Regex, Calculator,
  Video, Share2, CalendarDays, Image, Mic, Film, Send,
  Code2, FileCode2, Bug, LayoutTemplate, Gauge, TrendingUp, FileSearch, Palette, Rocket,
  QrCode, DollarSign, Link2, Repeat, Package, MessageSquare,
};

const CAT_COLORS: Record<string, string> = {
  ai:            "bg-violet-500/15 text-violet-300 border-violet-500/30",
  web:           "bg-blue-500/15 text-blue-300 border-blue-500/30",
  communication: "bg-green-500/15 text-green-300 border-green-500/30",
  utility:       "bg-orange-500/15 text-orange-300 border-orange-500/30",
  content:       "bg-pink-500/15 text-pink-300 border-pink-500/30",
  dev:           "bg-cyan-500/15 text-cyan-300 border-cyan-500/30",
  seo:           "bg-yellow-500/15 text-yellow-300 border-yellow-500/30",
  custom:        "bg-orion-accent/15 text-orion-accent-light border-orion-accent/30",
};

const TABS = ["all", "ai", "content", "dev", "seo", "web", "communication", "utility", "custom"] as const;
type Tab = typeof TABS[number];

interface Param {
  name: string;
  type: "text" | "textarea" | "json" | "select";
  required?: boolean;
  label: string;
  default?: string;
  placeholder?: string;
  options?: string[];
}

interface Skill {
  id: string;
  slug: string;
  type: "builtin" | "custom";
  name: string;
  description: string;
  icon: string;
  category: string;
  params: Param[];
  config?: Record<string, unknown>;
  owner_id?: number;
}

// ─── Test panel ─────────────────────────────────────────────────────────────
function TestPanel({ skill, onClose }: { skill: Skill; onClose: () => void }) {
  const [values, setValues] = useState<Record<string, string>>(() => {
    const init: Record<string, string> = {};
    skill.params.forEach((p) => { init[p.name] = p.default ?? ""; });
    return init;
  });
  const [running, setRunning] = useState(false);
  const [output, setOutput] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function run() {
    setRunning(true);
    setOutput(null);
    setError(null);
    try {
      const endpoint = skill.type === "builtin"
        ? `/skills/builtin/${skill.slug}/run/`
        : `/skills/custom/${skill.slug}/run/`;
      const res = await api.post<{ success: boolean; output: string }>(endpoint, { params: values });
      setOutput((res as { output?: string }).output ?? JSON.stringify(res, null, 2));
    } catch (err: unknown) {
      const msg = (err as { response?: { data?: { detail?: string } } })?.response?.data?.detail ?? "Erreur inconnue";
      setError(msg);
    } finally {
      setRunning(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm">
      <div className="bg-orion-surface border border-orion-border rounded-xl w-full max-w-xl mx-4 shadow-2xl flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-orion-border flex-shrink-0">
          <div className="flex items-center gap-3">
            {(() => { const Icon = ICONS[skill.icon] ?? Plug; return <Icon size={18} className="text-orion-accent-light" />; })()}
            <div>
              <p className="text-white font-medium text-sm">{skill.name}</p>
              <p className="text-orion-muted text-xs">{skill.description}</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-white/5 text-orion-muted hover:text-white transition-colors">
            <X size={16} />
          </button>
        </div>

        {/* Params */}
        <div className="px-5 py-4 space-y-3 overflow-y-auto flex-1">
          {skill.params.length === 0 && (
            <p className="text-orion-muted text-sm">Ce skill n'a pas de paramètres.</p>
          )}
          {skill.params.map((p) => (
            <div key={p.name}>
              <label className="block text-xs text-orion-muted mb-1">
                {p.label}{p.required && <span className="text-orion-red ml-0.5">*</span>}
              </label>
              {p.type === "textarea" || p.type === "json" ? (
                <textarea
                  className="w-full bg-orion-bg border border-orion-border rounded-lg px-3 py-2 text-white text-sm resize-none focus:outline-none focus:border-orion-accent/60 font-mono"
                  rows={4}
                  placeholder={p.placeholder ?? ""}
                  value={values[p.name] ?? ""}
                  onChange={(e) => setValues((v) => ({ ...v, [p.name]: e.target.value }))}
                />
              ) : p.type === "select" ? (
                <select
                  className="w-full bg-orion-bg border border-orion-border rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-orion-accent/60"
                  value={values[p.name] ?? p.default ?? ""}
                  onChange={(e) => setValues((v) => ({ ...v, [p.name]: e.target.value }))}
                >
                  {p.options?.map((o) => <option key={o} value={o}>{o}</option>)}
                </select>
              ) : (
                <input
                  className="w-full bg-orion-bg border border-orion-border rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-orion-accent/60"
                  placeholder={p.placeholder ?? p.default ?? ""}
                  value={values[p.name] ?? ""}
                  onChange={(e) => setValues((v) => ({ ...v, [p.name]: e.target.value }))}
                />
              )}
            </div>
          ))}
        </div>

        {/* Output */}
        {(output !== null || error !== null) && (
          <div className="px-5 pb-2 flex-shrink-0">
            <div className={`rounded-lg border p-3 ${error ? "border-orion-red/30 bg-orion-red/5" : "border-orion-green/30 bg-orion-green/5"}`}>
              <div className="flex items-center gap-2 mb-2">
                {error ? <AlertCircle size={14} className="text-orion-red" /> : <CheckCircle2 size={14} className="text-orion-green" />}
                <span className="text-xs font-medium text-orion-muted">{error ? "Erreur" : "Résultat"}</span>
              </div>
              <pre className="text-xs text-white whitespace-pre-wrap break-all overflow-auto max-h-48 font-mono">
                {error ?? output}
              </pre>
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="px-5 py-4 border-t border-orion-border flex justify-end gap-2 flex-shrink-0">
          <button onClick={onClose} className="px-3 py-1.5 text-xs text-orion-muted hover:text-white transition-colors">
            Fermer
          </button>
          <button
            onClick={run}
            disabled={running}
            className="flex items-center gap-2 px-4 py-1.5 bg-orion-accent rounded-lg text-white text-xs font-medium hover:bg-orion-accent/80 disabled:opacity-50 transition-colors"
          >
            {running ? <Loader2 size={14} className="animate-spin" /> : <Play size={14} />}
            Exécuter
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Add custom skill modal ──────────────────────────────────────────────────
function AddSkillModal({ onClose, onCreated }: { onClose: () => void; onCreated: () => void }) {
  const [form, setForm] = useState({
    name: "", description: "", icon: "Plug", category: "custom",
    endpoint_url: "", method: "POST", headers: "", body_template: "",
  });
  const [saving, setSaving] = useState(false);

  async function save() {
    if (!form.name.trim() || !form.endpoint_url.trim()) {
      toast.error("Nom et URL obligatoires");
      return;
    }
    setSaving(true);
    try {
      let headers: Record<string, string> | undefined;
      if (form.headers.trim()) headers = JSON.parse(form.headers);
      await api.post("/skills/", { ...form, headers, body_template: form.body_template || null });
      toast.success("Skill créé");
      onCreated();
      onClose();
    } catch {
      toast.error("Erreur lors de la création");
    } finally {
      setSaving(false);
    }
  }

  const field = (key: keyof typeof form) => ({
    value: form[key],
    onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) =>
      setForm((f) => ({ ...f, [key]: e.target.value })),
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm">
      <div className="bg-orion-surface border border-orion-border rounded-xl w-full max-w-lg mx-4 shadow-2xl">
        <div className="flex items-center justify-between px-5 py-4 border-b border-orion-border">
          <p className="text-white font-medium text-sm">Nouveau skill custom</p>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-white/5 text-orion-muted hover:text-white transition-colors">
            <X size={16} />
          </button>
        </div>
        <div className="px-5 py-4 space-y-3 max-h-[70vh] overflow-y-auto">
          {[
            { label: "Nom *", key: "name" as const, placeholder: "Mon skill" },
            { label: "Description", key: "description" as const, placeholder: "Ce que fait ce skill" },
            { label: "URL de l'endpoint *", key: "endpoint_url" as const, placeholder: "https://api.example.com/..." },
          ].map(({ label, key, placeholder }) => (
            <div key={key}>
              <label className="block text-xs text-orion-muted mb-1">{label}</label>
              <input
                className="w-full bg-orion-bg border border-orion-border rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-orion-accent/60"
                placeholder={placeholder}
                {...field(key)}
              />
            </div>
          ))}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs text-orion-muted mb-1">Méthode HTTP</label>
              <select className="w-full bg-orion-bg border border-orion-border rounded-lg px-3 py-2 text-white text-sm focus:outline-none" {...field("method")}>
                {["GET", "POST", "PUT", "PATCH", "DELETE"].map((m) => <option key={m}>{m}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs text-orion-muted mb-1">Catégorie</label>
              <select className="w-full bg-orion-bg border border-orion-border rounded-lg px-3 py-2 text-white text-sm focus:outline-none" {...field("category")}>
                {["custom", "ai", "web", "communication", "utility"].map((c) => <option key={c}>{c}</option>)}
              </select>
            </div>
          </div>
          <div>
            <label className="block text-xs text-orion-muted mb-1">Headers JSON (optionnel)</label>
            <textarea
              className="w-full bg-orion-bg border border-orion-border rounded-lg px-3 py-2 text-white text-sm font-mono resize-none focus:outline-none focus:border-orion-accent/60"
              rows={2}
              placeholder={`{"Authorization": "Bearer {{token}}"}`}
              {...field("headers")}
            />
          </div>
          <div>
            <label className="block text-xs text-orion-muted mb-1">Body template JSON (optionnel, utilisez {"{{param}}"} comme variables)</label>
            <textarea
              className="w-full bg-orion-bg border border-orion-border rounded-lg px-3 py-2 text-white text-sm font-mono resize-none focus:outline-none focus:border-orion-accent/60"
              rows={3}
              placeholder={`{"query": "{{query}}", "lang": "fr"}`}
              {...field("body_template")}
            />
          </div>
        </div>
        <div className="px-5 py-4 border-t border-orion-border flex justify-end gap-2">
          <button onClick={onClose} className="px-3 py-1.5 text-xs text-orion-muted hover:text-white transition-colors">Annuler</button>
          <button
            onClick={save}
            disabled={saving}
            className="flex items-center gap-2 px-4 py-1.5 bg-orion-accent rounded-lg text-white text-xs font-medium hover:bg-orion-accent/80 disabled:opacity-50 transition-colors"
          >
            {saving ? <Loader2 size={14} className="animate-spin" /> : <Plus size={14} />}
            Créer
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Skill card ──────────────────────────────────────────────────────────────
function SkillCard({ skill, onTest, onDelete, canDelete }: {
  skill: Skill;
  onTest: () => void;
  onDelete: () => void;
  canDelete: boolean;
}) {
  const Icon = ICONS[skill.icon] ?? Plug;
  const catCls = CAT_COLORS[skill.category] ?? CAT_COLORS.custom;

  return (
    <div className="bg-orion-surface border border-orion-border rounded-xl p-4 flex flex-col gap-3 hover:border-orion-accent/30 transition-colors group">
      <div className="flex items-start justify-between gap-2">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-orion-accent/10 flex items-center justify-center flex-shrink-0">
            <Icon size={17} className="text-orion-accent-light" />
          </div>
          <div>
            <p className="text-white text-sm font-medium leading-tight">{skill.name}</p>
            <span className={`text-[10px] px-1.5 py-0.5 rounded-full border font-medium mt-0.5 inline-block ${catCls}`}>
              {skill.category}
            </span>
          </div>
        </div>
        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
          {canDelete && (
            <button
              onClick={onDelete}
              className="p-1.5 rounded-lg hover:bg-orion-red/10 text-orion-muted hover:text-orion-red transition-colors"
              title="Supprimer"
            >
              <Trash2 size={13} />
            </button>
          )}
          <button
            onClick={onTest}
            className="p-1.5 rounded-lg hover:bg-orion-accent/10 text-orion-muted hover:text-orion-accent-light transition-colors"
            title="Tester"
          >
            <Play size={13} />
          </button>
        </div>
      </div>
      <p className="text-orion-muted text-xs leading-relaxed">{skill.description}</p>
      {skill.params.length > 0 && (
        <div className="flex flex-wrap gap-1">
          {skill.params.map((p) => (
            <span key={p.name} className="text-[10px] px-2 py-0.5 rounded-full bg-white/5 text-orion-muted border border-white/8">
              {p.name}{p.required ? "" : "?"}
            </span>
          ))}
        </div>
      )}
      <button
        onClick={onTest}
        className="flex items-center gap-1.5 text-xs text-orion-accent-light/70 hover:text-orion-accent-light transition-colors mt-auto"
      >
        Tester <ChevronRight size={12} />
      </button>
    </div>
  );
}

// ─── Main page ───────────────────────────────────────────────────────────────
export function Skills() {
  const { user } = useAuthStore();
  const [skills, setSkills] = useState<Skill[]>([]);
  const [tab, setTab] = useState<Tab>("all");
  const [testing, setTesting] = useState<Skill | null>(null);
  const [adding, setAdding] = useState(false);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    try {
      const res = await api.get<Skill[]>("/skills/");
      setSkills(res as Skill[]);
    } catch {
      toast.error("Erreur de chargement des skills");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  async function deleteSkill(skill: Skill) {
    if (!confirm(`Supprimer « ${skill.name} » ?`)) return;
    try {
      await api.delete(`/skills/${skill.slug}/`);
      toast.success("Skill supprimé");
      load();
    } catch {
      toast.error("Erreur lors de la suppression");
    }
  }

  const filtered = tab === "all" ? skills : skills.filter((s) => s.category === tab);

  const counts = TABS.reduce((acc, t) => {
    acc[t] = t === "all" ? skills.length : skills.filter((s) => s.category === t).length;
    return acc;
  }, {} as Record<Tab, number>);

  const TAB_LABELS: Record<Tab, string> = {
    all: "Tous", ai: "IA", content: "Contenu", dev: "Dev", seo: "SEO", web: "Web", communication: "Comms", utility: "Utilitaire", custom: "Custom",
  };

  return (
    <div className="flex-1 overflow-y-auto p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl font-semibold text-white">Skills</h1>
          <p className="text-orion-muted text-sm mt-0.5">Capacités réutilisables que vos agents peuvent invoquer</p>
        </div>
        <button
          onClick={() => setAdding(true)}
          className="flex items-center gap-2 px-4 py-2 bg-orion-accent rounded-lg text-white text-sm font-medium hover:bg-orion-accent/80 transition-colors"
        >
          <Plus size={15} /> Nouveau skill
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-3 mb-6">
        {[
          { label: "Built-in", value: skills.filter((s) => s.type === "builtin").length, color: "text-violet-400" },
          { label: "Custom", value: skills.filter((s) => s.type === "custom").length, color: "text-orion-accent-light" },
          { label: "Catégories", value: new Set(skills.map((s) => s.category)).size, color: "text-blue-400" },
          { label: "Total", value: skills.length, color: "text-orion-green" },
        ].map(({ label, value, color }) => (
          <div key={label} className="bg-orion-surface border border-orion-border rounded-xl p-4">
            <p className={`text-2xl font-bold ${color}`}>{value}</p>
            <p className="text-orion-muted text-xs mt-0.5">{label}</p>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 mb-5 border-b border-orion-border pb-3">
        {TABS.map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
              tab === t
                ? "bg-orion-accent/15 text-orion-accent-light border border-orion-accent/25"
                : "text-orion-muted hover:text-white hover:bg-white/5"
            }`}
          >
            {TAB_LABELS[t]}
            <span className={`text-[10px] px-1.5 py-0.5 rounded-full ${tab === t ? "bg-orion-accent/20" : "bg-white/5"}`}>
              {counts[t]}
            </span>
          </button>
        ))}
      </div>

      {/* Grid */}
      {loading ? (
        <div className="flex items-center justify-center h-40">
          <Loader2 size={24} className="animate-spin text-orion-accent" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16 text-orion-muted">
          <Plug size={32} className="mx-auto mb-3 opacity-30" />
          <p>Aucun skill dans cette catégorie</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {filtered.map((skill) => (
            <SkillCard
              key={skill.id}
              skill={skill}
              onTest={() => setTesting(skill)}
              onDelete={() => deleteSkill(skill)}
              canDelete={skill.type === "custom" && (skill.owner_id === user?.id || user?.role === "admin")}
            />
          ))}
        </div>
      )}

      {testing && <TestPanel skill={testing} onClose={() => setTesting(null)} />}
      {adding && <AddSkillModal onClose={() => setAdding(false)} onCreated={load} />}
    </div>
  );
}
