import { useEffect, useState } from "react";
import { Plus, Eye, EyeOff, Trash2, Lock } from "lucide-react";
import { api } from "@/api/client";
import { Header } from "@/components/layout/Header";
import { toast } from "@/components/ui/Toast";

interface Secret {
  id: number;
  name: string;
  created_at: string;
  updated_at: string;
}

export function Vault() {
  const [secrets, setSecrets] = useState<Secret[]>([]);
  const [revealed, setRevealed] = useState<Record<number, string>>({});
  const [name, setName] = useState("");
  const [value, setValue] = useState("");
  const [creating, setCreating] = useState(false);

  async function load() {
    try {
      const data = await api.get<Secret[]>("/vault/");
      setSecrets(data);
    } catch {
      // silently ignore
    }
  }

  useEffect(() => { load(); }, []);

  async function create() {
    if (!name.trim() || !value.trim()) return;
    setCreating(true);
    try {
      await api.post("/vault/", { name, value });
      setName(""); setValue("");
      await load();
      toast.success("Secret créé et chiffré");
    } catch {
      toast.error("Erreur lors de la création");
    } finally {
      setCreating(false);
    }
  }

  async function reveal(id: number) {
    if (revealed[id]) {
      setRevealed((p) => { const n = { ...p }; delete n[id]; return n; });
      return;
    }
    try {
      const data = await api.get<{ value: string }>(`/vault/${id}/reveal`);
      setRevealed((p) => ({ ...p, [id]: data.value }));
    } catch {
      toast.error("Impossible de révéler le secret");
    }
  }

  async function remove(id: number) {
    try {
      await api.delete(`/vault/${id}`);
      setSecrets((p) => p.filter((s) => s.id !== id));
      setRevealed((p) => { const n = { ...p }; delete n[id]; return n; });
      toast.success("Secret supprimé");
    } catch {
      toast.error("Erreur lors de la suppression");
    }
  }

  return (
    <div className="flex-1 flex flex-col">
      <Header title="Coffre-fort (Vault)" />

      <main className="flex-1 p-6 space-y-6 overflow-auto">
        <div className="orion-card p-5">
          <div className="flex items-center gap-2 mb-4">
            <Lock size={16} className="text-orion-accent-light" />
            <h3 className="text-white text-sm font-medium">Nouveau secret (chiffrement AES-256)</h3>
          </div>
          <div className="flex gap-3 flex-wrap">
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Nom de la variable (ex: OPENAI_KEY)"
              className="flex-1 min-w-[200px] px-4 py-2.5 bg-orion-bg border border-orion-border rounded-lg text-sm text-white placeholder-orion-muted focus:outline-none focus:border-orion-accent/50 font-mono"
            />
            <input
              value={value}
              onChange={(e) => setValue(e.target.value)}
              type="password"
              placeholder="Valeur secrète…"
              className="flex-1 min-w-[200px] px-4 py-2.5 bg-orion-bg border border-orion-border rounded-lg text-sm text-white placeholder-orion-muted focus:outline-none focus:border-orion-accent/50"
            />
            <button
              onClick={create}
              disabled={!name.trim() || !value.trim() || creating}
              className="px-4 py-2.5 bg-orion-accent hover:bg-orion-accent/80 disabled:opacity-40 text-white rounded-lg text-sm flex items-center gap-2 transition-colors"
            >
              <Plus size={16} /> Chiffrer
            </button>
          </div>
        </div>

        <div className="orion-card overflow-hidden">
          <div className="px-5 py-4 border-b border-orion-border">
            <h3 className="text-white text-sm font-medium">
              Secrets stockés
              <span className="text-orion-muted ml-2 font-normal">{secrets.length} secret{secrets.length !== 1 ? "s" : ""}</span>
            </h3>
          </div>

          {secrets.length === 0 ? (
            <div className="p-12 text-center text-orion-muted text-sm">Aucun secret stocké</div>
          ) : (
            <div className="divide-y divide-orion-border/50">
              {secrets.map((s) => (
                <div key={s.id} className="px-5 py-4 flex items-center gap-3">
                  <Lock size={14} className="text-orion-muted flex-shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-white text-sm font-mono">{s.name}</p>
                    <p className="text-orion-muted text-xs mt-0.5">
                      {revealed[s.id] ? (
                        <span className="font-mono text-orion-green">{revealed[s.id]}</span>
                      ) : (
                        "••••••••••••"
                      )}
                    </p>
                  </div>
                  <span className="text-orion-muted text-xs hidden sm:block">
                    {new Date(s.updated_at).toLocaleDateString("fr-FR")}
                  </span>
                  <button
                    onClick={() => reveal(s.id)}
                    className="p-1.5 rounded-lg text-orion-muted hover:text-white hover:bg-white/5 transition-colors"
                    title={revealed[s.id] ? "Masquer" : "Révéler"}
                  >
                    {revealed[s.id] ? <EyeOff size={14} /> : <Eye size={14} />}
                  </button>
                  <button
                    onClick={() => remove(s.id)}
                    className="p-1.5 rounded-lg text-orion-muted hover:text-orion-red hover:bg-orion-red/10 transition-colors"
                    title="Supprimer"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
