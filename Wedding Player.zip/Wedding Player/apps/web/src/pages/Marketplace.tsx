import { useEffect, useState } from "react";
import { api } from "@/api/client";
import { toast } from "@/components/ui/Toast";
import { Store, Copy, Tag } from "lucide-react";

interface PublicAgent {
  id: number;
  agent_id: string;
  name: string;
  description: string;
  category: string;
  model: string | null;
  created_at: string;
}

const CATEGORY_COLORS: Record<string, string> = {
  core: "bg-orion-accent/15 text-orion-accent-light",
  seo: "bg-blue-500/15 text-blue-400",
  social: "bg-pink-500/15 text-pink-400",
  marketing: "bg-orange-500/15 text-orange-400",
  dev: "bg-green-500/15 text-green-400",
  data: "bg-purple-500/15 text-purple-400",
};

export function Marketplace() {
  const [agents, setAgents] = useState<PublicAgent[]>([]);
  const [loading, setLoading] = useState(true);
  const [cloning, setCloning] = useState<string | null>(null);
  const [filter, setFilter] = useState("");

  useEffect(() => {
    api.get<PublicAgent[]>("/marketplace/")
      .then(setAgents)
      .catch(() => toast.error("Erreur de chargement du marketplace"))
      .finally(() => setLoading(false));
  }, []);

  async function handleClone(agentId: string, name: string) {
    setCloning(agentId);
    try {
      await api.post(`/marketplace/${agentId}/clone`);
      toast.success(`Agent "${name}" cloné dans vos agents`);
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Erreur lors du clonage");
    } finally {
      setCloning(null);
    }
  }

  const filtered = agents.filter(
    (a) =>
      !filter ||
      a.name.toLowerCase().includes(filter.toLowerCase()) ||
      a.description.toLowerCase().includes(filter.toLowerCase()) ||
      a.category.includes(filter.toLowerCase())
  );

  return (
    <div className="flex-1 overflow-auto p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            <Store size={20} className="text-orion-accent-light" />
            Marketplace d'agents
          </h1>
          <p className="text-orion-muted text-xs mt-0.5">
            Parcourez et clonez des agents partagés par la communauté
          </p>
        </div>
        <input
          className="bg-orion-bg border border-orion-border rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-orion-accent/60 w-52"
          placeholder="Filtrer…"
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
        />
      </div>

      {loading && (
        <div className="text-center py-16 text-orion-muted text-sm">Chargement…</div>
      )}

      {!loading && filtered.length === 0 && (
        <div className="text-center py-16 text-orion-muted">
          <Store size={36} className="mx-auto mb-3 opacity-20" />
          <p className="text-sm">
            {agents.length === 0
              ? "Aucun agent public pour le moment. Publiez le vôtre depuis Mes Agents !"
              : "Aucun résultat pour ce filtre"}
          </p>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
        {filtered.map((a) => (
          <div
            key={a.agent_id}
            className="bg-orion-surface border border-orion-border rounded-xl p-5 flex flex-col gap-3"
          >
            <div className="flex items-start justify-between gap-2">
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-white truncate">{a.name}</p>
                <p className="text-xs text-orion-muted mt-0.5 line-clamp-2">{a.description}</p>
              </div>
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              <span className={`flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full font-medium ${CATEGORY_COLORS[a.category] ?? "bg-orion-muted/20 text-orion-muted"}`}>
                <Tag size={9} /> {a.category}
              </span>
              {a.model && (
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-orion-bg text-orion-muted">
                  {a.model}
                </span>
              )}
            </div>

            <button
              onClick={() => handleClone(a.agent_id, a.name)}
              disabled={cloning === a.agent_id}
              className="mt-auto flex items-center justify-center gap-2 w-full py-2 bg-orion-accent/10 hover:bg-orion-accent/20 border border-orion-accent/25 text-orion-accent-light text-xs font-medium rounded-lg transition-colors disabled:opacity-50"
            >
              <Copy size={12} />
              {cloning === a.agent_id ? "Clonage…" : "Cloner dans mes agents"}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
