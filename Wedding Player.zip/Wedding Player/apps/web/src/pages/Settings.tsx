import { useState, useEffect, useCallback } from "react";
import { Plus, Trash2, ToggleLeft, ToggleRight, Loader2, Webhook, DatabaseZap, Download, Upload, CheckCircle, Mail, Palette, Bell, BellOff, BellRing, Cpu, Save } from "lucide-react";
import { usePushNotifications } from "@/hooks/usePushNotifications";
import { useThemeStore, ACCENT_PRESETS } from "@/store/useThemeStore";
import { Header } from "@/components/layout/Header";
import { useAuthStore } from "@/store/useAuthStore";
import { toast } from "@/components/ui/Toast";

interface WebhookEntry {
  id: number;
  name: string;
  url: string;
  events: string[];
  is_active: boolean;
  created_at: string;
}

const ALL_EVENTS = ["task.completed", "task.failed", "workflow.completed", "workflow.failed"];

async function whReq<T>(path: string, options: RequestInit = {}): Promise<T> {
  const token = (() => { try { const s = localStorage.getItem("orion-auth"); return s ? JSON.parse(s)?.state?.token : null; } catch { return null; } })();
  const res = await fetch(`/api/webhooks${path}`, {
    ...options,
    headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}), ...options.headers },
  });
  if (!res.ok) {
    const b = await res.json().catch(() => ({}));
    throw new Error(b.detail ?? `HTTP ${res.status}`);
  }
  if (res.status === 204) return undefined as T;
  return res.json();
}

const ROLE_LABEL: Record<string, string> = {
  admin: "Administrateur",
  user: "Utilisateur",
  readonly: "Lecture seule",
};

const ROLE_COLOR: Record<string, string> = {
  admin: "text-orion-accent-light bg-orion-accent/20",
  user: "text-orion-green bg-orion-green/15",
  readonly: "text-orion-muted bg-orion-muted/20",
};

function sysReq<T>(path: string, options: RequestInit = {}): Promise<T> {
  const token = (() => { try { const s = localStorage.getItem("orion-auth"); return s ? JSON.parse(s)?.state?.token : null; } catch { return null; } })();
  return fetch(`/api/system${path}`, {
    ...options,
    headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}), ...options.headers },
  }).then(async (res) => {
    if (!res.ok) { const b = await res.json().catch(() => ({})); throw new Error(b.detail ?? `HTTP ${res.status}`); }
    return res.json();
  });
}

export function Settings() {
  const { user } = useAuthStore();
  const push = usePushNotifications();
  const { accent, setAccent } = useThemeStore();
  const [webhooks, setWebhooks] = useState<WebhookEntry[]>([]);
  const [loadingWh, setLoadingWh] = useState(true);
  const [whName, setWhName] = useState("");
  const [whUrl, setWhUrl] = useState("");
  const [whEvents, setWhEvents] = useState<string[]>(["task.completed", "task.failed"]);
  const [creating, setCreating] = useState(false);

  // Import state
  const [importing, setImporting] = useState(false);
  const [importResult, setImportResult] = useState<{ message: string; total: number } | null>(null);

  // SMTP state
  const [smtpStatus, setSmtpStatus] = useState<{ configured: boolean; host: string | null; notify_on: string } | null>(null);
  const [testingSmtp, setTestingSmtp] = useState(false);

  // Data retention state
  const [retentionDays, setRetentionDays] = useState(0);
  const [retentionInput, setRetentionInput] = useState("0");
  const [savingRetention, setSavingRetention] = useState(false);
  const [purging, setPurging] = useState(false);
  const [purgeResult, setPurgeResult] = useState<string | null>(null);

  // LLM config state
  interface LLMProviderInfo { available: boolean; models: string[]; current_model: string }
  interface LLMConfig {
    active: { provider: string; model: string | null; status: string };
    override: { llm_provider?: string; ollama_model?: string; openai_model?: string; anthropic_model?: string };
    env_provider: string;
    providers: { ollama: LLMProviderInfo; openai: LLMProviderInfo; anthropic: LLMProviderInfo };
  }
  const [llmConfig, setLlmConfig] = useState<LLMConfig | null>(null);
  const [llmProvider, setLlmProvider] = useState("auto");
  const [llmModel, setLlmModel] = useState("");
  const [savingLlm, setSavingLlm] = useState(false);

  const loadWebhooks = useCallback(async () => {
    const data = await whReq<WebhookEntry[]>("/").catch(() => []);
    setWebhooks(data);
    setLoadingWh(false);
  }, []);

  const loadLlmConfig = useCallback(async () => {
    const cfg = await sysReq<LLMConfig>("/llm-config").catch(() => null);
    if (!cfg) return;
    setLlmConfig(cfg);
    const currentProvider = cfg.override.llm_provider ?? cfg.env_provider;
    setLlmProvider(currentProvider);
    const modelKey = `${currentProvider === "auto" ? "ollama" : currentProvider}_model` as keyof typeof cfg.override;
    setLlmModel((cfg.override[modelKey] as string | undefined) ?? cfg.providers[currentProvider === "auto" ? "ollama" : currentProvider as keyof typeof cfg.providers]?.current_model ?? "");
  }, []);

  async function saveLlmConfig() {
    if (!llmConfig) return;
    setSavingLlm(true);
    try {
      const body: Record<string, string | null> = { provider: llmProvider };
      if (llmProvider === "ollama" || llmProvider === "auto") body.ollama_model = llmModel || null;
      if (llmProvider === "openai") body.openai_model = llmModel || null;
      if (llmProvider === "anthropic") body.anthropic_model = llmModel || null;
      await sysReq("/llm-config", { method: "PUT", body: JSON.stringify(body) });
      toast.success("Fournisseur LLM mis à jour");
      await loadLlmConfig();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Erreur");
    } finally {
      setSavingLlm(false);
    }
  }

  useEffect(() => { loadWebhooks(); }, [loadWebhooks]);
  useEffect(() => { loadLlmConfig(); }, [loadLlmConfig]);

  useEffect(() => {
    if (user?.role === "admin") {
      sysReq<{ configured: boolean; host: string | null; notify_on: string }>("/smtp/status")
        .then(setSmtpStatus)
        .catch(() => {});
    }
  }, [user]);

  async function sendSmtpTest() {
    setTestingSmtp(true);
    try {
      await sysReq("/smtp/test", { method: "POST" });
      toast.success("Email de test envoyé !");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Erreur SMTP");
    } finally {
      setTestingSmtp(false);
    }
  }

  useEffect(() => {
    sysReq<{ days: number }>("/retention")
      .then((r) => { setRetentionDays(r.days); setRetentionInput(String(r.days)); })
      .catch(() => {});
  }, []);

  async function saveRetention() {
    const days = Math.max(0, parseInt(retentionInput, 10) || 0);
    setSavingRetention(true);
    try {
      const r = await sysReq<{ days: number }>("/retention", {
        method: "POST",
        body: JSON.stringify({ days }),
      });
      setRetentionDays(r.days);
      setRetentionInput(String(r.days));
      toast.success(r.days > 0 ? `Rétention enregistrée : ${r.days} jour(s)` : "Rétention désactivée");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Erreur");
    } finally {
      setSavingRetention(false);
    }
  }

  async function purgeNow() {
    const days = Math.max(1, parseInt(retentionInput, 10) || 30);
    if (!confirm(`Supprimer définitivement les tâches antérieures à ${days} jour(s) ?`)) return;
    setPurging(true);
    setPurgeResult(null);
    try {
      const r = await sysReq<{ deleted: number; message: string }>("/purge", {
        method: "POST",
        body: JSON.stringify({ days }),
      });
      setPurgeResult(r.message);
      toast.success(r.message);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Erreur");
    } finally {
      setPurging(false);
    }
  }

  function toggleEvent(ev: string) {
    setWhEvents((prev) =>
      prev.includes(ev) ? prev.filter((e) => e !== ev) : [...prev, ev]
    );
  }

  async function handleCreateWebhook(e: React.FormEvent) {
    e.preventDefault();
    if (!whName.trim() || !whUrl.trim() || whEvents.length === 0) return;
    setCreating(true);
    try {
      await whReq("/", {
        method: "POST",
        body: JSON.stringify({ name: whName.trim(), url: whUrl.trim(), events: whEvents }),
      });
      toast.success("Webhook créé");
      setWhName(""); setWhUrl(""); setWhEvents(["task.completed", "task.failed"]);
      loadWebhooks();
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Erreur création webhook");
    } finally {
      setCreating(false);
    }
  }

  async function toggleWebhook(id: number) {
    await whReq(`/${id}/toggle`, { method: "PATCH" }).catch(() => {});
    loadWebhooks();
  }

  async function deleteWebhook(id: number, name: string) {
    if (!confirm(`Supprimer le webhook "${name}" ?`)) return;
    await whReq(`/${id}`, { method: "DELETE" }).catch(() => {});
    toast.success("Webhook supprimé");
    loadWebhooks();
  }

  return (
    <div className="flex-1 flex flex-col">
      <Header title="Paramètres" />
      <main className="flex-1 p-6 overflow-auto">
        <div className="max-w-2xl space-y-6">

          {/* Mon compte */}
          <div className="orion-card p-5">
            <h3 className="text-white text-sm font-medium mb-4">Mon compte</h3>
            {user && (
              <div className="space-y-3">
                <div className="flex items-center justify-between py-2.5 border-b border-orion-border">
                  <span className="text-orion-muted text-xs uppercase tracking-wider">Nom d'utilisateur</span>
                  <span className="text-white text-sm font-medium">{user.username}</span>
                </div>
                <div className="flex items-center justify-between py-2.5 border-b border-orion-border">
                  <span className="text-orion-muted text-xs uppercase tracking-wider">Email</span>
                  <span className="text-white text-sm">{user.email}</span>
                </div>
                <div className="flex items-center justify-between py-2.5">
                  <span className="text-orion-muted text-xs uppercase tracking-wider">Rôle</span>
                  <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${ROLE_COLOR[user.role] ?? "text-orion-muted bg-orion-muted/20"}`}>
                    {ROLE_LABEL[user.role] ?? user.role}
                  </span>
                </div>
              </div>
            )}
          </div>

          {/* Notifications push */}
          <div className="orion-card p-5">
            <div className="flex items-center gap-2 mb-3">
              <Bell size={15} className="text-orion-accent" />
              <h3 className="text-white text-sm font-medium">Notifications push navigateur</h3>
            </div>
            <p className="text-orion-muted text-xs mb-4">
              Recevez une popup desktop quand une tâche se termine, même si l'onglet est en arrière-plan.
            </p>
            {push.state === "unsupported" && (
              <p className="text-xs text-orion-muted/60 flex items-center gap-2"><BellOff size={12} /> Non supporté par ce navigateur</p>
            )}
            {push.state === "denied" && (
              <p className="text-xs text-orion-red flex items-center gap-2"><BellOff size={12} /> Permission refusée — réinitialisez les permissions du site dans les paramètres du navigateur</p>
            )}
            {push.state === "loading" && (
              <div className="flex items-center gap-2 text-xs text-orion-muted"><Loader2 size={12} className="animate-spin" /> Chargement…</div>
            )}
            {(push.state === "subscribed" || push.state === "unsubscribed") && (
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2 text-xs">
                  {push.state === "subscribed"
                    ? <><BellRing size={13} className="text-orion-green" /><span className="text-orion-green">Activées</span></>
                    : <><BellOff size={13} className="text-orion-muted" /><span className="text-orion-muted">Désactivées</span></>}
                </div>
                <button
                  onClick={push.state === "subscribed" ? push.unsubscribe : push.subscribe}
                  className={`text-xs px-3 py-1.5 rounded-lg border transition-colors ${
                    push.state === "subscribed"
                      ? "border-orion-red/30 text-orion-red hover:bg-orion-red/10"
                      : "border-orion-accent/40 text-orion-accent-light hover:bg-orion-accent/10"
                  }`}
                >
                  {push.state === "subscribed" ? "Désactiver" : "Activer les notifications"}
                </button>
              </div>
            )}
          </div>

          {/* Thème personnalisé */}
          <div className="orion-card p-5">
            <div className="flex items-center gap-2 mb-4">
              <Palette size={15} className="text-orion-accent" />
              <h3 className="text-white text-sm font-medium">Couleur d'accent</h3>
            </div>
            <p className="text-orion-muted text-xs mb-4">Personnalisez la couleur principale de l'interface. Persistée automatiquement.</p>
            <div className="flex flex-wrap gap-3">
              {ACCENT_PRESETS.map((p) => {
                const isActive = accent === p.rgb;
                return (
                  <button
                    key={p.name}
                    onClick={() => setAccent(p.rgb, p.light)}
                    title={p.name}
                    className={`flex flex-col items-center gap-1.5 p-2 rounded-xl border-2 transition-all ${
                      isActive ? "border-white/40 scale-105" : "border-transparent hover:border-white/20"
                    }`}
                  >
                    <div
                      className="w-8 h-8 rounded-full ring-2 ring-white/10"
                      style={{ backgroundColor: `rgb(${p.rgb})` }}
                    />
                    <span className="text-[10px] text-orion-muted">{p.name}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Webhooks */}
          <div className="orion-card p-5">
            <div className="flex items-center gap-2 mb-4">
              <Webhook size={15} className="text-orion-accent" />
              <h3 className="text-white text-sm font-medium">Webhooks de notification</h3>
            </div>
            <p className="text-orion-muted text-xs mb-5">
              ORION envoie un POST JSON à vos URLs lors des événements sélectionnés.
            </p>

            {/* Form */}
            <form onSubmit={handleCreateWebhook} className="space-y-3 mb-6">
              <div className="flex gap-3">
                <input
                  value={whName}
                  onChange={(e) => setWhName(e.target.value)}
                  placeholder="Nom (ex: Slack #alerts)"
                  required
                  className="flex-1 bg-orion-bg border border-orion-border rounded-lg px-3 py-2 text-sm text-white placeholder-orion-muted/50 focus:outline-none focus:border-orion-accent/50"
                />
                <input
                  value={whUrl}
                  onChange={(e) => setWhUrl(e.target.value)}
                  placeholder="https://hooks.slack.com/…"
                  required
                  type="url"
                  className="flex-1 bg-orion-bg border border-orion-border rounded-lg px-3 py-2 text-sm text-white placeholder-orion-muted/50 focus:outline-none focus:border-orion-accent/50"
                />
              </div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-orion-muted text-xs">Événements :</span>
                {ALL_EVENTS.map((ev) => (
                  <button
                    key={ev}
                    type="button"
                    onClick={() => toggleEvent(ev)}
                    className={`text-xs px-2 py-0.5 rounded-full border transition-colors ${
                      whEvents.includes(ev)
                        ? "border-orion-accent/50 bg-orion-accent/15 text-orion-accent-light"
                        : "border-orion-border text-orion-muted hover:text-white"
                    }`}
                  >
                    {ev}
                  </button>
                ))}
                <button
                  type="submit"
                  disabled={creating || !whName.trim() || !whUrl.trim() || whEvents.length === 0}
                  className="ml-auto flex items-center gap-1.5 px-3 py-1.5 text-xs bg-orion-accent hover:bg-orion-accent/80 disabled:opacity-50 text-white rounded-lg transition-colors font-medium"
                >
                  {creating ? <Loader2 size={11} className="animate-spin" /> : <Plus size={11} />}
                  Ajouter
                </button>
              </div>
            </form>

            {/* List */}
            {loadingWh ? (
              <div className="flex justify-center py-4"><Loader2 size={18} className="animate-spin text-orion-accent" /></div>
            ) : webhooks.length === 0 ? (
              <p className="text-orion-muted text-sm text-center py-4">Aucun webhook configuré</p>
            ) : (
              <div className="space-y-2">
                {webhooks.map((wh) => (
                  <div key={wh.id} className={`flex items-center gap-3 px-4 py-3 rounded-xl border transition-colors ${
                    wh.is_active ? "bg-orion-bg border-orion-border" : "bg-orion-bg/50 border-orion-border/40 opacity-60"
                  }`}>
                    <div className="flex-1 min-w-0">
                      <p className="text-white text-sm font-medium truncate">{wh.name}</p>
                      <p className="text-orion-muted text-[11px] font-mono truncate">{wh.url}</p>
                      <div className="flex gap-1 mt-1 flex-wrap">
                        {wh.events.map((ev) => (
                          <span key={ev} className="text-[10px] px-1.5 py-0.5 rounded-full bg-orion-accent/10 text-orion-accent-light">{ev}</span>
                        ))}
                      </div>
                    </div>
                    <button
                      onClick={() => toggleWebhook(wh.id)}
                      title={wh.is_active ? "Désactiver" : "Activer"}
                      className="text-orion-muted hover:text-white transition-colors flex-shrink-0"
                    >
                      {wh.is_active
                        ? <ToggleRight size={18} className="text-orion-green" />
                        : <ToggleLeft size={18} />}
                    </button>
                    <button
                      onClick={() => deleteWebhook(wh.id, wh.name)}
                      className="p-1.5 rounded-lg hover:bg-orion-red/10 text-orion-muted hover:text-orion-red transition-colors flex-shrink-0"
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* LLM Provider */}
          <div className="orion-card p-5">
            <div className="flex items-center gap-2 mb-4">
              <Cpu size={15} className="text-orion-accent" />
              <h3 className="text-white text-sm font-medium">Fournisseur LLM</h3>
              {llmConfig && (
                <span className={`ml-auto text-xs px-2 py-0.5 rounded-full font-mono ${
                  llmConfig.active.status === "active" || llmConfig.active.status === "configured"
                    ? "bg-orion-green/15 text-orion-green"
                    : llmConfig.active.status === "fallback"
                    ? "bg-orion-gold/15 text-orion-gold"
                    : "bg-orion-red/15 text-orion-red"
                }`}>
                  {llmConfig.active.provider} · {llmConfig.active.status}
                </span>
              )}
            </div>

            {!llmConfig ? (
              <div className="flex justify-center py-4"><Loader2 size={18} className="animate-spin text-orion-accent" /></div>
            ) : (
              <div className="space-y-4">
                {/* Provider selector */}
                <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                  {(["auto", "ollama", "openai", "anthropic"] as const).map((p) => {
                    const info = p !== "auto" ? llmConfig.providers[p] : null;
                    const available = p === "auto" || (info?.available ?? false);
                    return (
                      <button
                        key={p}
                        onClick={() => {
                          setLlmProvider(p);
                          const target = p === "auto" ? "ollama" : p;
                          setLlmModel(llmConfig.providers[target as keyof typeof llmConfig.providers]?.current_model ?? "");
                        }}
                        className={`relative flex flex-col items-center gap-1.5 px-3 py-3 rounded-lg border text-xs font-medium transition-colors ${
                          llmProvider === p
                            ? "border-orion-accent bg-orion-accent/10 text-white"
                            : "border-orion-border text-orion-muted hover:border-orion-border/80 hover:text-white"
                        } ${!available ? "opacity-40 cursor-not-allowed" : "cursor-pointer"}`}
                        disabled={!available}
                      >
                        <span className="uppercase tracking-wider">{p}</span>
                        {info && (
                          <span className={`text-[10px] ${info.available ? "text-orion-green" : "text-orion-muted"}`}>
                            {info.available ? "disponible" : "non configuré"}
                          </span>
                        )}
                        {p === "auto" && (
                          <span className="text-[10px] text-orion-muted">détection auto</span>
                        )}
                      </button>
                    );
                  })}
                </div>

                {/* Model selector */}
                {llmProvider !== "auto" && (
                  <div>
                    <label className="block text-orion-muted text-xs uppercase tracking-wider mb-1.5">Modèle</label>
                    {llmProvider === "ollama" ? (
                      <select
                        value={llmModel}
                        onChange={(e) => setLlmModel(e.target.value)}
                        className="w-full px-3 py-2.5 bg-orion-bg border border-orion-border rounded-lg text-sm text-white focus:outline-none focus:border-orion-accent/50"
                      >
                        {(llmConfig.providers.ollama.models.length > 0
                          ? llmConfig.providers.ollama.models
                          : [llmConfig.providers.ollama.current_model]
                        ).map((m) => <option key={m} value={m}>{m}</option>)}
                      </select>
                    ) : (
                      <select
                        value={llmModel}
                        onChange={(e) => setLlmModel(e.target.value)}
                        className="w-full px-3 py-2.5 bg-orion-bg border border-orion-border rounded-lg text-sm text-white focus:outline-none focus:border-orion-accent/50"
                      >
                        {(llmProvider === "openai" ? llmConfig.providers.openai : llmConfig.providers.anthropic).models.map((m) => (
                          <option key={m} value={m}>{m}</option>
                        ))}
                      </select>
                    )}
                  </div>
                )}

                {/* Active model info when auto */}
                {llmProvider === "auto" && llmConfig.active.model && (
                  <p className="text-xs text-orion-muted">
                    Modèle actif : <span className="text-white font-mono">{llmConfig.active.model}</span>
                  </p>
                )}

                {user?.role === "admin" && (
                  <button
                    onClick={saveLlmConfig}
                    disabled={savingLlm}
                    className="flex items-center gap-2 px-4 py-2 bg-orion-accent hover:bg-orion-accent/80 disabled:opacity-50 text-white rounded-lg text-sm font-medium transition-colors"
                  >
                    {savingLlm ? <Loader2 size={13} className="animate-spin" /> : <Save size={13} />}
                    Enregistrer
                  </button>
                )}
              </div>
            )}
          </div>

          {/* Notifications par email */}
          {user?.role === "admin" && (
            <div className="orion-card p-5">
              <div className="flex items-center gap-2 mb-4">
                <Mail size={15} className="text-orion-accent" />
                <h3 className="text-white text-sm font-medium">Notifications par email (SMTP)</h3>
              </div>
              {smtpStatus === null ? (
                <div className="flex justify-center py-4"><Loader2 size={18} className="animate-spin text-orion-accent" /></div>
              ) : smtpStatus.configured ? (
                <div className="space-y-3">
                  <div className="flex items-center gap-2 text-xs text-orion-green">
                    <CheckCircle size={12} /> SMTP configuré — {smtpStatus.host}
                  </div>
                  <p className="text-orion-muted text-xs">
                    Événements actifs : <span className="text-white font-mono">{smtpStatus.notify_on || "aucun"}</span>
                  </p>
                  <p className="text-orion-muted text-xs">
                    Pour modifier les événements, ajoutez <code className="text-white">NOTIFY_ON=task_failed,task_completed</code> dans votre <code className="text-white">.env</code>.
                  </p>
                  <button
                    onClick={sendSmtpTest}
                    disabled={testingSmtp}
                    className="flex items-center gap-2 px-4 py-2 bg-orion-accent/10 hover:bg-orion-accent/20 border border-orion-accent/30 text-orion-accent-light rounded-lg text-sm font-medium transition-colors disabled:opacity-50"
                  >
                    {testingSmtp ? <Loader2 size={13} className="animate-spin" /> : <Mail size={13} />}
                    Envoyer un email de test
                  </button>
                </div>
              ) : (
                <div className="space-y-2">
                  <p className="text-orion-muted text-xs">SMTP non configuré.</p>
                  <p className="text-orion-muted text-xs">
                    Ajoutez dans votre <code className="text-white">.env</code> :{" "}
                    <code className="text-orion-accent-light">SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASSWORD, SMTP_FROM</code>
                  </p>
                </div>
              )}
            </div>
          )}

          {/* Rétention des données */}
          <div className="orion-card p-5">
            <div className="flex items-center gap-2 mb-4">
              <DatabaseZap size={15} className="text-orion-accent" />
              <h3 className="text-white text-sm font-medium">Rétention des données</h3>
            </div>
            <p className="text-orion-muted text-xs mb-5">
              Supprimez automatiquement les tâches et leurs logs après N jours.
              Saisissez <strong className="text-white">0</strong> pour désactiver.
            </p>

            <div className="flex items-end gap-3 mb-4">
              <div className="flex-1">
                <label className="block text-orion-muted text-xs uppercase tracking-wider mb-1.5">
                  Durée de rétention (jours)
                </label>
                <input
                  type="number"
                  min={0}
                  max={3650}
                  value={retentionInput}
                  onChange={(e) => setRetentionInput(e.target.value)}
                  className="w-full px-3 py-2.5 bg-orion-bg border border-orion-border rounded-lg text-sm text-white focus:outline-none focus:border-orion-accent/50"
                  placeholder="ex: 30"
                />
              </div>
              <button
                onClick={saveRetention}
                disabled={savingRetention}
                className="px-4 py-2.5 bg-orion-accent hover:bg-orion-accent/80 disabled:opacity-50 text-white rounded-lg text-sm font-medium transition-colors flex items-center gap-1.5"
              >
                {savingRetention ? <Loader2 size={13} className="animate-spin" /> : null}
                Enregistrer
              </button>
            </div>

            {retentionDays > 0 && (
              <p className="text-orion-green text-xs mb-4">
                ✓ Auto-suppression active — tâches &gt; {retentionDays} jour(s) effacées au prochain cycle
              </p>
            )}

            <div className="border-t border-orion-border/50 pt-4">
              <p className="text-orion-muted text-xs mb-3">
                Purge manuelle immédiate : supprime toutes les tâches antérieures au nombre de jours saisi.
              </p>
              <button
                onClick={purgeNow}
                disabled={purging || !(parseInt(retentionInput, 10) > 0)}
                className="flex items-center gap-2 px-4 py-2 bg-orion-red/10 hover:bg-orion-red/20 border border-orion-red/30 hover:border-orion-red/60 disabled:opacity-40 text-orion-red rounded-lg text-sm font-medium transition-colors"
              >
                {purging ? <Loader2 size={13} className="animate-spin" /> : <Trash2 size={13} />}
                Purger maintenant
              </button>
              {purgeResult && (
                <p className="text-orion-muted text-xs mt-2 font-mono">{purgeResult}</p>
              )}
            </div>
          </div>

          {/* Export complet */}
          <div className="orion-card p-5">
            <h3 className="text-white text-sm font-medium mb-1">Export complet</h3>
            <p className="text-orion-muted text-xs mb-4">
              Téléchargez toutes vos données (tâches, agents personnalisés, workflows, noms des secrets) en une archive ZIP.
            </p>
            <button
              onClick={() => {
                const token = (() => { try { const s = localStorage.getItem("orion-auth"); return s ? JSON.parse(s)?.state?.token : null; } catch { return null; } })();
                const a = document.createElement("a");
                a.href = `/api/export/download.zip`;
                if (token) {
                  fetch("/api/export/download.zip", { headers: { Authorization: `Bearer ${token}` } })
                    .then((r) => r.blob())
                    .then((blob) => {
                      a.href = URL.createObjectURL(blob);
                      a.download = `orion_export_${new Date().toISOString().slice(0,10)}.zip`;
                      a.click();
                    });
                }
              }}
              className="flex items-center gap-2 px-4 py-2 bg-orion-accent/10 hover:bg-orion-accent/20 border border-orion-accent/30 text-orion-accent-light rounded-lg text-sm font-medium transition-colors"
            >
              <Download size={14} /> Télécharger l'archive ZIP
            </button>
          </div>

          {/* Import ZIP */}
          <div className="orion-card p-5 space-y-3">
            <h3 className="text-white text-sm font-medium">Import de données</h3>
            <p className="text-orion-muted text-xs">
              Importez une archive ZIP issue d'un export ORION. Les doublons (même titre + agent) sont ignorés automatiquement.
            </p>
            <label className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium border transition-colors cursor-pointer ${
              importing
                ? "opacity-40 cursor-not-allowed border-orion-border text-orion-muted"
                : "border-orion-border text-orion-muted hover:text-white hover:border-orion-accent/50"
            }`}>
              {importing ? <Loader2 size={14} className="animate-spin" /> : <Upload size={14} />}
              {importing ? "Import en cours…" : "Importer un fichier ZIP"}
              <input
                type="file"
                accept=".zip"
                className="sr-only"
                disabled={importing}
                onChange={async (e) => {
                  const f = e.target.files?.[0];
                  if (!f) return;
                  setImporting(true);
                  setImportResult(null);
                  try {
                    const token = (() => { try { const s = localStorage.getItem("orion-auth"); return s ? JSON.parse(s)?.state?.token : null; } catch { return null; } })();
                    const fd = new FormData();
                    fd.append("file", f);
                    const res = await fetch("/api/export/import", {
                      method: "POST",
                      headers: token ? { Authorization: `Bearer ${token}` } : {},
                      body: fd,
                    });
                    const data = await res.json();
                    if (!res.ok) throw new Error(data.detail || "Erreur import");
                    setImportResult({ message: data.message, total: data.total });
                  } catch (err) {
                    toast.error(err instanceof Error ? err.message : "Erreur import");
                  } finally {
                    setImporting(false);
                    e.target.value = "";
                  }
                }}
              />
            </label>
            {importResult && (
              <div className="flex items-center gap-2 text-xs text-orion-green">
                <CheckCircle size={12} /> {importResult.message}
              </div>
            )}
          </div>

          {/* À propos */}
          <div className="orion-card p-5">
            <h3 className="text-white text-sm font-medium mb-1">À propos d'ORION AI</h3>
            <p className="text-orion-muted text-sm">Version 1.0.0 — 32 agents spécialisés</p>
            <p className="text-orion-muted text-xs mt-2">FastAPI + Ollama + React + SQLite</p>
          </div>

        </div>
      </main>
    </div>
  );
}
