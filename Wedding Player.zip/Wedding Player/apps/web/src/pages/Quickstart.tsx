import { useState } from "react";
import { CheckCircle, Bot, Zap, GitBranch, Key, ArrowRight, ExternalLink } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Header } from "@/components/layout/Header";

const STEPS = [
  {
    id: "agents",
    icon: Bot,
    title: "Découvrez les agents",
    desc: "ORION dispose de 32 agents spécialisés. Explorez-les et choisissez ceux qui correspondent à vos besoins.",
    action: "/agents",
    actionLabel: "Voir les agents",
    tip: "Utilisez l'auto-router pour laisser ORION choisir le meilleur agent automatiquement.",
  },
  {
    id: "task",
    icon: Zap,
    title: "Lancez votre première tâche",
    desc: "Créez une tâche et observez comment ORION la traite en temps réel.",
    action: "/tasks",
    actionLabel: "Créer une tâche",
    tip: "Exemple : \"Analyse le marché des assistants IA en 2025\" ou \"Rédige un email de prospection\".",
  },
  {
    id: "workflow",
    icon: GitBranch,
    title: "Créez un workflow multi-agents",
    desc: "Enchaînez plusieurs agents pour automatiser des processus complexes.",
    action: "/workflows",
    actionLabel: "Créer un workflow",
    tip: "Combinez recherche → analyse → rédaction en un seul pipeline automatique.",
  },
  {
    id: "api",
    icon: Key,
    title: "Intégrez via l'API",
    desc: "Générez une clé API pour intégrer ORION à vos propres applications.",
    action: "/api-keys",
    actionLabel: "Générer une clé API",
    tip: "L'API REST est documentée sur /docs (Swagger) et /redoc.",
  },
];

const LS_KEY = "orion-onboarding-done";

export function useOnboardingDone() {
  return localStorage.getItem(LS_KEY) === "true";
}

export function Quickstart() {
  const [completed, setCompleted] = useState<Set<string>>(new Set());
  const navigate = useNavigate();

  function markDone(id: string) {
    setCompleted((prev) => new Set([...prev, id]));
  }

  function finish() {
    localStorage.setItem(LS_KEY, "true");
    navigate("/");
  }

  const allDone = STEPS.every((s) => completed.has(s.id));

  return (
    <div className="flex-1 flex flex-col">
      <Header title="Démarrage rapide" />

      <main className="flex-1 p-6 overflow-auto">
        <div className="max-w-2xl mx-auto space-y-4">
          <div className="text-center mb-8">
            <div className="w-16 h-16 rounded-2xl bg-orion-accent/10 border border-orion-accent/25 flex items-center justify-center mx-auto mb-4">
              <span className="text-2xl font-bold text-orion-accent">O</span>
            </div>
            <h2 className="text-white text-xl font-semibold">Bienvenue sur ORION AI</h2>
            <p className="text-orion-muted text-sm mt-2">Suivez ces étapes pour tirer le meilleur parti de la plateforme.</p>
            <div className="mt-3 flex items-center justify-center gap-2">
              <div className="h-1.5 w-32 bg-orion-border rounded-full overflow-hidden">
                <div
                  className="h-full bg-orion-accent rounded-full transition-all duration-500"
                  style={{ width: `${(completed.size / STEPS.length) * 100}%` }}
                />
              </div>
              <span className="text-orion-muted text-xs">{completed.size}/{STEPS.length}</span>
            </div>
          </div>

          {STEPS.map((step) => {
            const done = completed.has(step.id);
            const Icon = step.icon;
            return (
              <div
                key={step.id}
                className={`orion-card p-5 transition-all ${done ? "opacity-60" : ""}`}
              >
                <div className="flex items-start gap-4">
                  <div className={`flex-shrink-0 w-10 h-10 rounded-xl flex items-center justify-center ${done ? "bg-orion-green/15" : "bg-orion-accent/10"}`}>
                    {done ? <CheckCircle size={20} className="text-orion-green" /> : <Icon size={20} className="text-orion-accent" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="text-white text-sm font-medium">{step.title}</h3>
                    <p className="text-orion-muted text-xs mt-1">{step.desc}</p>
                    <div className="mt-2 flex items-start gap-1.5">
                      <span className="text-orion-gold text-[10px] mt-0.5">💡</span>
                      <p className="text-orion-muted/70 text-[11px]">{step.tip}</p>
                    </div>
                    <div className="mt-3 flex gap-2">
                      <button
                        onClick={() => { markDone(step.id); navigate(step.action); }}
                        className="flex items-center gap-1.5 px-3 py-1.5 bg-orion-accent/15 hover:bg-orion-accent/25 text-orion-accent-light rounded-lg text-xs transition-colors"
                      >
                        <ExternalLink size={11} /> {step.actionLabel}
                      </button>
                      {!done && (
                        <button
                          onClick={() => markDone(step.id)}
                          className="px-3 py-1.5 text-xs text-orion-muted hover:text-white border border-orion-border rounded-lg hover:bg-white/5 transition-colors"
                        >
                          Marquer comme fait
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}

          <div className="flex justify-center pt-4">
            <button
              onClick={finish}
              className={`flex items-center gap-2 px-6 py-2.5 rounded-xl text-sm font-medium transition-colors ${
                allDone
                  ? "bg-orion-green hover:bg-orion-green/80 text-white"
                  : "bg-orion-accent hover:bg-orion-accent/80 text-white"
              }`}
            >
              {allDone ? <CheckCircle size={16} /> : <ArrowRight size={16} />}
              {allDone ? "Terminer le guide" : "Passer cette étape"}
            </button>
          </div>
        </div>
      </main>
    </div>
  );
}
