import { useState, useEffect } from "react";
import { api } from "@/api/client";

function urlBase64ToUint8Array(base64String: string) {
  const padding = "=".repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");
  const raw = atob(base64);
  return Uint8Array.from([...raw].map((c) => c.charCodeAt(0)));
}

type PushState = "unsupported" | "denied" | "subscribed" | "unsubscribed" | "loading";

export function usePushNotifications() {
  const [state, setState] = useState<PushState>("loading");
  const [registration, setRegistration] = useState<ServiceWorkerRegistration | null>(null);

  useEffect(() => {
    if (!("serviceWorker" in navigator) || !("PushManager" in window)) {
      setState("unsupported");
      return;
    }
    navigator.serviceWorker.register("/sw.js").then((reg) => {
      setRegistration(reg);
      reg.pushManager.getSubscription().then((sub) => {
        if (Notification.permission === "denied") { setState("denied"); return; }
        setState(sub ? "subscribed" : "unsubscribed");
      });
    }).catch(() => setState("unsupported"));
  }, []);

  async function subscribe() {
    if (!registration) return;
    setState("loading");
    try {
      const { public_key } = await api.get<{ public_key: string }>("/push/vapid-public-key");
      const permission = await Notification.requestPermission();
      if (permission !== "granted") { setState("denied"); return; }

      const sub = await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(public_key),
      });
      const keys = sub.toJSON().keys ?? {};
      try {
        await api.post("/push/subscribe", {
          endpoint: sub.endpoint,
          p256dh: keys.p256dh ?? "",
          auth: keys.auth ?? "",
        });
        setState("subscribed");
      } catch {
        await sub.unsubscribe();
        setState("unsubscribed");
      }
    } catch {
      setState("unsubscribed");
    }
  }

  async function unsubscribe() {
    if (!registration) return;
    setState("loading");
    try {
      const sub = await registration.pushManager.getSubscription();
      if (sub) {
        const keys = sub.toJSON().keys ?? {};
        await api.post("/push/unsubscribe", {
          endpoint: sub.endpoint,
          p256dh: keys.p256dh ?? "",
          auth: keys.auth ?? "",
        });
        await sub.unsubscribe();
      }
      setState("unsubscribed");
    } catch {
      setState("unsubscribed");
    }
  }

  return { state, subscribe, unsubscribe };
}
