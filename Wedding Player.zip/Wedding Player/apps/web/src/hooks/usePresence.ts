import { useState, useEffect, useRef } from "react";
import { useAuthStore } from "@/store/useAuthStore";

export interface PresenceUser {
  user_id: number;
  username: string;
}

export function usePresence() {
  const { token, user } = useAuthStore();
  const [users, setUsers] = useState<PresenceUser[]>([]);
  const wsRef = useRef<WebSocket | null>(null);

  useEffect(() => {
    if (!token) return;
    const proto = window.location.protocol === "https:" ? "wss" : "ws";
    const host = window.location.host;
    const ws = new WebSocket(`${proto}://${host}/api/ws/events?token=${token}`);
    wsRef.current = ws;

    ws.onmessage = (e) => {
      try {
        const { event, data } = JSON.parse(e.data);
        if (event === "user.joined") {
          setUsers((prev) => {
            if (prev.some((u) => u.user_id === data.user_id)) return prev;
            return [...prev, { user_id: data.user_id, username: data.username }];
          });
        } else if (event === "user.left") {
          setUsers((prev) => prev.filter((u) => u.user_id !== data.user_id));
        }
      } catch {
        // ignore parse errors
      }
    };

    // Fetch current presence on mount
    const authHeader = `Bearer ${token}`;
    fetch("/api/system/presence", { headers: { Authorization: authHeader } })
      .then((r) => r.json())
      .then((data) => setUsers(data.users ?? []))
      .catch(() => {});

    return () => { ws.close(); };
  }, [token]);

  // Exclude self from the displayed list
  const others = users.filter((u) => u.user_id !== user?.id);
  return { users: others, total: users.length };
}
