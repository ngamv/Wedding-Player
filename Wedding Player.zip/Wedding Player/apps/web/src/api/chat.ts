const BASE = "/api/chat";

function getToken(): string | null {
  try { const s = localStorage.getItem("orion-auth"); return s ? JSON.parse(s)?.state?.token : null; } catch { return null; }
}

async function req<T>(path: string, options: RequestInit = {}): Promise<T> {
  const token = getToken();
  const res = await fetch(`${BASE}${path}`, {
    ...options,
    headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}), ...options.headers },
  });
  if (!res.ok) { const b = await res.json().catch(() => ({})); throw new Error(b.detail ?? `HTTP ${res.status}`); }
  if (res.status === 204) return undefined as T;
  return res.json();
}

export interface ChatSession {
  id: number;
  title: string;
  created_at: string;
  updated_at: string;
}

export interface ChatMsg {
  id: number;
  role: "user" | "assistant";
  content: string;
  agent_name: string | null;
  created_at: string;
}

export const chatApi = {
  listSessions: (): Promise<ChatSession[]> => req("/sessions"),
  createSession: (): Promise<ChatSession> => req("/sessions", { method: "POST" }),
  getMessages: (sessionId: number): Promise<ChatMsg[]> => req(`/sessions/${sessionId}/messages`),
  sendMessage: (sessionId: number, content: string, agentId?: string): Promise<ChatMsg> =>
    req(`/sessions/${sessionId}/messages`, {
      method: "POST",
      body: JSON.stringify({ content, agent_id: agentId ?? null }),
    }),
  deleteSession: (sessionId: number): Promise<void> => req(`/sessions/${sessionId}`, { method: "DELETE" }),
};

export function createWsConnection(
  onEvent: (event: string, data: unknown) => void,
): () => void {
  let ws: WebSocket | null = null;
  let closed = false;

  function connect() {
    const token = getToken();
    if (!token) return;
    ws = new WebSocket(`ws://${location.host}/ws/events?token=${token}`);
    ws.onmessage = (e) => {
      try {
        const { event, data } = JSON.parse(e.data);
        onEvent(event, data);
      } catch { /* ignore */ }
    };
    ws.onclose = () => {
      if (!closed) setTimeout(connect, 3000);
    };
  }

  connect();
  return () => { closed = true; ws?.close(); };
}
