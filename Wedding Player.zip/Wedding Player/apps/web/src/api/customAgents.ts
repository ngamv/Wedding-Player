const BASE = "/api/custom-agents";

export interface CustomAgent {
  id: number;
  agent_id: string;
  name: string;
  description: string;
  category: string;
  system_prompt: string;
  model: string | null;
  rate_limit: number | null;
}

export interface CustomAgentBody {
  name: string;
  description: string;
  category: string;
  system_prompt: string;
  model?: string;
  rate_limit?: number | null;
}

async function req<T>(path: string, options: RequestInit = {}): Promise<T> {
  const res = await fetch(`${BASE}${path}`, {
    headers: { "Content-Type": "application/json", ...options.headers },
    ...options,
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.detail ?? `HTTP ${res.status}`);
  }
  if (res.status === 204) return undefined as T;
  return res.json();
}

export const customAgentsApi = {
  list: (): Promise<CustomAgent[]> => req("/"),
  get: (id: string): Promise<CustomAgent> => req(`/${id}`),
  create: (body: CustomAgentBody): Promise<CustomAgent> =>
    req("/", { method: "POST", body: JSON.stringify(body) }),
  update: (id: string, body: CustomAgentBody): Promise<CustomAgent> =>
    req(`/${id}`, { method: "PUT", body: JSON.stringify(body) }),
  delete: (id: string): Promise<void> => req(`/${id}`, { method: "DELETE" }),
  run: (id: string, task: string): Promise<{ result: string; agent: string }> =>
    req(`/${id}/run`, { method: "POST", body: JSON.stringify({ task }) }),
};
