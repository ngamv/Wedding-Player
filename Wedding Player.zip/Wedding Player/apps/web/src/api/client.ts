const BASE = "/api";

export function getToken(): string | null {
  try {
    const stored = localStorage.getItem("orion-auth");
    if (!stored) return null;
    return JSON.parse(stored)?.state?.token ?? null;
  } catch {
    return null;
  }
}

export function authHeaders(): HeadersInit {
  const token = getToken();
  return token ? { Authorization: `Bearer ${token}` } : {};
}

async function req<T>(path: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE}${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...authHeaders(),
      ...options?.headers,
    },
  });
  const limit = Number(res.headers.get("X-RateLimit-Limit"));
  const remaining = Number(res.headers.get("X-RateLimit-Remaining"));
  const used = Number(res.headers.get("X-RateLimit-Used"));
  if (limit > 0) {
    import("@/store/useRateLimitStore").then(({ useRateLimitStore }) => {
      useRateLimitStore.getState().update(used, remaining, limit);
    });
  }
  if (!res.ok) {
    let detail = `${res.status} ${res.statusText}`;
    try {
      const body = await res.json();
      if (body?.detail) detail = body.detail;
    } catch { /* ignore */ }
    throw new Error(detail);
  }
  if (res.status === 204) return undefined as T;
  return res.json();
}

export const api = {
  get: <T = unknown>(path: string) => req<T>(path),
  post: <T = unknown>(path: string, body?: unknown) =>
    req<T>(path, { method: "POST", body: JSON.stringify(body) }),
  put: <T = unknown>(path: string, body?: unknown) =>
    req<T>(path, { method: "PUT", body: JSON.stringify(body) }),
  patch: <T = unknown>(path: string, body?: unknown) =>
    req<T>(path, { method: "PATCH", body: JSON.stringify(body) }),
  delete: <T = unknown>(path: string) => req<T>(path, { method: "DELETE" }),
  getAgents: () => req<Agent[]>("/agents/"),
  runAgent: (task: string, agent_id?: string, context?: Record<string, unknown>) =>
    req<RunResult>("/agents/run", {
      method: "POST",
      body: JSON.stringify({ task, agent_id, context }),
    }),
  getTasks: (params?: { search?: string; status?: string; agent_id?: string; tag?: string; page?: number; page_size?: number }) => {
    const q = new URLSearchParams();
    if (params?.search) q.set("search", params.search);
    if (params?.status) q.set("status", params.status);
    if (params?.agent_id) q.set("agent_id", params.agent_id);
    if (params?.tag) q.set("tag", params.tag);
    if (params?.page) q.set("page", String(params.page));
    if (params?.page_size) q.set("page_size", String(params.page_size));
    const qs = q.toString();
    return req<TasksPage>(`/tasks/${qs ? `?${qs}` : ""}`);
  },
  createTask: (title: string, agent_id?: string) =>
    req<Task>("/tasks/", { method: "POST", body: JSON.stringify({ title, agent_id }) }),
  getMemory: (agent_id?: string) =>
    req<Memory[]>(`/memory/${agent_id ? `?agent_id=${agent_id}` : ""}`),
  getHealth: () => req<Health>("/system/health"),
  getStats: () => req<Stats>("/system/stats"),
  getMetrics: () => req<AgentMetric[]>("/system/metrics"),
  getAnalytics: () => req<Analytics>("/system/analytics"),
  getTools: () => req<{ tools: Tool[] }>("/system/tools"),
  adminStats: () => req<AdminStats>("/admin/stats"),
  adminUsers: () => req<AdminUser[]>("/admin/users"),
  adminSetRole: (userId: number, role: string) =>
    req(`/admin/users/${userId}/role`, { method: "PATCH", body: JSON.stringify({ role }) }),
};

export type Agent = { id: string; name: string; description: string; category: string };
export type Task = { id: number; title: string; agent_id: string; status: string; created_at: string; output_data?: unknown; tags?: string[] };
export type TasksPage = { tasks: Task[]; total: number; page: number; page_size: number; pages: number };
export type AdminUser = { id: number; username: string; email: string; role: string; is_active: boolean; created_at: string; task_count: number };
export type AdminStats = { total_users: number; total_tasks: number; tasks_today: number; total_runs: number; global_success_rate: number };
export type Analytics = { daily: { day: string; date: string; tasks: number }[]; top_agents: { agent_id: string; runs: number }[]; total_tasks: number; success_rate: number };
export type Tool = { name: string; doc: string };
export type Memory = { id: number; agent_id: string; key: string; value: string; created_at: string };
export type RunResult = { routed_to: string; agent_name: string; result: string; task: string };
export type Health = { status: string; ollama: boolean; models: string[]; agents_count: number };
export type Stats = { total_agents: number; by_category: Record<string, number>; agent_ids: string[] };
export type AgentMetric = {
  agent_id: string;
  total_runs: number;
  success_count: number;
  fail_count: number;
  success_rate: number;
  avg_time_ms: number;
  last_run: string | null;
};
