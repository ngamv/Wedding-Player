const BASE = "/api/workflows";

export interface WorkflowStep {
  agent_id: string;
  label: string;
  pass_output: boolean;
}

export interface Workflow {
  id: number;
  name: string;
  description: string;
  steps: WorkflowStep[];
  created_at: string;
}

export interface StepResult {
  step: number;
  agent_id: string;
  label: string;
  result: string;
  error: string | null;
}

export interface WorkflowRun {
  id: number;
  workflow_id: number;
  status: string;
  input_task: string;
  steps_results: StepResult[];
  created_at: string;
  completed_at: string | null;
}

function getToken(): string | null {
  try { const s = localStorage.getItem("orion-auth"); return s ? JSON.parse(s)?.state?.token : null; } catch { return null; }
}

async function req<T>(path: string, options: RequestInit = {}): Promise<T> {
  const token = getToken();
  const res = await fetch(`${BASE}${path}`, {
    ...options,
    headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}), ...options.headers },
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.detail ?? `HTTP ${res.status}`);
  }
  if (res.status === 204) return undefined as T;
  return res.json();
}

export const workflowsApi = {
  list: (): Promise<Workflow[]> => req("/"),
  get: (id: number): Promise<Workflow> => req(`/${id}`),
  create: (body: { name: string; description: string; steps: WorkflowStep[] }): Promise<Workflow> =>
    req("/", { method: "POST", body: JSON.stringify(body) }),
  update: (id: number, body: { name: string; description: string; steps: WorkflowStep[] }): Promise<Workflow> =>
    req(`/${id}`, { method: "PUT", body: JSON.stringify(body) }),
  delete: (id: number): Promise<void> => req(`/${id}`, { method: "DELETE" }),
  run: (id: number, task: string): Promise<WorkflowRun> =>
    req(`/${id}/run`, { method: "POST", body: JSON.stringify({ task }) }),
  runs: (id: number): Promise<WorkflowRun[]> => req(`/${id}/runs`),
  exportWorkflow: (id: number): Promise<unknown> => req(`/${id}/export`),
  importWorkflow: (data: unknown): Promise<Workflow> => req("/import", { method: "POST", body: JSON.stringify(data) }),
};
