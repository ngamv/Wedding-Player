const BASE = "/api";

export interface User {
  id: number;
  username: string;
  email: string;
  role: "admin" | "user" | "readonly";
  is_active: boolean;
}

export interface TokenOut {
  access_token: string;
  token_type: string;
  user: User;
}

async function request<T>(path: string, options: RequestInit): Promise<T> {
  const res = await fetch(`${BASE}${path}`, options);
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.detail ?? `HTTP ${res.status}`);
  }
  return res.json();
}

export const authApi = {
  login: (username: string, password: string): Promise<TokenOut> => {
    const form = new URLSearchParams({ username, password });
    return request("/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: form.toString(),
    });
  },

  register: (username: string, email: string, password: string): Promise<TokenOut> =>
    request("/auth/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, email, password }),
    }),

  me: (token: string): Promise<User> =>
    request("/auth/me", {
      headers: { Authorization: `Bearer ${token}` },
    }),
};
